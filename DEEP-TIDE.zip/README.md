# DEEP LUCK

Pick a stake. Dive. Cash out before trouble catches you.

Every safe dive raises your return. A deeper dive can find strange sea creatures and lucky treasures, or wipe out the current haul. Explore five changing sea zones and collect discoveries in the field notes.

Choose 10, 25, 50, or MAX shells, then tap **DIVE**. After a safe find, tap **GO DEEPER** or **CASH OUT**.

All shells are play points with no cash value. Standalone HTML; no external assets or libraries.
