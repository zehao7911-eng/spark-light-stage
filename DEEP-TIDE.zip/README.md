# DEEP LUCK — The Last Little Dive

A small, phone-friendly underwater push-your-luck game. Pick a shell stake, drop in, then decide whether to dive deeper or surface with your haul.

Each safe dive raises the return and the danger. Meet odd sea characters, find lucky treasures, and travel through five changing deep-sea zones. Your field notes and deepest descent are saved on your device.

## How to play

1. Pick a stake: 10, 25, 50, or all available shells.
2. Select **Drop In** to begin.
3. After each safe find, choose **Dive Deeper** to risk your haul for a larger return, or **Surface** to bank it.
4. Collect discoveries and see how deep you can go.

All shells are play points with no cash value. The game is a standalone HTML file and uses no external assets or libraries.
