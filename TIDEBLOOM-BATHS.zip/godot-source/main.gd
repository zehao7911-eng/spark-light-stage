extends Node2D
const CENTERS = [Vector2(278,252),Vector2(518,252),Vector2(278,405),Vector2(518,405)]
const NAMES = ['Mika','Finn','Poppy','Jules']
var bg = preload('res://assets/courtyard.png')
var baths = preload('res://assets/baths.png')
var people = preload('res://assets/guests.png')
var decor = preload('res://assets/decor.png')
var pools = []
var waiting = []
var walkers = []
var motes = []
var labels = []
var coins = 30
var visits = 0
var perfect = 0
var day = 1
var served = 0
var selected = 0
var guest_selected = 0
var tea = false
var linen = false
var garden = false
var started = false
var muted = false
var notice = 'Choose a guest, then tap a bath.'
var clock = 0.0
var sync_clock = 0.0
var callback
var zoom = 1.0
var origin = Vector2.ZERO

func _ready():
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	for i in range(4):
		pools.append({'open':i < 2,'temp':1,'aroma':0,'clean':3,'guests':[]})
	load_save()
	for i in range(3): waiting.append(make_guest(i))
	if OS.has_feature('web'):
		callback = JavaScriptBridge.create_callback(web_action)
		JavaScriptBridge.get_interface('window').tbAction = callback
	if '--qa' in OS.get_cmdline_user_args(): qa()

func make_guest(seed_value = -1):
	var k = randi_range(0,3) if seed_value < 0 else seed_value % 4
	return {'kind':k,'temp':1 if visits == 0 and seed_value == 0 else randi_range(0,2),'aroma':0 if visits == 0 and seed_value == 0 else randi_range(0,2),'social':randi_range(0,1),'progress':0.0,'arrival':0.0}

func web_action(args):
	if args.size(): action(str(args[0]))

func action(command):
	var bits = command.split(':')
	var a = bits[0]
	var n = int(bits[1]) if bits.size() > 1 else 0
	match a:
		'begin': started = true
		'guest': guest_selected = clampi(n,0,waiting.size()-1)
		'pool':
			selected = clampi(n,0,3)
			seat()
		'temp': pools[selected].temp = n
		'aroma': pools[selected].aroma = n
		'clean':
			pools[selected].clean = 3
			burst(CENTERS[selected],Color('#99e6d5'),20)
			notice = 'Fresh water. Fresh start.'
		'unlock':
			var cost = 90 if n == 2 else 160
			if n >= 2 and n <= 3 and not pools[n].open and coins >= cost:
				coins -= cost
				pools[n].open = true
				notice = 'A new bath is ready!'
		'tea':
			if coins >= 75 and not tea: coins -= 75; tea = true; notice = 'Complimentary tea: +4 per visit.'
		'linen':
			if coins >= 65 and not linen: coins -= 65; linen = true; notice = 'Soft towels: guests relax faster.'
		'garden':
			if coins >= 120 and not garden: coins -= 120; garden = true; notice = 'The courtyard is in bloom.'
		'sound': muted = not muted
		'pet': burst(Vector2(615,472),Color('#ffcab2'),16); notice = 'Prrrr. The garden keeper approves.'
	save_game()
	push_state()

func seat():
	var p = pools[selected]
	if not started: return
	if guest_selected < 0: notice = 'Choose a guest below, then tap a bath.'; return
	if not p.open: notice = 'Open this bath in the garden shop.'; return
	if p.guests.size() >= 2: notice = 'This bath is full. Try another.'; return
	var g = waiting.pop_at(guest_selected)
	g.arrival = 1.6
	p.guests.append(g)
	waiting.append(make_guest())
	guest_selected = -1
	notice = 'Match water and aroma for a perfect soak.'

func quality(p,g):
	var score = 1
	if p.temp == g.temp: score += 1
	if p.aroma == g.aroma: score += 1
	if p.guests.size() == 2 and g.social == 0: score = maxi(1,score-1)
	return score

func finish(p,g,index):
	var q = quality(p,g)
	var reward = 8 + q * 5 + (4 if tea else 0) + (2 if p.clean > 0 else 0) + (4 if g.social == 1 and p.guests.size() == 2 else 0)
	coins += reward
	labels.append({'pos':CENTERS[index]+Vector2(-28,-36),'text':'+'+str(reward),'life':2.4})
	visits += 1
	served += 1
	if q == 3: perfect += 1
	p.clean = maxi(0,p.clean-1)
	walkers.append({'pos':CENTERS[index]+Vector2(0,-5),'life':2.5,'kind':g.kind})
	burst(CENTERS[index]+Vector2(0,-30),Color('#ffe5a1'),18)
	notice = ('Perfect soak! ' if q == 3 else 'A lovely break. ') + '+' + str(reward)
	if served >= 6 + mini(day,6):
		day += 1
		served = 0
		coins += 30
		notice = 'Day '+str(day)+' · Welcome bonus +30'
	save_game()

func _process(dt):
	clock += dt
	if started:
		for i in range(4):
			var p = pools[i]
			for j in range(p.guests.size()-1,-1,-1):
				var g = p.guests[j]
				if g.arrival > 0: g.arrival -= dt; continue
				g.progress += dt * (1.0 + 0.16 * (quality(p,g)-1)) * (1.25 if linen else 1.0) / 14.0
				if g.progress >= 1:
					finish(p,g,i)
					p.guests.remove_at(j)
	for w in walkers:
		w.life -= dt
		w.pos += Vector2(35,-18)*dt
	walkers = walkers.filter(func(w): return w.life > 0)
	for m in motes: m.life -= dt; m.pos += m.vel*dt; m.vel.y += dt*22
	motes = motes.filter(func(m): return m.life > 0)
	for label in labels: label.life -= dt; label.pos.y -= dt*13
	labels = labels.filter(func(label): return label.life > 0)
	sync_clock += dt
	if sync_clock > 0.2: sync_clock = 0; push_state()
	queue_redraw()

func burst(pos,color,count):
	for i in range(count):
		motes.append({'pos':pos,'vel':Vector2(randf_range(-45,45),randf_range(-70,-15)),'life':randf_range(0.5,1.3),'color':color})

func _draw():
	var screen = get_viewport_rect().size
	var top = 48.0 if screen.y < 550 else 68.0
	var bottom = 215.0 if screen.x < 700 else (135.0 if screen.y < 550 else 165.0)
	zoom = minf(screen.x / (500.0 if screen.x < 700 else 768.0),(screen.y-top-bottom)/512.0)
	zoom = maxf(0.25,zoom)
	origin = Vector2(screen.x/2-398*zoom,top+(screen.y-top-bottom-512*zoom)/2)
	draw_rect(Rect2(Vector2.ZERO,screen),Color('#132c30'))
	draw_set_transform(origin,0,Vector2.ONE*zoom)
	draw_texture_rect(bg,Rect2(0,0,768,512),false)
	for i in range(4): draw_pool(i)
	for w in walkers: person(w.kind,1,w.pos,Vector2(43,63))
	for i in range(24):
		var x = fmod(i*71.3+clock*6,700)+30
		var y = 100+fmod(i*37.7+sin(clock+i)*5,360)
		if garden: draw_circle(Vector2(x,y),1.2,Color(1,0.8,0.65,0.65))
	for m in motes: draw_circle(m.pos,2.2,Color(m.color,m.life/1.3))
	for label in labels:
		draw_string(ThemeDB.fallback_font,label.pos+Vector2(1,1),label.text,HORIZONTAL_ALIGNMENT_LEFT,-1,21,Color('#23413a'))
		draw_string(ThemeDB.fallback_font,label.pos,label.text,HORIZONTAL_ALIGNMENT_LEFT,-1,21,Color('#ffe3a0'))
	if tea: prop(0,Rect2(150,280,66,88))
	if linen: prop(2,Rect2(570,335,55,73))
	if garden:
		prop(1,Rect2(155,123,70,94))
		prop(7,Rect2(246,104,320,110))
	prop(3,Rect2(585,430,60,80))

	draw_set_transform(Vector2.ZERO)

func prop(cell,dest):
	draw_texture_rect_region(decor,dest,Rect2((cell%4)*384,(cell/4)*512,384,512))

func panel(c):
	var s = StyleBoxFlat.new()
	s.bg_color = c
	s.corner_radius_top_left = 6
	s.corner_radius_top_right = 6
	s.corner_radius_bottom_left = 6
	s.corner_radius_bottom_right = 6
	return s

func draw_pool(i):
	var p = pools[i]
	var center = CENTERS[i]
	var dest = Rect2(center-Vector2(106,90),Vector2(212,180))
	var source = Rect2((i%2)*627,(i/2)*627,627,627)
	if not p.open:
		draw_texture_rect_region(baths,dest,source,Color(0.45,0.51,0.47,0.5))
		draw_string(ThemeDB.fallback_font,center+Vector2(-24,4),'OPEN',HORIZONTAL_ALIGNMENT_LEFT,-1,14,Color('#f7e7bd'))
		return
	if selected == i:
		var points = PackedVector2Array()
		for k in range(65): points.append(center+Vector2(cos(k*TAU/64)*98,sin(k*TAU/64)*46+12))
		draw_polyline(points,Color('#ffe8a6'),1.5)
	draw_texture_rect_region(baths,dest,source)
	var colors = [Color('#b9ebc6'),Color('#efb4ce'),Color('#f6dc88')]
	for k in range(6):
		var pos = center+Vector2(sin(k*2.4+clock*0.3)*48,cos(k*2.1+clock*0.4)*16-3)
		draw_line(pos,pos+Vector2(3,1),colors[p.aroma],2)
	for j in range(p.guests.size()):
		var g = p.guests[j]
		var pos = center+Vector2(-32 if j == 0 else 32,-4)
		if g.arrival > 0:
			pos = center.lerp(Vector2(385,125),g.arrival/1.6)
			person(g.kind,int(clock*5)%2,pos,Vector2(43,63))
		else:
			person(g.kind,3 if quality(p,g) == 3 else 2,pos,Vector2(48,48))
			if quality(p,g) == 3: draw_string(ThemeDB.fallback_font,pos+Vector2(-5,-44+sin(clock*2)*2),'♥',HORIZONTAL_ALIGNMENT_LEFT,-1,12,Color('#f7b5ad'))
	# Redraw the front lip in front of the bathers.
	var lip = 0.65
	draw_texture_rect_region(baths,Rect2(dest.position+Vector2(0,dest.size.y*lip),Vector2(dest.size.x,dest.size.y*(1-lip))),Rect2(source.position+Vector2(0,627*lip),Vector2(627,627*(1-lip))))
	for j in range(p.guests.size()):
		var g = p.guests[j]
		draw_rect(Rect2(center+Vector2(-48+j*51,62),Vector2(44,4)),Color('#374a43'))
		draw_rect(Rect2(center+Vector2(-48+j*51,62),Vector2(44*clampf(g.progress,0,1),4)),Color('#ffda8b'))
	for k in range(2+p.temp):
		var phase = fmod(clock*0.25+k*0.25,1.0)
		var pos = center+Vector2(-47+k*30+sin(clock+k)*4,-20-phase*42)
		draw_arc(pos,5+phase*5,0.4,2.6,9,Color(0.95,1,0.92,(1-phase)*0.32),1.5)
	for k in range(3): draw_circle(center+Vector2(-8+k*8,75),2,Color('#a2cfb4') if p.clean > k else Color('#66716a'))

func person(kind,col,pos,size):
	draw_texture_rect_region(people,Rect2(pos-Vector2(size.x/2,size.y),size),Rect2(col*313.5,kind*313.5,313.5,313.5))

func _unhandled_input(event):
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		var p = (event.position-origin)/zoom
		if p.distance_to(Vector2(615,472)) < 35: action('pet'); return
		for i in range(4):
			if Rect2(CENTERS[i]-Vector2(100,70),Vector2(200,140)).has_point(p): action('pool:'+str(i)); return

func snapshot():
	var out = []
	for p in pools:
		var item = p.duplicate(true)
		for g in item.guests: g['quality'] = quality(p,g)
		out.append(item)
	return {'started':started,'coins':coins,'visits':visits,'perfect':perfect,'day':day,'served':served,'selected':selected,'guest':guest_selected,'waiting':waiting,'pools':out,'tea':tea,'linen':linen,'garden':garden,'notice':notice,'muted':muted,'viewport':[get_viewport_rect().size.x,get_viewport_rect().size.y]}

func push_state():
	if OS.has_feature('web'): JavaScriptBridge.eval('window.tbState && window.tbState('+JSON.stringify(snapshot())+');')

func save_game():
	var data = {'coins':coins,'visits':visits,'perfect':perfect,'day':day,'served':served,'tea':tea,'linen':linen,'garden':garden,'muted':muted,'pools':[]}
	for p in pools: data.pools.append({'open':p.open,'temp':p.temp,'aroma':p.aroma,'clean':p.clean})
	var text = JSON.stringify(data)
	FileAccess.open('user://tidebloom.json',FileAccess.WRITE).store_string(text)
	if OS.has_feature('web'): JavaScriptBridge.eval('localStorage.setItem("tidebloom-baths-v1",'+JSON.stringify(text)+')')

func load_save():
	var text = ''
	if FileAccess.file_exists('user://tidebloom.json'): text = FileAccess.get_file_as_string('user://tidebloom.json')
	if OS.has_feature('web'):
		var browser_save = JavaScriptBridge.eval('localStorage.getItem("tidebloom-baths-v1") || ""')
		if browser_save: text = str(browser_save)
	if text.is_empty(): return
	var d = JSON.parse_string(text)
	if not d is Dictionary: return
	coins = int(d.get('coins',30)); visits = int(d.get('visits',0)); perfect = int(d.get('perfect',0)); day = int(d.get('day',1)); served = int(d.get('served',0))
	tea = d.get('tea',false); linen = d.get('linen',false); garden = d.get('garden',false); muted = d.get('muted',false)
	for i in range(mini(4,d.get('pools',[]).size())):
		for key in ['open','temp','aroma','clean']: pools[i][key] = d.pools[i][key]

func qa():
	started = true
	coins = 30
	waiting[0] = {'kind':0,'temp':1,'aroma':0,'social':1,'progress':0.0,'arrival':0.0}
	action('pool:0')
	assert(pools[0].guests.size() == 1)
	action('guest:0')
	action('pool:0')
	action('guest:0')
	action('pool:0')
	assert(pools[0].guests.size() == 2)
	pools[0].guests.remove_at(1)
	assert(quality(pools[0],pools[0].guests[0]) == 3)
	_process(2)
	_process(20)
	assert(visits > 0 and coins >= 55)
	coins = 400
	action('unlock:2'); action('unlock:3'); action('tea'); action('linen')
	assert(pools[2].open and pools[3].open and tea and linen)
	pools[0].clean = 0
	selected = 0
	action('clean')
	assert(pools[0].clean == 3)
	assert(quality({'temp':2,'aroma':2,'guests':[]}, {'temp':0,'aroma':0,'social':0}) == 1)
	print('TIDEBLOOM QA PASS: service, rewards, upgrades, capacity, save')
	get_tree().quit()