REEF REVIVAL`r`nOpen index.html in any modern desktop or mobile browser. Drag or swipe to clean the reef. No installation or network connection is needed.
