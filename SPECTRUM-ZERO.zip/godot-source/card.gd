extends Button

var symbol='ring'
var tint=Color('#77d7cb')
var top=''
var bottom=''
var small=false
var ring_index=0
var level=0
var owned=false
var locked=false
var selected=false
var fill=0.0
var kind='icon'
var base_font: Font = ThemeDB.fallback_font

func _ready():
	mouse_default_cursor_shape=Control.CURSOR_POINTING_HAND
	for key in ['normal','hover','pressed','disabled','focus']:
		var style=StyleBoxFlat.new()
		style.bg_color=Color('#142132') if key=='normal' else Color('#1e3345')
		if key=='disabled':style.bg_color=Color('#101a28')
		if key=='pressed':style.bg_color=Color('#28495a')
		style.border_color=Color('#2b3c50') if key!='focus' else Color('#93d4d0')
		style.set_border_width_all(1)
		style.set_corner_radius_all(26 if kind=='core' else 12 if kind!='ring' else 9)
		add_theme_stylebox_override(key,style)
	focus_mode=Control.FOCUS_ALL

func label(s,pos,size_,color_):
	draw_string(base_font,pos,str(s),HORIZONTAL_ALIGNMENT_LEFT,-1,size_,color_)
func centered(s,y,size_,color_):
	var width=base_font.get_string_size(str(s),HORIZONTAL_ALIGNMENT_LEFT,-1,size_).x
	label(s,Vector2((size.x-width)/2,y),size_,color_)
func stroke(a,b,c,w=2.0):draw_line(a,b,c,w,true)
func glyph(name,center,scale_,color_):
	var c=center;var s=scale_
	if name in ['ring','cycle','max','prestige','infinity','burst','star','module','auto','help','settings','sound','mute','pause','play','close','check','generator','clock','chart','export','reset','motion','lock','tap']:
		match name:
			'ring','cycle':
				draw_arc(c,10*s,-PI/2,PI*1.28,28,color_,2*s,true)
				draw_circle(c+Vector2(-6,8)*s,2.2*s,color_)
			'max':
				for x in [-5,3]:stroke(c+Vector2(x-4,-7)*s,c+Vector2(x+3,0)*s,color_,2*s);stroke(c+Vector2(x+3,0)*s,c+Vector2(x-4,7)*s,color_,2*s)
			'prestige':
				var points=PackedVector2Array([c+Vector2(0,-12)*s,c+Vector2(10,6)*s,c+Vector2(0,12)*s,c+Vector2(-10,6)*s,c+Vector2(0,-12)*s])
				draw_polyline(points,color_,2*s,true);stroke(c+Vector2(0,-12)*s,c+Vector2(0,12)*s,color_,1*s);stroke(c+Vector2(-10,6)*s,c+Vector2(10,6)*s,color_,1*s)
			'infinity':
				var p=PackedVector2Array()
				for j in range(65):
					var a=j*TAU/64;p.append(c+Vector2(cos(a)*12,sin(2*a)*6)*s)
				draw_polyline(p,color_,2.2*s,true)
			'burst','star':
				var p=PackedVector2Array()
				for j in range(9):
					var a=j*TAU/8-PI/2;var r=12 if j%2==0 else 4;p.append(c+Vector2(cos(a),sin(a))*r*s)
				draw_polyline(p,color_,2*s,true)
			'module','generator':
				draw_rect(Rect2(c-Vector2(8,8)*s,Vector2(16,16)*s),color_,false,2*s);draw_circle(c,3*s,color_)
				for j in [-1,1]:
					for x in [-4,4]:stroke(c+Vector2(x,j*8)*s,c+Vector2(x,j*12)*s,color_,2*s);stroke(c+Vector2(j*8,x)*s,c+Vector2(j*12,x)*s,color_,2*s)
			'auto':
				glyph('cycle',c,s,color_);stroke(c+Vector2(6,-10)*s,c+Vector2(6,-3)*s,color_,2*s);stroke(c+Vector2(6,-3)*s,c+Vector2(12,-4)*s,color_,2*s)
			'settings','motion':
				for j in range(3):
					var x=(j-1)*7;stroke(c+Vector2(x,-10)*s,c+Vector2(x,10)*s,color_,2*s);draw_circle(c+Vector2(x,[-4,4,-2][j])*s,3*s,color_)
			'help':draw_arc(c+Vector2(0,-3)*s,6*s,-PI,PI/2,18,color_,2*s,true);stroke(c+Vector2(0,3)*s,c+Vector2(0,6)*s,color_,2*s);draw_circle(c+Vector2(0,11)*s,1.5*s,color_)
			'sound','mute':
				draw_polyline(PackedVector2Array([c+Vector2(-10,-4)*s,c+Vector2(-5,-4)*s,c+Vector2(1,-10)*s,c+Vector2(1,10)*s,c+Vector2(-5,4)*s,c+Vector2(-10,4)*s,c+Vector2(-10,-4)*s]),color_,2*s,true)
				if name=='sound':draw_arc(c+Vector2(-2,0)*s,12*s,-0.8,0.8,15,color_,2*s,true)
				else:stroke(c+Vector2(5,-5)*s,c+Vector2(12,5)*s,color_,2*s);stroke(c+Vector2(12,-5)*s,c+Vector2(5,5)*s,color_,2*s)
			'pause':stroke(c+Vector2(-4,-8)*s,c+Vector2(-4,8)*s,color_,3*s);stroke(c+Vector2(4,-8)*s,c+Vector2(4,8)*s,color_,3*s)
			'play':draw_polyline(PackedVector2Array([c+Vector2(-5,-9)*s,c+Vector2(9,0)*s,c+Vector2(-5,9)*s,c+Vector2(-5,-9)*s]),color_,2*s,true)
			'close','reset':stroke(c+Vector2(-7,-7)*s,c+Vector2(7,7)*s,color_,2*s);stroke(c+Vector2(7,-7)*s,c+Vector2(-7,7)*s,color_,2*s)
			'check':draw_polyline(PackedVector2Array([c+Vector2(-9,0)*s,c+Vector2(-2,7)*s,c+Vector2(10,-8)*s]),color_,2.5*s,true)
			'clock':glyph('ring',c,s,color_);stroke(c,c+Vector2(0,-7)*s,color_,2*s);stroke(c,c+Vector2(6,2)*s,color_,2*s)
			'chart':
				for j in range(3):draw_rect(Rect2(c+Vector2(-10+j*8,8-[7,13,20][j])*s,Vector2(4,[7,13,20][j])*s),color_)
			'export':stroke(c+Vector2(0,-11)*s,c+Vector2(0,5)*s,color_,2*s);stroke(c+Vector2(-5,0)*s,c+Vector2(0,5)*s,color_,2*s);stroke(c+Vector2(0,5)*s,c+Vector2(5,0)*s,color_,2*s);draw_polyline(PackedVector2Array([c+Vector2(-10,5)*s,c+Vector2(-10,11)*s,c+Vector2(10,11)*s,c+Vector2(10,5)*s]),color_,2*s,true)
			'lock':draw_arc(c+Vector2(0,-3)*s,6*s,-PI,0,18,color_,2*s,true);draw_rect(Rect2(c+Vector2(-8,-3)*s,Vector2(16,14)*s),color_,false,2*s);draw_circle(c+Vector2(0,3)*s,1.5*s,color_)
			'tap':draw_circle(c,6*s,color_,false,2*s,true);draw_arc(c,12*s,-2.5,-0.65,18,color_,1.5*s,true)

func _draw():
	var color_=tint if not disabled else tint.darkened(0.55)
	if selected:draw_rect(Rect2(Vector2(2,2),size-Vector2(4,4)),color_,false,1)
	if kind=='ring':
		draw_rect(Rect2(0,9,3,size.y-18),color_)
		if small:
			glyph('lock' if locked else 'ring',Vector2(size.x/2,19),0.72,color_)
			if not locked:centered(str(level) if level>0 else '+',23,10,color_)
			centered(bottom,size.y-10,12,Color('#c4cddd') if not disabled else Color('#526176'))
		else:
			glyph('lock' if locked else 'ring',Vector2(26,size.y/2),0.85,color_)
			if not locked:label(str(level) if level>0 else '+',Vector2(22,size.y/2+4),11,color_)
			label(top,Vector2(48,20),13,Color('#c4cddd') if not disabled else Color('#526176'))
			label(bottom,Vector2(48,38),12,color_)
			if owned:glyph('max',Vector2(size.x-18,size.y/2),0.5,color_)
		if fill>0:draw_rect(Rect2(4,size.y-3,(size.x-8)*fill,2),color_)
	elif kind=='card':
		glyph(symbol,Vector2(27,28),0.9,color_)
		var fs=15
		while fs>10 and base_font.get_string_size(top,HORIZONTAL_ALIGNMENT_LEFT,-1,fs).x>size.x-62:fs-=1
		label(top,Vector2(51,32),fs,Color('#e6e9f0'))
		label(bottom,Vector2(17,size.y-16),13,color_)
		if level>0:
			for j in range(5):draw_circle(Vector2(size.x-15-j*7,16),2,Color('#b6dcce') if j<level else Color('#344456'))
	elif kind=='wide':
		if symbol=='':centered(top,size.y/2+5,14,color_)
		else:
			glyph(symbol,Vector2(25,size.y/2),0.8,color_)
			var fs=14
			while fs>11 and base_font.get_string_size(top,HORIZONTAL_ALIGNMENT_LEFT,-1,fs).x>size.x-56:fs-=1
			label(top,Vector2(47,size.y/2+5),fs,color_)
		if bottom!='':label(bottom,Vector2(size.x-66,size.y/2+5),13,color_)
	else:
		glyph(symbol,size/2,0.9,color_)
		if top!='':centered(top,size.y-5,9,color_)
