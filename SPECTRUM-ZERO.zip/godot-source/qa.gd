extends SceneTree
const Sim=preload('res://sim.gd')
func _initialize():
	var g=Sim.new();g.started=true
	var first=-1.0;var infinity=-1.0;var prestiges=[]
	for tick in range(4*60*60*4):
		g.step(0.25)
		if tick%2==0:g.buy_all()
		if g.resonance>=100:g.activate()
		if tick%8==0:
			for i in range(12):g.claim(i)
		if g.prestige_gain()>=3 and g.refractions<5:
			if first<0:first=tick/4.0
			prestiges.append({'t':tick/4.0,'gain':g.refract()})
			for i in [4,0,1,3,2,5]:
				if g.prisms>=g.module_cost(i):g.action('module',i)
			if g.modules[4]>0:g.auto=true
		if g.infinity_gain()>=1:
			infinity=tick/4.0;g.infinity();break
		g.events.clear()
	print('Progression ',JSON.stringify({'first_refraction':first,'prestiges':prestiges,'infinity':infinity,'levels':g.levels,'rate':g.rate(),'energy':g.energy,'cores':g.cores}))
	assert(first>0 and first<1800,'First reset must be reachable in normal production')
	assert(infinity>0 and infinity<7200,'Infinity must be reachable')
	assert(g.prism_total>0,'Infinity retains earned prism power so the next run is stronger')
	# Snapshot exactness at 0.25s simulation steps, including phases and active bursts.
	g.energy=100000;g.buy_all();g.resonance=100;g.activate();g.step(1.25)
	var copy=Sim.new();assert(copy.restore(JSON.parse_string(JSON.stringify(g.snapshot()))))
	for i in range(80):g.step(0.25);copy.step(0.25)
	assert(is_equal_approx(g.energy,copy.energy) and g.all_laps==copy.all_laps,'Save restores active loops and burst remainder exactly')
	var old=g.energy;g.paused=true;g.step(100);assert(g.energy==old);g.paused=false
	var f=Sim.new();f.started=true;f.energy=100000;f.buy_all();f.burst=1
	var h=Sim.new();h.restore(f.snapshot().duplicate(true));f.offline(20)
	for i in range(20):h.step(1)
	assert(is_equal_approx(f.energy,h.energy),'Offline boost must expire after one second')
	assert(not Sim.new().restore({'v':1,'levels':[]}))
	g.refractions=2;g.prism_total=100;g.modules[0]=3
	for trial in range(3):
		assert(g.action('trial',trial));g.energy=100000;g.buy_all()
		for tick in range(1600):g.step(0.25);g.buy_all()
		assert(g.trials[trial] and g.trial_done,'Trial must be completable')
		assert(g.action('exit-trial'))
	g.cores=100
	for i in range(4):assert(g.action('generator',i))
	g.step(100);assert(g.flux[0]>0 and g.flux[3]>0)
	g.lifetime=1e10;g.refractions=20;g.infinities=8;g.all_laps=100000;g.bursts=12;g.modules.fill(3);g.levels.fill(4)
	for i in range(12):
		if i not in g.claims:assert(g.claim(i))
		assert(not g.claim(i),'Reward must not duplicate')
	print('PASS: economy, both resets, exact save, boost expiration, malformed save, all trials, generator chain and once-only badges')
	quit()
