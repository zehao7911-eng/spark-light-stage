extends Node2D

const Sim=preload('res://sim.gd')
const Card=preload('res://card.gd')
const SAVE='spectrum-zero.v1'
const BG=Color('#0b121e')
const PANEL=Color('#111c2b')
const LINE=Color('#26384b')
const WHITE=Color('#e8edf3')
const DIM=Color('#71869f')
const MINT=Color('#8ee0cb')
var g=Sim.new()
var font: Font=ThemeDB.fallback_font
var ui: Control
var modal_ui: Control
var buttons=[]
var modal_buttons=[]
var hud_buttons={}
var ring_buttons=[]
var top_labels={}
var popup=''
var popup_text: Label
var popup_value: Label
var page=0
var compact=false
var landscape=false
var size_before=Vector2.ZERO
var center=Vector2.ZERO
var radius=200.0
var hero=Rect2()
var view=Vector2.ZERO
var t=0.0
var sync=0.0
var saving=0.0
var last_event=0
var particles=[]
var rings_flash=[]
var toast=''
var toast_life=0.0
var impact=0.0
var reveal=0.0
var native_callback
var away_at=0.0
var tab_hidden=false
var sound_players=[]
var sound_timer=0.0
var sounds={}
var old_prism_gain=0
var offline_gain=0.0
var qa_fixture=false
var ui_scale=1.0
var safe_offset=Vector2.ZERO

func _ready():
	Engine.max_fps=60
	rings_flash.resize(10);rings_flash.fill(0.0)
	load_game()
	for name in ['tap','buy','lap','burst','prestige','infinity','badge']:
		var file='res://audio/'+name+'.wav'
		if ResourceLoader.exists(file):sounds[name]=load(file)
	for i in range(6):
		var player=AudioStreamPlayer.new();add_child(player);sound_players.append(player)
	ui=Control.new();ui.mouse_filter=Control.MOUSE_FILTER_IGNORE;add_child(ui)
	if OS.has_feature('web'):
		native_callback=JavaScriptBridge.create_callback(web_event)
		JavaScriptBridge.get_interface('window').spectrumLifecycle=native_callback
		JavaScriptBridge.eval('window.spectrumReady && window.spectrumReady()')
	if '--art-qa' in OS.get_cmdline_user_args():make_fixture()
	layout()
	if not g.started:open_popup('welcome')
	elif offline_gain>0:notify('Welcome back  +'+fmt(offline_gain))

func make_fixture():
	qa_fixture=true;g=Sim.new();g.started=true;g.levels=[12,11,10,9,8,7,6,5,4,3];g.energy=3250000;g.run_earned=7200000;g.lifetime=1e8
	g.prisms=8;g.prism_total=16;g.refractions=5;g.core_total=2;g.cores=3;g.infinities=1;g.all_laps=12000;g.resonance=100
	for i in range(10):g.phases[i]=fmod(i*0.16+0.23,1.0);g.laps[i]=i*24+40
	g.modules=[2,2,1,1,1,1];g.auto=false

func fmt(n):
	if not is_finite(n):return '∞'
	var x=maxf(0,n)
	if x<1000:return str(int(x)) if x>=10 else ('%.1f'%x).trim_suffix('.0')
	var index=int(floor(log(x)/log(1000.0)))
	if index<=6:return ('%.2f'%(x/pow(1000,index))).trim_suffix('0').trim_suffix('.')+['','K','M','B','T','Qa','Qi'][index]
	return '%.2fe%d'%[x/pow(10,floor(log(x)/log(10.0))),int(floor(log(x)/log(10.0)))]
func text(s,pos,sz=14,col=WHITE):draw_string(font,pos,str(s),HORIZONTAL_ALIGNMENT_LEFT,-1,sz,col)
func centered(s,pos,sz=14,col=WHITE):
	var width=font.get_string_size(str(s),HORIZONTAL_ALIGNMENT_LEFT,-1,sz).x
	text(s,pos-Vector2(width/2,0),sz,col)
func line(a,b,col=LINE,w=1.0):draw_line(a,b,col,w,true)
func rounded(rect,color_,r=14):
	var style=StyleBoxFlat.new();style.bg_color=color_;style.set_corner_radius_all(r);draw_style_box(style,rect)
func label_node(parent,text_,pos,size_,font_size=16,color_=WHITE):
	var label=Label.new();label.add_theme_font_size_override('font_size',font_size);label.add_theme_color_override('font_color',color_);label.mouse_filter=Control.MOUSE_FILTER_IGNORE;label.clip_text=true
	if font_size<=20:label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	label.position=pos;label.size=size_;parent.add_child(label);label.text=text_;return label
func card(parent,id,symbol,rect,action,n=0,kind='icon',title_=''):
	var names={'page':'Cycles','prestige-view':'Refraction','infinity-view':'Infinity','modules-view':'Permanent circuits','automation':'Autopilot','badges':'Milestones','stats':'Statistics','settings':'Control room','help':'Quick guide'}
	var b=Card.new();b.symbol=symbol;b.kind=kind;b.position=rect.position;b.size=rect.size;b.tooltip_text=title_ if title_!='' else names.get(action,'');b.set_meta('id',id);b.set_meta('action',action);b.set_meta('n',n)
	b.pressed.connect(func():command(action,n))
	parent.add_child(b)
	if parent==ui:buttons.append(b)
	else:modal_buttons.append(b)
	return b
func clear_ui():
	for b in ui.get_children():b.queue_free()
	buttons.clear();ring_buttons.clear();hud_buttons.clear();top_labels.clear()
func layout():
	size_before=get_viewport_rect().size
	ui_scale=maxf(1.0,DisplayServer.screen_get_scale()) if OS.has_feature('web') else 1.0
	var insets=[0.0,0.0,0.0,0.0]
	if OS.has_feature('web'):
		var value_=JavaScriptBridge.eval('JSON.stringify(["--sal","--sat","--sar","--sab"].map(k=>parseFloat(getComputedStyle(document.documentElement).getPropertyValue(k))||0))')
		var parsed=JSON.parse_string(str(value_))
		if typeof(parsed)==TYPE_ARRAY and parsed.size()==4:insets=parsed
	safe_offset=Vector2(insets[0],insets[1]);scale=Vector2(ui_scale,ui_scale);position=safe_offset*ui_scale
	view=size_before/ui_scale-Vector2(insets[0]+insets[2],insets[1]+insets[3])
	landscape=view.y<560 and view.x>view.y*1.3;compact=view.x<760 or landscape
	clear_ui()
	if compact:
		var grid_y=view.y-208
		var hero_y=104.0;var hero_h=maxf(170,grid_y-hero_y-10)
		hero=Rect2(10,hero_y,view.x-20,hero_h);center=hero.get_center()+Vector2(0,-5);radius=minf((view.x-72)/2,(hero_h-36)/2)
		var gap=5.0;var cell=(view.x-24-gap*4)/5
		var grid_x=12.0
		if landscape:
			hero=Rect2(12,92,view.x*0.46-18,view.y-156);center=hero.get_center();radius=minf(hero.size.x/2-30,hero.size.y/2-14)
			grid_x=view.x*0.46+12;grid_y=118;cell=(view.x-grid_x-14-gap*4)/5
		for i in range(10):
			var b=card(ui,'ring-'+str(i),'ring',Rect2(grid_x+(i%5)*(cell+gap),grid_y+int(i/5)*65,cell,60),'buy',i,'ring','Upgrade spectrum '+str(i+1))
			b.small=true;b.ring_index=i;b.tint=Color(Sim.COLORS[i]);ring_buttons.append(b)
		for i in range(5):
			var symbols=['cycle','prestige','module','star','settings']
			var actions=['page','prestige-view','modules-view','badges','settings']
			var nav_x=grid_x if landscape else 12.0;var nav_w=view.x-nav_x-12
			var b=card(ui,'nav-'+str(i),symbols[i],Rect2(nav_x+i*nav_w/5,view.y-64,(nav_w-20)/5,48),actions[i],i)
			b.selected=i==0;hud_buttons['nav'+str(i)]=b
		hud_buttons['max']=card(ui,'max','max',Rect2(view.x-58,50,44,44),'max',0,'icon','Buy all affordable upgrades')
		hud_buttons['pause']=card(ui,'pause','pause',Rect2(view.x-58,6,44,44),'pause',0,'icon','Pause / resume')
		hud_buttons['mode']=card(ui,'mode','',Rect2(12,50,52,44),'cycle-mode',0,'wide','Purchase quantity')
		hud_buttons['mode'].top='×1'
		hud_buttons['burst']=card(ui,'burst','tap',Rect2(center.x-24,center.y-24,48,48),'tap',0,'core','Tap for energy; resonance at 100% gives a 3× burst')
	else:
		var rail=74.0;var left=246.0;var right=240.0
		if view.y<550:left=214;right=190
		hero=Rect2(left+32,90,view.x-left-right-rail-60,view.y-180)
		center=hero.get_center()+Vector2(0,-6);radius=minf(hero.size.x/2-18,hero.size.y/2-20)
		var bh=minf(50,(view.y-162)/10.0)
		for i in range(10):
			var b=card(ui,'ring-'+str(i),'ring',Rect2(22,110+i*(bh+4),left-22,bh),'buy',i,'ring','Spectrum '+str(i+1)+' · Speed and production upgrade')
			b.ring_index=i;b.tint=Color(Sim.COLORS[i]);ring_buttons.append(b)
		var symbols=['cycle','prestige','infinity','module','auto','star','chart','settings','help']
		var actions=['page','prestige-view','infinity-view','modules-view','automation','badges','stats','settings','help']
		for i in range(symbols.size()):
			var b=card(ui,'nav-'+str(i),symbols[i],Rect2(view.x-62,100+i*minf(57,(view.y-130)/9),48,48),actions[i],i)
			b.selected=i==0;hud_buttons['nav'+str(i)]=b
		hud_buttons['max']=card(ui,'max','max',Rect2(left-24,55,48,44),'max',0,'icon','Buy all affordable upgrades')
		hud_buttons['mode']=card(ui,'mode','',Rect2(22,55,60,44),'cycle-mode',0,'wide','Purchase quantity')
		hud_buttons['mode'].top='×1'
		hud_buttons['pause']=card(ui,'pause','pause',Rect2(view.x-62,15,48,44),'pause',0,'icon','Pause / resume')
		hud_buttons['burst']=card(ui,'burst','tap',Rect2(center.x-24,center.y-24,48,48),'tap',0,'core','Tap for energy · charged resonance gives a 3× burst')
		var px=view.x-right-rail-4
		hud_buttons['prestige']=card(ui,'prestige','prestige',Rect2(px,190,right-18,58),'prestige-view',0,'wide','Refraction: reset cycles for permanent power')
		hud_buttons['infinity']=card(ui,'infinity','infinity',Rect2(px,273,right-18,58),'infinity-view',0,'wide','Infinity: reset for cores and generators')
		hud_buttons['auto']=card(ui,'auto','auto',Rect2(px,356,right-18,48),'automation',0,'wide','Automatic purchases')
		hud_buttons['modules']=card(ui,'modules','module',Rect2(px,422,right-18,48),'modules-view',0,'wide','Permanent upgrades')
		if view.y<550:
			for name in ['modules','auto']:hud_buttons[name].visible=false
	refresh_ui()
	if popup!='':var old=popup;close_popup(false);open_popup(old)

func open_popup(name):
	if modal_ui:modal_ui.queue_free()
	popup=name;modal_buttons.clear();popup_text=null;popup_value=null
	modal_ui=Control.new();modal_ui.size=view;modal_ui.mouse_filter=Control.MOUSE_FILTER_IGNORE;add_child(modal_ui)
	var shade=ColorRect.new();shade.color=Color(0.02,0.04,0.07,0.88);shade.size=view;shade.mouse_filter=Control.MOUSE_FILTER_STOP
	shade.gui_input.connect(func(ev):
		if ev is InputEventMouseButton and ev.pressed and name not in ['welcome','confirm-reset']:close_popup())
	modal_ui.add_child(shade)
	var w=minf(590,view.x-28);var h=minf(610,view.y-42)
	if name in ['prestige-view','infinity-view','confirm-reset','welcome']:h=minf(430,view.y-42)
	var panel=Panel.new();panel.size=Vector2(w,h);panel.position=(view-panel.size)/2
	var style=StyleBoxFlat.new();style.bg_color=Color('#111d2d');style.border_color=Color('#344b61');style.set_border_width_all(1);style.set_corner_radius_all(20);panel.add_theme_stylebox_override('panel',style);modal_ui.add_child(panel)
	var titles={'welcome':'SPECTRUM ZERO','prestige-view':'Refraction','infinity-view':'Infinity','modules-view':'Permanent circuits','badges':'Milestones','settings':'Control room','help':'One more revolution','stats':'Your spectrum','automation':'Autopilot','trials':'Challenge chambers','generators':'Generator chain','confirm-reset':'Begin again?'}
	var title_=str(titles.get(name,name));var title_size=23
	while title_size>17 and font.get_string_size(title_,HORIZONTAL_ALIGNMENT_LEFT,-1,title_size).x>w-92:title_size-=1
	label_node(panel,title_,Vector2(22,20),Vector2(w-92,35),title_size)
	if name!='welcome':card(panel,'close','close',Rect2(w-64,15,44,44),'close',0,'icon','Close')
	var scroll=ScrollContainer.new();scroll.position=Vector2(18,74);scroll.size=Vector2(w-36,h-92);scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED;panel.add_child(scroll)
	var content=Control.new();content.custom_minimum_size=Vector2(w-48,h-108);scroll.add_child(content)
	var cw=w-48
	match name:
		'welcome':
			popup_text=label_node(content,'Tap the core for energy.\nUpgrade circles to produce more.',Vector2(4,8),Vector2(cw-8,72),19,DIM)
			var b=card(content,'welcome-start','play',Rect2(8,128,cw-16,58),'start',0,'wide','Start your spectrum');b.top='START THE ENGINE';b.tint=MINT
			label_node(content,'Full resonance gives a 3× burst.',Vector2(8,203),Vector2(cw-16,50),14,DIM)
		'prestige-view','infinity-view':
			var infinity_=name=='infinity-view';var gain=g.infinity_gain() if infinity_ else g.prestige_gain()
			var intro='Reset cycles for cores and generators.\nEarned prism power and circuits stay.' if infinity_ else 'Restart the circles.\nKeep a permanent production boost.'
			label_node(content,intro,Vector2(4,8),Vector2(cw-8,68),16,DIM)
			popup_value=label_node(content,'',Vector2(8,85),Vector2(cw-16,53),30,MINT)
			var b=card(content,'confirm-rebirth','infinity' if infinity_ else 'prestige',Rect2(8,160,cw-16,56),'infinity' if infinity_ else 'prestige',0,'wide','Confirm reset for permanent rewards');b.top='ENTER INFINITY' if infinity_ else 'REFRACT';b.tint=Color('#b8a5e9') if infinity_ else MINT
			label_node(content,'Needs 10M earned this run.' if infinity_ else 'Needs 10K earned this run.',Vector2(8,232),Vector2(cw-16,30),13,DIM)
			if not infinity_:
				var next=card(content,'next-infinity','infinity',Rect2(8,274,cw-16,44),'infinity-view',0,'wide','View the next reset layer');next.top='INFINITY';next.tint=Color('#b7a4e5')
				content.custom_minimum_size.y=328
		'modules-view':
			popup_value=label_node(content,'',Vector2(4,0),Vector2(cw-8,28),15,MINT)
			var columns=2 if compact else 3;var bw=(cw-8*(columns-1))/columns
			for i in range(6):
				var b=card(content,'module-'+str(i),['burst','clock','star','play','auto','ring'][i],Rect2((i%columns)*(bw+8),35+int(i/columns)*104,bw,94),'module',i,'card',Sim.MOD_DESC[i]);b.top=Sim.MODULES[i];b.tint=MINT
			content.custom_minimum_size.y=35+ceil(6.0/columns)*104+85
			popup_text=label_node(content,'Prisms are earned by refraction.\nCircuits remain through both resets.',Vector2(4,content.custom_minimum_size.y-75),Vector2(cw-8,64),14,DIM)
		'badges':
			var columns=2 if compact else 3;var bw=(cw-8*(columns-1))/columns
			for i in range(12):
				var b=card(content,'badge-'+str(i),'star',Rect2((i%columns)*(bw+8),int(i/columns)*100,bw,90),'claim',i,'card',Sim.BADGES[i][0]);b.top=Sim.BADGES[i][0];b.tint=Color('#dcca88')
			content.custom_minimum_size.y=ceil(12.0/columns)*100
		'settings':
			var rows=[['automation','auto','Autopilot'],['infinity-view','infinity','Infinity'],['generators','generator','Generators'],['trials','star','Challenges'],['sound','sound','Sound'],['motion','motion','Motion'],['pause','pause','Pause'],['export','export','Export save'],['stats','chart','Statistics'],['help','help','Quick guide'],['confirm-reset','reset','New spectrum']]
			for i in range(rows.size()):
				var bw=(cw-8)/2;var b=card(content,'setting-'+rows[i][0],rows[i][1],Rect2((i%2)*(bw+8),int(i/2)*68,bw,58),rows[i][0],0,'wide',rows[i][2]);b.top=rows[i][2]
			content.custom_minimum_size.y=ceil(rows.size()/2.0)*68+52
			label_node(content,'Saved on this device · 2-hour away progress',Vector2(4,content.custom_minimum_size.y-40),Vector2(cw-8,38),12,DIM)
		'help':
			var hints=[['cycle','Circles earn energy every lap.'],['max','Upgrade speed and output. ×1 / ×10 / MAX.'],['tap','Tap the center for a little extra energy.'],['burst','At 100%, tap for a 3× resonance burst.'],['prestige','At 10K earned, refract for permanent power.'],['module','Spend prisms on lasting circuits.'],['infinity','At 10M, enter infinity and build generators.'],['star','Claim milestones. Try challenge chambers.']]
			for i in range(hints.size()):
				var b=card(content,'help-'+str(i),hints[i][0],Rect2(0,i*59,44,44),'none');b.disabled=true
				label_node(content,hints[i][1],Vector2(58,i*59+2),Vector2(cw-60,53),14,WHITE).autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
			content.custom_minimum_size.y=hints.size()*59
		'stats':
			popup_text=label_node(content,'',Vector2(8,8),Vector2(cw-16,400),17,WHITE)
		'automation':
			label_node(content,'Upgrades chosen automatically.\nNew circles come first, then efficient upgrades.',Vector2(4,8),Vector2(cw-8,78),16,DIM)
			var b=card(content,'auto-toggle','auto',Rect2(8,106,cw-16,60),'auto',0,'wide','Toggle automatic upgrades');b.top='AUTOPILOT'
			label_node(content,'Unlock the Autobuyer circuit with prisms.',Vector2(8,185),Vector2(cw-16,80),14,DIM).autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
		'trials':
			var rows=[['Quiet chamber','No tapping · 30K energy'],['Heavy chamber','65% lap speed · 70K energy'],['Manual chamber','No autopilot or burst · 160K energy']]
			for i in range(3):
				var b=card(content,'trial-'+str(i),['tap','clock','auto'][i],Rect2(0,i*100,cw,90),'trial',i,'card',rows[i][1]);b.top=rows[i][0];b.tint=Color('#c6acdf')
			label_node(content,'Each completion permanently boosts production 25%.\nEntering restarts the run. Permanent power stays.',Vector2(4,310),Vector2(cw-8,85),14,DIM).autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
			var b=card(content,'exit-trial','close',Rect2(0,405,cw,52),'exit-trial',0,'wide','Leave the current challenge');b.top='LEAVE CHAMBER';content.custom_minimum_size.y=470
		'generators':
			label_node(content,'IV > III > II > I > production\nSpend cores. Upper generators feed the chain.',Vector2(4,4),Vector2(cw-8,70),15,DIM)
			for i in range(4):
				var b=card(content,'generator-'+str(i),'generator',Rect2(0,78+i*87,cw,77),'generator',i,'card','Generator '+str(i+1));b.top='GENERATOR '+['I','II','III','IV'][i];b.tint=Color('#c1b0ec')
			content.custom_minimum_size.y=440
		'confirm-reset':
			label_node(content,'All energy, circuits and permanent progress\non this device will be replaced by a fresh game.',Vector2(4,10),Vector2(cw-8,94),16,DIM).autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
			var b=card(content,'reset-confirm','reset',Rect2(8,135,cw-16,56),'reset-confirm',0,'wide','Confirm new spectrum');b.top='START FRESH';b.tint=Color('#ec9994')
	refresh_ui()
	web_snapshot()

func close_popup(refresh=true):
	if modal_ui:modal_ui.queue_free();modal_ui=null
	modal_buttons.clear();popup='';popup_text=null;popup_value=null
	if refresh:refresh_ui();web_snapshot()
func notify(message):toast=message;toast_life=3.2

func command(a,n=0):
	if a=='none':return
	if a=='close':close_popup();return
	if a in ['prestige-view','infinity-view','modules-view','badges','settings','help','stats','automation','trials','generators','confirm-reset']:
		open_popup(a);return
	if a=='page':close_popup();return
	if a=='cycle-mode':g.buy_mode=10 if g.buy_mode==1 else 60 if g.buy_mode==10 else 1
	elif a=='reset-confirm':
		g=Sim.new();last_event=0;particles.clear();rings_flash.fill(0.0);close_popup();open_popup('welcome');save_game()
	elif a=='export':export_save();notify('Save exported')
	elif a=='tap':
		if g.resonance>=100 and g.burst<=0 and g.trial!=2:g.activate()
		else:g.tap()
	elif a=='trial':
		if g.refractions>0 and g.trial<0:g.action(a,n);close_popup();notify('Challenge chamber entered')
		else:notify('Refract once to unlock chambers')
	elif a=='prestige' or a=='infinity':
		if g.action(a,n):close_popup();save_game()
	else:
		var ok=g.action(a,n)
		if a=='start':close_popup()
		if a=='auto' and not ok:notify('Unlock the Autobuyer circuit first')
		if a=='module' and not ok:notify('Needs more prisms')
		if a=='generator' and not ok:notify('Needs cores from infinity')
		if a=='exit-trial' and ok:close_popup()
		if ok:save_game()
	refresh_ui()
	web_snapshot()

func refresh_ui():
	for i in range(ring_buttons.size()):
		var b=ring_buttons[i];b.level=g.levels[i];b.owned=g.levels[i]>0;b.locked=not g.can_unlock(i);b.fill=g.phases[i]
		b.top=('%.2f'%g.speed(i))+'/s  ×'+fmt(pow(1.24,maxi(0,g.levels[i]-1))) if b.owned else 'SPECTRUM '+str(i+1)
		b.bottom='MAX' if g.levels[i]>=60 else fmt(g.cost(i))
		b.disabled=not g.started or not g.can_unlock(i) or g.energy<g.cost(i) or g.levels[i]>=60
		b.tooltip_text='Spectrum '+str(i+1)+' · Level '+str(g.levels[i])+'\n'+fmt(g.value(i))+' per lap · '+fmt(g.cost(i))+' energy'
		b.queue_redraw()
	for key in hud_buttons:
		var b=hud_buttons[key]
		match key:
			'mode':b.top='×1' if g.buy_mode==1 else '×10' if g.buy_mode==10 else 'MAX'
			'pause':b.symbol='play' if g.paused else 'pause'
			'burst':
				b.symbol='burst' if (g.resonance>=100 and g.trial!=2) or g.burst>0 else 'tap';b.top='';b.tint=MINT if g.resonance>=100 and g.trial!=2 else Color('#97a9c1')
				b.disabled=g.paused or (g.heat>=94 and g.resonance<100) or (g.trial==0 and g.resonance<100)
			'prestige':b.top='REFRACT';b.bottom='+'+str(g.prestige_gain());b.tint=MINT if g.prestige_gain()>0 else DIM
			'infinity':b.top='INFINITY';b.bottom='+'+str(g.infinity_gain());b.tint=Color('#b7a4e5') if g.infinity_gain()>0 else DIM
			'auto':b.top='AUTO  ON' if g.auto else 'AUTO  OFF';b.tint=MINT if g.auto else DIM
			'modules':b.top='CIRCUITS';b.bottom=str(g.prisms)
		b.queue_redraw()
	for b in modal_buttons:
		var a=str(b.get_meta('action'));var n=int(b.get_meta('n'))
		match a:
			'module':b.level=g.modules[n];b.bottom=str(g.module_cost(n))+' prisms';b.disabled=g.prisms<g.module_cost(n) or g.modules[n]>=5
			'generator':b.level=mini(5,g.generators[n]);b.bottom=str(g.gen_cost(n))+' cores  ·  '+fmt(g.flux[n])+' flux';b.disabled=g.cores<g.gen_cost(n) or (n>0 and g.generators[n-1]==0)
			'claim':b.bottom='CLAIM' if g.badge_ready(n) else 'COLLECTED' if n in g.claims else fmt(g.badge_value(Sim.BADGES[n][1]))+' / '+fmt(Sim.BADGES[n][2]);b.disabled=not g.badge_ready(n);b.symbol='check' if n in g.claims else 'star'
			'auto':b.bottom='ON' if g.auto else 'OFF';b.disabled=g.modules[4]==0
			'prestige':b.disabled=g.prestige_gain()<1 or g.trial>=0
			'infinity':b.disabled=g.infinity_gain()<1 or g.trial>=0
			'trial':b.disabled=g.refractions==0 or g.trial>=0;b.bottom='COMPLETE · ×1.25' if g.trials[n] else ['NO TAPPING','SLOW CYCLES','NO AUTOPILOT / BURST'][n]
			'exit-trial':b.disabled=g.trial<0
			'sound':b.symbol='mute' if g.muted else 'sound';b.top='Sound off' if g.muted else 'Sound on'
			'motion':b.top='Calm motion' if g.reduced else 'Full motion'
			'pause':b.symbol='play' if g.paused else 'pause';b.top='Resume' if g.paused else 'Pause'
		b.queue_redraw()
	if popup_value and is_instance_valid(popup_value):
		if popup=='modules-view':popup_value.text='P '+str(g.prisms)+'  ·  ×'+fmt(g.multiplier())+' production'
		else:
			popup_value.text=('+'+fmt(g.infinity_gain())+' cores' if popup=='infinity-view' else '+'+fmt(g.prestige_gain())+' prisms  ·  +'+fmt(g.prestige_gain()*45)+'%')
			var fs=30
			while fs>17 and font.get_string_size(popup_value.text,HORIZONTAL_ALIGNMENT_LEFT,-1,fs).x>popup_value.size.x:fs-=1
			popup_value.add_theme_font_size_override('font_size',fs)
	if popup=='stats' and popup_text:
		popup_text.text='Energy produced   '+fmt(g.lifetime)+'\n\nRevolutions   '+fmt(g.all_laps)+'\n\nRefractions   '+str(g.refractions)+'\n\nInfinities   '+str(g.infinities)+'\n\nStars   '+str(g.stars())+'\n\nProduction power   ×'+fmt(g.multiplier())+'\n\nPlay time   '+str(int(g.seconds/60))+' min'

func process_events():
	for ev in g.events:
		if ev.id<=last_event:continue
		last_event=ev.id
		var kind=ev.kind
		if kind=='lap':rings_flash[int(ev.n)]=1.0
		if kind in ['buy','tap','burst','prestige','infinity','badge','module','trial-win']:
			impact=0.7 if kind in ['buy','tap'] else 1.0
			if not g.reduced:
				var count=9 if kind in ['tap','buy'] else 32
				for j in range(count):
					if particles.size()>=120:break
					var a=randf()*TAU;particles.append({'p':center,'v':Vector2(cos(a),sin(a))*randf_range(25,105),'life':randf_range(0.5,1.4),'col':Color(Sim.COLORS[posmod(int(ev.n)+j,10)])})
		if kind=='buy':play_sound('buy')
		elif kind=='tap':play_sound('tap')
		elif kind=='lap' and ev.n==0:play_sound('lap')
		elif kind in sounds:play_sound(kind)
		if kind=='prestige':reveal=1.0;notify('Refraction  +'+str(int(ev.value))+' prisms')
		if kind=='infinity':reveal=1.0;notify('Infinity  +'+str(int(ev.value))+' cores')
		if kind=='module':notify('Circuit improved')
		if kind=='badge':notify(Sim.BADGES[int(ev.n)][0]+'  +'+fmt(ev.value))
		if kind=='trial-win':notify('Chamber complete  ·  permanent ×1.25')
	g.events.clear()
func play_sound(kind):
	if g.muted or sound_timer>0 or kind not in sounds:return
	for player in sound_players:
		if not player.playing:player.stream=sounds[kind];player.volume_db=-12 if kind=='lap' else -6;player.play();sound_timer=0.12;return

func _process(delta):
	var dt=minf(delta,0.15)
	if get_viewport_rect().size!=size_before:layout()
	if not tab_hidden:
		g.step(dt)
		if not g.paused:t+=dt
	process_events()
	for i in range(10):rings_flash[i]=maxf(0,rings_flash[i]-dt*2.5)
	for i in range(particles.size()-1,-1,-1):
		var p=particles[i];p.life-=dt;p.p+=p.v*dt;p.v*=pow(0.4,dt)
		if p.life<=0:particles.remove_at(i)
	impact=maxf(0,impact-dt*2);reveal=maxf(0,reveal-dt*.8);toast_life=maxf(0,toast_life-dt);sound_timer=maxf(0,sound_timer-dt)
	sync+=dt;saving+=dt
	if sync>=0.15:sync=0;refresh_ui();web_snapshot()
	if saving>=4:saving=0;save_game()
	queue_redraw()

func _draw():
	draw_rect(get_viewport_rect(),BG)
	if view.x<=0:return
	# A restrained instrument face: calibrated ticks, etched crosshairs, layered arcs.
	for j in range(90):
		var x=fmod(j*137.32,view.x);var y=fmod(j*97.16,view.y)
		draw_circle(Vector2(x,y),0.6,Color('#294053'))
	if not compact:
		rounded(Rect2(12,100,238 if view.y>=550 else 206,view.y-116),PANEL,14)
		rounded(Rect2(view.x-310,126,224,view.y-194),Color('#101a29'),14)
		line(Vector2(view.x-76,80),Vector2(view.x-76,view.y-20))
		text('SPECTRUM',Vector2(22,33),17,WHITE);text('ZERO',Vector2(130,33),17,MINT)
		text('PERMANENT SYSTEMS',Vector2(view.x-292,155),10,DIM)
		text('P',Vector2(view.x-292,180),13,MINT);text(fmt(g.prisms),Vector2(view.x-275,180),13,WHITE)
		text('∞',Vector2(view.x-220,180),17,Color('#c2b1ea'));text(fmt(g.cores),Vector2(view.x-195,180),13,WHITE)
		text('SPECTRUM '+str(g.unlocked_count())+' / 10',Vector2(22,view.y-23),11,DIM)
		centered('EACH REVOLUTION BUILDS THE NEXT',Vector2(center.x,view.y-24),10,DIM)
	else:
		text('SPECTRUM',Vector2(14,25),11,WHITE);text('ZERO',Vector2(84,25),11,MINT)
		text('P '+fmt(g.prisms),Vector2(14,43),11,Color('#b4dfd0'));text('∞ '+fmt(g.cores),Vector2(90,43),11,Color('#c3b1e9'))
	var value_y=84.0 if compact else 56.0
	var energy_size=32 if compact else 38
	centered(fmt(g.energy),Vector2(view.x/2 if compact else center.x,value_y),energy_size,WHITE)
	centered('+'+fmt(g.rate())+' / s',Vector2(view.x/2 if compact else center.x,value_y+20),11,MINT)
	var outer=radius
	var inner=maxf(28,outer*0.23)
	var band=(outer-inner)/10
	for i in range(3):draw_arc(center,outer+10+i*9,0,TAU,128,Color(0.16,0.23,0.31,0.6-i*.16),1,true)
	for i in range(72):
		var a=i*TAU/72-PI/2;var rr=outer+15
		line(center+Vector2(cos(a),sin(a))*rr,center+Vector2(cos(a),sin(a))*(rr+(5 if i%6==0 else 2)),Color('#405166') if i%6==0 else Color('#25364a'))
	for p in [Vector2(-1,0),Vector2(1,0),Vector2(0,-1),Vector2(0,1)]:line(center+p*(outer+29),center+p*(outer+38),Color('#496173'),1)
	for i in range(9,-1,-1):
		var rr=inner+i*band
		var color_=Color(Sim.COLORS[i]);var width=maxf(3,band*0.52)
		draw_arc(center,rr,-PI/2,TAU-PI/2,100,Color('#1b2c3f'),width,true)
		if g.levels[i]>0:
			var end=g.phases[i]*TAU-PI/2
			if not g.reduced:draw_arc(center,rr,-PI/2,end,80,Color(color_,0.08),width+8,true)
			draw_arc(center,rr,-PI/2,end,80,color_,width,true)
			var point=center+Vector2(cos(end),sin(end))*rr
			draw_circle(point,width*.64,Color('#edf2ed'));draw_circle(point,width*.42,color_.lightened(.28))
			if rings_flash[i]>0:draw_arc(center,rr,0,TAU,96,Color(color_,rings_flash[i]*.34),width+3,true)
		else:
			draw_arc(center,rr,-PI/2,-PI/2+0.07,3,Color(color_,.25),width,true)
	draw_circle(center,maxf(21,inner-12),Color('#112436'))
	draw_circle(center,maxf(21,inner-12),Color('#3c5d6b'),false,1,true)
	if g.heat>0:draw_arc(center,minf(34,inner-3),-PI/2,-PI/2+TAU*g.heat/100,48,Color('#dba96b'),1.6,true)
	if not g.reduced:
		for j in range(3):
			var a=t*.12+j*TAU/3;var p=center+Vector2(cos(a),sin(a))*(outer+25);draw_circle(p,1.8,Color('#74b9bd'))
	if impact>0:draw_arc(center,outer+15+(1-impact)*18,0,TAU,128,Color(MINT,impact*.35),1,true)
	if reveal>0:
		for j in range(4):draw_arc(center,(1-reveal)*(view.x*.7)+j*15,0,TAU,120,Color(MINT,reveal*.4),2,true)
	var bar_y=hero.end.y+2
	if compact and not landscape:bar_y=view.y-234
	if not compact:bar_y=view.y-72
	var bar_w=minf(hero.size.x-30,360);var bx=center.x-bar_w/2
	rounded(Rect2(bx,bar_y,bar_w,5),Color('#1d3042'),2)
	var progress=clampf(g.resonance/100,0,1)
	if progress>0:rounded(Rect2(bx,bar_y,bar_w*progress,5),MINT if g.burst<=0 else Color('#d8c58c'),2)
	centered(('RESONANCE  '+str(int(g.resonance))+'%') if g.burst<=0 else 'RESONANCE  ×3  '+('%.1f'%g.burst)+'s',Vector2(center.x,bar_y+20),10,MINT)
	if not compact:
		var progress_=clampf(log(1+g.run_earned)/log(1+10000000.0),0,1)
		text('∞',Vector2(view.x-291,view.y-118),19,Color('#b9a3df'))
		text(str(int(progress_*100))+'%',Vector2(view.x-265,view.y-119),13,DIM)
		rounded(Rect2(view.x-291,view.y-102,174,4),Color('#253447'),2);rounded(Rect2(view.x-291,view.y-102,174*progress_,4),Color('#ad9ace'),2)
		if g.trial>=0:text('CHAMBER '+str(g.trial+1),Vector2(view.x-291,view.y-78),11,Color('#c9ace4'))
	for p in particles:draw_circle(p.p,1.8,Color(p.col,clampf(p.life,0,1)))
	if g.paused:
		centered('PAUSED',Vector2(center.x,center.y+60),12,Color('#e4bd8c'))
	if g.trial>=0 and compact:centered('CHAMBER '+str(g.trial+1)+'  '+fmt(g.run_earned)+' / '+fmt(g.trial_goal),Vector2(view.x/2,hero.position.y+14),10,Color('#c4a6e1'))
	if toast_life>0 and popup=='':
		var tw=minf(view.x-32,font.get_string_size(toast,HORIZONTAL_ALIGNMENT_LEFT,-1,13).x+32)
		var ty=view.y-270 if compact else view.y-132
		rounded(Rect2(view.x/2-tw/2,ty,tw,36),Color('#203b46'),10);centered(toast,Vector2(view.x/2,ty+23),13,Color('#d3e9dc'))

func save_game():
	if qa_fixture:return
	var data=JSON.stringify(g.snapshot())
	if OS.has_feature('web'):JavaScriptBridge.eval('try{localStorage.setItem("'+SAVE+'",'+JSON.stringify(data)+')}catch(e){window.spectrumSaveError=true}')
	else:
		var file=FileAccess.open('user://spectrum.json',FileAccess.WRITE)
		if file:file.store_string(data)
func load_game():
	var raw=''
	if OS.has_feature('web'):raw=str(JavaScriptBridge.eval('(function(){try{return localStorage.getItem("'+SAVE+'")||""}catch(e){return ""}})()'))
	elif FileAccess.file_exists('user://spectrum.json'):raw=FileAccess.get_file_as_string('user://spectrum.json')
	if raw=='':return
	var json=JSON.new()
	if json.parse(raw)!=OK:return
	if g.restore(json.data) and g.started and not g.paused:
		var elapsed=Time.get_unix_time_from_system()-float(json.data.get('saved',Time.get_unix_time_from_system()))
		if elapsed>5:offline_gain=g.offline(elapsed)
func export_save():
	var data=JSON.stringify(g.snapshot())
	if OS.has_feature('web'):
		JavaScriptBridge.eval('(()=>{const a=document.createElement("a");a.href=URL.createObjectURL(new Blob(['+JSON.stringify(data)+'],{type:"application/json"}));a.download="spectrum-zero-save.json";a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000)})()')
	else:
		var file=FileAccess.open('user://spectrum-export.json',FileAccess.WRITE)
		if file:file.store_string(data)
func web_event(args):
	if args.size()==0:return
	var a=str(args[0])
	if a=='away':away_at=Time.get_unix_time_from_system();tab_hidden=true;save_game()
	if a=='back':
		tab_hidden=false
		if away_at>0 and g.started and not g.paused:
			var amount=g.offline(Time.get_unix_time_from_system()-away_at)
			if amount>0:notify('Welcome back  +'+fmt(amount))
		away_at=0;save_game()
	if a=='save':save_game()
func web_snapshot():
	if not OS.has_feature('web'):return
	var rows=[]
	for b in buttons+modal_buttons:
		if not is_instance_valid(b) or not b.is_visible_in_tree():continue
		var r=b.get_global_rect();rows.append({'id':b.get_meta('id'),'action':b.get_meta('action'),'n':b.get_meta('n'),'x':r.position.x/ui_scale,'y':r.position.y/ui_scale,'w':r.size.x/ui_scale,'h':r.size.y/ui_scale,'disabled':b.disabled,'tooltip':b.tooltip_text})
	var s={'energy':g.energy,'run':g.run_earned,'rate':g.rate(),'levels':g.levels,'phases':g.phases,'prisms':g.prisms,'cores':g.cores,'refractions':g.refractions,'infinities':g.infinities,'modules':g.modules,'generators':g.generators,'flux':g.flux,'claims':g.claims,'stars':g.stars(),'resonance':g.resonance,'burst':g.burst,'started':g.started,'paused':g.paused,'muted':g.muted,'reduced':g.reduced,'auto':g.auto,'trial':g.trial,'trial_done':g.trial_done,'trials':g.trials,'seconds':g.seconds,'popup':popup,'buttons':rows,'view':[view.x,view.y]}
	JavaScriptBridge.eval('window.spectrumSnapshot && window.spectrumSnapshot('+JSON.stringify(s)+')')
func _unhandled_key_input(event):
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode==KEY_ESCAPE and popup!='welcome':close_popup()
		elif event.keycode==KEY_SPACE and popup=='':command('tap')
		elif event.keycode==KEY_M and popup=='':command('max')

