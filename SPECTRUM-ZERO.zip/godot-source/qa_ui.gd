extends SceneTree
const Main=preload('res://main.gd')
var game
func _initialize():
	game=Main.new();game.qa_fixture=true;root.add_child(game);call_deferred('check')
func check():
	game.close_popup();game.g.started=true;game.g.trial=2;game.g.resonance=100
	var before=game.g.energy;game.command('tap')
	assert(game.g.energy>before and game.g.burst==0,'Manual chamber must still allow taps when resonance is full')
	game.g.trial=0;game.g.resonance=0;game.g.tap_cooldown=0;before=game.g.energy;game.command('tap')
	assert(game.g.energy==before,'Quiet chamber must block taps')
	game.g.resonance=100;game.command('tap');assert(game.g.burst>0,'Quiet chamber still allows resonance')
	game.g.trial=-1;game.g.run_earned=100000;game.command('prestige-view')
	assert(game.popup=='prestige-view')
	var found=false
	for b in game.modal_buttons:
		if b.get_meta('id')=='next-infinity':found=true
	assert(found,'Phone users must have access to the second reset layer')
	game.command('prestige');assert(game.g.prisms>0 and game.popup=='')
	game.command('settings');found=false
	for b in game.modal_buttons:
		if b.get_meta('id')=='setting-automation':found=true
	assert(found,'Phone users must have access to autopilot')
	game.command('reset-confirm');assert(game.g.started==false and game.last_event==0,'Fresh game must restore feedback event processing')
	var narrow=SubViewport.new();narrow.size=Vector2i(320,667);root.add_child(narrow)
	var phone=Main.new();phone.qa_fixture=true;narrow.add_child(phone);phone.open_popup('automation')
	var checked=false
	for label in phone.modal_ui.find_children('*','Label',true,false):
		if label.text.begins_with('Upgrades chosen'):
			assert(label.size.x<280,'Phone paragraph width must not expand to its unwrapped minimum')
			assert(label.get_line_count()>=3,'Phone paragraph must wrap into readable lines')
			checked=true
	assert(checked)
	print('PASS: native command routing, all three chamber tap/boost rules, second-layer access, autopilot access and reset feedback')
	quit()
