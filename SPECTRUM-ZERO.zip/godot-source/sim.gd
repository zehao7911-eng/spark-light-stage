extends RefCounted

const COLORS=['#fa746e','#f3a75d','#e4ce69','#a8d975','#6cddb1','#67cddd','#7c9cf4','#ac8ae6','#e194c9','#e6e8ed']
const COSTS=[5.0,10.0,65.0,320.0,1600.0,8000.0,40000.0,200000.0,1000000.0,5000000.0]
const SPEEDS=[0.25,0.17,0.13,0.10,0.08,0.06,0.048,0.037,0.030,0.025]
const VALUES=[1.0,3.0,12.0,45.0,170.0,650.0,2400.0,9000.0,36000.0,140000.0]
const MODULES=['Amplifier','Flywheel','Overdrive','Starter','Autobuyer','Star lens']
const MOD_DESC=['+35% all production','+12% cycle speed','Longer resonance bursts','Start with more energy','Unlock automatic upgrades','More power from stars']
const BADGES=[['First light',0,10.0],['A little faster',1,10.0],['Full spectrum',2,10.0],['A thousand turns',3,1000.0],['First refraction',4,1.0],['Ten refractions',4,10.0],['Millionaire',0,1000000.0],['Into infinity',5,1.0],['Starlight',6,10.0],['Synchronized',7,10.0],['Engineer',8,12.0],['Beyond',5,5.0]]
var energy=12.0
var run_earned=0.0
var lifetime=0.0
var levels=[1,0,0,0,0,0,0,0,0,0]
var phases=[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]
var laps=[0,0,0,0,0,0,0,0,0,0]
var all_laps=0
var prisms=0
var prism_total=0
var refractions=0
var cores=0
var core_total=0
var infinities=0
var modules=[0,0,0,0,0,0]
var generators=[0,0,0,0]
var flux=[0.0,0.0,0.0,0.0]
var claims=[]
var trials=[false,false,false]
var trial=-1
var trial_clock=0.0
var trial_goal=0.0
var trial_best=[0.0,0.0,0.0]
var trial_done=false
var resonance=0.0
var burst=0.0
var bursts=0
var heat=0.0
var tap_cooldown=0.0
var event_id=0
var events=[]
var auto=false
var auto_clock=0.0
var buy_mode=1
var seconds=0.0
var started=false
var paused=false
var muted=false
var reduced=false
var upgrades_bought=0

func unlocked_count():
	var n=0
	for level in levels:
		if level>0:n+=1
	return n
func stars():return int(sqrt(float(all_laps)/80.0))
func multiplier():
	var power=(1.0+prism_total*0.45)*(1.0+core_total*1.6)
	power*=1.0+modules[0]*0.35
	power*=1.0+stars()*(0.025+modules[5]*0.012)
	var mult=1.0
	for i in range(10):mult*=1.0+log(1.0+laps[i])*0.085
	for j in range(3):
		if trials[j]:power*=1.25
	power*=1.0+flux[0]*0.012
	return minf(1e150,power*mult)
func speed(i):
	var s=SPEEDS[i]*(1.0+maxi(0,levels[i]-1)*0.07)*(1+modules[1]*0.12)
	if trial==1:s*=0.65
	return s
func value(i):
	return VALUES[i]*pow(1.24,maxi(0,levels[i]-1))*multiplier()
func rate():
	var total=0.0
	for i in range(10):
		if levels[i]>0:total+=speed(i)*value(i)
	return total*(3.0 if burst>0 else 1.0)
func cost(i):
	return COSTS[i]*pow(1.43,maxi(0,levels[i]-1))
func can_unlock(i):return i==0 or levels[i-1]>0
func module_cost(i):return [1,1,2,2,3,2][i]+modules[i]*[1,1,2,2,2,2][i]
func gen_cost(i):return [1,2,4,7][i]*(generators[i]+1)
func prestige_gain():return int(minf(1000000,sqrt(maxf(0,run_earned)/10000.0)))
func infinity_gain():return int(minf(1000000,pow(maxf(0,run_earned)/10000000.0,0.35)))
func emit(kind,n=0,value_=0.0):
	event_id+=1
	if events.size()<40:events.append({'id':event_id,'kind':kind,'n':n,'value':value_})
func earn(amount):
	if amount<=0 or not is_finite(amount):return
	energy=minf(1e200,energy+amount);run_earned=minf(1e200,run_earned+amount);lifetime=minf(1e200,lifetime+amount)
func buy(i,count_=1):
	if i<0 or i>=10 or not can_unlock(i) or levels[i]>=60:return 0
	var bought=0
	for j in range(mini(count_,60-levels[i])):
		var price=cost(i)
		if energy+1e-8<price:break
		energy=maxf(0,energy-price);levels[i]+=1;bought+=1;upgrades_bought+=1
	if bought>0:emit('buy',i,bought)
	return bought
func buy_best():
	# Newly available spectrum rings get a chance before ROI upgrades consume the bank.
	for i in range(10):
		if levels[i]==0 and can_unlock(i) and energy>=cost(i):buy(i,1);return
	var best=-1;var score=INF
	for i in range(10):
		if levels[i]==0 or levels[i]>=60 or energy<cost(i):continue
		var gain=speed(i)*value(i)*0.30
		var roi=cost(i)/maxf(0.01,gain)
		if roi<score:score=roi;best=i
	if best>=0:buy(best,1)
func buy_all():
	for j in range(120):
		var old=upgrades_bought;buy_best()
		if old==upgrades_bought:break
func tap():
	if not started or paused or trial==0 or tap_cooldown>0 or heat>=94:return false
	tap_cooldown=0.09;heat=minf(100,heat+14)
	var gain=maxf(1.0,rate()*0.20)
	earn(gain);resonance=minf(100,resonance+2);emit('tap',0,gain);return true
func activate():
	if resonance<100 or burst>0 or trial==2:return false
	resonance=0;burst=6.0+modules[2]*1.5;bursts+=1;emit('burst');return true
func reset_run():
	energy=12+modules[3]*150;run_earned=0.0;levels=[1,0,0,0,0,0,0,0,0,0];phases.fill(0.0);laps.fill(0)
	resonance=0;burst=0;heat=0;tap_cooldown=0
func refract():
	if trial>=0:return 0
	var gain=prestige_gain()
	if gain<1:return 0
	prisms+=gain;prism_total+=gain;refractions+=1;reset_run();emit('prestige',0,gain);return gain
func infinity():
	if trial>=0:return 0
	var gain=infinity_gain()
	if gain<1:return 0
	cores+=gain;core_total+=gain;infinities+=1;prisms=0;reset_run();emit('infinity',0,gain);return gain
func badge_value(kind):
	match kind:
		0:return lifetime
		1:
			var total=0
			for n in levels:total+=n
			return total
		2:return unlocked_count()
		3:return all_laps
		4:return refractions
		5:return infinities
		6:return stars()
		7:return bursts
		8:
			var n=0
			for m in modules:n+=m
			return n
	return 0
func badge_ready(i):return i not in claims and badge_value(BADGES[i][1])>=BADGES[i][2]
func claim(i):
	if i<0 or i>=BADGES.size() or not badge_ready(i):return false
	claims.append(i);var gain=maxf(20*(i+1),rate()*12);earn(gain);emit('badge',i,gain);return true
func action(a,n=0):
	if a=='start':started=true;return true
	if a=='pause':paused=not paused;return true
	if a=='sound':muted=not muted;return true
	if a=='motion':reduced=not reduced;return true
	if a=='mode':buy_mode=n;return true
	if not started:return false
	if a=='buy':return buy(n,buy_mode)>0
	if a=='max':buy_all();return true
	if a=='burst':return activate()
	if a=='tap':return tap()
	if a=='prestige':return refract()>0
	if a=='infinity':return infinity()>0
	if a=='claim':return claim(n)
	if a=='auto' and modules[4]>0:auto=not auto;return true
	if a=='module' and n>=0 and n<6 and modules[n]<5 and prisms>=module_cost(n):
		prisms-=module_cost(n);modules[n]+=1;emit('module',n);return true
	if a=='generator' and n>=0 and n<4 and (n==0 or generators[n-1]>0) and cores>=gen_cost(n):
		cores-=gen_cost(n);generators[n]+=1;emit('module',n);return true
	if a=='trial' and refractions>0 and trial<0 and n>=0 and n<3:
		trial=n;trial_goal=[30000.0,70000.0,160000.0][n];trial_clock=0;trial_done=false;reset_run();emit('trial',n);return true
	if a=='exit-trial' and trial>=0:
		trial=-1;trial_done=false;reset_run();return true
	return false
func step(dt):
	if not started or paused or dt<=0:return
	seconds+=dt;heat=maxf(0,heat-dt*19);tap_cooldown=maxf(0,tap_cooldown-dt)
	if trial>=0:trial_clock+=dt
	var remaining=dt
	# Split at burst expiration so away gains never extend a short boost over a long absence.
	while remaining>0.00001:
		var chunk=remaining
		if burst>0:chunk=minf(chunk,burst)
		var time_mult=3.0 if burst>0 else 1.0
		for i in range(10):
			if levels[i]<=0:continue
			var turns=phases[i]+chunk*speed(i)*time_mult
			var count=int(floor(turns));phases[i]=fmod(turns,1.0)
			if count>0:
				earn(value(i)*count);laps[i]+=count;all_laps+=count;resonance=minf(100,resonance+count*(1.0+modules[2]*0.1));emit('lap',i,count)
		if burst>0:burst=maxf(0,burst-chunk)
		remaining-=chunk
	# A chain: upper generators feed the next lower generator, whose flux amplifies the rings.
	for i in range(3,-1,-1):
		flux[i]+=dt*generators[i]*0.02*(1.0+(flux[i+1]*0.02 if i<3 else 0))
	if auto and modules[4]>0 and trial!=2:
		auto_clock+=dt
		if auto_clock>=maxf(0.3,2.5-modules[4]*0.4):auto_clock=0;buy_best()
	if trial>=0 and not trial_done and run_earned>=trial_goal:
		trials[trial]=true;trial_done=true
		if trial_best[trial]<=0 or trial_clock<trial_best[trial]:trial_best[trial]=trial_clock
		emit('trial-win',trial,trial_clock)
func offline(elapsed):
	var capped=clampf(elapsed,0,7200)
	var before=energy
	# 1-second steps preserve autobuyer decisions and boosts, bounded to two hours.
	for i in range(int(capped)):step(1.0);events.clear()
	return maxf(0,energy-before)
func snapshot():
	return {'v':1,'energy':energy,'run_earned':run_earned,'lifetime':lifetime,'levels':levels,'phases':phases,'laps':laps,'all_laps':all_laps,'prisms':prisms,'prism_total':prism_total,'refractions':refractions,'cores':cores,'core_total':core_total,'infinities':infinities,'modules':modules,'generators':generators,'flux':flux,'claims':claims,'trials':trials,'trial':trial,'trial_clock':trial_clock,'trial_goal':trial_goal,'trial_best':trial_best,'trial_done':trial_done,'resonance':resonance,'burst':burst,'bursts':bursts,'heat':heat,'tap_cooldown':tap_cooldown,'auto':auto,'auto_clock':auto_clock,'buy_mode':buy_mode,'seconds':seconds,'started':started,'paused':paused,'muted':muted,'reduced':reduced,'upgrades_bought':upgrades_bought,'saved':Time.get_unix_time_from_system()}
func restore(d):
	if typeof(d)!=TYPE_DICTIONARY or int(d.get('v',0))!=1:return false
	for pair in [['levels',10],['phases',10],['laps',10],['modules',6],['generators',4],['flux',4],['trials',3],['trial_best',3]]:
		if typeof(d.get(pair[0]))!=TYPE_ARRAY or d[pair[0]].size()!=pair[1]:return false
	if typeof(d.get('claims'))!=TYPE_ARRAY:return false
	for k in d:
		if k not in ['v','saved']:set(k,d[k])
	for arr in [levels,laps,modules,generators,claims]:
		for i in range(arr.size()):arr[i]=int(arr[i])
	for k in ['all_laps','prisms','prism_total','refractions','cores','core_total','infinities','trial','bursts','buy_mode','upgrades_bought']:set(k,int(get(k)))
	energy=maxf(0,energy)
	for i in range(10):levels[i]=clampi(levels[i],0,60);phases[i]=clampf(float(phases[i]),0,0.9999999)
	return true
