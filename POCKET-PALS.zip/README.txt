POCKET PALS
An unofficial Pokemon fan puzzle.

Open index.html, or host this folder on any static web server.
No installation, external CDN, or internet connection is needed after download.

Tap an arrow between four buddies to rotate them together.
Match every buddy to its habitat color. Use the top arrow to switch direction.
Undo, reset, and a shortest-path hint are available at any time.
Earn up to three friendship stars per meetup and unlock evolved buddies.
Choose your unlocked buddies in the collection. Progress saves on this device.

120 carefully verified starting puzzles, followed by advanced remixed meetups.
English interface. Touch, mouse, and keyboard buttons. Portrait and landscape.
Sound starts after interaction; toggle the music-note button to mute.

Pokemon and character names belong to their respective owners.
This fan project is not affiliated with or endorsed by The Pokemon Company.
