TINY RAILWAY — A Town in Motion

Open tiny-railway.html in a modern browser. Keep the HTML, CSS, JavaScript and WebP image in one folder.

Tap the gold switches to route each colored train to the station with the matching name, icon and color. Deliver eight trains to finish a day. The stations move and trains speed up each new day. A delivery grows flowers in the miniature town. Three wrong deliveries end the run; press Try Again to restart.

Made for touchscreens and desktop browsers. Sound can be toggled in the top right.
No purchases, wagering or real-money features.
