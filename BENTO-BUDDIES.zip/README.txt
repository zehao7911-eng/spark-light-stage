BENTO BUDDIES
A little box of happy.

PLAY
Drag the food buddies into the lunchbox. Every buddy must fit, with no overlaps.
Fill the whole box to pack a happy lunch. The shapes keep their orientation.
You can also tap a buddy, then tap the cell for its first topmost square.
Move packed buddies whenever you want. Drag one outside the box to unpack it.
HINT reveals a useful placement. If needed, it first makes space for a solution.
The arrow at the top unpacks the current lunchbox. There are no timers or lives.

REWARDS
Every three completed lunches unlock another picnic style.
Open PICNIC STYLES to use an unlocked palette. Six styles change the game colors.
Lunchbox progress, rewards, the selected style and sound preference save locally.

CONTENTS
120 generated, verified puzzle layouts with a rising difficulty curve:
1-5: 3x3, three buddies. 6-12: 4x4, four buddies.
13-24: 4x5, five buddies. 25-44: 5x5, larger irregular buddies.
45-72: 5x6, six buddies. 73 onward: 6x6, six complex buddies.
After the first set, mirrored advanced layouts keep the picnic going without
returning to the introductory levels. There is no final level screen.
Six original food buddies, magnetic previews, squash-and-stretch, cheerful
expressions, synthesized chimes, a closing lunchbox lid and confetti.

RUN
Extract the ZIP and open index.html, or serve the folder from a static web host.
Upload the ZIP with index.html at its root to an HTML5 game platform.
All art and audio are generated in code. No CDN, account or network is needed.
Sound starts after a player interaction; it can be switched off with the note.

TECHNICAL
Standalone HTML5, Canvas 2D, CSS and JavaScript. No external dependencies.
Touch/pointer dragging, tap-to-place and keyboard-accessible target buttons.
Responsive portrait and landscape layouts, safe-area spacing, a capped pixel
ratio, reduced-motion support and animation suspension when the tab is hidden.

VALIDATION
Verified 1,200 puzzle selections, connected shapes and
complete board coverage. Tested drag/tap controls, invalid drops, hints,
completion, reward unlocks, palette switching and progress after reload.
Layouts checked at 320x568, 390x844, 844x390 and 1440x900.
Mobile viewport tests are browser simulations rather than physical-device tests.
