extends Node2D

const NAMES = ['Plaster','Brick','Timber','Tile roof','Flat roof','Window','Shutters','Door','Awning','Balcony','Air unit','Pipe','Planter','Climber','Tree','Bench','Bicycle','Laundry','Lamp','Cat','Chimney','Fence','Steps','Flowers']
const WALLS = ['#e9d8ad','#d9977b','#9db8af','#b6b1c5']
var pieces = []
var undo_stack = []
var redo_stack = []
var chosen = 0
var paint = 0
var tool = 'build'
var theme = 0
var evening = false
var muted = false
var time = 0.0
var camera_x = 240.0
var magnify = 1.0
var zoom = 1.0
var origin = Vector2.ZERO
var hover = Vector2(-999,-999)
var pointer_start = Vector2.ZERO
var drag_id = -1
var dragging = false
var before_drag = []
var event_id = 0
var notice = 'Choose a piece. Tap your little world.'
var callback
var sync = 0.0
var photographing = false
var world: SubViewport
var burst_fx = []

func _ready():
	world = SubViewport.new()
	world.size = Vector2i(480,300)
	world.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	world.transparent_bg = false
	add_child(world)
	var painter = Node2D.new()
	painter.set_script(preload('res://painter.gd'))
	painter.game = self
	world.add_child(painter)
	load_game()
	if OS.has_feature('web'):
		callback = JavaScriptBridge.create_callback(web_action)
		JavaScriptBridge.get_interface('window').sAction = callback
	if '--qa' in OS.get_cmdline_user_args(): verify()

func starter():
	pieces = []
	for x in [152,184,216]:
		for y in [198,230]: pieces.append({'id':0,'x':x,'y':y,'c':0})
	for x in [152,184,216]: pieces.append({'id':3,'x':x,'y':166,'c':0})
	for x in [152,216]:
		pieces.append({'id':6,'x':x,'y':198,'c':2})
		pieces.append({'id':12,'x':x,'y':204,'c':0})
	pieces.append({'id':7,'x':184,'y':230,'c':2})
	pieces.append({'id':8,'x':216,'y':230,'c':0})
	pieces.append({'id':5,'x':216,'y':230,'c':1})
	for x in [248,280]:
		pieces.append({'id':1,'x':x,'y':230,'c':1})
		pieces.append({'id':4,'x':x,'y':198,'c':0})
		pieces.append({'id':5,'x':x,'y':229,'c':0})
		pieces.append({'id':12,'x':x,'y':195,'c':0})
	pieces.append({'id':9,'x':264,'y':191,'c':0})
	pieces.append({'id':10,'x':241,'y':217,'c':0})
	pieces.append({'id':11,'x':296,'y':226,'c':0})
	pieces.append({'id':13,'x':132,'y':228,'c':1})
	pieces.append({'id':14,'x':335,'y':231,'c':0})
	pieces.append({'id':15,'x':332,'y':239,'c':0})
	pieces.append({'id':16,'x':123,'y':234,'c':2})
	pieces.append({'id':17,'x':270,'y':174,'c':0})
	pieces.append({'id':20,'x':216,'y':151,'c':0})
	pieces.append({'id':22,'x':184,'y':237,'c':0})
	for x in [72,104,368,400]: pieces.append({'id':21,'x':x,'y':232,'c':0})
	for x in [90,114,307,368]: pieces.append({'id':23,'x':x,'y':237,'c':0})
	pieces.append({'id':19,'x':321,'y':233,'c':0})
	pieces.append({'id':18,'x':305,'y':232,'c':0})

func web_action(args):
	if args.size(): action(str(args[0]))

func action(command):
	var b = command.split(':')
	var v = int(b[1]) if b.size()>1 else 0
	match b[0]:
		'piece': chosen = clampi(v,0,23); tool = 'build'; notice = NAMES[chosen]+' · tap to place'
		'paint': paint = clampi(v,0,3)
		'tool': tool = b[1]; drag_id = -1
		'enddrag':
			if drag_id>=0 and dragging:
				undo_stack.append(before_drag); redo_stack.clear(); save_game()
			drag_id = -1; dragging = false
		'undo':
			if undo_stack.size(): redo_stack.append(pieces.duplicate(true)); pieces = undo_stack.pop_back(); notice = 'A little step back.'; save_game()
		'redo':
			if redo_stack.size(): undo_stack.append(pieces.duplicate(true)); pieces = redo_stack.pop_back(); save_game()
		'theme': theme = posmod(v,3); save_game()
		'light': evening = not evening; save_game()
		'sound': muted = not muted; save_game()
		'zoom': magnify = clampf(magnify+v*0.2,0.7,1.8)
		'home': camera_x = 240; magnify = 1
		'photo': photo()
		'reset': checkpoint(); starter(); save_game()
	push_state()

func checkpoint():
	undo_stack.append(pieces.duplicate(true))
	if undo_stack.size()>60: undo_stack.pop_front()
	redo_stack.clear()

func put(pos):
	if pieces.size()>=350: notice = 'This little world is full. Move or remove a piece.'; return
	checkpoint()
	var p = snap(pos)
	# Replace only identical layers at identical anchors; decoration can overlap a facade.
	for i in range(pieces.size()-1,-1,-1):
		var item = pieces[i]
		if item.id == chosen and Vector2(item.x,item.y).distance_to(p)<3: pieces.remove_at(i)
	pieces.append({'id':chosen,'x':p.x,'y':p.y,'c':paint})
	event_id += 1
	for i in range(10): burst_fx.append({'pos':p+Vector2(randf_range(-14,14),4),'vel':Vector2(randf_range(-10,10),randf_range(-25,-12)),'life':0.7})
	notice = ['A place for slow afternoons.','Looking lived-in.','One little detail at a time.','Make yourself at home.'][event_id%4]
	save_game()

func snap(p,id=-1):
	var part = chosen if id<0 else id
	var step = 32 if part<=4 else 4
	var off = Vector2(24,6) if part<=4 else Vector2(0,2)
	return Vector2(clampf(round((p.x-off.x)/step)*step+off.x,-80,560),clampf(round((p.y-off.y)/step)*step+off.y,50,244))

func hit(p):
	for i in range(pieces.size()-1,-1,-1):
		var q = pieces[i]
		if Rect2(q.x-18,q.y-23,40,34).has_point(p): return i
	return -1

func screen_world(p): return Vector2((p.x-origin.x)/zoom+camera_x-240,(p.y-origin.y)/zoom)

func _unhandled_input(e):
	if e is InputEventMouseButton:
		if e.button_index == MOUSE_BUTTON_WHEEL_UP and e.pressed: action('zoom:1')
		elif e.button_index == MOUSE_BUTTON_WHEEL_DOWN and e.pressed: action('zoom:-1')
		elif e.button_index == MOUSE_BUTTON_LEFT:
			if e.position.y<60 or e.position.y>get_viewport_rect().size.y-(156 if get_viewport_rect().size.x<600 else 132): return
			var p = screen_world(e.position)
			if e.pressed:
				pointer_start = e.position; dragging = false; hover = p
				if tool == 'move': drag_id = hit(p); before_drag = pieces.duplicate(true)
			else:
				if tool == 'build' and not dragging: put(p)
				elif tool == 'erase':
					var i = hit(p)
					if i>=0: checkpoint(); pieces.remove_at(i); event_id+=1; save_game()
				elif tool == 'move' and drag_id>=0 and dragging:
					undo_stack.append(before_drag); redo_stack.clear(); save_game()
				drag_id = -1; push_state()
	if e is InputEventMouseMotion:
		hover = screen_world(e.position)
		if e.button_mask & MOUSE_BUTTON_MASK_LEFT:
			if e.position.distance_to(pointer_start)>6: dragging = true
			if dragging:
				if tool == 'move' and drag_id>=0:
					var target = snap(hover,int(pieces[drag_id].id))
					pieces[drag_id].x = target.x; pieces[drag_id].y = target.y
				else: camera_x = clampf(camera_x-e.relative.x/zoom,80,400)
	if e is InputEventKey and e.pressed and not e.echo and not e.ctrl_pressed and not e.meta_pressed:
		if e.keycode == KEY_Z: action('undo')
		if e.keycode == KEY_Y: action('redo')
		if e.keycode == KEY_ESCAPE: tool = 'pan'

func _process(dt):
	time += dt
	for f in burst_fx: f.life -= dt; f.pos += f.vel*dt
	burst_fx = burst_fx.filter(func(f): return f.life>0)
	var size = get_viewport_rect().size
	var bottom = 156 if size.x<600 else 132
	zoom = minf(size.x/(280.0 if size.x<600 else 480.0),(size.y-60-bottom)/300.0)*magnify
	origin = Vector2((size.x-480*zoom)/2,60+(size.y-60-bottom-300*zoom)/2)
	if size.y<450:
		zoom = minf(size.x/480.0,(size.y-60-bottom)/150.0)*magnify
		origin = Vector2((size.x-480*zoom)/2,60+(size.y-60-bottom)*0.5-190*zoom)
	world.get_child(0).queue_redraw()
	sync += dt
	if sync>.2: sync = 0; push_state()
	queue_redraw()

func _draw():
	draw_rect(get_viewport_rect(),Color('#ede7d5'))
	draw_texture_rect(world.get_texture(),Rect2(origin,Vector2(480,300)*zoom),false)

func push_state():
	if OS.has_feature('web'):
		JavaScriptBridge.eval('window.sState&&window.sState('+JSON.stringify({'chosen':chosen,'paint':paint,'tool':tool,'theme':theme,'evening':evening,'muted':muted,'count':pieces.size(),'undo':undo_stack.size(),'redo':redo_stack.size(),'event':event_id,'notice':notice,'view':{'origin':[origin.x,origin.y],'zoom':zoom,'camera':camera_x},'lastPiece':pieces.back() if pieces.size() else {}})+');')

func save_game():
	var s = JSON.stringify({'version':1,'pieces':pieces,'theme':theme,'evening':evening,'muted':muted})
	FileAccess.open('user://sunroom.json',FileAccess.WRITE).store_string(s)
	if OS.has_feature('web'): JavaScriptBridge.eval('try{localStorage.setItem("sunroom-v1",'+JSON.stringify(s)+')}catch(e){}')

func load_game():
	var s = ''
	if OS.has_feature('web'):
		var result = JavaScriptBridge.eval('localStorage.getItem("sunroom-v1")||""')
		if result: s = str(result)
	elif FileAccess.file_exists('user://sunroom.json'): s = FileAccess.get_file_as_string('user://sunroom.json')
	var d = JSON.parse_string(s) if not s.is_empty() else null
	if d is Dictionary and d.get('pieces') is Array:
		for p in d.pieces:
			if p is Dictionary and (p.get('id') is float or p.get('id') is int) and (p.get('x') is float or p.get('x') is int) and (p.get('y') is float or p.get('y') is int) and (p.get('c') is float or p.get('c') is int):
				pieces.append({'id':clampi(int(p.id),0,23),'x':clampf(p.x,-80,560),'y':clampf(p.y,50,244),'c':clampi(int(p.c),0,3)})
				if pieces.size()>=350: break
		theme = clampi(int(d.get('theme',0)),0,2); evening = bool(d.get('evening',false)); muted = bool(d.get('muted',false))
	else: starter()

func photo():
	if OS.has_feature('web'):
		photographing = true
		await RenderingServer.frame_post_draw
		var data = Marshalls.raw_to_base64(world.get_texture().get_image().save_png_to_buffer())
		JavaScriptBridge.eval('window.sPhoto&&window.sPhoto('+JSON.stringify(data)+');')
		photographing = false

func verify():
	starter(); var n = pieces.size(); chosen = 0; put(Vector2(350,170)); assert(pieces.size()==n+1)
	action('undo'); assert(pieces.size()==n); action('redo'); assert(pieces.size()==n+1)
	put(Vector2(350,170)); assert(pieces.size()==n+1)
	chosen = 12; put(Vector2(350,170)); assert(pieces.size()==n+2)
	assert(hit(Vector2(350,170))>=0)
	pieces=[]; starter(); save_game(); var saved=pieces.duplicate(true); pieces=[]; load_game(); assert(pieces.size()==saved.size())
	for i in range(pieces.size()):
		for k in ['id','x','y','c']: assert(float(pieces[i][k])==float(saved[i][k]))
	print('SUNROOM QA PASS: placement, same-layer replacement, decoration overlap, undo, redo, hit, save reload')
	get_tree().quit()
