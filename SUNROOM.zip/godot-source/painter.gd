extends Node2D
var game
var rng = RandomNumberGenerator.new()
const INK = '#59695c'

func r(x,y,w,h,c): draw_rect(Rect2(floor(x),floor(y),ceil(w),ceil(h)),Color(c))
func line(a,b,c,w=1): draw_line(a,b,Color(c),w,false)
func poly(points,c): draw_colored_polygon(PackedVector2Array(points),Color(c))
func _draw():
	var g = game
	var sky = ['#b8d7d5','#a9c8bc','#dab5b4'][g.theme]
	r(0,0,480,300,sky)
	for i in range(5):
		var x = fmod(i*114+g.time*0.45,620)-70
		r(x,35+i%3*17,56,3,'#e8e4cc'); r(x+10,31+i%3*17,28,4,'#e8e4cc'); r(x+20,28+i%3*17,15,3,'#e8e4cc')
	poly([Vector2(0,170),Vector2(0,132),Vector2(40,121),Vector2(69,139),Vector2(115,94),Vector2(150,120),Vector2(195,86),Vector2(251,145),Vector2(284,127),Vector2(340,148),Vector2(400,109),Vector2(480,138),Vector2(480,180)],'#8cae9f')
	poly([Vector2(92,121),Vector2(115,94),Vector2(151,121),Vector2(127,113),Vector2(117,105),Vector2(112,115)],'#d5d9c5')
	poly([Vector2(164,115),Vector2(195,86),Vector2(227,121),Vector2(205,110),Vector2(194,99),Vector2(185,113)],'#d5d9c5')
	if g.theme == 0:
		r(0,165,480,70,'#85b6b3')
		for i in range(80):
			var x = posmod(i*173,480); var y = 169+posmod(i*31,65)
			r(x+sin(g.time+i)*2,y,4+i%16,1,'#b7cdc0' if i%3 else '#6da7aa')
	else:
		poly([Vector2(0,155),Vector2(100,147),Vector2(240,177),Vector2(400,144),Vector2(480,155),Vector2(480,255),Vector2(0,255)],'#9bab76')
		for i in range(15): tree(Vector2(i*43-50,185+i%3*7),0.42,false)
	r(0,239,480,61,'#a4ad79')
	for i in range(160): r(posmod(i*97,480),237+i%3,2,4,'#899c68')
	r(0,240,480,3,'#899867'); r(0,252,480,22,'#d6caab'); r(0,272,480,3,'#b9ad91')
	rng.seed = 8864
	for i in range(280):
		var x = rng.randi_range(0,480); var y = rng.randi_range(240,300)
		r(x,y,1+rng.randi()%3,1,'#c5be92' if y>274 else '#aaab77')
	# Entire scene uses one low resolution viewport and pixel coordinates.
	draw_set_transform(Vector2(240-g.camera_x,0))
	for i in range(7):
		var x = i*106-40
		r(x,238,32,2,'#9c9e6a')
	for p in g.pieces:
		if p.id in [0,1,2] and p.y>220: poly([Vector2(p.x-16,238),Vector2(p.x+24,238),Vector2(p.x+47,248),Vector2(p.x+2,248)],Color(.26,.35,.25,.12))
	var ordered = g.pieces.duplicate()
	ordered.sort_custom(func(a,b): return layer(a)<layer(b) if layer(a)!=layer(b) else a.y<b.y)
	for p in ordered:
		rng.seed = int(p.x*731+p.y*13+p.id*192)
		piece(int(p.id),Vector2(p.x,p.y),int(p.c))
	for i in range(3):
		var x = fmod(g.time*(3+i)+i*173,620)-60
		var y = 247+i%2*3
		person(Vector2(x,y),i)
	for i in range(4):
		var x = fmod(g.time*6+i*163,650)-80; var y = 70+sin(g.time+i)*4+i%2*14
		line(Vector2(x-3,y),Vector2(x,y+1),INK); line(Vector2(x,y+1),Vector2(x+3,y),INK)
	if g.tool=='build' and g.hover.x>-500 and not g.photographing:
		var p = g.snap(g.hover)
		r(p.x-18,p.y-24,36,35,Color(1,1,0.8,0.15)); draw_rect(Rect2(p.x-18,p.y-24,36,35),Color('#fcf1cb'),false,1)
	draw_set_transform(Vector2.ZERO)
	if g.evening:
		r(0,0,480,300,Color(0.32,0.22,0.42,0.23))
		for p in ordered:
			if p.id in [5,6,18]:
				var x=p.x+240-g.camera_x; var y=p.y
				r(x-6,y-14,10,11,Color(1,0.77,0.39,0.7)); r(x-10,y-17,18,18,Color(1,0.8,0.4,0.07))

func layer(p):
	if p.id<=2: return 0
	if p.id in [3,4,20]: return 1
	return 2

func piece(id,p,c):
	var x=p.x; var y=p.y; var base = Color(game.WALLS[c]); var dark=base.darkened(0.22); var light=base.lightened(0.09)
	match id:
		0,1,2:
			r(x-16,y-24,32,32,base); r(x+16,y-24,8,32,dark)
			r(x-16,y-24,32,2,light); r(x-16,y+7,40,1,dark)
			for i in range(30):
				var a=rng.randi_range(-15,15); var b=rng.randi_range(-21,6)
				r(x+a,y+b,1+rng.randi()%3,1,base.darkened(0.06))
			if id==1:
				for j in range(5):
					r(x-16,y-20+j*6,32,1,dark.lightened(.1))
					for k in range(4): r(x-14+k*9+(j%2)*4,y-20+j*6,1,6,dark.lightened(.1))
			if id==2:
				for k in range(8): r(x-16+k*4,y-24,1,32,dark)
		3:
			poly([Vector2(x-20,y+8),Vector2(x-14,y-12),Vector2(x+16,y-12),Vector2(x+21,y+8)],'#c27b58')
			poly([Vector2(x+21,y+8),Vector2(x+16,y-12),Vector2(x+24,y-9),Vector2(x+29,y+8)],'#965c4b')
			for j in range(5):
				var yy=y-10+j*4; var left=x-14-j
				line(Vector2(left,yy),Vector2(x+17+j,yy),'#e2a477')
				for k in range(7): r(left+k*5+(j%2)*2,yy,1,4,'#a96b50')
			r(x-20,y+8,49,3,'#716e59'); r(x-19,y+11,42,2,Color(0.3,0.3,0.3,.15))
		4:
			r(x-19,y,44,8,'#8b8d7a'); r(x-19,y,44,2,'#e9d8b4'); r(x-17,y+2,39,3,'#c9bda0')
		5,6:
			r(x-8,y-21,16,22,'#a3987b'); r(x-7,y-21,14,2,'#fff0c9'); r(x-6,y-18,12,17,'#4e7473')
			r(x-5,y-17,5,7,'#8fac9e'); r(x+1,y-17,4,7,'#bad0b7'); r(x-5,y-8,10,4,'#718f81')
			r(x-1,y-19,2,20,'#dfcba1'); r(x-6,y-11,12,2,'#dfcba1'); r(x-10,y+1,20,3,'#eee0b9')
			if id==6:
				for a in [-15,10]:
					r(x+a,y-20,6,21,base.darkened(.3)); r(x+a,y-20,6,1,base.lightened(.1))
					for j in range(5): r(x+a+1,y-17+j*4,4,1,base.darkened(.45))
		7:
			r(x-9,y-25,18,33,'#a69a7e'); r(x-7,y-24,14,32,'#617e73'); r(x-5,y-22,10,10,'#9eafa0'); r(x-5,y-9,10,14,'#4b6c62'); r(x+3,y-5,2,2,'#e6c779'); r(x-10,y+7,20,2,'#eee0b9')
		8:
			r(x-18,y-19,36,6,'#f0dbb0')
			for j in range(6): r(x-18+j*6,y-19,3,8,'#af6d56')
			line(Vector2(x-17,y-11),Vector2(x-17,y+8),INK); line(Vector2(x+17,y-11),Vector2(x+17,y+8),INK)
		9:
			r(x-18,y+1,40,5,'#8c8c72'); r(x-18,y-12,40,2,'#f0e1ba')
			for i in range(10): r(x-18+i*4,y-11,1,13,'#717c69')
		10:
			r(x-10,y-16,22,13,'#aea88d'); r(x-10,y-16,22,2,'#ede2c2')
			for i in range(5): r(x-7,y-12+i*2,12,1,'#7e8c7d')
			r(x+7,y-12,3,5,'#8f9983'); line(Vector2(x+12,y-5),Vector2(x+17,y-5),INK); line(Vector2(x+17,y-5),Vector2(x+17,y+12),INK)
		11:
			r(x+7,y-27,3,34,'#c8b999'); r(x+10,y-27,1,34,'#839285'); r(x+4,y-24,6,2,'#7d8c7c'); r(x+4,y+1,6,2,'#7d8c7c')
		12:
			r(x-11,y-3,22,7,'#b07656'); r(x-12,y-4,24,2,'#d79b68')
			for j in range(7): foliage(Vector2(x-9+j*3,y-6-j%2*3),3,'#64885c','#8ea36e')
			for j in range(5): r(x-8+j*4,y-9-j%2*3,2,2,'#d99b88')
		13:
			line(Vector2(x,y+8),Vector2(x+5,y-42),'#758b58')
			for j in range(13): foliage(Vector2(x+sin(j*2)*5,y+5-j*3),3,'#627b4e','#94a66b')
		14: tree(p,1.0)
		15:
			for j in range(3): r(x-15,y-12+j*3,30,2,'#b28d63')
			r(x-16,y-2,32,3,'#d2b17f'); r(x-13,y+1,2,7,INK); r(x+11,y+1,2,7,INK)
		16:
			draw_arc(Vector2(x-10,y+3),7,0,TAU,20,Color(INK)); draw_arc(Vector2(x+11,y+3),7,0,TAU,20,Color(INK))
			line(Vector2(x-10,y+3),Vector2(x,y-8),'#ae6e58'); line(Vector2(x,y-8),Vector2(x+11,y+3),'#ae6e58'); line(Vector2(x+11,y+3),Vector2(x-10,y+3),'#ae6e58'); line(Vector2(x-5,y-5),Vector2(x+10,y-5),'#ae6e58'); r(x+7,y-11,6,2,INK); r(x-6,y-10,7,2,INK)
		17:
			line(Vector2(x-24,y-24),Vector2(x+24,y-20),INK)
			for i in range(4):
				var sway=round(sin(game.time*1.6+i))
				r(x-21+i*12+sway,y-22+i,8,12,['#d9a17d','#e5d8b6','#809b8c','#c2989c'][i]); r(x-20+i*12+sway,y-21+i,1,10,Color(1,1,1,.16))
		18:
			r(x,y-43,2,51,'#6c7969'); r(x-1,y-44,12,2,INK); r(x+7,y-43,2,8,INK); r(x+4,y-36,8,9,'#e9d09a'); r(x+3,y-37,10,2,INK)
		19:
			r(x-6,y+1,12,5,'#b58f69'); r(x+3,y-2,6,7,'#b58f69'); r(x+3,y-4,2,3,'#b58f69'); r(x+7,y-4,2,3,'#b58f69'); r(x+7,y,1,1,INK)
			line(Vector2(x-5,y+4),Vector2(x-11,y+1+sin(game.time)*2),'#b58f69',2)
		20:
			r(x-5,y-20,11,27,'#b7a28a'); r(x-7,y-21,15,3,'#e3c7a0'); r(x+4,y-18,3,24,'#8e8877')
			for j in range(4): r(x-4,y-16+j*6,8,1,'#968d7a')
		21:
			for i in range(9): r(x-16+i*4,y-12,2,20,'#e5d7b4')
			r(x-17,y-8,36,2,'#c6c4a0'); r(x-17,y+1,36,2,'#c6c4a0')
		22:
			for i in range(3): r(x-12-i*3,y-4+i*3,24+i*6,3,'#c5bda3'); r(x-12-i*3,y-4+i*3,24+i*6,1,'#e5d7b4')
		23:
			for i in range(7):
				var xx=x-13+i*4; var yy=y-3-i%3*2
				r(xx,yy,1,9,'#78945b'); r(xx-1,yy,3,2,['#d9a17d','#e8d9ad','#b395a4'][i%3])

func foliage(p,s,a,b):
	r(p.x-s,p.y-s,s*2,s*2,a); r(p.x-s+1,p.y-s-1,s*2-2,s,b); r(p.x-s-1,p.y-1,s,3,a)

func tree(p,scale,local=true):
	draw_set_transform(p,0,Vector2.ONE*scale)
	r(-25,6,53,3,Color(.25,.35,.2,.12)); r(-3,-35,5,44,'#8e8b61'); r(1,-32,2,38,'#b8ad78')
	line(Vector2(0,-21),Vector2(-14,-41),'#8e8b61',2); line(Vector2(1,-28),Vector2(15,-48),'#8e8b61',2)
	for i in range(33):
		var a=i*2.4; var rr=16+sin(i*7)*8
		var q=Vector2(cos(a)*rr,sin(a)*rr*.65-49)
		foliage(q,6+i%4,'#7b9861','#9dae70')
	r(-5,6,10,2,'#71865b')
	draw_set_transform(Vector2(240-game.camera_x,0) if local else Vector2.ZERO)

func person(p,i):
	var leg=int(game.time*6+i)%4
	r(p.x-3,p.y,6,1,Color(.25,.3,.2,.2)); r(p.x-2,p.y-12,4,4,'#c6a17e'); r(p.x-3,p.y-13,6,2,'#d8c599')
	r(p.x-2,p.y-8,4,5,['#788f89','#b58170','#a5a78d'][i]); r(p.x-2-(1 if leg==0 else 0),p.y-3,1,3,INK); r(p.x+1+(1 if leg==2 else 0),p.y-3,1,3,INK)
