extends SceneTree
func _initialize():call_deferred("bake")
func own(n,r):
 for c in n.get_children():c.owner=r;own(c,r)
func bake():
 var g=load("res://World.tscn").instantiate();root.add_child(g);await process_frame
 var scene=Node3D.new();scene.name="RavensWake";scene.set_script(load("res://World.gd"))
 var preview=g.room_root.duplicate();preview.name="EnvironmentPreview";scene.add_child(preview);preview.owner=scene;own(preview,scene)
 var packed=PackedScene.new();packed.pack(scene);ResourceSaver.save(packed,"res://World.tscn")
 g.queue_free();scene.free();await process_frame;quit()
