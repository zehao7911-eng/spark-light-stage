extends CharacterBody3D
var world
var kind=-1
var hp=6.0
var maxhp=6.0
var rig:Node3D
var face=Vector3.FORWARD
var state="chase"
var timer=0.0
var attack_cd=0.0
var dash_cd=0.0
var invuln=0.0
var dash_time=0.0
var dash_dir=Vector3.FORWARD
var combo=0
var combo_time=0.0
var step_time=0.0
var stun=0.0
var hitflash=0.0
var knock=Vector3.ZERO
var dead=false
var visual_hp:MeshInstance3D
var phase_two=false

func setup(game,k:int,pos:Vector3):
 world=game;kind=k;position=pos
 collision_layer=2 if k<0 else 4
 collision_mask=1
 var col=CollisionShape3D.new();var shape=CapsuleShape3D.new();shape.radius=.28 if k<4 else .65;shape.height=1.2 if k<4 else 2.4;col.shape=shape;col.position.y=shape.height/2;add_child(col)
 rig=RavenArt.crow() if k<0 else RavenArt.monster(k)
 add_child(rig)
 if k<0:
  maxhp=float(world.s.maxhp);hp=float(world.s.hp)
 else:
  maxhp=(8+world.s.room*1.0) if k<4 else (64+world.s.room*6.0)
  if k==2:maxhp*=1.3
  hp=maxhp
  timer=1.2+randf()
  var mesh=BoxMesh.new();mesh.size=Vector3(.6,.04,.03)
  visual_hp=RavenArt.mesh(self,mesh,Vector3(0,1.55 if k<4 else 2.7,0),"8dd8c0",true)

func _physics_process(dt):
 if world==null or world.mode!="play" or dead:return
 if world.hitstop>0:return
 tick(dt)
 move_and_slide()
 position.x=clampf(position.x,-7.6,7.6);position.z=clampf(position.z,-5.6,5.6)
 position.y=0

func tick(dt):
 invuln=maxf(0,invuln-dt);attack_cd=maxf(0,attack_cd-dt);dash_cd=maxf(0,dash_cd-dt)
 combo_time=maxf(0,combo_time-dt);stun=maxf(0,stun-dt);hitflash=maxf(0,hitflash-dt)
 knock=knock.move_toward(Vector3.ZERO,dt*18)
 if combo_time<=0:combo=0
 if kind<0:player_tick(dt)
 else:enemy_tick(dt)
 velocity+=knock
 step_time+=dt*(10 if velocity.length()>1 else 2)
 rig.position.y=sin(step_time)*(.035 if velocity.length()>1 else .018)
 rig.rotation.y=lerp_angle(rig.rotation.y,atan2(-face.x,-face.z),minf(1,dt*15))
 if kind<0:
  rig.get_node("Wing-1").rotation.z=sin(step_time)*.14
  rig.get_node("Wing1").rotation.z=-sin(step_time)*.14
  rig.get_node("Cape").rotation.x=sin(step_time*.7)*.1
  rig.get_node("SwordArm").rotation.y=sin((.32-attack_cd)*PI/.32)*2.0-1.0 if attack_cd>.04 else 0
  rig.visible=invuln<=0 or int(invuln*18)%2==0 or dash_time>0
 if visual_hp:visual_hp.scale.x=maxf(.01,hp/maxhp)

func player_tick(dt):
 var input=world.hud.move_vec
 var keyboard=Vector2(float(Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT))-float(Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT)),float(Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN))-float(Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP)))
 if keyboard.length()>0:input=keyboard.normalized()
 var dir=world.screen_direction(input)
 if world.move_goal!=Vector3.INF and input.length()<.01:
  dir=world.move_goal-position;dir.y=0
  if dir.length()<.2:world.move_goal=Vector3.INF;dir=Vector3.ZERO
  else:dir=dir.normalized()
 if dash_time>0:
  dash_time-=dt;velocity=dash_dir*13
  world.sparks(position+Vector3(0,.25,0),"91cbd366",1)
 else:
  velocity=dir*(4.2+float(world.s.speed))
  if dir.length()>.1:face=dir.normalized()
 if (world.hud.attack_held or Input.is_physical_key_pressed(KEY_SPACE)) and attack_cd<=0:slash()
 if Input.is_physical_key_pressed(KEY_SHIFT) and dash_cd<=0:dash()

func slash():
 if attack_cd>0 or dead or world.mode!="play":return
 attack_cd=maxf(.16,.32-float(world.s.haste));combo=(combo%3)+1;combo_time=.9
 var e=world.closest_enemy(position)
 if e and position.distance_to(e.position)<3.6:face=(e.position-position).normalized()
 var damage=float(world.s.damage)*(1.65 if combo==3 else 1.0)
 var hits=0
 for enemy in world.enemies.duplicate():
  if enemy.dead:continue
  var d=enemy.position-position;d.y=0
  if d.length()<float(world.s.reach)+(.45 if combo==3 else 0) and (face.dot(d.normalized())>-.1 if combo==3 else face.dot(d.normalized())>.15):
   enemy.hurt(damage,face*(5 if combo==3 else 3),combo==3)
   hits+=1
 if hits>0:
  world.s.mana=mini(4,int(world.s.mana)+1)
  world.hitstop=.035;world.cam_shake=.12
  world.sound("hit")
 world.swing(position,face,combo==3)
 world.sound("move")

func dash():
 if dash_cd>0 or world.mode!="play":return
 dash_cd=maxf(.45,.9-float(world.s.dash));dash_time=.21;invuln=maxf(invuln,.28)
 dash_dir=face
 var dir=world.screen_direction(world.hud.move_vec)
 if dir.length()>.1:dash_dir=dir.normalized()
 if world.s.dashfire:
  for e in world.enemies.duplicate():
   if e.position.distance_to(position)<2:e.hurt(float(world.s.damage)*.8,dash_dir*3,true)
 world.sound("move")

func enemy_tick(dt):
 velocity=Vector3.ZERO
 if stun>0:return
 timer-=dt
 var d=world.hero.position-position;d.y=0
 var dist=d.length()
 if dist>.001:face=d.normalized()
 if hp<maxhp*.5 and kind>=4 and not phase_two:
  phase_two=true
  world.hud.toast("WARDEN ENRAGED")
  world.spawn_enemy(0,position+Vector3(-2,0,0));world.spawn_enemy(1,position+Vector3(2,0,0))
 if state=="windup":
  if timer<=0:
   if kind==1:world.bolt(position+Vector3(0,.7,0),face*4.4,1,true)
   elif kind>=4:
    var n=10 if phase_two else 7
    for i in n:world.bolt(position+Vector3(0,.6,0),Vector3(sin(i*TAU/n),0,cos(i*TAU/n))*3.5,1,true)
   state="recover";timer=.65 if kind<4 else 1.2
 elif state=="recover":
  if timer<=0:state="chase";timer=1.0
 else:
  if kind==1:
   if dist>5.0:velocity=face*1.4
   elif dist<3:velocity=-face*.9
   if timer<=0:
    state="windup";timer=.7;world.warning(position,1.0,.7,false)
  elif kind>=4:
   if dist>3.4:velocity=face*(1.45 if not phase_two else 1.9)
   if timer<=0:
    state="windup";timer=1.0
    var radius=2.7 if kind==4 else 2.0
    world.warning(world.hero.position,radius,.95,true)
    if kind==5:
     world.warning(world.hero.position+Vector3(2.5,0,0),1.6,1.15,true)
     world.warning(world.hero.position+Vector3(-2.5,0,0),1.6,1.35,true)
    elif kind==6:
     world.warning(position,3.1,.9,true)
  else:
   if dist>1.35:
    velocity=face*(1.55 if kind!=3 else 2.2)
   elif timer<=0:
    state="windup";timer=.7
    world.warning(position+face*.7,1.1,.68,true)

func hurt(damage:float,push:Vector3=Vector3.ZERO,heavy:bool=false):
 if dead:return
 if kind<0:
  if invuln>0:return
  hp-=damage;world.s.hp=hp;invuln=.85;world.cam_shake=.3;world.hud.redflash=.4
  world.sound("hurt")
 else:
  if kind==2 and not heavy:
   var source=(world.hero.position-position).normalized()
   if source.dot(face)>.3:damage*=.35
  hp-=damage;stun=.12 if kind<4 else .03;hitflash=.2;knock+=push
  world.sparks(position+Vector3(0,.8,0),"dbdec7",6)
  world.hud.floating(str(int(ceil(damage))),position+Vector3(0,1.3,0))
 if hp<=0:
  dead=true
  if kind<0:world.finish(false)
  else:
   world.enemy_died(self)
   queue_free()
