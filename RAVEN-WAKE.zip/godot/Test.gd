extends SceneTree
var game
var steps=0
var errors=[]
func _initialize():call_deferred("run")
func run():
 game=load("res://World.tscn").instantiate();root.add_child(game)
 await process_frame
 game.meta={"souls":0,"best":0,"blade":0,"heart":0};game.new_run();game.mode="play"
 Engine.max_fps=0;Engine.time_scale=8
 for i in 15000:
  await physics_frame
  steps+=1
  if game.mode=="lost":break
  if game.mode=="won":break
  if game.mode=="reward":game.gift(0)
  if game.mode=="route":game.route("rest")
  if game.mode!="play":continue
  var e=game.closest_enemy(game.hero.position)
  game.hud.attack_held=true
  if e:
   var d=e.position-game.hero.position;d.y=0
   var desired=d.normalized() if d.length()>1.35 else Vector3.ZERO
   var right=game.camera.global_basis.x;right.y=0;right=right.normalized()
   var down=game.camera.global_basis.z;down.y=0;down=down.normalized()
   game.hud.move_vec=Vector2(desired.dot(right),desired.dot(down))
   if game.s.mana>=3 and d.length()<5:game.magic()
   for h in game.hazards:
    if h.time<.25 and game.hero.position.distance_to(h.p)<h.r+.4 and game.hero.dash_cd<=0:
     var away=(game.hero.position-h.p).normalized()
     if away.length()<.1:away=Vector3.RIGHT
     game.hud.move_vec=Vector2(away.dot(right),away.dot(down));game.hero.dash()
  else:game.hud.move_vec=Vector2.ZERO
 print("CAMPAIGN ",game.mode," room=",game.s.room," kills=",game.s.kills," hp=",game.hero.hp," steps=",steps)
 if game.s.room<4:errors.append("Did not reach first boss")
 game.default_state();game.s.room=4;game.enter_room()
 var boss=game.enemies[0];boss.hurt(1000,Vector3.ZERO,true)
 await process_frame
 assert(game.mode=="reward")
 game.gift(0);assert(game.mode=="route");game.route("rest");assert(game.s.room==5)
 game.hero.invuln=0;game.hero.dash();var hp=game.hero.hp;game.hero.hurt(1);assert(game.hero.hp==hp)
 game.finish(false);assert(game.mode=="lost");assert(game.meta.souls>=0)
 print("Boss reward, route, roll invulnerability, banking PASS")
 var f=FileAccess.open(game.SAVE,FileAccess.WRITE);f.store_string("{}");f.close()
 quit(0 if errors.is_empty() else 1)


