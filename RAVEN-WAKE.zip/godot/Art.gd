class_name RavenArt
extends RefCounted
static var mats:Dictionary={}
static func mat(hex:String,glow:bool=false)->StandardMaterial3D:
 var key=hex+str(glow)
 if mats.has(key):return mats[key]
 var m=StandardMaterial3D.new();m.albedo_color=Color(hex);m.roughness=1
 if glow:m.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED;m.emission_enabled=true;m.emission=Color(hex)
 if m.albedo_color.a<1:m.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA;m.cull_mode=BaseMaterial3D.CULL_DISABLED
 mats[key]=m;return m
static func mesh(parent:Node3D,shape:Mesh,pos:Vector3,color:String,glow:bool=false)->MeshInstance3D:
 var n=MeshInstance3D.new();n.mesh=shape;n.position=pos;n.material_override=mat(color,glow);parent.add_child(n);return n
static func box(p:Node3D,pos:Vector3,size:Vector3,c:String)->MeshInstance3D:
 var m=BoxMesh.new();m.size=size;return mesh(p,m,pos,c)
static func orb(p:Node3D,pos:Vector3,size:Vector3,c:String)->MeshInstance3D:
 var m=SphereMesh.new();m.radius=.5;m.height=1;m.radial_segments=10;m.rings=5
 var n=mesh(p,m,pos,c);n.scale=size;return n
static func cone(p:Node3D,pos:Vector3,r:float,h:float,c:String,top:float=0.0)->MeshInstance3D:
 var m=CylinderMesh.new();m.top_radius=top;m.bottom_radius=r;m.height=h;m.radial_segments=8;return mesh(p,m,pos,c)
static func disc(p:Node3D,pos:Vector3,r:float,c:String)->MeshInstance3D:
 var m=CylinderMesh.new();m.top_radius=r;m.bottom_radius=r;m.height=.025;m.radial_segments=32
 return mesh(p,m,pos,c,true)
static func line(p:Node3D,a:Vector3,b:Vector3,r:float,c:String)->MeshInstance3D:
 var n=cone(p,(a+b)/2,r,a.distance_to(b),c,r)
 if a.distance_to(b)>.001:n.quaternion=Quaternion(Vector3.UP,(b-a).normalized())
 return n
static func shadow(p:Node3D,r:float):disc(p,Vector3(0,.018,0),r,"08101766")
static func crow()->Node3D:
 var p=Node3D.new();p.name="CrowRig"
 orb(p,Vector3(0,.52,0),Vector3(.62,.72,.55),"172030")
 orb(p,Vector3(0,1.0,-.08),Vector3(.66,.62,.58),"20283b")
 orb(p,Vector3(-.2,1.08,-.305),Vector3(.14,.21,.085),"e8eee5")
 orb(p,Vector3(.2,1.08,-.305),Vector3(.14,.21,.085),"e8eee5")
 var beak=cone(p,Vector3(0,.94,-.45),.11,.32,"a1a4ad")
 beak.rotation.x=PI/2
 for side in [-1,1]:
  var wing=Node3D.new();wing.name="Wing"+str(side);wing.position=Vector3(side*.27,.65,.03);p.add_child(wing)
  for i in 3:
   var feather=orb(wing,Vector3(side*.025*i,-.09*i,.06*i),Vector3(.14,.34,.18),"293044")
   feather.rotation.z=side*.22
  line(p,Vector3(side*.13,.15,0),Vector3(side*.13,.05,-.15),.04,"665754")
 var cape=cone(p,Vector3(0,.44,.19),.36,.7,"473245",.17);cape.scale.z=.45;cape.name="Cape"
 box(p,Vector3(0,.76,-.05),Vector3(.6,.09,.42),"7f4655")
 var hand=Node3D.new();hand.name="SwordArm";hand.position=Vector3(.39,.58,-.03);p.add_child(hand)
 box(hand,Vector3(.02,0,-.45),Vector3(.065,.06,.8),"d2dbd5")
 box(hand,Vector3(.02,0,-.06),Vector3(.28,.06,.055),"b89868")
 cone(hand,Vector3(.02,0,-.91),.065,.14,"d2dbd5").rotation.x=PI/2
 shadow(p,.4)
 return p
static func monster(k:int)->Node3D:
 var p=Node3D.new();p.name="MonsterRig"
 var color=["425c60","6c575e","718080","503e55","4a6e62","56556e","71574a"][k]
 if k>=4:
  orb(p,Vector3(0,.8,0),Vector3(1.1,1.4,.9),color)
  cone(p,Vector3(0,.8,.15),.74,1.3,"273c3e",.32)
  orb(p,Vector3(0,1.7,-.12),Vector3(1.05,.9,.85),color)
  for side in [-1,1]:
   line(p,Vector3(side*.5,1.9,0),Vector3(side*.85,2.5,.13),.09,"b7ae8a")
   line(p,Vector3(side*.7,2.2,.08),Vector3(side*1.07,2.36,.15),.07,"b7ae8a")
   orb(p,Vector3(side*.3,1.78,-.49),Vector3(.15,.13,.08),"ee9b66")
   line(p,Vector3(side*.65,1.15,0),Vector3(side*.95,.3,-.3),.14,color)
  box(p,Vector3(.94,.34,-.58),Vector3(.65,.7,.45),"8e9788")
 else:
  orb(p,Vector3(0,.5,0),Vector3(.7,.9,.62),color)
  orb(p,Vector3(0,.96,-.09),Vector3(.57,.57,.49),"b9b9a6")
  for side in [-1,1]:orb(p,Vector3(side*.15,1.03,-.3),Vector3(.095,.09,.06),"dc7b78")
  cone(p,Vector3(0,.46,.15),.45,.8,"304548" if k!=1 else "4b334e",.21)
  if k==1:
   cone(p,Vector3(0,1.34,0),.4,.65,"705978")
   line(p,Vector3(.5,.05,0),Vector3(.5,1.45,0),.04,"755e55")
   orb(p,Vector3(.5,1.5,0),Vector3(.2,.2,.2),"bd8cd5")
  elif k==2:
   box(p,Vector3(0,.6,-.48),Vector3(.8,.85,.11),"849186")
   box(p,Vector3(0,.62,-.55),Vector3(.16,.62,.04),"b1bca4")
  elif k==3:
   for side in [-1,1]:cone(p,Vector3(side*.22,1.36,0),.1,.4,"adb6a3")
  else:
   line(p,Vector3(.4,.5,0),Vector3(.4,.6,-.65),.035,"a8b5ab")
 shadow(p,.55 if k<4 else 1)
 return p
static func column(p:Node3D,pos:Vector3,h:float):
 box(p,pos+Vector3(0,.14,0),Vector3(.95,.28,.95),"525f59")
 cone(p,pos+Vector3(0,h/2+.25,0),.34,h,"78857a",.32)
 box(p,pos+Vector3(0,h+.34,0),Vector3(.86,.24,.86),"939a88")
static func tree(p:Node3D,pos:Vector3,scale_value:float,c:String):
 var n=Node3D.new();p.add_child(n);n.position=pos;n.scale=Vector3.ONE*scale_value
 line(n,Vector3.ZERO,Vector3(.1,2.7,.05),.2,"4e5145")
 for i in 3:
  var a=Vector3(.05,1.8+i*.25,0);var b=Vector3((i-1)*.8,2.65+(i%2)*.4,(i%2)*.65-.3)
  line(n,a,b,.12,"4e5145")
  orb(n,b,Vector3(1.7,1.0,1.45),c)
static func gate(p:Node3D,pos:Vector3):
 for side in [-1,1]:
  box(p,pos+Vector3(side*1.18,1.4,0),Vector3(.5,2.8,.65),"6b7b73")
  box(p,pos+Vector3(side*1.18,.2,0),Vector3(.8,.4,.95),"84968b")
 box(p,pos+Vector3(0,2.85,0),Vector3(2.95,.38,.85),"97a394")
 for i in 5:box(p,pos+Vector3((i-2)*.4,3.17+(.2 if i==2 else 0),0),Vector3(.3,.35,.6),"778978")
 box(p,pos+Vector3(0,1.25,.12),Vector3(1.7,2.3,.1),"182731")
 for i in 4:box(p,pos+Vector3((i-1.5)*.35,1.2,-.02),Vector3(.055,2.15,.06),"af9272")
