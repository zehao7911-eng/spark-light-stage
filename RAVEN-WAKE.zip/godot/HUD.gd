extends Control
var world
var move_vec=Vector2.ZERO
var attack_held=false
var redflash=0.0
var toast_text=""
var toast_time=0.0
var floats:Array=[]
var buttons:Array=[]
var joy_id=-1
var attack_id=-1
var joy_origin=Vector2.ZERO
var font=ThemeDB.fallback_font
func _ready():
 mouse_filter=Control.MOUSE_FILTER_IGNORE
func reset_input():
 move_vec=Vector2.ZERO;attack_held=false;joy_id=-1;attack_id=-1
func toast(t):toast_text=t;toast_time=2.2
func floating(t,p):floats.append({"t":t,"p":p,"life":.8})
func _process(dt):
 size=get_viewport_rect().size;redflash=maxf(0,redflash-dt);toast_time=maxf(0,toast_time-dt)
 for f in floats.duplicate():
  f.life-=dt;f.p.y+=dt*.9
  if f.life<=0:floats.erase(f)
 queue_redraw()
func text(t,p,n=18,c=Color("ecdfbe")):
 draw_string(font,p,str(t),HORIZONTAL_ALIGNMENT_LEFT,-1,n,c)
func center(t,y,n=24,c=Color("ecdfbe")):
 var w=font.get_string_size(str(t),HORIZONTAL_ALIGNMENT_LEFT,-1,n).x;text(t,Vector2((size.x-w)/2,y),n,c)
func panel(r,col=Color("14262ef0")):
 var b=StyleBoxFlat.new();b.bg_color=col;b.border_color=Color("526366");b.set_border_width_all(1);b.set_corner_radius_all(12);draw_style_box(b,r)
func button(t,r,id):
 panel(r);var w=font.get_string_size(t,HORIZONTAL_ALIGNMENT_LEFT,-1,18).x;text(t,r.position+Vector2((r.size.x-w)/2,r.size.y/2+6));buttons.append({"r":r,"id":id})
func round_button(p,r,t,id):
 draw_circle(p,r,Color("18343ae6"));draw_arc(p,r,0,TAU,40,Color("beac76"),2,true);text(t,p-Vector2(font.get_string_size(t,HORIZONTAL_ALIGNMENT_LEFT,-1,14).x/2,-5),14);buttons.append({"r":Rect2(p-Vector2.ONE*r,Vector2.ONE*r*2),"id":id})
func _draw():
 buttons=[]
 if not world or world.s.is_empty():return
 var s=world.s;var w=size.x;var h=size.y
 if world.mode=="play":
  panel(Rect2(14,14,225,65));text("COURT "+str(int(s.room))+"   •   "+str(int(s.earned))+" SOULS",Vector2(26,36),15)
  for i in int(s.maxhp):draw_circle(Vector2(32+i*19,54),6,Color("ed766b") if i<ceil(world.hero.hp) else Color("45545a"))
  for i in 4:draw_circle(Vector2(28+i*17,72),3,Color("8fd4db") if i<s.mana else Color("45545a"))
  button("II",Rect2(w-58,14,44,44),"pause")
  var jc=Vector2(83,h-90);draw_circle(jc,55,Color("19333c99"));draw_arc(jc,55,0,TAU,40,Color("81958b88"),1,true);draw_circle(jc+move_vec*30,22,Color("acbba6aa"))
  round_button(Vector2(w-62,h-88),40,"SLASH","slash")
  round_button(Vector2(w-151,h-74),31,"ROLL","roll")
  round_button(Vector2(w-77,h-181),31,["FIRE","FROST","STORM"][int(s.spell)],"magic")
  if s.frost or s.storm:button("Q",Rect2(w-151,h-205,44,44),"spell")
  for e in world.enemies:
   if e.kind>=4:
    panel(Rect2(w*.23,94,w*.54,28));draw_rect(Rect2(w*.23+3,97,(w*.54-6)*maxf(0,e.hp/e.maxhp),22),Color("ad5d51"));center("THE WARDEN",113,13)
  for f in floats:
   var p=world.camera.unproject_position(f.p);text(f.t,p,22,Color("fff0bf",f.life/.8))
  if toast_time>0:center(toast_text,154 if w<h else 92,15)
  if redflash>0:draw_rect(Rect2(Vector2.ZERO,size),Color(1,.12,.08,redflash*.28))
  return
 draw_rect(Rect2(Vector2.ZERO,size),Color("071319bb"))
 var bw=minf(340,w-40)
 match world.mode:
  "title":
   center("RAVEN’S WAKE",h*.24,38);center("A BLADE BETWEEN WORLDS",h*.24+30,13,Color("b5b6a2"))
   button("Begin journey",Rect2((w-bw)/2,h*.38,bw,52),"new")
   if not world.checkpoint.is_empty():button("Continue",Rect2((w-bw)/2,h*.38+64,bw,48),"continue")
   center(str(int(world.meta.souls))+" SOULS  ·  BEST COURT "+str(int(world.meta.best)),h*.38+150,14)
   button("Blade "+str(int(world.meta.blade))+"  ·  "+str(15+int(world.meta.blade)*15)+" souls",Rect2((w-bw)/2,h*.38+170,bw,44),"blade")
   button("Vitality "+str(int(world.meta.heart))+"  ·  "+str(15+int(world.meta.heart)*15)+" souls",Rect2((w-bw)/2,h*.38+220,bw,44),"heart")
  "help":
   center("ONE SMALL CROW",h*.25,28);center("One very sharp sword.",h*.25+35,18)
   center("Move left • Hold SLASH to combo",h*.25+85,17);center("ROLL through danger • Hits refill magic",h*.25+115,16)
   center("Keyboard: WASD · Space · Shift · E",h*.25+155,15)
   button("Enter the court",Rect2((w-bw)/2,h*.25+190,bw,52),"play")
  "reward":
   center("A SOUL REMEMBERS",h*.15,28);center("Choose a gift",h*.15+28,16)
   for i in s.reward.size():
    var gift=world.GIFTS[int(s.reward[i])];var rr=Rect2((w-bw)/2,h*.15+55+i*92,bw,80)
    panel(rr);text(gift[0],rr.position+Vector2(18,30),22);text(gift[1],rr.position+Vector2(18,58),15,Color("b5c9bf"));buttons.append({"r":rr,"id":"gift"+str(i)})
  "route":
   center("BEYOND THE GATE",h*.25,28)
   button("Spring  ·  Heal 2",Rect2((w-bw)/2,h*.25+45,bw,55),"rest")
   button("Anvil  ·  Sharpen blade",Rect2((w-bw)/2,h*.25+112,bw,55),"forge")
   button("Hunt  ·  Extra souls",Rect2((w-bw)/2,h*.25+179,bw,55),"hunt")
  "pause":
   center("A QUIET MOMENT",h*.25,28)
   button("Return",Rect2((w-bw)/2,h*.25+50,bw,52),"play")
   button("Sound: "+("Off" if world.muted else "On"),Rect2((w-bw)/2,h*.25+114,bw,48),"sound")
   button("Shadows: "+("Off" if world.low_fx else "On"),Rect2((w-bw)/2,h*.25+174,bw,48),"quality")
   button("Main menu",Rect2((w-bw)/2,h*.25+234,bw,48),"title")
  "won","lost":
   center("DAWN RETURNS" if world.mode=="won" else "A SOUL RESTS",h*.25,30)
   center("Court "+str(int(s.room))+" · "+str(int(s.kills))+" defeats · "+str(int(s.earned))+" souls",h*.25+40,17)
   if world.mode=="won":button("Beyond dawn  ·  Endless",Rect2((w-bw)/2,h*.25+74,bw,52),"endless")
   button("New journey",Rect2((w-bw)/2,h*.25+140,bw,52),"new")
   button("Return to forge",Rect2((w-bw)/2,h*.25+204,bw,48),"title")
func action(id):
 match id:
  "new":world.new_run()
  "continue":world.resume()
  "play":world.mode="play";reset_input()
  "pause":world.mode="pause";reset_input()
  "title":world.mode="title";reset_input()
  "blade","heart":world.upgrade(id)
  "roll":world.hero.dash()
  "magic":world.magic()
  "spell":
   var spells=[0]
   if world.s.frost:spells.append(1)
   if world.s.storm:spells.append(2)
   world.s.spell=spells[(spells.find(int(world.s.spell))+1)%spells.size()]
  "rest","forge","hunt":world.route(id)
  "sound":world.muted=not world.muted;world.save_game()
  "quality":world.low_fx=not world.low_fx;world.sun.shadow_enabled=not world.low_fx;world.save_game()
  "endless":world.s.room+=1;world.s.paid=false;world.s.earned=0;world.s.hp=world.s.maxhp;world.enter_room()
  _:
   if id.begins_with("gift"):world.gift(int(id.substr(4)))
func press(p,id):
 for b in buttons:
  if b.r.has_point(p):
   if b.id=="slash":attack_held=true;attack_id=id
   else:action(b.id)
   return
 if world.mode=="play" and p.x<size.x*.46:
  joy_id=id;joy_origin=p;move_vec=Vector2.ZERO;world.move_goal=Vector3.INF
func release(id):
 if id==joy_id:joy_id=-1;move_vec=Vector2.ZERO
 if id==attack_id:attack_id=-1;attack_held=false
func _input(e):
 if e is InputEventScreenTouch:
  if e.pressed:press(e.position,e.index)
  else:release(e.index)
 elif e is InputEventScreenDrag and e.index==joy_id:move_vec=((e.position-joy_origin)/45).limit_length(1)
 elif e is InputEventMouseButton and e.button_index==MOUSE_BUTTON_LEFT:
  if e.pressed:press(e.position,100)
  else:release(100)
 elif e is InputEventMouseMotion and joy_id==100:move_vec=((e.position-joy_origin)/45).limit_length(1)
 elif e is InputEventKey and e.pressed and not e.echo:
  if e.keycode==KEY_ESCAPE:action("pause" if world.mode=="play" else "play")
  if world.mode=="play":
   if e.keycode==KEY_E:action("magic")
   if e.keycode==KEY_Q:action("spell")
