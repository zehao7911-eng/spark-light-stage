extends Node3D
const ActorScript=preload("res://Actor.gd")
const HudScript=preload("res://HUD.gd")
const SAVE="user://raven_wake.json"
const GIFTS=[
 ["Keen edge","Sword damage +25%","damage"],["Long feather","Sword reach +0.35","reach"],["Fleet claws","Move speed +0.35","speed"],
 ["Quick draw","Slash cooldown -0.035s","haste"],["Moon roll","Roll cooldown -0.12s","dash"],["Royal seed","Max health +1; heal 2","heart"],
 ["Ash trail","Roll burns nearby enemies","dashfire"],["Soul bloom","Heal every sixth defeat","vampire"],["Twin souls","Magic adds another bolt","bolts"],
 ["Frost vow","Unlock freezing magic","frost"],["Storm oath","Unlock chain lightning","storm"],["Deep breath","Magic damage +25%","magic"]
]
var s:Dictionary={}
var meta:Dictionary={"souls":0,"best":0,"blade":0,"heart":0}
var checkpoint:Dictionary={}
var saved_mode="play"
var mode="title"
var enemies:Array=[]
var hero
var camera:Camera3D
var sun:DirectionalLight3D
var hud
var room_root:Node3D
var actor_root:Node3D
var fx_root:Node3D
var effects:Array=[]
var hazards:Array=[]
var projectiles:Array=[]
var pots:Array=[]
var drops:Array=[]
var lights:Array=[]
var rng=RandomNumberGenerator.new()
var wave=1
var wave_delay=0.0
var hitstop=0.0
var cam_shake=0.0
var time=0.0
var bridge_timer=0.0
var save_timer=0.0
var move_goal=Vector3.INF
var low_fx=false
var muted=false
var sounds:Dictionary={}
var audio_players:Array=[]

func _ready():
 if has_node("EnvironmentPreview"):get_node("EnvironmentPreview").queue_free()
 Engine.max_fps=30
 rng.randomize()
 var envnode=WorldEnvironment.new();var env=Environment.new()
 env.background_mode=Environment.BG_COLOR;env.background_color=Color("1c303c")
 env.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;env.ambient_light_color=Color("9ebec3");env.ambient_light_energy=.32
 env.tonemap_mode=Environment.TONE_MAPPER_FILMIC
 env.fog_enabled=true;env.fog_light_color=Color("263e46");env.fog_density=.007
 envnode.environment=env;add_child(envnode)
 sun=DirectionalLight3D.new();sun.rotation_degrees=Vector3(-53,-28,0);sun.light_color=Color("f4dcad");sun.light_energy=.82;sun.shadow_enabled=true
 sun.directional_shadow_mode=DirectionalLight3D.SHADOW_ORTHOGONAL;sun.directional_shadow_max_distance=40;add_child(sun)
 camera=Camera3D.new();camera.projection=Camera3D.PROJECTION_ORTHOGONAL;camera.position=Vector3(13,20,19);add_child(camera);camera.look_at(Vector3.ZERO);camera.current=true
 room_root=Node3D.new();room_root.name="Ruins";add_child(room_root)
 actor_root=Node3D.new();actor_root.name="Actors";add_child(actor_root)
 fx_root=Node3D.new();fx_root.name="Effects";add_child(fx_root)
 hud=HudScript.new();hud.world=self;add_child(hud)
 for n in ["shot","move","hit","coin","hurt"]:sounds[n]=load("res://audio/"+n+".wav")
 for i in 6:
  var p=AudioStreamPlayer.new();p.volume_db=-13;add_child(p);audio_players.append(p)
 load_game()
 if s.is_empty():default_state()
 build_room()
 spawn_hero()
 mode="title"
 get_viewport().size_changed.connect(resize)
 resize()

func default_state():
 s={"room":1,"hp":6+int(meta.heart),"maxhp":6+int(meta.heart),"damage":3.0+int(meta.blade)*.5,"reach":2.1,"speed":0.0,"haste":0.0,"dash":0.0,"mana":4,"magic":1.0,"bolts":0,"spell":0,"frost":false,"storm":false,"dashfire":false,"vampire":false,"kills":0,"earned":0,"upgrades":[],"reward":[],"paid":false}
func new_run():
 default_state();checkpoint=s.duplicate(true);enter_room();mode="help";save_game()
func spawn_hero():
 if is_instance_valid(hero):hero.queue_free()
 hero=ActorScript.new();actor_root.add_child(hero);hero.name="Crow";hero.setup(self,-1,Vector3(0,0,3.8))
func enter_room():
 for e in enemies:if is_instance_valid(e):e.queue_free()
 enemies=[]
 for e in effects:if is_instance_valid(e.node):e.node.queue_free()
 for h in hazards:if is_instance_valid(h.node):h.node.queue_free()
 for p in projectiles:if is_instance_valid(p.node):p.node.queue_free()
 for d in drops:if is_instance_valid(d.node):d.node.queue_free()
 effects=[];hazards=[];projectiles=[];drops=[]
 move_goal=Vector3.INF;hud.reset_input();hitstop=0
 build_room();spawn_hero();wave=1;wave_delay=0
 mode="play";checkpoint=s.duplicate(true);saved_mode="play";save_game();spawn_wave()
 hud.toast(["THE OVERGROWN COURT","THE SILENT ARCHIVE","THE ASHEN SANCTUM"][mini(2,int((int(s.room)-1)/4))]+" · "+str(int(s.room)))
func resize():
 var actual=DisplayServer.window_get_size();var portrait=actual.x<actual.y*1.1
 var wanted=Vector2i(480,800) if portrait else Vector2i(900,500)
 if get_viewport().content_scale_size!=wanted:get_viewport().content_scale_size=wanted
 camera.keep_aspect=Camera3D.KEEP_WIDTH if portrait else Camera3D.KEEP_HEIGHT
 camera.size=16.0 if portrait else 12.8
 hud.queue_redraw()
func screen_direction(v:Vector2)->Vector3:
 var right=camera.global_basis.x;right.y=0;right=right.normalized()
 var down=camera.global_basis.z;down.y=0;down=down.normalized()
 return (right*v.x+down*v.y).limit_length(1)
func build_room():
 for c in room_root.get_children():c.free()
 pots=[];lights=[]
 var chapter=mini(2,int((int(s.room)-1)/4))
 var floor_color=[Color("778a7b"),Color("748596"),Color("948576")][chapter]
 var floor=StaticBody3D.new();room_root.add_child(floor)
 var col=CollisionShape3D.new();var box=BoxShape3D.new();box.size=Vector3(18,1,14);col.shape=box;col.position.y=-.55;floor.add_child(col)
 RavenArt.box(room_root,Vector3(0,-.55,0),Vector3(18,1,14),"465957")
 var tile=BoxMesh.new();tile.size=Vector3(.98,.08,.98)
 var m=MultiMesh.new();m.transform_format=MultiMesh.TRANSFORM_3D;m.use_colors=true;m.mesh=tile;m.instance_count=16*12
 var mm=MultiMeshInstance3D.new();mm.multimesh=m
 var mat=StandardMaterial3D.new();mat.vertex_color_use_as_albedo=true;mat.roughness=1;mm.material_override=mat;room_root.add_child(mm)
 for z in 12:
  for x in 16:
   var pos=Vector3(x-7.5,-.035,z-5.5)
   m.set_instance_transform(z*16+x,Transform3D(Basis(),pos))
   m.set_instance_color(z*16+x,floor_color.darkened(rng.randf_range(.05,.3)))
 for side in [-1,1]:
  static_box(Vector3(side*8.35,.1,0),Vector3(.45,1,12.5))
  static_box(Vector3(0,.1,side*6.35),Vector3(17,1,.45))
  for i in 13:RavenArt.box(room_root,Vector3(side*8.5,.07,i-6),Vector3(.65,.38,.87),"86978b")
  for i in 17:RavenArt.box(room_root,Vector3(i-8,.07,side*6.5),Vector3(.87,.38,.65),"86978b")
 RavenArt.gate(room_root,Vector3(0,0,-6.7))
 for i in 3:RavenArt.box(room_root,Vector3(0,-.1-i*.13,7.1+i*.5),Vector3(3.2,.2,.6),"91a194")
 for x in [-6.8,6.8]:
  for z in [-4.8,1.8]:
   RavenArt.column(room_root,Vector3(x,0,z),2.2 if z<0 else 1.3)
   var p=Vector3(x,2.65 if z<0 else 1.75,z)
   RavenArt.cone(room_root,p,.24,.2,"605753",.32)
   var flame=RavenArt.orb(room_root,p+Vector3(0,.3,0),Vector3(.3,.5,.3),"e5b878")
   flame.material_override=RavenArt.mat("ffc77d",true)
   var light=OmniLight3D.new();light.position=p+Vector3(0,.5,0);light.omni_range=4.3;light.light_energy=.75;light.light_color=Color("ffc17b");room_root.add_child(light);lights.append(light)
 for i in 8:
  var x=(-10.0 if i%2==0 else 10.0)+rng.randf_range(-.5,.5);var z=(i/2)*4.0-7
  RavenArt.tree(room_root,Vector3(x,-.1,z),rng.randf_range(.7,1.2),["536954","5b677f","776455"][chapter])
 for side in [-1,1]:
  for i in 3:
   var p=Vector3(side*(4.7+i*.6),0,-2.8+i*1.3)
   RavenArt.box(room_root,p+Vector3(0,.24,0),Vector3(.65,.18,1.1),"687d70")
   var tomb=RavenArt.box(room_root,p+Vector3(0,.65,-.3),Vector3(.58,.95,.18),"a6b0a0");tomb.rotation.z=side*.1
   RavenArt.box(room_root,p+Vector3(0,.72,-.405),Vector3(.28,.08,.025),"61756e")
 for i in 12:
  var p=Vector3(rng.randf_range(-7.5,7.5),.02,rng.randf_range(-5.5,5.5))
  var moss=RavenArt.disc(room_root,p,rng.randf_range(.15,.4),"6c825b88");moss.scale.z=.65
 for p in [Vector3(-4,0,3),Vector3(4,0,2.8),Vector3(-3.8,0,-1.8)]:
  var n=Node3D.new();n.position=p;room_root.add_child(n)
  RavenArt.cone(n,Vector3(0,.3,0),.32,.55,"a27765",.22)
  RavenArt.cone(n,Vector3(0,.59,0),.25,.07,"715647",.25)
  pots.append({"node":n,"p":p,"hp":2})
 for i in 9:
  var p=Vector3((i%3)*3.1-3.1,.08,int(i/3)*2.4-2.4)
  if i==4:continue
  RavenArt.box(room_root,p,Vector3(.9,.055,.11),"a6b2a0")
  RavenArt.box(room_root,p+Vector3(.42,0,0),Vector3(.065,.055,.52),"a6b2a0")
 for side in [-1,1]:
  # Weathered arcade frames and brass memorials beyond the combat boundary.
  for j in 3:
   var base=Vector3(side*9.6,0,j*3.5-4.8)
   RavenArt.column(room_root,base,2.5+j*.25)
   RavenArt.box(room_root,base+Vector3(0,2.7+j*.25,1.6),Vector3(.65,.42,3.2),"566862")
   RavenArt.box(room_root,base+Vector3(0,.6,0),Vector3(.82,.045,.82),"abb09b")
  var statue=Vector3(side*7.2,0,-5)
  RavenArt.box(room_root,statue+Vector3(0,.45,0),Vector3(1,.9,1),"596b68")
  var idol=RavenArt.crow();idol.position=statue+Vector3(0,.9,0);idol.scale=Vector3.ONE*1.2;room_root.add_child(idol)
 for j in 24:
  var p=Vector3(rng.randf_range(-7.6,7.6),.02,rng.randf_range(-5.4,5.4))
  var crack=RavenArt.box(room_root,p,Vector3(rng.randf_range(.1,.4),.02,.022),"465852");crack.rotation.y=rng.randf()*TAU
func static_box(pos:Vector3,size:Vector3):
 var body=StaticBody3D.new();room_root.add_child(body);body.position=pos
 var shape=BoxShape3D.new();shape.size=size;var col=CollisionShape3D.new();col.shape=shape;body.add_child(col)
func spawn_enemy(k:int,p:Vector3):
 var e=ActorScript.new();actor_root.add_child(e);e.setup(self,k,Vector3(clampf(p.x,-7,7),0,clampf(p.z,-5,5)));enemies.append(e);return e
func spawn_wave():
 if int(s.room)%4==0:
  spawn_enemy(4+mini(2,int((int(s.room)-1)/4)),Vector3(0,0,-2.5));wave=2
 else:
  var n=mini(6,2+int(s.room)/3+wave)
  for i in n:
   var k=0 if int(s.room)==1 else (i+int(s.room)+wave)%4
   var a=i*TAU/n
   spawn_enemy(k,Vector3(sin(a)*4.7,0,cos(a)*3.8-1.1))
func closest_enemy(pos:Vector3):
 var best=null;var d=1000.0
 for e in enemies:
  if not e.dead and pos.distance_to(e.position)<d:best=e;d=pos.distance_to(e.position)
 return best
func enemy_died(e):
 enemies.erase(e);s.kills+=1;s.earned+=2 if e.kind<4 else 12
 sparks(e.position+Vector3(0,.5,0),"a8d5c2",10)
 if s.vampire and int(s.kills)%6==0:hero.hp=minf(hero.maxhp,hero.hp+1);s.hp=hero.hp
 if enemies.is_empty():
  if wave<2:wave=2;wave_delay=1.0;hud.toast("SECOND WAVE")
  else:clear_room()
func clear_room():
 mode="reward";hud.reset_input();s.hp=hero.hp;s.mana=4
 s.earned+=4
 if int(s.room)%4==0:
  s.hp=minf(float(s.maxhp),float(s.hp)+2);hero.hp=s.hp
  if int(s.room)==12:finish(true);return
 s.reward=[]
 var pool=range(GIFTS.size())
 for i in 3:
  var j=rng.randi_range(0,pool.size()-1);s.reward.append(pool[j]);pool.remove_at(j)
 checkpoint=s.duplicate(true);saved_mode="reward";save_game();sound("coin")
func gift(index:int):
 var id=int(s.reward[index]);var key=GIFTS[id][2]
 s.upgrades.append(id)
 match key:
  "damage":s.damage=minf(10,float(s.damage)*1.25)
  "reach":s.reach=minf(3.4,float(s.reach)+.35)
  "speed":s.speed=minf(1.4,float(s.speed)+.35)
  "haste":s.haste=minf(.14,float(s.haste)+.035)
  "dash":s.dash=minf(.45,float(s.dash)+.12)
  "heart":s.maxhp=mini(10,int(s.maxhp)+1);s.hp=minf(float(s.maxhp),float(s.hp)+2)
  "dashfire":s.dashfire=true
  "vampire":s.vampire=true
  "bolts":s.bolts=mini(3,int(s.bolts)+1)
  "frost":s.frost=true;s.spell=1
  "storm":s.storm=true;s.spell=2
  "magic":s.magic=minf(3,float(s.magic)*1.25)
 mode="route";checkpoint=s.duplicate(true);saved_mode="route";save_game()
func route(kind:String):
 if kind=="rest":s.hp=minf(float(s.maxhp),float(s.hp)+2)
 elif kind=="forge":s.damage=minf(10,float(s.damage)+.4)
 elif kind=="hunt":s.earned+=3
 s.room+=1;enter_room()
func magic():
 if mode!="play" or int(s.mana)<3:return
 s.mana-=3
 var e=closest_enemy(hero.position)
 var dir=hero.face
 if e:dir=(e.position-hero.position).normalized();dir.y=0
 if int(s.spell)==1:
  for enemy in enemies.duplicate():
   if hero.position.distance_to(enemy.position)<4.8:
    enemy.hurt(5*float(s.magic),dir*2,true);enemy.stun=1.3
  var n=RavenArt.disc(fx_root,hero.position+Vector3(0,.09,0),1,"8bcddd77")
  effects.append({"node":n,"life":.6,"max":.6,"v":Vector3.ZERO,"grow":7.0})
 elif int(s.spell)==2:
  var last=hero.position+Vector3(0,.7,0);var count=0
  var targets=enemies.duplicate();targets.sort_custom(func(a,b):return a.position.distance_to(hero.position)<b.position.distance_to(hero.position))
  for enemy in targets.slice(0,5):
   var n=RavenArt.line(fx_root,last,enemy.position+Vector3(0,.7,0),.06,"bddde9")
   n.material_override=RavenArt.mat("bddde9",true);effects.append({"node":n,"life":.25,"max":.25,"v":Vector3.ZERO,"grow":0.0})
   enemy.hurt(8*float(s.magic),dir*2,true);last=enemy.position+Vector3(0,.7,0);count+=1
 else:
  var amount=3+int(s.bolts)
  for i in amount:
   var a=(float(i)/maxf(1,amount-1)-.5)*.45
   bolt(hero.position+Vector3(0,.7,0),dir.rotated(Vector3.UP,a)*9,7*float(s.magic),false)
 sound("shot");cam_shake=.2
func bolt(pos:Vector3,vel:Vector3,damage:float,enemy:bool):
 if projectiles.size()>40:return
 var n=RavenArt.orb(fx_root,pos,Vector3(.21,.21,.45),"d4878a" if enemy else "8fd5e4")
 n.material_override=RavenArt.mat("f2998c" if enemy else "9bddf1",true)
 projectiles.append({"node":n,"v":vel,"damage":damage,"enemy":enemy,"life":3.5})
func warning(pos:Vector3,radius:float,delay:float,damage:bool):
 var p=Vector3(clampf(pos.x,-7.5,7.5),.04,clampf(pos.z,-5.5,5.5))
 var n=RavenArt.disc(fx_root,p,radius,"e7756655")
 hazards.append({"node":n,"p":p,"r":radius,"time":delay,"max":delay,"damage":damage})
func swing(pos:Vector3,dir:Vector3,heavy:bool):
 var st=SurfaceTool.new();st.begin(Mesh.PRIMITIVE_TRIANGLES)
 var radius=float(s.reach)+(.4 if heavy else 0)
 var angle=atan2(dir.x,dir.z)
 for i in 12:
  var a=angle+(float(i)/12-.5)*2.4;var b=angle+(float(i+1)/12-.5)*2.4
  var vs=[Vector3(sin(a)*radius,.6,cos(a)*radius),Vector3(sin(b)*radius,.6,cos(b)*radius),Vector3(sin(a)*(radius-.28),.6,cos(a)*(radius-.28)),Vector3(sin(b)*radius,.6,cos(b)*radius),Vector3(sin(b)*(radius-.28),.6,cos(b)*(radius-.28)),Vector3(sin(a)*(radius-.28),.6,cos(a)*(radius-.28))]
  for v in vs:st.add_vertex(v)
 var n=RavenArt.mesh(fx_root,st.commit(),pos,"f6daaabb" if heavy else "badfe999",true)
 effects.append({"node":n,"life":.16,"max":.16,"v":Vector3.ZERO,"grow":0.0})
 for pot in pots.duplicate():
  if pot.p.distance_to(pos)<radius:
   pot.hp-=1
   if pot.hp<=0:
    pots.erase(pot);pot.node.queue_free();sparks(pot.p+Vector3(0,.3,0),"b08c76",7)
    s.mana=mini(4,int(s.mana)+1);s.earned+=1
    if rng.randf()<.25:
     var seed=RavenArt.orb(fx_root,pot.p+Vector3(0,.3,0),Vector3(.3,.3,.3),"a4c79b");drops.append({"node":seed,"p":pot.p})
func sparks(pos:Vector3,color:String,n:int):
 for i in n:
  if effects.size()>45 if low_fx else effects.size()>90:break
  var p=RavenArt.orb(fx_root,pos,Vector3.ONE*.09,color);p.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
  effects.append({"node":p,"life":rng.randf_range(.2,.6),"max":.6,"v":Vector3(rng.randf_range(-2,2),rng.randf_range(.5,2),rng.randf_range(-2,2)),"grow":0.0})
func _physics_process(dt):
 if mode!="play":return
 if hitstop>0:hitstop=maxf(0,hitstop-dt);return
 if wave_delay>0:
  wave_delay-=dt
  if wave_delay<=0:spawn_wave()
 for h in hazards.duplicate():
  h.time-=dt
  h.node.scale=Vector3.ONE*(.93+sin(h.time*20)*.04)
  if h.time<=0:
   if h.damage:
    sparks(h.p+Vector3(0,.2,0),"edbd92",8)
    if hero.position.distance_to(h.p)<h.r:hero.hurt(1)
   h.node.queue_free();hazards.erase(h)
 for p in projectiles.duplicate():
  p.life-=dt;p.node.position+=p.v*dt
  var hit=false
  if p.enemy:
   if p.node.position.distance_to(hero.position+Vector3(0,.7,0))<.5:hero.hurt(p.damage);hit=true
  else:
   for e in enemies.duplicate():
    if p.node.position.distance_to(e.position+Vector3(0,.7,0))<(.8 if e.kind>=4 else .55):e.hurt(p.damage,p.v.normalized()*3,true);hit=true;break
  if hit or p.life<=0 or absf(p.node.position.x)>9 or absf(p.node.position.z)>7:
   p.node.queue_free();projectiles.erase(p)
 for d in drops.duplicate():
  if hero.position.distance_to(d.p)<.8:
   hero.hp=minf(hero.maxhp,hero.hp+1);s.hp=hero.hp;d.node.queue_free();drops.erase(d);sound("coin")
func _process(dt):
 time+=dt;bridge_timer+=dt
 if hero and mode=="play":
  var focus=Vector3(clampf(hero.position.x,-2.5,2.5),0,clampf(hero.position.z,-1.7,1.7))
  camera.position=camera.position.lerp(Vector3(13,20,19)+focus,dt*3);camera.look_at(camera.position-Vector3(13,20,19))
 cam_shake=maxf(0,cam_shake-dt)
 camera.h_offset=sin(time*80)*cam_shake*.25;camera.v_offset=cos(time*73)*cam_shake*.25
 if mode=="play":
  for e in effects.duplicate():
   e.life-=dt;e.node.position+=e.v*dt
   if e.grow>0:e.node.scale+=Vector3.ONE*dt*e.grow
   if e.life<=0:e.node.queue_free();effects.erase(e)
 for l in lights:l.light_energy=.65+sin(time*4+l.position.x)*.09
 if OS.has_feature("web") and bridge_timer>.3:
  bridge_timer=0
  var em:Array=[]
  for e in enemies:
   var p=camera.unproject_position(e.position+Vector3(0,.6,0));em.append({"x":e.position.x,"z":e.position.z,"hp":e.hp,"k":e.kind,"screen":[p.x,p.y]})
  var h=camera.unproject_position(hero.position+Vector3(0,.5,0)) if hero else Vector2.ZERO
  JavaScriptBridge.eval("window.RavenSnapshot="+JSON.stringify({"mode":mode,"state":s,"meta":meta,"viewport":[get_viewport().get_visible_rect().size.x,get_viewport().get_visible_rect().size.y],"hero":[hero.position.x,hero.position.z,h.x,h.y,hero.hp],"enemies":em,"wave":wave}),true)
func finish(won:bool):
 mode="won" if won else "lost";hud.reset_input()
 s.hp=maxf(0,hero.hp);meta.best=maxi(int(meta.best),int(s.room))
 if not s.paid:meta.souls+=int(s.earned);s.paid=true
 checkpoint=s.duplicate(true);saved_mode=mode;save_game();sound("coin" if won else "hurt")
func save_game():
 if checkpoint.is_empty():return
 var f=FileAccess.open(SAVE,FileAccess.WRITE)
 if f:f.store_string(JSON.stringify({"checkpoint":checkpoint,"mode":saved_mode,"meta":meta,"low":low_fx,"muted":muted}))
func load_game():
 if not FileAccess.file_exists(SAVE):return
 var f=FileAccess.open(SAVE,FileAccess.READ);var d=JSON.parse_string(f.get_as_text())
 if d is Dictionary:
  meta=d.get("meta",meta);checkpoint=d.get("checkpoint",{});s=checkpoint.duplicate(true);saved_mode=d.get("mode","play");low_fx=d.get("low",false);muted=d.get("muted",false)
  sun.shadow_enabled=not low_fx
func resume():
 s=checkpoint.duplicate(true)
 if saved_mode=="play":enter_room()
 else:mode=saved_mode
func sound(n:String):
 if muted:return
 for p in audio_players:
  if not p.playing:p.stream=sounds[n];p.play();return
func upgrade(kind:String):
 var level=int(meta.get(kind,0));var cost=15+level*15
 if level>=3 or int(meta.souls)<cost:return
 meta.souls-=cost;meta[kind]=level+1;save_game();sound("coin")
func _notification(what):
 if what==NOTIFICATION_APPLICATION_FOCUS_OUT:
  if hud:hud.reset_input()
  if mode=="play":mode="pause"
  save_game()



