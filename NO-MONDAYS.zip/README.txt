GARFIELD: NO MONDAYS
Unofficial non-commercial fan game. Garfield belongs to Paws, Inc.
Original procedural geometry, code and synthesized sounds. Three.js r147 MIT license included.

Open index.html directly; all dependencies are bundled, no server or network is needed.
Hold anywhere on the play floor, pull away from your desired direction and release to launch.
Dots show an approximate bounce route. Your drag origin can be anywhere on the floor.
Knock every office object over. Flying objects can knock others over; coffee spills hit nearby objects.
Grab three lasagna plates for a brief speed boost. The orange cat rolls until friction stops it.
Unlimited launches, no timer or lives. Six office layouts cycle with slight deterministic variation.
Stars: complete a room; eat all three lasagna plates; complete in five launches or fewer.
Nine accumulated stars unlock a lasagna crown on subsequent rooms.
Completed rooms, stars, best combo and sound preference save locally when permitted.
Restart resets this room only. Cancel a drag or pause without launching. Pause stops rolling too.
Keyboard: left/right adjust direction; Space launches; Escape pauses.
Mobile portrait-first, 44px controls, DPR capped1.5, bounded80FX/16voices, static batching.
If WebGL is lost or unavailable, use Retry in a current browser.
