WARIO: WAH-RECKING CREW
Unofficial fan-made HTML5 game; original procedural artwork and synthesized sound.

PULL the giant fist sideways. RELEASE to swing into the castle.
Knock every crown off its tower to win. Gold coins are optional bonuses.
Red barrels explode when struck hard and push nearby rubble.
Unlimited attempts. No countdown or lives. Cancelling a touch does not swing.
Keyboard: arrows or A/D to pull, Space to release, Escape to pause.

STARS: finish / both coins / finish in three swings or fewer.
Best stars per castle count once. Six stars unlock a purple glove;
twelve unlock Wario's crown. Eight designed layouts repeat after castle eight
through numbered castle999; these are not999 independently designed castles.

Use index.html on any static host or open it directly. All JavaScript is bundled.
No network services, CDN, commercial music or extracted game model assets.
WebGL required. Portrait recommended; landscape supported. Browser touch and
viewport emulation tested; no claim of testing every physical phone.
Local progress saves when storage is available; resumed games start paused.
Matter collision caches are rebuilt on reload; settling may differ slightly.

Loose physics-demolition inspiration: ABRISS - build to destroy, Steam1671480.
This is a compact original pendulum game, not an ABRISS port or asset reproduction.
Wario belongs to Nintendo. Unofficial fan work; not endorsed by Nintendo.
Three.js r147 and Matter.js0.20 are MIT; licenses included.
