GRAND LINE: SKYBOUND

A mobile-first 3D sailing game featuring three Blender ships: the Going Merry, the Going Merry in its Sky Island form, and the Thousand Sunny. The game interface and in-game text are in English. All models, textures, scripts, and libraries are bundled locally; gameplay does not depend on a CDN.

PLAY
Steer left or right with the screen buttons, drag across the sea, or use the arrow keys. Collect golden rings for treasure and a streak bonus. Avoid sea maws, barrels, and buoys. Tap COLA BURST to clear nearby hazards and surge forward. Switch ships at the top: the Merry is balanced, the Sky Merry turns quicker, and the Sunny sails faster. Find 120 treasure to complete the voyage.

MOBILE
Designed for touch and narrow portrait screens, with responsive landscape controls. GLB ships load only when selected so the first ship starts quickly on mobile connections.

RUN LOCALLY
Extract the full folder and run `node serve.cjs` from this directory. Open http://127.0.0.1:4270/ in a modern browser. Node.js is only required for the local web server; no package installation is needed.

The original rigged Blender meshes were exported as posed static GLB geometry because the source files contain no animation clips. The game adds sailing bob, banking, a wake, treasure, hazards, and animated ocean motion in real time.
