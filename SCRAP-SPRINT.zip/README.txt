WALL·E: SCRAP SPRINT

An original unofficial fan-made browser minigame. All interface text is English.
Open index.html to play offline. No installation, build, CDN, account or payment.

DRAG anywhere on the yard to drive and collect scrap. Four scraps automatically
compress into one cube. Carry up to three cubes, then drive to the glowing ring
at the bridge edge to deliver them. Each cube physically extends the bridge.
When it is complete, cross to EVE. Collect the three little plants for a star.
Batteries briefly increase speed and suction. Avoid dark oil puddles; a wobble
never destroys your cargo. No lives or failure timer. Lift a finger to brake.

Keyboard: WASD / arrows to drive, Space to brake, Escape to pause.
Stars: finish / all three plants / no oil wobbles. Best stars for each yard are
saved; replay does not farm stars. Six total stars unlock a solar panel and a
wider permanent magnet. Local storage remembers exact active progress, records
and mute. A resumed yard starts paused. If storage is blocked, play still works
for the session. No private data is sent. Sound is original synthesis; mute
available. Pointer cancellation, hiding and blur safely stop controls/sound.

Eight original yard layouts and palettes. After yard 8, numbered remixes reuse
these layouts with alternating reflection (up to 999); not infinitely unique
handmade levels. This is a compact collection/compaction/delivery game, not a
factory management simulator. The production loop loosely references Steam
Little Big Workshop: https://store.steampowered.com/app/574720/

WALL-E and EVE belong to Disney/Pixar. This fan game is not affiliated with or
endorsed by them. Character reference: https://www.pixar.com/wall-e
All included models, handmade canvas textures, level layouts, code and sounds
are original procedural work. No commercial game/movie files were extracted.
Three.js r147 is bundled under MIT; see THREE-LICENSE.txt. No AI image generation.

Mobile: portrait-first, landscape supported, 46px controls, safe-area layout,
DPR capped at 1.5, bounded scrap/particles/tracks/audio. WebGL context loss
offers Retry. Mobile viewport and native touch emulation tested; no claim of
physical handset performance or platform review score. Edit engine.js,
scene.js, app.js and style.css in the source version to customize.
