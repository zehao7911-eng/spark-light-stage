Minecraft Dungeons · Fan Quest

Open emberwood.html from a local web server, or run:
  node serve.cjs
Then visit http://127.0.0.1:4240/

Controls
  Desktop: WASD / arrows or click the ground to move. Click enemies to pursue.
  Hold J for sword combos, K for bow, Space to roll.
  E to interact, I for equipment, Q for potion, F for lightning.
  Mobile: virtual joystick, hold sword, bow, roll, and extra tool buttons.

Mission: Free three villagers, find the rune key, defeat the stone golem,
and reach the exit. Equip loot and spend level-up points on enchantments.

Unofficial fan recreation. Character and environment assets are rebuilt
with code; no source assets from the reference video are included.
