EMBERWOOD · Voxel Quest

Open emberwood.html from a local web server, or run:
  node serve.cjs
Then visit http://127.0.0.1:4240/

Controls
  Desktop: WASD / arrow keys to move, J or click for sword, K for arc bolt,
  Space to dash.
  Mobile: virtual joystick and three action buttons.

The game contains an original voxel hero and world built with Three.js.
No source assets from the reference video are included.
