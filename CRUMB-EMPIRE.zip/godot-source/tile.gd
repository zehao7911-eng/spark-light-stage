extends Button
const Art=preload('res://art.gd')
var kind=0
var title_=''
var sub=''
var count_=''
var gold=false
var compact=false
var meter=0.0
var scenery=-1
var anim=0.0
var stone=false
var font_=ThemeDB.fallback_font
var title_font:Font
func _ready():
	title_font=FontVariation.new();title_font.base_font=preload('res://fonts/Bitter.ttf');title_font.variation_opentype={2003265652:650.0}
	flat=true;mouse_default_cursor_shape=Control.CURSOR_POINTING_HAND;focus_mode=Control.FOCUS_ALL;clip_contents=true
func _draw():
	var r=Rect2(Vector2.ZERO,size)
	var style=StyleBoxFlat.new();style.bg_color=Color('#223142') if not gold else Color('#4b3d28');style.border_color=Color('#746347') if gold else Color('#4d5861');style.set_border_width_all(1);style.corner_radius_top_left=4;style.corner_radius_top_right=4;style.corner_radius_bottom_left=4;style.corner_radius_bottom_right=4
	if is_hovered() and not disabled:style.bg_color=style.bg_color.lightened(.12)
	if is_pressed():style.bg_color=style.bg_color.darkened(.2)
	if stone:
		style.bg_color=Color('#acb3ad') if not disabled else Color('#73817f');style.border_color=Color('#5b4b38');style.corner_radius_top_left=0;style.corner_radius_top_right=0;style.corner_radius_bottom_left=0;style.corner_radius_bottom_right=0
		if is_hovered() and not disabled:style.bg_color=style.bg_color.lightened(.14)
	draw_style_box(style,r);draw_rect(Rect2(2,2,size.x-4,2),Color(1,1,1,.16))
	if stone:
		for y in range(5,int(size.y)-3,9):draw_line(Vector2(2,y),Vector2(size.x-2,y),Color(1,1,1,.04),1)
	if scenery>=0:Art.vignette(self,Rect2(2,49,size.x-4,size.y-51),scenery,int(count_),anim)
	if meter>0:draw_rect(Rect2(1,size.y-4,(size.x-2)*clampf(meter,0,1),3),Color('#d9b975'))
	var alpha=.43 if disabled else 1.0
	Art.icon(self,kind,Vector2(7,maxf(5,(size.y-32)/2)),1.0)
	if compact:
		if sub!='':draw_string(font_,Vector2(3,size.y-4),sub,HORIZONTAL_ALIGNMENT_CENTER,size.x-6,10,Color('#f5dfae'))
	else:
		if stone:draw_string(title_font,Vector2(49,25),title_,HORIZONTAL_ALIGNMENT_LEFT,maxf(1,size.x-94),19,Color(0,0,0,.3))
		draw_string(title_font,Vector2(48,23),title_,HORIZONTAL_ALIGNMENT_LEFT,maxf(1,size.x-94),19 if stone else 17,Color(1,.98,.89,.95) if stone else Color(1,.94,.84,alpha))
		draw_string(font_,Vector2(48,43),sub,HORIZONTAL_ALIGNMENT_LEFT,maxf(1,size.x-60),12,Color('#2e5236') if stone and not disabled else Color(.87,.76,.55,alpha))
		var tw=font_.get_string_size(count_,HORIZONTAL_ALIGNMENT_LEFT,-1,24).x
		draw_string(font_,Vector2(size.x-tw-12,32),count_,HORIZONTAL_ALIGNMENT_LEFT,-1,24,Color(1,.94,.84,alpha*.5))
	if has_focus():draw_rect(Rect2(2,2,size.x-4,size.y-4),Color('#f4d798'),false,2)
