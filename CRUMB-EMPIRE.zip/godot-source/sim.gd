extends RefCounted

const NAMES=['Cursor','Grandma','Farm','Mine','Factory','Bank','Temple','Wizard','Shipment','Alchemy','Portal','Time machine']
const PRICES=[15.0,100.0,1100.0,12000.0,130000.0,1400000.0,20000000.0,330000000.0,5100000000.0,75000000000.0,1000000000000.0,14000000000000.0]
const RATES=[0.1,1.0,8.0,47.0,260.0,1400.0,7800.0,44000.0,260000.0,1600000.0,10000000.0,65000000.0]
const GOALS=[1,100,1000,10000,100000,1000000,100000000,10000000000,1000000000000,100000000000000]
var bank=0.0
var lifetime=0.0
var run=0.0
var buildings=[]
var upgrades=[]
var clicks=0
var manual=0.0
var gold_clicks=0
var golden=0.0
var gold_wait=22.0
var frenzy=0.0
var click_frenzy=0.0
var harvest_boost=0.0
var plants=[]
var harvests=0
var mana=0.0
var chips=0
var ascensions=0
var heavenly=[]
var elapsed=0.0
var started=false
var paused=false
var muted=false
var calm=false
var mode=1
var badge_count=0
var badges=[]
var events=[]
var rng=RandomNumberGenerator.new()

func _init():
	buildings.resize(12);buildings.fill(0)
	plants.resize(9);plants.fill(-1.0)
	heavenly.resize(3);heavenly.fill(0)
	rng.seed=761234
func fmt(n):
	if n<10:return ('%.1f'%n).trim_suffix('.0')
	if n<1000:return str(int(floor(n+0.000001)))
	var tier=int(floor(log(maxf(1,n))/log(1000.0)))
	if tier<=8:return ('%.2f'%(n/pow(1000,tier))).trim_suffix('0').trim_suffix('.')+['','K','M','B','T','Qa','Qi','Sx','Sp'][tier]
	return '%.2e'%n
func earn(n):
	n=clampf(n,0,1e200);bank=minf(1e200,bank+n);lifetime=minf(1e200,lifetime+n);run=minf(1e200,run+n)
func production_base():
	var out=0.0
	for i in range(12):
		var mult=1.0
		for t in range(3):
			if i*3+t in upgrades:mult*=2
		out+=RATES[i]*buildings[i]*mult
	var global_mult=1.0
	for k in range(4):
		if 50+k in upgrades:global_mult*=1.25
	var earned_chips=chips
	for level in heavenly:earned_chips+=level*level
	return out*global_mult*(1.0+earned_chips*0.15)*(1.0+milestones().size()*0.02)*(1.0+heavenly[0]*0.25)
func building_rate(i):
	var total_raw=0.0;var own=0.0
	for j in range(12):
		var rate=RATES[j]*buildings[j]
		for t in range(3):
			if j*3+t in upgrades:rate*=2
		total_raw+=rate
		if j==i:own=rate
	return cps()*own/total_raw if total_raw>0 else 0.0
func cps():return production_base()*(7.0 if frenzy>0 else 1.0)*(1.5 if harvest_boost>0 else 1.0)
func click_value():
	var power_=1.0
	for k in range(5):
		if 40+k in upgrades:power_*=2
	power_+=production_base()*0.01*heavenly[2]
	return power_*(777.0 if click_frenzy>0 else 1.0)*(7.0 if frenzy>0 else 1.0)
func tap():
	if not started or paused:return 0.0
	var value=click_value();earn(value);clicks+=1;manual+=value;return value
func cost(i,n=1):
	return ceil(PRICES[i]*pow(1.15,buildings[i])*(pow(1.15,n)-1.0)/0.15-0.0000001)
func amount(i):
	if mode!=0:return mode
	var n=0
	while n<100 and cost(i,n+1)<=bank:n+=1
	return maxi(1,n)
func buy(i):
	if paused or i<0 or i>=12:return false
	var n=amount(i);var price=cost(i,n)
	if bank+0.000001<price or buildings[i]+n>1000:return false
	bank=maxf(0,bank-price);buildings[i]+=n;events.append(['buy',i]);return true
func sell(i):
	if paused or i<0 or i>=12 or buildings[i]<=0:return false
	var n=mini(buildings[i],mode if mode>0 else buildings[i]);var refund=0.0
	for j in range(n):refund+=ceil(PRICES[i]*pow(1.15,buildings[i]-1-j)-.0000001)*.25
	buildings[i]-=n;bank+=floor(refund);events.append(['sell',i]);return true
func upgrade_info(id):
	if id<36:
		var i=int(id/3);var tier=id%3
		return {'name':NAMES[i]+' ×2','price':PRICES[i]*[10,50,250][tier],'ready':buildings[i]>=[1,10,25][tier],'icon':i,'detail':'Double this building’s production.'}
	if id>=40 and id<=44:
		return {'name':'Handmade ×2','price':50.0*pow(10,id-40),'ready':clicks>=[20,100,500,1500,5000][id-40],'icon':12,'detail':'Double cookies earned by tapping.'}
	return {'name':'Butter biscuit','price':1000.0*pow(20,id-50),'ready':run>=500.0*pow(20,id-50),'icon':13,'detail':'+25% production from all buildings.'}
func available_upgrades():
	var out=[]
	for id in range(36):
		if not id in upgrades and upgrade_info(id).ready:out.append(id)
	for id in [40,41,42,43,44,50,51,52,53]:
		if not id in upgrades and upgrade_info(id).ready:out.append(id)
	out.sort_custom(func(a,b):return upgrade_info(a).price<upgrade_info(b).price)
	return out
func buy_upgrade(id):
	if paused or id in upgrades or not id in available_upgrades():return false
	var p=upgrade_info(id).price
	if bank<p:return false
	bank-=p;upgrades.append(id);events.append(['upgrade',id]);return true
func milestones():
	var out=[]
	for i in range(GOALS.size()):
		if lifetime>=GOALS[i]:out.append(i)
	for i in range(12):
		if buildings[i]>0:out.append(10+i)
	for i in range(5):
		if clicks>=[10,100,1000,5000,20000][i]:out.append(22+i)
	for i in range(3):
		if gold_clicks>=[1,7,25][i]:out.append(27+i)
	if harvests>0:out.append(30)
	if ascensions>0:out.append(31)
	for id in out:
		if not id in badges:badges.append(id)
	badges.sort();return badges.duplicate()
func update(dt):
	if not started or paused:return
	dt=clampf(dt,0,1.0);elapsed+=dt
	# Integrate at buff boundaries so expiring effects do not multiply a whole interval.
	var left=dt
	while left>0.0000001:
		var step=left
		for buff in [frenzy,harvest_boost]:
			if buff>0:step=minf(step,buff)
		earn(cps()*step);frenzy=maxf(0,frenzy-step);harvest_boost=maxf(0,harvest_boost-step);left-=step
	click_frenzy=maxf(0,click_frenzy-dt)
	if golden>0:golden=maxf(0,golden-dt)
	else:
		gold_wait-=dt
		if gold_wait<=0:golden=13;gold_wait=rng.randf_range(38,65);events.append(['gold',0])
	for i in range(9):
		if plants[i]>0:plants[i]=maxf(0,plants[i]-dt)
	if buildings[7]>0:mana=minf(100,mana+dt*2)
	var b=milestones().size()
	if b>badge_count:badge_count=b;events.append(['badge',b])
func collect_gold(kind=-1):
	if paused or golden<=0:return ''
	golden=0;gold_clicks+=1
	if kind<0:kind=rng.randi_range(0,2)
	if kind==0:frenzy=maxf(frenzy,30.0);events.append(['frenzy',7]);return 'FRENZY  ×7  ·  30s'
	if kind==1:
		var reward=maxf(25,minf(bank*0.15+25,production_base()*600+25));earn(reward);events.append(['lucky',reward]);return 'LUCKY  +'+fmt(reward)
	click_frenzy=maxf(click_frenzy,9.0);events.append(['frenzy',777]);return 'CLICK FRENZY  ×777  ·  9s'
func plant(i):
	if paused or buildings[2]<=0 or i<0 or i>8:return false
	if plants[i]==0:
		plants[i]=-1;harvests+=1;harvest_boost=45;earn(maxf(15,production_base()*15));events.append(['harvest',i]);return true
	if plants[i]<0 and bank>=10:bank-=10;plants[i]=30.0;events.append(['plant',i]);return true
	return false
func cast():
	if paused or buildings[7]<=0 or mana<100:return false
	mana=0;golden=13;events.append(['gold',0]);return true
func ascend_gain():return maxi(0,int(floor(pow(run/1000000.0,0.5))))
func ascend():
	var gain=ascend_gain()
	if gain<1 or paused:return false
	chips+=gain;ascensions+=1;bank=25.0+heavenly[1]*100;run=0;manual=0;clicks=0
	buildings.fill(0);upgrades.clear();plants.fill(-1.0);frenzy=0;click_frenzy=0;harvest_boost=0;golden=0;gold_wait=15;mana=0
	events.append(['ascend',gain]);return true
func heaven_buy(i):
	if i<0 or i>2 or heavenly[i]>=5 or paused:return false
	var price=1+heavenly[i]*2
	if chips<price:return false
	# Earned prestige power is not consumed: spent chips are recorded separately in heavenly levels.
	chips-=price;heavenly[i]+=1;events.append(['upgrade',i]);return true
func away(seconds):
	var secs=clampf(seconds,0,14400)
	var value=production_base()*secs*0.5
	earn(value);elapsed+=secs;frenzy=maxf(0,frenzy-secs);click_frenzy=maxf(0,click_frenzy-secs);harvest_boost=maxf(0,harvest_boost-secs);golden=0
	for i in range(9):
		if plants[i]>0:plants[i]=maxf(0,plants[i]-secs)
	if buildings[7]>0:mana=minf(100,mana+secs*2)
	return value
func snapshot():
	return {'version':1,'bank':bank,'lifetime':lifetime,'run':run,'buildings':buildings.duplicate(),'upgrades':upgrades.duplicate(),'clicks':clicks,'manual':manual,'gold_clicks':gold_clicks,'golden':golden,'gold_wait':gold_wait,'frenzy':frenzy,'click_frenzy':click_frenzy,'harvest_boost':harvest_boost,'plants':plants.duplicate(),'harvests':harvests,'mana':mana,'chips':chips,'ascensions':ascensions,'heavenly':heavenly.duplicate(),'elapsed':elapsed,'started':started,'paused':paused,'muted':muted,'calm':calm,'mode':mode,'badge_count':badge_count,'badges':badges.duplicate(),'rng':str(rng.state),'stamp':Time.get_unix_time_from_system()}
func restore(d):
	if not d is Dictionary or d.get('version')!=1:return false
	for key in ['buildings','plants','heavenly']:
		if not d.get(key) is Array or d[key].size()!={'buildings':12,'plants':9,'heavenly':3}[key]:return false
	for key in ['bank','lifetime','run','manual','golden','gold_wait','frenzy','click_frenzy','harvest_boost','mana','elapsed']:
		if not d.get(key) is float and not d.get(key) is int:return false
		if not is_finite(float(d[key])) or float(d[key])<0:return false
	if not d.get('upgrades') is Array:return false
	if not d.get('badges',[]) is Array:return false
	for x in d.get('badges',[]):
		if not (x is float or x is int) or x<0 or x>31:return false
	for i in range(12):
		if not (d.buildings[i] is float or d.buildings[i] is int) or d.buildings[i]<0 or d.buildings[i]>1000:return false
	for x in d.plants:
		if not (x is float or x is int) or not is_finite(x) or x< -1 or x>30:return false
	for x in d.heavenly:
		if not (x is float or x is int) or x<0 or x>5:return false
	for x in d.upgrades:
		if not int(x) in range(36) and not int(x) in [40,41,42,43,44,50,51,52,53]:return false
	for key in ['clicks','gold_clicks','harvests','chips','ascensions','badge_count']:
		if not (d.get(key) is float or d.get(key) is int) or d[key]<0 or d[key]>1e12:return false
	for key in ['bank','lifetime','run','manual','golden','gold_wait','frenzy','click_frenzy','harvest_boost','mana','elapsed','clicks','gold_clicks','harvests','chips','ascensions','badge_count']:set(key,d[key])
	buildings=d.buildings.map(func(x):return int(x));plants=d.plants.map(func(x):return float(x));heavenly=d.heavenly.map(func(x):return int(x));upgrades=d.upgrades.map(func(x):return int(x))
	badges=d.get('badges',[]).map(func(x):return int(x))
	for key in ['started','paused','muted','calm']:set(key,d.get(key,false)==true)
	mode=int(d.get('mode',1));if not mode in [0,1,10,100]:mode=1
	rng.state=int(d.get('rng','761234'));events.clear();return true
