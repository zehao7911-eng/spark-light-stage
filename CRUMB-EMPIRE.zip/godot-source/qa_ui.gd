extends SceneTree
func _initialize():call_deferred('run')
func run():
	var scene=load('res://main.tscn').instantiate();root.add_child(scene);await process_frame
	scene.fixture=true;scene.g=load('res://sim.gd').new();scene.g.started=true;scene.g.bank=10000000;scene.g.run=4000000;scene.layout()
	scene.command('buy',2);assert(scene.g.buildings[2]==1)
	scene.command('inspect',2);assert(scene.popup=='garden')
	scene.command('plant',0);assert(scene.g.plants[0]==30)
	for i in range(30):scene.g.update(1)
	scene.command('plant',0);assert(scene.g.harvests==1)
	scene.g.buildings[7]=1;scene.g.mana=100;scene.command('inspect',7);assert(scene.popup=='wizard');scene.command('cast');assert(scene.popup=='' and scene.g.golden==13)
	scene.command('ascend');scene.command('ascend-confirm');assert(scene.g.ascensions==1 and scene.g.chips>=2 and scene.g.buildings[2]==0)
	scene.command('heaven',0);assert(scene.g.heavenly[0]==1)
	scene.command('settings');scene.command('pause');var bank=scene.g.bank;scene.bake(scene.center);assert(scene.g.bank==bank)
	scene.command('pause');scene.command('close');scene.bake(scene.center);assert(scene.g.bank>bank)
	var narrow=SubViewport.new();narrow.size=Vector2i(320,667);root.add_child(narrow);root.remove_child(scene);narrow.add_child(scene);scene.layout();scene.open_popup('help');await process_frame
	assert(scene.view.x==320)
	for b in scene.buttons:
		if b.get_meta('id')=='close':assert(b.size.x>=44 and b.position.x>=0)
	var labels=[]
	collect_labels(scene.overlay,labels)
	for l in labels:assert(l.size.x<=300)
	print('PASS: native UI commands garden/wizard/ascend/heaven/pause/tap/narrow wrapped help')
	scene.queue_free();await process_frame;await process_frame;narrow.queue_free();await process_frame
	quit()
func collect_labels(node,out):
	if node is Label:out.append(node)
	for child in node.get_children():collect_labels(child,out)
