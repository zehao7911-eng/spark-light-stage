extends RefCounted

const INK=Color('#30241e')
const GOLD=Color('#f3cb7e')
const CREAM=Color('#fff1d0')

static func box(c,p,s,col):c.draw_rect(Rect2(p,s),Color(col))
static func disk(c,p,r,col):c.draw_circle(p,r,Color(col))
static func cookie(c,p,r,t=0.0,gold=false):
	var edge=PackedVector2Array()
	for i in range(80):
		var a=i*TAU/80;edge.append(p+Vector2(cos(a),sin(a))*r*(1.0+sin(i*2.7)*0.018))
	c.draw_colored_polygon(edge,Color('#8a4d28') if not gold else Color('#b07824'))
	for j in range(22):
		var rr=r*(0.97-j*0.012)
		var v=j/22.0
		var col=Color('#c17e3d').lerp(Color('#eabd77'),v)
		if gold:col=Color('#d39b31').lerp(Color('#ffde73'),v)
		disk(c,p+Vector2(-r*.035,-r*.05),rr,col)
	var rng_=RandomNumberGenerator.new();rng_.seed=9238
	for i in range(240):
		var a=rng_.randf()*TAU;var d=sqrt(rng_.randf())*r*.89;var q=p+Vector2(cos(a),sin(a))*d
		var v=rng_.randf();disk(c,q,r*rng_.randf_range(.004,.016),Color('#bb783e') if v<.5 else Color('#f8d99b'))
	var chips_=[Vector3(-.47,-.50,.13),Vector3(.17,-.68,.14),Vector3(.54,-.34,.12),Vector3(-.08,-.22,.145),Vector3(-.69,.06,.12),Vector3(.37,.08,.15),Vector3(-.34,.42,.16),Vector3(.10,.67,.13),Vector3(.65,.42,.10)]
	for i in range(chips_.size()):
		var v=chips_[i];var q=p+Vector2(v.x,v.y)*r;var rr=v.z*r
		disk(c,q+Vector2(1,2)*r*.02,rr*1.15,Color('#ac713f'))
		var pts=PackedVector2Array()
		for k in range(6):
			var a=k*TAU/6+i*.8;pts.append(q+Vector2(cos(a),sin(a))*rr*(.8+.2*sin(k*7+i)))
		c.draw_colored_polygon(pts,Color('#5b3426'))
		c.draw_line(q+Vector2(-rr*.5,-rr*.25),q+Vector2(rr*.25,-rr*.55),Color('#956043'),maxf(1,r*.015),true)
		c.draw_line(q+Vector2(rr*.3,rr*.45),q+Vector2(rr*.65,0),Color('#3e2821'),maxf(1,r*.012),true)
	# Soft baked highlight; the texture is deterministic original drawing, not a commercial sprite.
	c.draw_arc(p+Vector2(-r*.03,-r*.05),r*.91,3.65,5.6,42,Color(1,.88,.62,.35),maxf(1,r*.025),true)

static func icon(c,id,p,s=1.0):
	# Every building has its own original pixel silhouette. Coordinates are in a 32px cell.
	var dark='#45372d';var cream='#fbe8b1';var gold='#e9ad54';var blue='#77b1b7';var green='#78a15b'
	if id==0:
		var pts=PackedVector2Array([p+Vector2(7,3)*s,p+Vector2(7,26)*s,p+Vector2(13,20)*s,p+Vector2(19,29)*s,p+Vector2(24,26)*s,p+Vector2(18,17)*s,p+Vector2(27,17)*s])
		c.draw_colored_polygon(pts,Color(dark));c.draw_colored_polygon(PackedVector2Array([p+Vector2(9,7)*s,p+Vector2(9,22)*s,p+Vector2(14,17)*s,p+Vector2(20,27)*s,p+Vector2(22,26)*s,p+Vector2(17,16)*s,p+Vector2(23,16)*s]),Color(cream))
	elif id==1:
		box(c,p+Vector2(5,9)*s,Vector2(22,16)*s,dark);box(c,p+Vector2(8,5)*s,Vector2(16,11)*s,'#dadbd0');box(c,p+Vector2(10,12)*s,Vector2(12,10)*s,'#dba57f');box(c,p+Vector2(7,23)*s,Vector2(20,7)*s,'#ad6d73');box(c,p+Vector2(12,24)*s,Vector2(10,6)*s,cream)
		box(c,p+Vector2(11,15)*s,Vector2(4,3)*s,dark);box(c,p+Vector2(18,15)*s,Vector2(4,3)*s,dark);box(c,p+Vector2(15,16)*s,Vector2(3,1)*s,dark)
	elif id==2:
		box(c,p+Vector2(2,26)*s,Vector2(28,4)*s,dark);box(c,p+Vector2(7,12)*s,Vector2(18,16)*s,'#b76a52');c.draw_colored_polygon(PackedVector2Array([p+Vector2(4,12)*s,p+Vector2(16,2)*s,p+Vector2(28,12)*s]),Color(cream));box(c,p+Vector2(13,19)*s,Vector2(6,9)*s,dark)
		for x in [4,28]:box(c,p+Vector2(x,17)*s,Vector2(2,12)*s,green);box(c,p+Vector2(x-2,16)*s,Vector2(6,3)*s,gold)
	elif id==3:
		box(c,p+Vector2(4,10)*s,Vector2(24,20)*s,dark);box(c,p+Vector2(8,13)*s,Vector2(16,17)*s,'#182735');box(c,p+Vector2(2,7)*s,Vector2(28,5)*s,gold);box(c,p+Vector2(5,10)*s,Vector2(3,20)*s,'#bd8751');box(c,p+Vector2(24,10)*s,Vector2(3,20)*s,'#bd8751');box(c,p+Vector2(13,22)*s,Vector2(9,5)*s,blue)
	elif id==4:
		box(c,p+Vector2(3,14)*s,Vector2(26,16)*s,'#71888c');box(c,p+Vector2(7,3)*s,Vector2(6,13)*s,dark);box(c,p+Vector2(19,7)*s,Vector2(5,9)*s,dark);box(c,p+Vector2(3,13)*s,Vector2(26,3)*s,cream)
		for x in [7,17]:box(c,p+Vector2(x,20)*s,Vector2(6,5)*s,gold)
	elif id==5 or id==6:
		box(c,p+Vector2(3,25)*s,Vector2(26,5)*s,dark);c.draw_colored_polygon(PackedVector2Array([p+Vector2(2,9)*s,p+Vector2(16,1)*s,p+Vector2(30,9)*s]),Color(gold));box(c,p+Vector2(4,10)*s,Vector2(24,3)*s,cream)
		for x in [5,13,22]:box(c,p+Vector2(x,13)*s,Vector2(4,12)*s,cream)
		if id==6:disk(c,p+Vector2(16,7)*s,3*s,Color('#b86985'))
	elif id==7:
		box(c,p+Vector2(8,15)*s,Vector2(16,15)*s,'#9e86ad');c.draw_colored_polygon(PackedVector2Array([p+Vector2(3,16)*s,p+Vector2(17,1)*s,p+Vector2(29,16)*s]),Color('#5d4d87'));box(c,p+Vector2(13,22)*s,Vector2(6,8)*s,dark);disk(c,p+Vector2(19,10)*s,2*s,cream)
	elif id==8:
		box(c,p+Vector2(6,24)*s,Vector2(20,4)*s,dark);c.draw_colored_polygon(PackedVector2Array([p+Vector2(16,2)*s,p+Vector2(6,23)*s,p+Vector2(26,23)*s]),Color(cream));box(c,p+Vector2(13,11)*s,Vector2(6,12)*s,blue);box(c,p+Vector2(13,27)*s,Vector2(6,4)*s,gold)
	elif id==9:
		box(c,p+Vector2(12,3)*s,Vector2(8,13)*s,cream);box(c,p+Vector2(9,17)*s,Vector2(14,10)*s,green);box(c,p+Vector2(6,21)*s,Vector2(20,8)*s,green);box(c,p+Vector2(10,4)*s,Vector2(12,3)*s,dark);disk(c,p+Vector2(15,24)*s,3*s,gold)
	elif id==10:
		for i in range(5):c.draw_arc(p+Vector2(16,17)*s,(14-i*2)*s,0,TAU,28,Color('#aa77ca').lerp(Color('#392f67'),i/5.0),2*s,false)
		disk(c,p+Vector2(16,17)*s,4*s,Color('#f8ce89'))
	elif id==11:
		box(c,p+Vector2(5,3)*s,Vector2(22,27)*s,dark);box(c,p+Vector2(8,5)*s,Vector2(16,23)*s,'#b28252');disk(c,p+Vector2(16,15)*s,8*s,cream);c.draw_line(p+Vector2(16,15)*s,p+Vector2(16,9)*s,Color(dark),2*s);c.draw_line(p+Vector2(16,15)*s,p+Vector2(21,18)*s,Color(dark),2*s)
	elif id==12:cookie(c,p+Vector2(16,16)*s,13*s)
	elif id==13:box(c,p+Vector2(3,8)*s,Vector2(26,20)*s,'#cba256');box(c,p+Vector2(5,6)*s,Vector2(22,16)*s,'#ffe6a1');box(c,p+Vector2(10,10)*s,Vector2(12,3)*s,cream)
	elif id==14:
		var pts=PackedVector2Array()
		for i in range(10):pts.append(p+Vector2(16,16)*s+Vector2.from_angle(i*TAU/10-PI/2)*(14 if i%2==0 else 6)*s)
		c.draw_colored_polygon(pts,Color(gold));disk(c,p+Vector2(16,16)*s,3*s,cream)
	elif id==15:
		box(c,p+Vector2(4,22)*s,Vector2(24,7)*s,'#986845')
		for x in [9,21]:box(c,p+Vector2(x,13)*s,Vector2(2,12)*s,green);box(c,p+Vector2(x-4,10)*s,Vector2(5,5)*s,green);box(c,p+Vector2(x+1,6)*s,Vector2(6,6)*s,'#a5bd72')
	elif id==17:
		box(c,p+Vector2(3,12)*s,Vector2(7,10)*s,cream);c.draw_colored_polygon(PackedVector2Array([p+Vector2(9,12)*s,p+Vector2(18,5)*s,p+Vector2(18,28)*s,p+Vector2(9,22)*s]),Color(gold));c.draw_arc(p+Vector2(17,17)*s,10*s,-.9,.9,12,Color(cream),2*s,true)
	elif id==19:
		c.draw_line(p+Vector2(7,7)*s,p+Vector2(25,25)*s,Color(cream),3*s,true);c.draw_line(p+Vector2(7,25)*s,p+Vector2(25,7)*s,Color(cream),3*s,true)
	elif id==20:
		box(c,p+Vector2(7,5)*s,Vector2(6,23)*s,cream);box(c,p+Vector2(20,5)*s,Vector2(6,23)*s,cream)
	elif id==21:
		c.draw_arc(p+Vector2(16,16)*s,13*s,0,TAU,24,Color(gold),2*s,true);c.draw_arc(p+Vector2(16,12)*s,5*s,PI,TAU+PI*.5,16,Color(cream),2*s,true);box(c,p+Vector2(15,16)*s,Vector2(2,4)*s,cream);box(c,p+Vector2(15,23)*s,Vector2(2,2)*s,cream)
	elif id==22 or id==23:
		box(c,p+Vector2(4,3)*s,Vector2(24,27)*s,blue);box(c,p+Vector2(8,4)*s,Vector2(15,8)*s,dark);box(c,p+Vector2(8,18)*s,Vector2(16,11)*s,cream);box(c,p+Vector2(19,5)*s,Vector2(3,5)*s,cream)
	elif id==26:box(c,p+Vector2(4,19)*s,Vector2(24,10)*s,'#986845');box(c,p+Vector2(4,19)*s,Vector2(24,3)*s,'#574232')
	elif id==28:
		box(c,p+Vector2(4,22)*s,Vector2(24,7)*s,'#986845');box(c,p+Vector2(15,11)*s,Vector2(2,14)*s,green);box(c,p+Vector2(7,14)*s,Vector2(8,4)*s,green);cookie(c,p+Vector2(17,9)*s,7*s)
	else:
		c.draw_arc(p+Vector2(16,16)*s,12*s,0,TAU,28,Color(cream),3*s,true)
		for i in range(8):c.draw_line(p+Vector2.from_angle(i*TAU/8)*10*s+Vector2(16,16)*s,p+Vector2.from_angle(i*TAU/8)*16*s+Vector2(16,16)*s,Color(gold),3*s,true)

static func vignette(c,r,id,count,t):
	var palettes=[['#29495b','#508399'],['#4b3b3e','#926b64'],['#47604a','#7fa46b'],['#303a48','#58606d'],['#364855','#697f89'],['#3b414b','#a6926c'],['#3e4550','#a18c7a'],['#3c3653','#83709e'],['#233b53','#497291'],['#314d48','#589d80'],['#342c4c','#735c93'],['#413a37','#9d8b70']]
	var a=Color(palettes[id][0]);var b=Color(palettes[id][1]);c.draw_rect(r,a)
	for k in range(7):c.draw_rect(Rect2(r.position+Vector2(0,k*r.size.y/7),Vector2(r.size.x,r.size.y/7+1)),a.lerp(b,k/12.0))
	# Tiny wallpaper/stone marks are tied to each vignette, never cover the production controls.
	for x in range(int(r.position.x),int(r.end.x),18):
		for y in range(int(r.position.y+10),int(r.end.y-10),15):c.draw_rect(Rect2(x+(y%2)*6,y,3,2),Color(1,1,1,.045))
	c.draw_rect(Rect2(r.position+Vector2(0,r.size.y-12),Vector2(r.size.x,12)),Color('#2b2927'))
	c.draw_rect(Rect2(r.position+Vector2(0,r.size.y-12),Vector2(r.size.x,2)),b.lightened(.2))
	var n=mini(count,9)
	for i in range(n):
		var x=r.position.x+20+i*minf(36,(r.size.x-40)/maxf(1,n-1));var y=r.end.y-41
		if id==0:
			var a_=t*.5+i*TAU/maxf(1,n);icon(c,0,Vector2(x,y+sin(a_)*3),.85)
		else:icon(c,id,Vector2(x,y+sin(t*1.5+i)*.7),.9)
		if id==4:
			var sy=fmod(t*10+i*7,25);disk(c,Vector2(x+10,y-sy),2+sy*.08,Color(.8,.8,.75,.4*(1-sy/25)))
	c.draw_line(r.position,r.position+Vector2(r.size.x,0),GOLD.darkened(.5),2)
	c.draw_line(r.position+Vector2(0,3),r.position+Vector2(r.size.x,3),Color(1,1,1,.09),1)
