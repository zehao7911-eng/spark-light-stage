extends Node2D
const Sim=preload('res://sim.gd')
const Art=preload('res://art.gd')
const Tile=preload('res://tile.gd')
const SAVE='crumb-empire.v1'
var g=Sim.new()
var font_:Font
var ui:Control
var overlay:Control
var buttons=[]
var popup=''
var page=0
var view=Vector2(1280,800)
var root_scale=1.0
var safe=Vector2.ZERO
var old_raw=Vector2.ZERO
var hero=Rect2()
var bakery=Rect2()
var shop=Rect2()
var center=Vector2.ZERO
var radius=100.0
var cookie_tex:Texture2D
var gold_tex:Texture2D
var tick=0.0
var sync=0.0
var save_time=0.0
var age=0.0
var kick=0.0
var fx=[]
var pops=[]
var toast=''
var toast_time=0.0
var gold_pos=Vector2.ZERO
var gold_seen=false
var hidden_=false
var away_at=0.0
var callback
var sounds={}
var players=[]
var click_sound_wait=0.0
var cookie_hover=false
var fixture=false
var build_scroll:ScrollContainer
var upgrade_scroll:ScrollContainer
var modal_scroll:ScrollContainer
var wallets=[]
var tile_data=[]
var last_badges=0
var upgrade_signature=''
var save_input:TextEdit
var selling=false

func _ready():
	Engine.max_fps=60
	font_=FontVariation.new();font_.base_font=preload('res://fonts/Bitter.ttf');font_.variation_opentype={2003265652:650.0}
	for name_ in ['tap','buy','gold','badge','ascend','harvest']:
		if ResourceLoader.exists('res://audio/'+name_+'.wav'):sounds[name_]=load('res://audio/'+name_+'.wav')
	for i in range(8):var player=AudioStreamPlayer.new();add_child(player);players.append(player)
	ui=Control.new();ui.mouse_filter=Control.MOUSE_FILTER_IGNORE;add_child(ui)
	load_game()
	if '--art-qa' in OS.get_cmdline_user_args():
		fixture=true;g.started=true;g.bank=375000;g.run=1280000;g.lifetime=1280000;g.clicks=682;g.buildings=[25,16,10,4,1,0,0,0,0,0,0,0];g.upgrades=[0,1,3,6,40,50];g.frenzy=24;g.golden=13;g.badge_count=g.milestones().size()
	make_cookie(false);make_cookie(true)
	layout()
	if not g.started:open_popup('welcome')
	if OS.has_feature('web'):
		callback=JavaScriptBridge.create_callback(lifecycle)
		JavaScriptBridge.get_interface('window').crumbLifecycle=callback
		JavaScriptBridge.eval('window.crumbReady && window.crumbReady()')
	web_snapshot()
func make_cookie(golden_):
	var vp=SubViewport.new();vp.size=Vector2i(512,512);vp.transparent_bg=true;vp.render_target_update_mode=SubViewport.UPDATE_ONCE;add_child(vp)
	var node=Node2D.new();vp.add_child(node);node.draw.connect(func():Art.cookie(node,Vector2(256,256),238,0,golden_));node.queue_redraw()
	if golden_:gold_tex=vp.get_texture()
	else:cookie_tex=vp.get_texture()
func txt(s,p,sz=14,col=Color('#f4e7ce')):draw_string(font_,p,str(s),HORIZONTAL_ALIGNMENT_LEFT,-1,sz,col)
func ct(s,p,sz=14,col=Color('#f4e7ce')):
	var w=font_.get_string_size(str(s),HORIZONTAL_ALIGNMENT_LEFT,-1,sz).x;txt(s,p-Vector2(w*.5,0),sz,col)
func panel(r,bg=Color('#18293b'),border=Color('#776044')):
	draw_rect(r,bg);draw_rect(r,Color('#37281f'),false,6);draw_rect(r.grow(-2),border,false,1);draw_rect(Rect2(r.position+Vector2(3,3),Vector2(r.size.x-6,1)),Color(1,1,1,.12))
	for y in range(int(r.position.y+8),int(r.end.y-8),23):draw_line(Vector2(r.position.x-1,y),Vector2(r.position.x+1,y+8),Color('#6c4b30'),1)
func label_(parent,s,p,size_,sz=15,col=Color('#f0e4cb')):
	var l=Label.new();l.position=p;l.size=size_;l.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;l.clip_text=true;l.mouse_filter=Control.MOUSE_FILTER_IGNORE;l.add_theme_font_size_override('font_size',sz);l.add_theme_color_override('font_color',col)
	if sz>=18:l.add_theme_font_override('font',font_)
	l.text=str(s);parent.add_child(l);return l
func tile(parent,id,kind,r,title_='',sub='',action='',n=0,compact_=false):
	var b=Tile.new();b.position=r.position;b.size=r.size;b.custom_minimum_size=r.size;b.kind=kind;b.title_=title_;b.sub=sub;b.compact=compact_;b.tooltip_text=title_+'\n'+sub;b.set_meta('id',id);b.set_meta('action',action);b.set_meta('n',n);b.stone=action=='buy';parent.add_child(b);b.pressed.connect(func():command(action,n),CONNECT_DEFERRED);buttons.append(b);return b
func scroller(parent,r):
	var sc=ScrollContainer.new();sc.position=r.position;sc.size=r.size;sc.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED;parent.add_child(sc)
	var content=Control.new();content.custom_minimum_size=Vector2(r.size.x-12,100);content.mouse_filter=Control.MOUSE_FILTER_IGNORE;sc.add_child(content);return [sc,content]
func layout():
	var previous_scroll=build_scroll.scroll_vertical if is_instance_valid(build_scroll) else 0
	old_raw=get_viewport_rect().size;root_scale=maxf(1,DisplayServer.screen_get_scale()) if OS.has_feature('web') else 1.0
	var insets=[0,0,0,0]
	if OS.has_feature('web'):
		var raw=JavaScriptBridge.eval('JSON.stringify(["--sal","--sat","--sar","--sab"].map(k=>parseFloat(getComputedStyle(document.documentElement).getPropertyValue(k))||0))')
		var parsed=JSON.parse_string(str(raw));if parsed is Array:insets=parsed
	safe=Vector2(insets[0],insets[1]);scale=Vector2.ONE*root_scale;position=safe*root_scale;view=old_raw/root_scale-Vector2(insets[0]+insets[2],insets[1]+insets[3])
	for c in ui.get_children():c.free()
	buttons=[];tile_data=[];wallets=[];build_scroll=null;upgrade_scroll=null
	var mobile=view.x<900
	if not mobile:
		hero=Rect2(14,70,view.x*.34-16,view.y-90);bakery=Rect2(view.x*.34+12,70,view.x*.32-22,view.y-90);shop=Rect2(view.x*.66+6,70,view.x*.34-20,view.y-90)
		create_shop(shop)
		create_bakery(bakery)
	else:
		hero=Rect2(10,70,view.x-20,view.y-142);bakery=hero;shop=hero
		if page==1:create_shop(shop)
		if page==2:create_bakery(bakery)
		for i in range(4):tile(ui,'tab-'+str(i),[12,4,1,14][i],Rect2(10+i*(view.x-20)/4,view.y-62,(view.x-28)/4,48),['Bake','Store','Bakery','Album'][i],'','page',i,true)
	center=hero.position+Vector2(hero.size.x*.5,hero.size.y*.46)
	radius=minf(hero.size.x*.34,hero.size.y*.27)
	if mobile and view.x>view.y:
		center=hero.position+Vector2(hero.size.x*.29,hero.size.y*.54);radius=minf(hero.size.y*.34,hero.size.x*.15)
	# Native icon buttons with a minimum 44 CSS-pixel touch area.
	tile(ui,'sound',17,Rect2(view.x-106,12,44,44),'Sound','','sound',0,true)
	tile(ui,'settings',16,Rect2(view.x-56,12,44,44),'Settings','','settings',0,true)
	if mobile:
		if page==0:
			if view.x>view.y:
				tile(ui,'quick-buy',0,Rect2(hero.position.x+hero.size.x*.59,hero.position.y+90,hero.size.x*.38,52),'Cursor','','buy',0)
				tile(ui,'quick-grandma',1,Rect2(hero.position.x+hero.size.x*.59,hero.position.y+148,hero.size.x*.38,52),'Grandma','','buy',1)
			else:
				tile(ui,'quick-buy',0,Rect2(hero.position.x+12,hero.end.y-62,hero.size.x-24,52),'Cursor','','buy',0)
				if hero.size.y>420:tile(ui,'quick-grandma',1,Rect2(hero.position.x+12,hero.end.y-120,hero.size.x-24,52),'Grandma','','buy',1)
	if is_instance_valid(build_scroll):build_scroll.set_deferred('scroll_vertical',previous_scroll)
	upgrade_signature=str(g.available_upgrades())
	if g.golden>0:place_gold()
	if popup!='':build_popup()
	refresh();queue_redraw();web_snapshot()
func create_shop(r):
	label_(ui,'STORE',r.position+Vector2(14,10),Vector2(r.size.x-100,30),18)
	tile(ui,'trade',5,Rect2(r.end.x-132,r.position.y+5,46,44),'Trade','','trade',0,true)
	tile(ui,'mode',0,Rect2(r.end.x-80,r.position.y+5,66,44),'Quantity','','mode',0,true)
	var up=scroller(ui,Rect2(r.position+Vector2(10,56),Vector2(r.size.x-20,58)));upgrade_scroll=up[0]
	var available=g.available_upgrades();var number=min(available.size(),40)
	up[1].custom_minimum_size=Vector2(number*54,52);upgrade_scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_AUTO;upgrade_scroll.vertical_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED
	for j in range(number):
		var id=available[j];var d=g.upgrade_info(id);var b=tile(up[1],'upgrade-'+str(id),d.icon,Rect2(j*54,0,48,48),d.name,g.fmt(d.price),'upgrade',id,true);b.tooltip_text=d.name+' · '+g.fmt(d.price)+' cookies\n'+d.detail
	if number==0:label_(up[1],'Upgrades appear as you grow',Vector2(4,15),Vector2(r.size.x-32,28),12,Color('#afad9f'))
	var rows=scroller(ui,Rect2(r.position+Vector2(10,124),Vector2(r.size.x-20,r.size.y-136)));build_scroll=rows[0]
	var visible=3
	for i in range(12):
		if g.buildings[i]>0 or g.lifetime>=Sim.PRICES[i]*.35:visible=maxi(visible,mini(12,i+2))
	rows[1].custom_minimum_size.y=visible*66
	for i in range(visible):tile(rows[1],'buy-'+str(i),i,Rect2(0,i*66,r.size.x-34,60),Sim.NAMES[i],'','buy',i)
func create_bakery(r):
	label_(ui,'YOUR BAKERY',r.position+Vector2(12,9),Vector2(r.size.x-24,30),18)
	var rows=scroller(ui,Rect2(r.position+Vector2(8,46),Vector2(r.size.x-16,r.size.y-56)))
	var count_=0
	for i in range(12):
		if g.buildings[i]>0:count_+=1
	rows[1].custom_minimum_size.y=maxf(r.size.y-66,count_*106+60)
	var y=0
	for i in range(12):
		if g.buildings[i]<=0:continue
		var b=tile(rows[1],'scene-'+str(i),i,Rect2(0,y,r.size.x-30,98),Sim.NAMES[i],'','inspect',i)
		b.scenery=i;b.set_meta('vignette',true);tile_data.append(b);y+=106
	if count_==0:label_(rows[1],'Your first helper is one cursor away.',Vector2(16,50),Vector2(r.size.x-50,80),16,Color('#b5b9b2'))
	label_(rows[1],'Every helper has a place here.',Vector2(8,y+12),Vector2(r.size.x-40,35),12,Color('#a5adad'))
func refresh():
	for b in buttons:
		if not is_instance_valid(b):continue
		var action=b.get_meta('action');var n=int(b.get_meta('n'))
		if action=='buy':
			b.sub=('SELL  25% refund' if selling else g.fmt(g.cost(n,g.amount(n)))+'  •  '+g.fmt(g.building_rate(n))+'/s');b.count_=str(g.buildings[n]);b.disabled=g.paused or (g.buildings[n]<=0 if selling else g.bank+1e-6<g.cost(n,g.amount(n)));b.tooltip_text=Sim.NAMES[n]+' · '+('Sell' if selling else 'Buy '+str(g.amount(n)))+'\nCost '+g.fmt(g.cost(n,g.amount(n)))+' cookies'
		elif action=='upgrade':b.disabled=g.paused or g.bank<g.upgrade_info(n).price
		elif action=='mode':b.sub='MAX' if g.mode==0 else '×'+str(g.mode)
		elif action=='trade':b.sub='SELL' if selling else 'BUY'
		elif action=='plant':
			b.sub='10' if g.plants[n]<0 else ('READY' if g.plants[n]==0 else str(int(ceil(g.plants[n])))+'s');b.disabled=g.paused or (g.plants[n]>0) or (g.plants[n]<0 and g.bank<10);b.kind=26 if g.plants[n]<0 else (28 if g.plants[n]==0 else 15);b.meter=1.0-g.plants[n]/30 if g.plants[n]>=0 else 0
		elif action=='cast':b.sub=str(int(g.mana))+' / 100';b.disabled=g.paused or g.mana<100
		elif action=='ascend-confirm':b.disabled=g.paused or g.ascend_gain()<1;b.sub='+'+str(g.ascend_gain())+' heavenly chips'
		elif action=='heaven':b.disabled=g.paused or g.chips<1+int(g.heavenly[n])*2 or g.heavenly[n]>=5;b.sub=str(1+int(g.heavenly[n])*2)+' chips  •  '+str(g.heavenly[n])+'/5'
		elif action=='inspect':b.count_=str(g.buildings[n]);b.sub='GARDEN' if n==2 else ('GRIMOIRE' if n==7 else g.fmt(g.building_rate(n))+' /s')
		b.anim=age;b.queue_redraw()
func open_popup(name_):popup=name_;build_popup();web_snapshot()
func build_popup():
	if is_instance_valid(overlay):overlay.free()
	buttons=buttons.filter(func(b):return is_instance_valid(b))
	overlay=Control.new();overlay.mouse_filter=Control.MOUSE_FILTER_STOP;overlay.size=view;ui.add_child(overlay)
	var bg=ColorRect.new();bg.color=Color(0.025,.04,.06,.88);bg.size=view;overlay.add_child(bg)
	var w=minf(560,view.x-24);var h=minf(620,view.y-42);var origin=(view-Vector2(w,h))/2
	var frame=Panel.new();frame.position=origin;frame.size=Vector2(w,h);var st=StyleBoxFlat.new();st.bg_color=Color('#1b2c3b');st.border_color=Color('#a38b5c');st.set_border_width_all(2);frame.add_theme_stylebox_override('panel',st);overlay.add_child(frame)
	var titles={'welcome':'A little cookie. A very big dream.','settings':'Bakery desk','album':'Achievements','ascend':'Beyond the bakery','garden':'Cookie garden','wizard':'The grimoire','help':'One more cookie','reset':'Start a fresh bakery?','stats':'Bakery ledger','import':'Restore a bakery'}
	label_(frame,titles.get(popup,'Bakery'),Vector2(18,16),Vector2(w-88,58),23)
	if popup!='welcome':tile(frame,'close',19,Rect2(w-62,10,44,44),'Close','','close',0,true)
	var result=scroller(frame,Rect2(16,80,w-32,h-100));modal_scroll=result[0];var body=result[1];var bw=w-48;var y=0.0
	if popup=='welcome':
		label_(body,'Tap the cookie. Hire helpers. Catch the golden ones.',Vector2(5,y),Vector2(bw-10,70),19);y+=80
		for i in range(4):tile(body,'intro-'+str(i),[12,1,14,10][i],Rect2(i*bw/4,y,bw/4-6,56),'','','none',0,true)
		y+=82;label_(body,'A tiny beginning becomes an impossible bakery. Your progress is saved automatically.',Vector2(5,y),Vector2(bw-10,85),15);y+=100
		tile(body,'start',12,Rect2(0,y,bw,58),'LET’S BAKE','','start');y+=70
	elif popup=='settings':
		for item in [['pause',20,'Resume' if g.paused else 'Pause'],['sound',17,'Sound off' if not g.muted else 'Sound on'],['calm',14,'Calm motion' if not g.calm else 'Full motion'],['stats',5,'Statistics'],['album',14,'Achievements'],['ascend',10,'Ascension'],['help',21,'Quick guide'],['export',22,'Export save'],['import',23,'Import save'],['reset',3,'Fresh bakery']]:
			tile(body,'setting-'+item[0],item[1],Rect2(0,y,bw,54),item[2],'',item[0]);y+=62
	elif popup=='help':
		label_(body,'Tap the big cookie to bake.\n\nHire makers in the Store. Each building adds cookies every second. Prices rise by 15% per purchase.\n\nBuy the small upgrade icons to double a building or improve tapping. Hold an icon to read its tooltip on desktop.\n\nCatch golden cookies for a lucky payout, ×7 production or a short ×777 tapping frenzy.\n\nA Farm unlocks the garden. A Wizard unlocks spells. Ascend after baking 1M in a run for permanent heavenly growth.\n\nSpace: bake · Escape: close. Progress stays in this browser; export a backup before clearing browser data.',Vector2(2,0),Vector2(bw-4,650),16);y=660
	elif popup=='album':
		var earned=g.milestones()
		label_(body,str(earned.size())+' / 32  •  Milk bonus +'+str(earned.size()*2)+'%',Vector2(2,0),Vector2(bw-4,35),17);y=42
		for i in range(32):
			var col=i%4;var row=int(i/4);var size_=(bw-18)/4
			var name_='Bake '+g.fmt(Sim.GOALS[i]) if i<10 else (Sim.NAMES[i-10] if i<22 else ('Handmade' if i<27 else 'Golden touch'))
			var b=tile(body,'badge-'+str(i),14 if i in earned else 16,Rect2(col*(size_+6),y+row*62,size_,56),name_,str(i+1) if i in earned else '•','none',0,true);b.gold=i in earned;b.tooltip_text=name_+' · '+('Unlocked' if i in earned else 'Not yet')
		y+=8*62
	elif popup=='ascend':
		label_(body,'Reset buildings and ordinary upgrades. Keep achievements and heavenly upgrades. Each earned chip gives +15% production, even after spending it.',Vector2(2,y),Vector2(bw-4,100),16);y+=110
		label_(body,'This run  '+g.fmt(g.run)+'  /  1M\nHeavenly chips  '+str(g.chips),Vector2(2,y),Vector2(bw-4,60),18);y+=72
		tile(body,'ascend-confirm',10,Rect2(0,y,bw,60),'ASCEND','','ascend-confirm');y+=76
		for i in range(3):tile(body,'heaven-'+str(i),[14,5,0][i],Rect2(0,y,bw,58),['Heavenly butter','Starter bakery','Celestial fingers'][i],'','heaven',i);y+=66
	elif popup=='garden':
		label_(body,'Plant for 10 cookies. Harvest after 30 seconds: cookies + 45s of ×1.5 production.',Vector2(2,y),Vector2(bw-4,74),16);y+=84
		var size_=(bw-16)/3
		for i in range(9):tile(body,'plot-'+str(i),15,Rect2((i%3)*(size_+8),y+int(i/3)*84,size_,76),'Plot','','plant',i,true)
		y+=270
	elif popup=='wizard':
		label_(body,'Conjure a golden cookie. Magic refills while your wizard works.',Vector2(2,0),Vector2(bw-4,90),18);y=110
		tile(body,'cast',7,Rect2(0,y,bw,70),'CONJURE','','cast');y+=85
	elif popup=='reset':
		label_(body,'This deletes this bakery’s local progress. Export a save first if you want to keep it.',Vector2(2,0),Vector2(bw-4,110),17);y=130
		tile(body,'reset-confirm',3,Rect2(0,y,bw,60),'RESET THIS BAKERY','','reset-confirm');y+=75
	elif popup=='import':
		label_(body,'Paste an exported Crumb Empire JSON save. Restoring replaces this bakery.',Vector2(2,0),Vector2(bw-4,85),16)
		save_input=TextEdit.new();save_input.position=Vector2(0,95);save_input.size=Vector2(bw,200);save_input.placeholder_text='Paste save JSON here';body.add_child(save_input)
		tile(body,'import-apply',5,Rect2(0,312,bw,58),'RESTORE SAVE','','import-apply');y=390
	elif popup=='stats':
		label_(body,'Cookies baked  '+g.fmt(g.lifetime)+'\nThis ascension  '+g.fmt(g.run)+'\nPer second  '+g.fmt(g.cps())+'\nPer tap  '+g.fmt(g.click_value())+'\nHandmade  '+g.fmt(g.manual)+'\nGolden cookies  '+str(g.gold_clicks)+'\nUpgrades  '+str(g.upgrades.size())+' / 45\nHarvests  '+str(g.harvests)+'\nAscensions  '+str(g.ascensions)+'\nTime baked  '+str(int(g.elapsed/60))+' min',Vector2(4,0),Vector2(bw-8,420),18);y=430
	body.custom_minimum_size.y=y;refresh()
func command(action,n=0):
	var rebuild=false
	match action:
		'start':g.started=true;popup='';rebuild=true
		'close':popup='';rebuild=true
		'page':
			if n==3:open_popup('album')
			else:page=n;popup='';rebuild=true
		'buy':
			var amount_=mini(g.buildings[n],g.mode if g.mode>0 else g.buildings[n]) if selling else g.amount(n)
			if (g.sell(n) if selling else g.buy(n)):notify(Sim.NAMES[n]+(' −' if selling else ' +')+str(amount_));sound('buy');rebuild=true
		'upgrade':
			if g.buy_upgrade(n):notify(g.upgrade_info(n).name);sound('buy');rebuild=true
		'mode':g.mode=10 if g.mode==1 else (100 if g.mode==10 else (0 if g.mode==100 else 1))
		'trade':selling=not selling
		'inspect':
			if n==2:open_popup('garden')
			elif n==7:open_popup('wizard')
			else:notify(Sim.NAMES[n]+'  ·  '+str(g.buildings[n])+' working')
		'settings','album','ascend','help','reset','stats','import':open_popup(action)
		'pause':g.paused=not g.paused;notify('Paused' if g.paused else 'Back to baking');build_popup()
		'sound':
			g.muted=not g.muted;notify('Sound off' if g.muted else 'Sound on')
			if g.muted:for p in players:p.stop()
			if popup=='settings':build_popup()
		'calm':
			g.calm=not g.calm;notify('Calm motion' if g.calm else 'Full motion')
			if popup=='settings':build_popup()
		'ascend-confirm':
			if g.ascend():notify('A new beginning');sound('ascend');rebuild=true
		'heaven':
			if g.heaven_buy(n):sound('buy');build_popup()
		'plant':
			if g.plant(n):sound('harvest');notify('Harvest!  ×1.5 production' if g.plants[n]<0 else 'A little patience…')
		'cast':
			if g.cast():popup='';page=0;rebuild=true;sound('gold')
		'export':export_save()
		'import-apply':
			var data=JSON.parse_string(save_input.text)
			if g.restore(data):popup='';page=0;notify('Bakery restored');rebuild=true
			else:save_input.placeholder_text='Invalid save. Your bakery is safe.';save_input.text='';notify('Invalid save')
		'reset-confirm':g=Sim.new();popup='welcome';page=0;fx.clear();pops.clear();gold_seen=false;rebuild=true
	if rebuild:layout()
	refresh();save_game();web_snapshot()
func notify(s):toast=s;toast_time=3.5
func sound(name_):
	if g.muted or hidden_ or not sounds.has(name_):return
	for p in players:
		if not p.playing:p.stream=sounds[name_];p.pitch_scale=randf_range(.97,1.04) if name_=='tap' else 1.0;p.play();return
func bake(p):
	var value=g.tap()
	if value<=0:return
	kick=.12
	if click_sound_wait<=0:sound('tap');click_sound_wait=.055
	if pops.size()<30:pops.append({'p':p+Vector2(randf_range(-12,12),-10),'text':'+'+g.fmt(value),'life':1.2})
	if not g.calm:
		for i in range(7):
			if fx.size()<150:fx.append({'p':p,'v':Vector2(randf_range(-130,130),randf_range(-200,-70)),'life':randf_range(.4,1.1),'r':randf_range(2,5),'col':Color('#e9b36a') if i%2==0 else Color('#673f2c')})
	web_snapshot()
func _input(event):
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode==KEY_ESCAPE and popup!='':command('close');get_viewport().set_input_as_handled()
		elif event.keycode==KEY_SPACE and popup=='':bake(center);get_viewport().set_input_as_handled()
	if event is InputEventMouseMotion:cookie_hover=(event.position/root_scale-safe).distance_to(center)<radius
	if event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_LEFT and event.pressed and popup=='' and not hidden_ and not g.paused:
		var p=event.position/root_scale-safe
		if g.golden>0 and p.distance_to(gold_pos)<30:
			notify(g.collect_gold());sound('gold');kick=.2;save_game();web_snapshot();get_viewport().set_input_as_handled()
		elif (view.x>=900 or page==0) and p.distance_to(center)<radius:bake(p);get_viewport().set_input_as_handled()
func _process(dt):
	if old_raw!=get_viewport_rect().size:layout()
	if hidden_:return
	if not g.paused:
		age+=dt;g.update(dt);kick=maxf(0,kick-dt);click_sound_wait=maxf(0,click_sound_wait-dt)
		for p in fx:p.p+=p.v*dt;p.v.y+=420*dt;p.life-=dt
		fx=fx.filter(func(p):return p.life>0)
		for p in pops:p.p.y-=35*dt;p.life-=dt
		pops=pops.filter(func(p):return p.life>0)
		toast_time=maxf(0,toast_time-dt)
	if g.golden>0 and not gold_seen:
		gold_seen=true;place_gold();sound('gold')
	if g.golden<=0:gold_seen=false
	for e in g.events:
		if e[0]=='badge':notify('Achievement unlocked');sound('badge')
	g.events.clear()
	sync+=dt;save_time+=dt
	if sync>.15:
		sync=0
		if popup=='' and upgrade_signature!=str(g.available_upgrades()):layout()
		refresh();web_snapshot()
	if save_time>4:save_time=0;save_game()
	queue_redraw()
func place_gold():gold_pos=hero.position+Vector2(hero.size.x*(.49 if view.x<900 and view.x>view.y else .78),hero.size.y*.72)
func _draw():
	draw_rect(Rect2(Vector2.ZERO,view),Color('#0f1e2d'))
	# Blue brocade wallpaper, dark timber rails and brass pin lines reference the visual hierarchy.
	for x in range(0,int(view.x),32):
		draw_rect(Rect2(x,0,16,view.y),Color(1,1,1,.018))
		for y in range(10,int(view.y),44):
			var p=Vector2(x+16,y);draw_colored_polygon(PackedVector2Array([p+Vector2(0,-4),p+Vector2(3,0),p+Vector2(0,4),p+Vector2(-3,0)]),Color(.43,.65,.75,.08))
	draw_rect(Rect2(0,0,view.x,64),Color('#152230'));draw_line(Vector2(0,64),Vector2(view.x,64),Color('#937747'),2)
	txt('CRUMB EMPIRE',Vector2(18,28),19,Color('#f4dfb2'));txt(g.fmt(g.bank)+' cookies  •  '+g.fmt(g.cps())+'/s' if view.x<900 and page>0 else 'one more cookie',Vector2(18,48),11,Color('#a9b5b4'))
	if view.x>=900:ct('Your bakery is getting wonderfully out of hand.',Vector2(view.x*.51,36),13,Color('#b1b9b5'))
	if view.x>=900 or page==0:draw_hero()
	if view.x>=900 or page==1:panel(shop,Color(0.07,.11,.15,.5))
	if view.x>=900 or page==2:panel(bakery,Color(0.08,.12,.16,.6))
	# Small visible production scenes live in native button cells and remain clickable.
	for b in tile_data:
		if not is_instance_valid(b):continue
		var r=Rect2((b.global_position-position)/root_scale,b.size)
		var clip_r=r.intersection(bakery.grow(-6));if clip_r.size.y<80:continue
		# Scenes rendered by tile script; no screen-space overlay that could obscure input.
	if g.golden>0 and popup=='':
		var a=age*1.3
		for i in range(12):
			var v=Vector2.from_angle(a+i*TAU/12);draw_line(gold_pos+v*28,gold_pos+v*(36+sin(age*5)*3),Color(1,.8,.3,.5),2,true)
		draw_circle(gold_pos,32,Color(1,.75,.2,.12));draw_texture_rect(gold_tex,Rect2(gold_pos-Vector2.ONE*24,Vector2.ONE*48),false)
		draw_arc(gold_pos,29,-PI/2,-PI/2+TAU*g.golden/13,40,Color('#ffe6a1'),2,true)
	for p in fx:draw_rect(Rect2(p.p,Vector2.ONE*p.r),Color(p.col,clampf(p.life*2,0,1)))
	for p in pops:ct(p.text,p.p,20,Color(1,.95,.8,clampf(p.life,0,1)))
	if toast_time>0 and popup=='':
		var w=minf(view.x-28,font_.get_string_size(toast,HORIZONTAL_ALIGNMENT_LEFT,-1,14).x+30);var y=view.y-84 if view.x<900 else view.y-36
		panel(Rect2((view.x-w)/2,y-22,w,34),Color('#263a3d'),Color('#aa9160'));ct(toast,Vector2(view.x/2,y),14)
func draw_hero():
	panel(hero,Color(.08,.18,.26,.4))
	var s=1.0+(kick/.12)*.035
	if cookie_hover and not g.calm:s+=.018
	if g.calm:s=1
	var glow=Color('#d6ecf1') if g.frenzy<=0 else Color('#ffdd7d')
	for i in range(12):
		var a=i*TAU/12+(age*.04 if not g.calm else 0);var pts=PackedVector2Array([center,center+Vector2.from_angle(a)*radius*1.46,center+Vector2.from_angle(a+.15)*radius*1.46]);draw_colored_polygon(pts,Color(glow,.025))
	for i in range(18):draw_circle(center,radius*(1.35-i*.035),Color(glow,.006))
	# Cursors orbit around the cookie rather than sitting in an abstract number panel.
	for i in range(mini(24,int(g.buildings[0]))):
		var a=i*TAU/maxf(1,mini(24,int(g.buildings[0])))+age*.12;var p=center+Vector2.from_angle(a)*radius*1.2;Art.icon(self,0,p-Vector2(9,9),.55)
	draw_circle(center+Vector2(0,radius*.07),radius*s*1.01,Color(0,0,0,.25))
	draw_texture_rect(cookie_tex,Rect2(center-Vector2.ONE*radius*s*512/476,Vector2.ONE*radius*s*1024/476),false)
	var wallet_y=hero.position.y+40
	ct(g.fmt(g.bank)+' cookies',Vector2(hero.get_center().x,wallet_y),28 if hero.size.x>330 else 23)
	ct(g.fmt(g.cps())+' / second',Vector2(hero.get_center().x,wallet_y+24),14,Color('#bdcaca'))
	var milk=clampf(g.milestones().size()/32.0,0,1);var mh=minf(50,hero.size.y*.1)*milk
	if view.x>=900 or hero.size.y>430:
		var bottom=hero.end.y-138 if view.x<900 else hero.end.y-8
		draw_rect(Rect2(hero.position.x+3,bottom-mh,hero.size.x-6,mh),Color('#e6ddca'))
		for x in range(int(hero.position.x+3),int(hero.end.x-3),9):draw_circle(Vector2(x,bottom-mh+sin(x*.07+age)*2),5,Color('#ece5d6'))
	var status_y=center.y+radius*1.48+18
	if status_y<hero.end.y-165 or view.x>=900:
		ct('+'+g.fmt(g.click_value())+' per tap',Vector2(center.x,status_y),13,Color('#d8cbaa'))
	if g.frenzy>0 or g.click_frenzy>0 or g.harvest_boost>0:
		var msg='×777 TAP  '+str(int(ceil(g.click_frenzy)))+'s' if g.click_frenzy>0 else ('×7 FRENZY  '+str(int(ceil(g.frenzy)))+'s' if g.frenzy>0 else '×1.5 HARVEST  '+str(int(ceil(g.harvest_boost)))+'s')
		ct(msg,Vector2(hero.get_center().x,hero.position.y+90),14,Color('#ffe29c'))
	if g.paused:ct('PAUSED',center+Vector2(0,radius+25),20,Color('#ffe4ac'))
func save_game():
	if fixture:return
	var data=JSON.stringify(g.snapshot())
	if OS.has_feature('web'):JavaScriptBridge.eval('try{localStorage.setItem("'+SAVE+'",'+JSON.stringify(data)+')}catch(e){}')
	else:var file=FileAccess.open('user://bakery.json',FileAccess.WRITE);if file:file.store_string(data)
func load_game():
	var raw=''
	if OS.has_feature('web'):raw=str(JavaScriptBridge.eval('(function(){try{return localStorage.getItem("'+SAVE+'")||""}catch(e){return ""}})()'))
	elif FileAccess.file_exists('user://bakery.json'):raw=FileAccess.get_file_as_string('user://bakery.json')
	if raw=='':return
	var d=JSON.parse_string(raw)
	if g.restore(d) and g.started and not g.paused:
		var gain=g.away(maxf(0,Time.get_unix_time_from_system()-float(d.get('stamp',Time.get_unix_time_from_system()))))
		if gain>=1:notify('Welcome back  +'+g.fmt(gain));save_game()
func lifecycle(args):
	if args.is_empty():return
	var s=str(args[0])
	if s=='away':hidden_=true;away_at=Time.get_unix_time_from_system();save_game();for p in players:p.stop()
	elif s=='back':
		if hidden_ and away_at>0 and not g.paused:g.away(Time.get_unix_time_from_system()-away_at)
		hidden_=false;away_at=0;save_game()
	else:save_game()
func export_save():
	var data=JSON.stringify(g.snapshot())
	if OS.has_feature('web'):JavaScriptBridge.eval('(()=>{let a=document.createElement("a");a.href=URL.createObjectURL(new Blob(['+JSON.stringify(data)+'],{type:"application/json"}));a.download="crumb-empire-save.json";a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000)})()')
	notify('Save exported')
func web_snapshot():
	if not OS.has_feature('web'):return
	var d={'bank':g.bank,'cps':g.cps(),'click_value':g.click_value(),'lifetime':g.lifetime,'run':g.run,'buildings':g.buildings,'upgrades':g.upgrades,'clicks':g.clicks,'golden':g.golden,'frenzy':g.frenzy,'click_frenzy':g.click_frenzy,'gold_clicks':g.gold_clicks,'plants':g.plants,'harvests':g.harvests,'chips':g.chips,'ascensions':g.ascensions,'started':g.started,'paused':g.paused,'popup':popup,'page':page,'view':[view.x,view.y],'cookie':[center.x+safe.x,center.y+safe.y,radius],'gold_pos':[gold_pos.x+safe.x,gold_pos.y+safe.y],'buttons':[]}
	for b in buttons:
		if not is_instance_valid(b) or not b.is_visible_in_tree():continue
		var p=b.global_position/root_scale;var size_=b.size
		var visible=true;var parent_=b.get_parent()
		while parent_!=null:
			if parent_ is ScrollContainer:
				var sr=Rect2(parent_.global_position/root_scale,parent_.size);if not sr.encloses(Rect2(p,size_)):visible=false
			parent_=parent_.get_parent()
		if visible:d.buttons.append({'id':b.get_meta('id'),'x':p.x,'y':p.y,'w':size_.x,'h':size_.y,'disabled':b.disabled,'action':b.get_meta('action'),'n':b.get_meta('n')})
	JavaScriptBridge.eval('window.crumbSnapshot && window.crumbSnapshot('+JSON.stringify(d)+')')
