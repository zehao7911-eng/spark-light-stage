STELLAR BLOOM
An interactive p5.js light experience.

Open index.html in a modern browser after extracting the entire ZIP.
For local HTTP preview: node serve.cjs, then open http://127.0.0.1:4180/.
For web hosting or HTML5 platforms, upload index.html, style.css, app.js and p5.min.js together at the same level.

Drag or hold on the particle field, then release to bloom.
BLOOM triggers a burst with keyboard or touch. COLOR cycles three palettes.
SOUND enables synthesized ambient tones after a user gesture.
All dependencies are local. No external images, audio downloads, trackers or login required.

Mobile: adaptive particle counts, capped pixel density, pointer input, safe-area layout, and background pause.
Validation: desktop and 390 x 844 browser viewport; no physical phone test performed.
p5.js 1.11.11 is included with its license notice in p5.min.js (LGPL-2.1).
