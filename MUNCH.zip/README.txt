MUNCH — The little food lab

Open index.html in a modern browser. All assets are included locally.
Drag food into the mouth. Mix two foods to discover reactions. Tap the ice three times to thaw. Tap a floating creature to deflate. Tap popcorn to feed it back.
Use the discovery drawer for recipe hints. Sound is optional. Discoveries are saved locally when storage is available.
Designed for touch and responsive layouts. Real iOS/Android device testing remains pending.
