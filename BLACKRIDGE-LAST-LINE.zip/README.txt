BLACKRIDGE: LAST LINE

A mobile-ready 3D tank defense game powered by three.js. All artwork and code are included locally; no external runtime assets are required.

Play: drag on the battlefield to aim, tap the field or the FIRE control to shoot, and use the left/right arrows to dodge incoming shells. Every five eliminations advances the wave. Heavy armor appears in later waves. Protect the ridge.

For local play, serve this folder over HTTP (for example, run `node serve.cjs`) and open http://127.0.0.1:4250/.

Designed for mobile portrait and landscape layouts. Browser emulation and desktop preview are checked; physical phone testing may differ by device.
