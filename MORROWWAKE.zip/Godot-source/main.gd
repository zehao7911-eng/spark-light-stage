extends Node2D

const SAVE='morrowwake.v1'
const NAMES=['hatch','wheel','nest','engine','crane','door','lamp','beetle','frog','snail']
# Coordinates are shared with the browser's accessible touch targets.
const POINTS=[Vector2(480,570),Vector2(800,525),Vector2(600,392),Vector2(1165,510),Vector2(1644,240),Vector2(1582,565),Vector2(1530,127),Vector2(414,337),Vector2(925,610),Vector2(1680,470)]
var f={'key':false,'water':false,'fuse':false,'power':false,'lens':false,'door':false,'light':false,'sailed':false}
var critters=[false,false,false]
var form=0
var x=360.0
var actor_y=638.0
var target_y=638.0
var target_x=360.0
var facing=1.0
var pending=''
var timer=0.0
var time=0.0
var event=0
var sound=true
var paused=true
var started=false
var scene_focus=0.0
var wanted_focus=0.0
var css_size=Vector2(1280,800)
var top=88.0
var bottom=132.0
var scale_world=1.0
var scene_rect=Rect2()
var puzzle=''
var gears=[0,0,0]
var crane=0
var entered=[]
var notice='A little harbour has lost its morning.'
var callback
var tick=0.0
var pulse=0.0
var photo_requested=false
var panorama=false
var background:Texture2D
var girl:Texture2D
var robot:Texture2D

func _ready():
	background=load('res://assets/harbour.webp')
	var sheet=load('res://assets/friends.png')
	girl=AtlasTexture.new(); girl.atlas=sheet; girl.region=Rect2(25,10,690,995)
	robot=AtlasTexture.new(); robot.atlas=sheet; robot.region=Rect2(810,10,710,995)
	restore()
	if OS.has_feature('web'):
		callback=JavaScriptBridge.create_callback(web_action); JavaScriptBridge.get_interface('window').mAction=callback
	if '--qa' in OS.get_cmdline_user_args(): verify()

func stage():
	var n=0
	for k in f:
		if f[k]: n+=1
	return n
func goal():
	if not f.key: return 'Look inside the workshop hatch.'
	if not f.water: return 'The wheel needs a stronger pair of hands.'
	if not f.fuse: return 'Fresh water has woken the vine. Explore above.'
	if not f.power: return 'Return the spark to the little engine.'
	if not f.lens: return 'There is something shining beneath the crane.'
	if not f.door: return 'The lighthouse door is rusted shut.'
	if not f.light: return 'Take the lens upstairs. Follow the old signal.'
	if not f.sailed: return 'The harbour is awake. Your little boat is waiting.'
	return 'Stay a little. Listen to the morning.'
func say(s,kind='tap'):
	notice=s; event+=1; pulse=1.0
	if OS.has_feature('web'): JavaScriptBridge.eval('window.mSound&&window.mSound('+JSON.stringify(kind)+')')
func action(cmd):
	var p=cmd.split(':'); var n=int(p[1]) if p.size()>1 else 0
	match p[0]:
		'view':
			if p.size()>=5: css_size=Vector2(maxi(240,n),maxi(240,int(p[2]))); top=float(p[3]); bottom=float(p[4])
		'begin': started=true; paused=false; say(goal())
		'pause': paused=n==1
		'zone': wanted_focus=clampf(n/1000.0,0,1)
		'pan': wanted_focus=clampf(wanted_focus+n/1000.0,0,1)
		'mute': sound=not sound; save_game()
		'photo': photo_requested=true
		'panorama': panorama=n==1
		'replay':
			for k in f: f[k]=false
			gears=[0,0,0]; crane=0; entered=[]; puzzle=''; pending=''; x=360; target_x=x; form=0; wanted_focus=0; say('A new morning. Your discoveries stay with you.'); save_game()
		'form':
			if not paused and puzzle.is_empty() and pending.is_empty(): form=1-form; say('Small and nimble.' if form==0 else 'Strong and steady.','switch'); save_game()
		'close': puzzle=''; entered=[]
		'gear':
			if not paused and puzzle=='engine' and n>=0 and n<3: gears[n]=posmod(int(gears[n])+1,4); say('A little turn.','gear'); save_game()
		'connect':
			if not paused and puzzle=='engine' and f.fuse and f.water:
				if gears==[2,1,3]: f.power=true; puzzle=''; say('The whole harbour hums again.','reward'); save_game()
				else: say('Match each dial to its engraved pipe mark.','wrong')
		'crane':
			if not paused and puzzle=='crane': crane=clampi(n,0,4); say('The hook follows the rail.','gear'); save_game()
		'lift':
			if not paused and puzzle=='crane' and f.power and form==1:
				if crane==3: f.lens=true; puzzle=''; say('A sun-glass lens. Not a single scratch.','reward'); save_game()
				else: say('Only ripples here. Follow the glint beneath the water.','splash')
		'note':
			if not paused and puzzle=='lamp' and n>=0 and n<3:
				var seq=[1,0,2,1]
				if n!=seq[entered.size()]: entered=[]; say('Almost. The little brass plate remembers.','wrong')
				else:
					entered.append(n); say('A familiar little note.','note'+str(n))
					if entered.size()==4: f.light=true; puzzle=''; entered=[]; say('And the morning found its way home.','finale'); save_game()
		'hot':
			if paused or not puzzle.is_empty() or not pending.is_empty() or not NAMES.has(p[1]): return
			var i=NAMES.find(p[1]); pending=p[1]; target_x=clampf(POINTS[i].x,340,1590); timer=0.15
			target_y=638.0
			if form==0 and ((i==2 and f.water) or (i==6 and f.door)): target_y=POINTS[i].y+65
			if i in [2,6,7,8,9]: target_x=clampf(POINTS[i].x-35,340,1590)
			wanted_focus=clampf((target_x-480)/1000,0,1)
		'sail':
			if not paused and pending.is_empty() and f.light and not f.sailed: f.sailed=true; say('One small repair. A whole new horizon.','finale'); save_game()
	queue_redraw(); emit_state()

func interact(id):
	match id:
		'hatch':
			if f.key: say('A warm workshop, and a very small doorway.')
			elif form==1: say('Too broad for this tiny hatch. Try your smaller self.','wrong')
			else: f.key=true; say('Found a brass winding key.','find')
		'wheel':
			if f.water: say('Round and round. The water is flowing.','splash')
			elif not f.key: say('The square spindle is missing its key.')
			elif form==0: say('The key fits. The wheel is much too heavy.','wrong')
			else: f.water=true; say('Water! Even the old vine is stirring.','reward')
		'nest':
			if f.fuse: say('A bird has made a home in the warm pipe.')
			elif not f.water: say('The dry vine cannot carry you up there.')
			elif form==1: say('These new leaves need lighter footsteps.','wrong')
			else: f.fuse=true; say('A glow-seed, tucked inside the nest.','find')
		'engine':
			if f.power: say('Three steady sparks. Everything is connected.','gear')
			elif not f.fuse: say('An empty heart. Something bright might fit inside.')
			else: puzzle='engine'; say('Turn the three dials to their pipe marks.')
		'crane':
			if f.lens: say('The hook rests above a perfectly empty patch of water.')
			elif not f.power: say('The crane is waiting for power.')
			elif form==0: say('Those heavy controls were made for stronger hands.','wrong')
			else: puzzle='crane'; say('Look for the little glint. Then lower the hook.')
		'door':
			if f.door: say('The stairs are open. The lamp waits above.')
			elif not f.lens: say('First find the missing lens. The harbour crane may help.')
			elif form==0: say('The rusty door needs a careful, powerful pull.','wrong')
			else: f.door=true; say('A creak, a sigh, and a stairway to the sky.','reward')
		'lamp':
			if f.light: say('Warm light, all the way to the clouds.','note1')
			elif not f.door: say('The lighthouse door below is still closed.')
			elif form==1: say('The winding stair is too narrow. Try your smaller self.','wrong')
			else: puzzle='lamp'; entered=[]; say('The old signal is engraved beside the glass.')
		'beetle','frog','snail':
			var i=['beetle','frog','snail'].find(id)
			if critters[i]: say(['The clockwork beetle waves hello.','Your tiny frog friend sings back.','The cloud snail is enjoying the view.'][i],'note'+str(i))
			else: critters[i]=true; say(['A clockwork beetle! Added to your field notes.','A puddle frog! Added to your field notes.','A cloud snail! Added to your field notes.'][i],'find')
	save_game()

func web_action(args):
	if args.size()>0: action(str(args[0]))
func state():
	return {'flags':f,'critters':critters,'form':form,'paused':paused,'started':started,'focus':scene_focus,'wanted':wanted_focus,'puzzle':puzzle,'gears':gears,'crane':crane,'entered':entered,'notice':notice,'event':event,'sound':sound,'goal':goal(),'stage':stage(),'moving':not pending.is_empty(),'scene':[scene_rect.position.x,scene_rect.position.y,scene_rect.size.x,scene_rect.size.y],'x':x,'panorama':panorama}
func emit_state():
	if OS.has_feature('web'): JavaScriptBridge.eval('window.mState&&window.mState('+JSON.stringify(state())+')')
func save_game():
	var data=JSON.stringify({'flags':f,'critters':critters,'form':form,'gears':gears,'crane':crane,'sound':sound})
	var file=FileAccess.open('user://morrowwake.json',FileAccess.WRITE)
	if file: file.store_string(data)
	if OS.has_feature('web'): JavaScriptBridge.eval('try{localStorage.setItem("'+SAVE+'",'+JSON.stringify(data)+')}catch(e){}')
func restore_data(s):
	if not s is Dictionary or not s.get('flags') is Dictionary or not s.get('critters') is Array or s.critters.size()!=3: return false
	for k in f:
		if not s.flags.get(k) is bool: return false
	for v in s.critters:
		if not v is bool: return false
	var chain=['key','water','fuse','power','lens','door','light','sailed']; var previous=true
	for k in chain:
		if s.flags[k] and not previous: return false
		previous=s.flags[k]
	f=s.flags.duplicate(); critters=s.critters.duplicate(); form=clampi(int(s.get('form',0)),0,1); sound=bool(s.get('sound',true))
	gears=[0,0,0]
	var g=s.get('gears',[])
	if g is Array and g.size()==3:
		for i in range(3): gears[i]=clampi(int(g[i]),0,3)
	crane=clampi(int(s.get('crane',0)),0,4); notice=goal(); return true
func restore():
	var data=''
	if OS.has_feature('web'): data=str(JavaScriptBridge.eval('(function(){try{return localStorage.getItem("'+SAVE+'")||""}catch(e){return ""}})()'))
	elif FileAccess.file_exists('user://morrowwake.json'): data=FileAccess.get_file_as_string('user://morrowwake.json')
	if not data.is_empty(): restore_data(JSON.parse_string(data))

func _process(delta):
	var h=maxf(180,css_size.y-top-bottom)
	scale_world=h/1080.0
	var visible=css_size.x/scale_world; var offset=maxf(0,1920-visible)
	var left=(css_size.x-1920*scale_world)*.5 if visible>1920 else -offset*scene_focus*scale_world
	scene_rect=Rect2(Vector2(left,top),Vector2(1920,1080)*scale_world)
	if panorama:
		scale_world=minf(css_size.x/1920.0,css_size.y/1080.0)
		scene_rect=Rect2((css_size-Vector2(1920,1080)*scale_world)*.5,Vector2(1920,1080)*scale_world)
	if not paused:
		time+=delta; pulse=maxf(0,pulse-delta*.7)
		scene_focus=move_toward(scene_focus,wanted_focus,delta*.85)
		if not pending.is_empty():
			facing=1 if target_x>x else -1
			if absf(actor_y-638)>1 and absf(x-target_x)>1: actor_y=move_toward(actor_y,638,delta*330)
			else: x=move_toward(x,target_x,delta*(345 if form==0 else 270))
			if absf(x-target_x)<1:
				actor_y=move_toward(actor_y,target_y,delta*330)
				if absf(actor_y-target_y)<1: timer-=delta
				if timer<=0: var id=pending; pending=''; interact(id)
		elif puzzle!='lamp': actor_y=move_toward(actor_y,638,delta*330)
	tick+=delta
	if tick>.1: tick=0; emit_state()
	queue_redraw()
	if photo_requested:
		photo_requested=false; await RenderingServer.frame_post_draw
		if OS.has_feature('web'):
			var im=get_viewport().get_texture().get_image()
			var r=Rect2i(scene_rect).intersection(Rect2i(Vector2i.ZERO,im.get_size()))
			if r.size.x>0 and r.size.y>0: im=im.get_region(r)
			JavaScriptBridge.eval('window.mPhoto&&window.mPhoto('+JSON.stringify(Marshalls.raw_to_base64(im.save_png_to_buffer()))+')')

func ellipse(pos:Vector2,r:Vector2,c:Color):
	draw_set_transform(pos,0,r); draw_circle(Vector2.ZERO,1,c); draw_set_transform(Vector2.ZERO)
func gear(pos:Vector2,r:float,angle:float,c:Color):
	var pts=PackedVector2Array()
	for i in range(48):
		var a=angle+i*TAU/48; var rr=r*(1.0 if i%4<2 else .83); pts.append(pos+Vector2(cos(a),sin(a))*rr)
	draw_colored_polygon(pts,c); draw_arc(pos,r*.62,0,TAU,32,Color('#e3c599'),2); draw_circle(pos,7,Color('#364e4d'))
func _draw():
	draw_rect(Rect2(Vector2.ZERO,css_size),Color('#192d31'))
	if not background: return
	draw_texture_rect(background,scene_rect,false)
	draw_set_transform(scene_rect.position,0,Vector2.ONE*scale_world)
	# Thin translucent painterly glazes keep generated artwork dominant.
	if f.water:
		for i in range(9):
			var y=543+fmod(time*95+i*16,64); draw_line(Vector2(700+sin(i)*8,y),Vector2(703+sin(i)*8,y+12),Color(.65,.87,.81,.55),2)
	gear(Vector2(802,553),16, time*.28 if f.water else 0,Color('#7d684d'))
	gear(Vector2(1068,597),22,-time*.6 if f.power else 0,Color('#a27c51'))
	if f.fuse:
		var a=.25+sin(time*2)*.1; draw_circle(Vector2(1168,511),24,Color(.89,.65,.25,a)); draw_circle(Vector2(1168,511),8,Color('#e9c976'))
	if f.power:
		for i in range(3): draw_circle(Vector2(1127+i*28,567),4,Color('#e1e4a5'))
	if f.door: draw_style_box(door_style(),Rect2(1559,512,47,96))
	if f.light:
		var beam=PackedVector2Array([Vector2(1530,127),Vector2(1918,30),Vector2(1918,300)])
		draw_colored_polygon(beam,Color(1,.86,.52,.11+sin(time*.7)*.025))
		for r in [75,48,27]: draw_circle(Vector2(1530,127),r,Color(1,.82,.37,.06))
		draw_circle(Vector2(1530,127),12,Color('#fff0b9'))
		for i in range(16):
			var q=Vector2(170+fmod(i*117.0+time*(8+i%3),1540),290+sin(time*.8+i*4)*40+i%5*83)
			draw_circle(q,2,Color(1,.9,.55,.6))
	# Living details: fluttering moths, tiny clouds, ripples, breathing creatures.
	for i in range(7):
		var q=Vector2(310+i*190+sin(time*.3+i)*28,520+sin(time*.6+i*2)*74)
		var wing=3+abs(sin(time*9+i))*5
		draw_line(q,q+Vector2(-wing,-5),Color('#ead7ab'),2); draw_line(q,q+Vector2(wing,-5),Color('#ead7ab'),2)
	for i in range(3):
		var p=POINTS[i+7]+Vector2(0,sin(time*2+i)*2)
		if i==0:
			draw_circle(p,10,Color('#5d7773')); draw_line(p+Vector2(0,-8),p+Vector2(0,8),Color('#e6bc79'),2)
		elif i==1:
			draw_circle(p,10,Color('#899d6d')); draw_circle(p+Vector2(-6,-7),4,Color('#d7d8a1')); draw_circle(p+Vector2(6,-7),4,Color('#d7d8a1'))
		else:
			draw_circle(p,11,Color('#d4bcb0')); draw_arc(p,7,0,TAU*1.7,26,Color('#76645e'),1.5)
		if critters[i]: draw_circle(p+Vector2(15,-12),3,Color('#f5dda2'))
	if f.water:
		for i in range(6):
			var p=Vector2(577+sin(i*2)*14,580-i*35); draw_line(p,p+Vector2(0,-42),Color('#617956'),3)
	var tex=girl if form==0 else robot
	if tex:
		var moving=not pending.is_empty(); var bob=sin(time*(10 if form==0 else 7))* (3.2 if moving else .65)
		var height=119.0 if form==0 else 128.0
		var width=height*tex.get_width()/tex.get_height()
		draw_set_transform(scene_rect.position+Vector2(x,actor_y+bob)*scale_world,sin(time*8)*.025 if moving else 0,Vector2(scale_world*facing,scale_world))
		draw_texture_rect(tex,Rect2(-width*.5,-height,width,height),false)
	# Soft vignette kept away from UI and tap targets.
	draw_set_transform(Vector2.ZERO)
	var veil=Color('#122f38'); veil.a=.03 if not f.light else .0; draw_rect(scene_rect,veil)

func door_style():
	var st=StyleBoxFlat.new(); st.bg_color=Color('#263e3b'); st.corner_radius_top_left=24; st.corner_radius_top_right=24; st.border_width_left=2; st.border_width_right=2; st.border_width_top=2; st.border_color=Color('#ac8a59'); return st

func verify():
	for k in f: f[k]=false
	critters=[false,false,false]; paused=false; form=1; interact('hatch'); assert(not f.key)
	form=0; interact('hatch'); assert(f.key); interact('wheel'); assert(not f.water)
	form=1; interact('wheel'); assert(f.water); interact('nest'); assert(not f.fuse)
	form=0; interact('nest'); assert(f.fuse); interact('engine'); assert(puzzle=='engine')
	action('connect'); assert(not f.power)
	for i in range(2): action('gear:0')
	action('gear:1')
	for i in range(3): action('gear:2')
	action('connect'); assert(f.power and puzzle=='')
	interact('crane'); assert(puzzle==''); form=1; interact('crane'); action('lift'); assert(not f.lens)
	action('crane:3'); action('lift'); assert(f.lens)
	form=0; interact('door'); assert(not f.door); form=1; interact('door'); assert(f.door)
	interact('lamp'); assert(puzzle==''); form=0; interact('lamp'); action('note:2'); assert(entered.is_empty())
	for n in [1,0,2,1]: action('note:'+str(n))
	assert(f.light); action('sail'); assert(f.sailed and stage()==8)
	for id in ['beetle','frog','snail']: interact(id); interact(id)
	assert(critters==[true,true,true]); var s={'flags':f.duplicate(),'critters':critters.duplicate(),'gears':gears,'crane':crane,'form':form}
	assert(restore_data(JSON.parse_string(JSON.stringify(s))))
	s.flags.water=false; assert(not restore_data(s)); assert(not restore_data({}))
	paused=true; action('gear:0'); assert(gears==[2,1,3]); paused=false; action('replay'); assert(stage()==0 and critters==[true,true,true])
	print('MORROWWAKE QA PASS: full chain, wrong form, all puzzle guards, lens alignment, signal reset, JSON restore, replay retention')
	get_tree().quit()
