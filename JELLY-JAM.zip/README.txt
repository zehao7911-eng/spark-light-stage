JELLY JAM — Pull. Drop. Groove.

Grab the orange jelly, pull back and release. A longer hold charges the throw; the dotted line shows the launch direction. Hit the illuminated pad for bonus points and advance the multiplier. Other pads still make music. Each impact records a percussion sound into the 16-step loop. Catch the moving jelly to redirect it. A short tap launches toward the lit pad.

The music icon mutes audio. The pause icon pauses the recorded loop. The reset icon clears the score and recorded rhythm. Audio begins on the first user gesture. Six synthesized sounds: kick, hat, clap, tom, bass and bell. No audio files, images, external CDNs or paid APIs are required.

Upload these files with index.html at the root to a static web host. Local preview: node serve.cjs, then http://127.0.0.1:4220/.

Verified in a desktop browser at phone portrait and landscape sizes. Real iOS/Android devices and Appai's embedded browser have not yet been tested. Rendering and sound pause in background tabs. Reduced-motion preference suppresses screen shake and trails.

p5.js is bundled locally; its LGPL-2.1 notices are preserved in p5.min.js.
