SUGAR SPELLS

Open sugar-spells.html in a modern browser. Keep all files together.

Brew, then tap STOP three times to freeze the ingredient dials.
Match symbols for bigger star rewards. Make today's wish for a bonus.
Every fifth brew is a Sugar Rush. Tap the discovery counter to view your album.

Designed for mobile and desktop. Sound can be toggled in the top right.
Stars are fictional game points with no cash value or purchase option.
All artwork is original and bundled in this archive.
