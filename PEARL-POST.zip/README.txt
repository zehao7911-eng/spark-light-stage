PEARL POST
Special little deliveries.

START
Extract this ZIP and open index.html in a modern browser. You can also upload these files together to an HTML5 game platform. No installation, build step, external library, online assets, or server is required for the downloaded version.

PLAY
Swipe in one direction to slide the otter and every loose pearl. They stop at the edge, a rock, or another piece. A pearl stops and is delivered when it reaches its matching shell. Deliver every pearl to finish the puzzle.

Matching pearls and shells share a color and a symbol. The otter can help other pieces stop in useful places. There is no timer and no penalty for using Undo or restarting.

CONTROLS
Swipe on the ice, tap a direction button, or use arrow keys / WASD. UNDO reverses a slide. HINT highlights a useful next direction. The curved arrow in the top right restarts the current delivery. The envelope opens the postcard collection. The music note toggles synthesized sound.

REWARDS
Every delivery earns one stamp. Finish without hints and within two slides of the shortest solution for a second stamp. Every four stamps unlocks a new postcard and a seaside decoration. There are eight postcards. Deliveries continue after the collection is complete.

PUZZLES
168 verified base layouts with rotations and reflections. Start with one pearl, progress to two and three, and enjoy occasional simpler deliveries between harder ones. Progress and postcards are saved in this browser when storage is available.

MOBILE
Touch controls, portrait and landscape layouts, responsive Canvas 2D artwork, bounded particle effects, and no heavy 3D assets. Tested at 320 x 568, 390 x 844, 844 x 390 and 1440 x 900. 1,200 level selections were checked for solvability.

ONLINE
https://zehao7911-eng.github.io/spark-light-stage/pearl-post.html
