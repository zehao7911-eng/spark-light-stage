extends Node2D

const NAMES = ['Silver minnow','Yellow perch','Copper roach','Sunveil koi','Rainbow trout','Blue sunfish','Willow pike','Moonlace carp','Blue mackerel','Red snapper','Sea bass','Crown sturgeon']
const SITES = ['Amber Lake','Willow Reach','Sunrise Inlet']
const VALUES = [12,17,23,70,22,28,35,105,35,42,50,150]
const WEIGHTS = [0.2,0.8,1.1,4.2,1.5,0.7,3.8,5.5,1.3,2.8,4.6,9.0]
const WATER = [Color('#a6c8c8'),Color('#86bcc2'),Color('#a7ced9')]
var scenes = [preload('res://assets/lake.png'),preload('res://assets/fen.png'),preload('res://assets/coast.png')]
var angler = preload('res://assets/angler.png')
var props = preload('res://assets/props.png')
var fish = preload('res://assets/fish.png')
var regions = {}
var backdrop: Sprite2D
var callback
var mode = 'title'
var site = 0
var unlocked = [true,false,false]
var coins = 20
var rod = 0
var reel = 0
var bait = 0
var caught = 0
var local_catches = [0,0,0]
var journal = []
var kept = []
var best = []
var pending = {}
var last_new = false
var notice = 'A little quiet. A little wonder.'
var muted = false
var reduced = false
var paused = false
var holding = false
var time = 0.0
var phase = 0.0
var tension = 0.15
var progress = 0.0
var danger = 0.0
var peak = 0.0
var fight_time = 0.0
var surging = false
var species = 0
var hook_bonus = false
var cast_point = Vector2(580,425)
var boat = Vector2(385,420)
var current_boat = Vector2(385,420)
var origin = Vector2.ZERO
var zoom = 1.0
var visible_left = 0.0
var visible_right = 960.0
var view_bottom = 640.0
var view_top = 0.0
var motes = []
var rings = []
var events = 0
var event_type = ''
var sync = 0.0

func _ready():
	Engine.max_fps = 60
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	regions = JSON.parse_string(FileAccess.get_file_as_string('res://regions.json'))
	journal.resize(12); journal.fill(0)
	kept.resize(12); kept.fill(false)
	best.resize(12); best.fill(0.0)
	load_save()
	backdrop = Sprite2D.new()
	backdrop.centered = false
	backdrop.show_behind_parent = true
	backdrop.texture = scenes[site]
	var mat = ShaderMaterial.new()
	mat.shader = preload('res://water.gdshader')
	backdrop.material = mat
	add_child(backdrop)
	if OS.has_feature('web'):
		callback = JavaScriptBridge.create_callback(web_action)
		JavaScriptBridge.get_interface('window').wAction = callback
	if '--qa' in OS.get_cmdline_user_args(): self_test()

func emit_sound(kind):
	events += 1
	event_type = kind

func web_action(args):
	if args.size() > 0: action(str(args[0]))

func action(command):
	var bits = command.split(':')
	var what = bits[0]
	var value = int(bits[1]) if bits.size() > 1 else 0
	match what:
		'begin':
			mode = 'result' if not pending.is_empty() else 'travel'
			phase = 0
			paused = false
			if pending.is_empty(): notice = 'Welcome aboard. Your dog found a good spot.'
		'primary':
			if paused: return
			if mode == 'idle': start_cast()
			elif mode == 'bite': hook()
		'hold': holding = value == 1 and mode == 'reel' and not paused
		'pause': paused = value == 1; holding = false
		'bait':
			if mode == 'idle' or mode == 'title': bait = clampi(value,0,2)
		'sell': resolve_catch(false)
		'keep': resolve_catch(true)
		'site':
			if mode != 'idle': return
			if value < 0 or value > 2: return
			if not unlocked[value]:
				var cost = 90 if value == 1 else 180
				if coins < cost or rod < value:
					notice = 'This water needs rod '+str(value)+' and '+str(cost)+' shells.'
					return
				coins -= cost
				unlocked[value] = true
			site = value
			backdrop.texture = scenes[site]
			mode = 'travel'; phase = 0
			notice = 'Drifting toward '+SITES[site]+'.'
			paused = false
		'rod':
			if rod < 3 and coins >= rod_cost() and mode == 'idle':
				coins -= rod_cost(); rod += 1; notice = 'Stronger rod. Calmer line. Bigger possibilities.'; emit_sound('buy')
		'reel':
			if reel < 3 and coins >= reel_cost() and mode == 'idle':
				coins -= reel_cost(); reel += 1; notice = 'A smoother reel. Bring them closer, faster.'; emit_sound('buy')
		'sanctuary':
			if mode == 'idle': mode = 'sanctuary'; holding = false
			elif mode == 'sanctuary': mode = 'idle'
		'pet':
			burst(current_boat+Vector2(50,-42),Color('#f2cfaa'),12)
			notice = 'A very good fishing buddy.'; emit_sound('pet')
		'sound': muted = not muted
		'motion': reduced = not reduced
	save_game()
	push_state()

func rod_cost(): return [55,110,180,0][rod]
func reel_cost(): return [45,90,150,0][reel]

func pick_species():
	var start = site*4
	if rod >= site+1 and local_catches[site] >= 4 and local_catches[site] % 5 == 4: return start+3
	for i in range(3):
		if journal[start+i] == 0: return start+i
	var weights = [1.0,1.0,1.0]
	weights[bait] = 4.0
	var roll = randf()*6.0
	for i in range(3):
		roll -= weights[i]
		if roll <= 0: return start+i
	return start+2

func start_cast():
	species = pick_species()
	phase = 0
	mode = 'cast'
	progress = 0
	tension = 0.15
	danger = 0
	peak = 0
	fight_time = 0
	holding = false
	cast_point = Vector2(clampf(cast_point.x,510,630),clampf(cast_point.y,390,485))
	notice = 'Listen to the water.'
	emit_sound('cast')

func hook():
	hook_bonus = phase < 1.4
	progress = 0.15 if hook_bonus else 0.03
	phase = 0
	mode = 'reel'
	holding = false
	notice = 'Hold to reel. Let go when the fish pulls.'
	emit_sound('hook')
	burst(cast_point,WATER[site],20)

func _process(dt):
	if not paused:
		time += dt
		phase += dt
		match mode:
			'travel':
				if phase >= 2.5: mode = 'idle'; phase = 0; notice = 'Tap the water to aim, then cast.'
			'cast':
				if phase >= 0.85:
					mode = 'wait'; phase = 0
					add_ring(cast_point); burst(cast_point,WATER[site],12); emit_sound('splash')
			'wait':
				if phase >= 2.0+0.2*site: mode = 'bite'; phase = 0; notice = 'A bite! Tap to hook.'; emit_sound('bite')
			'bite':
				if phase >= 4.0: mode = 'wait'; phase = 0; notice = 'Still here. Another bite will come.'
			'reel': fight_step(dt)
			'land':
				if phase >= 1.25: complete_catch()
		for m in motes: m.life -= dt; m.pos += m.vel*dt; m.vel.y += dt*95
		motes = motes.filter(func(m): return m.life > 0)
		for r in rings: r.life -= dt
		rings = rings.filter(func(r): return r.life > 0)
		if (mode == 'wait' or mode == 'bite' or mode == 'reel') and fmod(time,0.65) < dt: add_ring(lure_position())
	backdrop.material.set_shader_parameter('clock',time)
	backdrop.material.set_shader_parameter('still',reduced)
	sync += dt
	if sync >= 0.1: sync = 0; push_state()
	queue_redraw()

func fight_step(dt):
	fight_time += dt
	surging = fmod(fight_time,3.2) > 1.8
	var resistance = 1.0 + site*0.14 + (0.3 if species%4 == 3 else 0.0)
	if holding:
		tension += dt*(0.12+(0.47 if surging else 0.0))*resistance/(1.0+rod*0.2)
		progress += dt*(0.055 if surging else 0.19)*(1.0+reel*0.18)/resistance
	else:
		tension -= dt*0.56
		progress -= dt*0.008
	tension = clampf(tension,0.06,1.0)
	progress = clampf(progress,0,1)
	peak = maxf(peak,tension)
	danger = danger+dt if tension >= 0.96 else maxf(0,danger-dt*2)
	if danger >= 0.85:
		mode = 'idle'; phase = 0; holding = false
		notice = 'It slipped away. No bait lost. Try a gentler hand.'
		emit_sound('slip')
	elif progress >= 1.0:
		mode = 'land'; phase = 0; holding = false
		burst(lure_position(),WATER[site],34)
		emit_sound('land')

func complete_catch():
	if mode != 'land': return
	var weight = snappedf(WEIGHTS[species]*randf_range(0.7,1.55),0.01)
	last_new = journal[species] == 0
	var record = weight > best[species]
	journal[species] += 1
	best[species] = maxf(best[species],weight)
	caught += 1
	local_catches[site] += 1
	var grade = 3 if peak < 0.76 and hook_bonus else (2 if peak < 0.95 else 1)
	var price = int(VALUES[species]*(0.85+grade*0.15))
	var discovery = 15 if last_new else 0
	var milestone = 30 if caught == 3 else (40 if caught%5 == 0 else 0)
	coins += discovery+milestone
	pending = {'id':species,'weight':weight,'price':price,'grade':grade,'new':last_new,'record':record,'bonus':discovery+milestone}
	mode = 'result'; phase = 0
	notice = 'A new story for the journal.' if last_new else 'Another lovely catch.'
	emit_sound('rare' if species%4 == 3 else 'catch')
	save_game()

func resolve_catch(keep_it):
	if mode != 'result' or pending.is_empty(): return
	var id = int(pending.id)
	if keep_it:
		kept[id] = true
		notice = NAMES[id]+' is now in your sanctuary.'
	else:
		coins += int(pending.price)
		notice = '+'+str(pending.price)+' shells. Your journal keeps the memory.'
	pending = {}
	mode = 'idle'; phase = 0
	emit_sound('buy')

func lure_position():
	if mode == 'reel':
		return cast_point.lerp(current_boat+Vector2(80,15),progress*0.75)+Vector2(sin(fight_time*(8 if surging else 3))* (13 if surging else 3),sin(fight_time*4)*3)
	if mode == 'cast':
		var f = clampf(phase/0.85,0,1)
		return (current_boat+Vector2(35,-45)).lerp(cast_point,f)-Vector2(0,sin(f*PI)*85)
	return cast_point+Vector2(0,sin(time*5)* (5 if mode == 'bite' else 1.4))

func add_ring(pos): rings.append({'pos':pos,'life':1.2})
func burst(pos,color,count):
	if reduced: count = mini(count,8)
	for i in range(count): motes.append({'pos':pos,'vel':Vector2(randf_range(-55,55),randf_range(-95,-20)),'life':randf_range(0.4,1.2),'color':color})

func _draw():
	var screen = get_viewport_rect().size
	var top = 60.0 if screen.y >= 550 else 48.0
	var bottom = 142.0 if screen.y >= 550 else 112.0
	var available = maxf(160,screen.y-top-bottom)
	zoom = maxf(screen.x/960.0,available/640.0)
	var camera_x = 480.0 if screen.x > 700 else 453.0
	origin = Vector2(screen.x/2-camera_x*zoom,top+(available-640*zoom)*0.5)
	view_bottom = (screen.y-bottom-origin.y)/zoom
	view_top = (top-origin.y)/zoom
	visible_left = -origin.x/zoom
	visible_right = (screen.x-origin.x)/zoom
	backdrop.position = origin
	backdrop.scale = Vector2.ONE*zoom*0.625
	draw_set_transform(origin,0,Vector2.ONE*zoom)
	# Separate animated layer: birds, air particles and drifting leaves.
	for i in range(5):
		var x = fmod(time*(9+i*2)+i*197,1100)-50
		var y = 140+i*19+sin(time*0.6+i)*6
		var flap = sin(time*5+i)*3
		draw_polyline(PackedVector2Array([Vector2(x-4,y-flap),Vector2(x,y),Vector2(x+4,y-flap)]),Color(0.19,0.25,0.3,0.5),1)
	for i in range(26):
		var x = fmod(time*(5+i%3)+i*69,1100)-60
		var y = 285+fmod(i*57+time*(5 if site == 0 else 1),320)
		var c = Color('#ddad65') if site == 0 else Color('#e9ddaa')
		c.a = 0.45 if site != 1 else 0.35+sin(time*2+i)*0.25
		draw_line(Vector2(x,y),Vector2(x+2+sin(time+i),y+1),c,1.5)
	# Independent submerged fish silhouettes.
	for i in range(5):
		var pos = Vector2(330+fmod(time*(9+i*2)+i*91,340),450+i*19+sin(time+i)*5)
		fish_sprite(site*4+i%3,pos,Vector2(30+i*3,18),Color(0.2,0.3,0.31,0.17),sin(time*0.8+i)>0)
	if mode == 'sanctuary': draw_sanctuary(); return
	current_boat = boat+Vector2(0,0 if reduced else sin(time*1.8)*1.5)
	if mode == 'travel': current_boat.x -= (1.0-clampf(phase/2.5,0,1))*150
	# Reflection layer, followed by the actual independent boat and actor.
	draw_set_transform(origin+(current_boat+Vector2(0,31))*zoom,0,Vector2(zoom,-zoom*0.48))
	draw_boat(Vector2.ZERO,true)
	draw_set_transform(origin,0,Vector2.ONE*zoom)
	for r in rings:
		var pts = PackedVector2Array()
		var radius = (1.2-r.life)*23+3
		for k in range(33): pts.append(r.pos+Vector2(cos(k*TAU/32)*radius,sin(k*TAU/32)*radius*0.3))
		draw_polyline(pts,Color(WATER[site],r.life*0.55),1)
	draw_boat(current_boat,false)
	if mode == 'idle': draw_arc(cast_point,7,0,TAU,24,Color(0.95,0.86,0.64,0.5),1)
	if mode in ['cast','wait','bite','reel','land']:
		var tip = current_boat+Vector2(22,-66)
		var lure = lure_position()
		var pts = PackedVector2Array()
		for k in range(25):
			var f = k/24.0
			pts.append(tip.lerp(lure,f)+Vector2(0,sin(f*PI)*(3 if holding else 14)))
		var line_color = Color('#f4e5b9') if tension < 0.76 else Color('#ff9a76')
		draw_polyline(pts,line_color,1.2)
		if mode != 'land':
			draw_line(lure+Vector2(0,-8),lure+Vector2(0,2),Color('#f2ddb8'),2.5)
			draw_circle(lure+Vector2(0,-4),2.5,Color('#d5754e'))
		if mode == 'reel':
			fish_sprite(species,lure+Vector2(-12,12),Vector2(40,24),Color(0.5,0.7,0.65,0.6),surging)
			if surging and fmod(time,0.18)<0.06 and not reduced: draw_line(lure+Vector2(-7,0),lure+Vector2(8,-3),WATER[site],2)
		if mode == 'land':
			var f = clampf(phase/1.25,0,1)
			var pos = lure.lerp(current_boat+Vector2(0,-35),f)-Vector2(0,sin(f*PI)*100)
			fish_sprite(species,pos,Vector2(55+18*sin(f*PI),36),Color.WHITE,false)
	for m in motes: draw_circle(m.pos,1.4,Color(m.color,clampf(m.life,0,1)))
	draw_foreground()
	draw_set_transform(Vector2.ZERO)

func draw_boat(pos,reflection):
	var tint = Color(0.32,0.38,0.42,0.22) if reflection else Color.WHITE
	var frame = 0
	var walk_offset = 0.0
	if mode == 'travel': frame = int(time*7)%4; walk_offset = -25+clampf(phase/2.5,0,1)*25
	elif mode == 'cast': frame = 4+mini(3,int(phase/0.85*4))
	elif mode == 'reel': frame = 8+(int(time*(9 if holding else 3))%4)
	elif mode in ['wait','bite','land']: frame = 7
	elif fmod(time,15) < 2.5: frame = int(time*6)%4; walk_offset = -sin(fmod(time,15)/2.5*PI)*13
	var src = Rect2((frame%4)*384,(frame/4)*1024.0/3,384,1024.0/3)
	draw_texture_rect_region(angler,Rect2(pos+Vector2(-58+walk_offset,-68),Vector2(82,73)),src,tint)
	var dog_frame = 1+(int(time*(7 if mode in ['reel','result'] else 3))%3)
	prop_sprite(0,Rect2(pos+Vector2(-96,-39),Vector2(192,83)),tint)
	# Equal-sized dog cells share the same ground anchor; render above the bow.
	prop_sprite(dog_frame,Rect2(pos+Vector2(29,-43),Vector2(51.15,39)),tint)
	if not reflection:
		draw_line(pos+Vector2(-82,33),pos+Vector2(84,33),Color(WATER[site],0.42),1)

func rect_from(values): return Rect2(values[0],values[1],values[2],values[3])
func prop_sprite(id,dest,tint=Color.WHITE): draw_texture_rect_region(props,dest,rect_from(regions.props[id]),tint)
func fish_sprite(id,pos,size,tint=Color.WHITE,flip=false):
	var dest = Rect2(pos-size*0.5,size)
	if flip: dest.position.x += size.x; dest.size.x = -size.x
	draw_texture_rect_region(fish,dest,rect_from(regions.fish[id]),tint)

func draw_foreground():
	var sway = 0 if reduced else sin(time*0.6)*2
	prop_sprite(4,Rect2(visible_left-26+sway,view_bottom-141,123,170),Color(0.72,0.75,0.7,0.95))
	prop_sprite(5,Rect2(visible_right-92-sway,view_bottom-162,119,190),Color(0.68,0.72,0.74,0.95))
	if rod >= 2: prop_sprite(6,Rect2(visible_left+25,view_bottom-100,30,75))

func draw_sanctuary():
	var tank_top = maxf(230,view_top+60)
	var bounds = Rect2(visible_left+20,tank_top,visible_right-visible_left-40,maxf(165,view_bottom-tank_top-22))
	draw_rect(bounds,Color(0.03,0.15,0.19,0.8))
	draw_rect(bounds,Color('#ae936a'),false,3)
	draw_rect(Rect2(bounds.position+Vector2(3,3),bounds.size-Vector2(6,6)),Color(0.7,0.89,0.85,0.18),false,1)
	draw_rect(Rect2(bounds.position.x+3,bounds.end.y-18,bounds.size.x-6,15),Color('#263e40'))
	prop_sprite(4,Rect2(bounds.position.x+5,bounds.end.y-93,48,78),Color(0.35,0.65,0.62,0.85))
	prop_sprite(5,Rect2(bounds.end.x-53,bounds.end.y-99,48,85),Color(0.32,0.61,0.62,0.85))
	var number = 0
	for i in range(12):
		if not kept[i]: continue
		number += 1
		var travel = fmod(time*(10+i)+i*67,bounds.size.x-100)
		var x = bounds.end.x-50-travel if i%2==1 else bounds.position.x+50+travel
		var y = bounds.position.y+40+(i%4)*(bounds.size.y-80)/3+sin(time*0.8+i)*6
		fish_sprite(i,Vector2(x,y),Vector2((60 if i%4!=3 else 85)*(0.98+sin(time*5+i)*0.02),35 if i%4!=3 else 49),Color.WHITE,i%2==1)
	for i in range(13):
		var x = bounds.position.x+20+fmod(i*67,bounds.size.x-40)
		var y = bounds.end.y-fmod(time*13+i*23,bounds.size.y-15)
		draw_arc(Vector2(x,y),1.5,0,TAU,8,Color(0.7,0.9,0.88,0.25),1)
	if number == 0: draw_string(ThemeDB.fallback_font,Vector2(bounds.position.x+15,bounds.position.y+95),'Keep a catch to welcome it here.',HORIZONTAL_ALIGNMENT_LEFT,-1,13,Color('#e9d7b4'))
	draw_foreground()
	draw_set_transform(Vector2.ZERO)

func _unhandled_input(event):
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		var pos = (event.position-origin)/zoom
		if pos.distance_to(current_boat+Vector2(50,-30)) < 32: action('pet'); return
		if mode == 'idle' and pos.y > 345:
			cast_point = Vector2(clampf(pos.x,510,630),clampf(pos.y,390,minf(485,view_bottom-18))); add_ring(cast_point)
			notice = 'A promising spot. Ready when you are.'
	if event is InputEventKey and not event.echo:
		if event.keycode == KEY_SPACE:
			if event.pressed:
				if mode == 'title': action('begin')
				elif mode == 'reel': action('hold:1')
				else: action('primary')
			else: action('hold:0')
		if event.pressed and event.keycode == KEY_ENTER and mode == 'result': action('sell')

func snapshot():
	var unique = 0
	for n in journal:
		if n > 0: unique += 1
	return {'mode':mode,'site':site,'sites':SITES,'unlocked':unlocked,'coins':coins,'rod':rod,'reel':reel,'rodCost':rod_cost(),'reelCost':reel_cost(),'bait':bait,'caught':caught,'local':local_catches,'journal':journal,'kept':kept,'best':best,'names':NAMES,'pending':pending,'notice':notice,'tension':tension,'progress':progress,'surging':surging,'holding':holding,'paused':paused,'muted':muted,'reduced':reduced,'unique':unique,'event':events,'sound':event_type,'viewport':[get_viewport_rect().size.x,get_viewport_rect().size.y],'world':{'zoom':zoom,'origin':[origin.x,origin.y],'boat':[current_boat.x,current_boat.y],'lure':[cast_point.x,cast_point.y]}}

func push_state():
	if OS.has_feature('web'): JavaScriptBridge.eval('window.wState && window.wState('+JSON.stringify(snapshot())+');')

func save_game():
	var data = {'version':1,'site':site,'unlocked':unlocked,'coins':coins,'rod':rod,'reel':reel,'bait':bait,'caught':caught,'local':local_catches,'journal':journal,'kept':kept,'best':best,'pending':pending,'muted':muted,'reduced':reduced}
	var text = JSON.stringify(data)
	FileAccess.open('user://willowline.json',FileAccess.WRITE).store_string(text)
	if OS.has_feature('web'): JavaScriptBridge.eval('localStorage.setItem("willowline-v1",'+JSON.stringify(text)+')')

func load_save():
	var text = FileAccess.get_file_as_string('user://willowline.json') if FileAccess.file_exists('user://willowline.json') else ''
	if OS.has_feature('web'):
		var browser_save = JavaScriptBridge.eval('localStorage.getItem("willowline-v1") || ""')
		if browser_save: text = str(browser_save)
	if text.is_empty(): return
	var d = JSON.parse_string(text)
	if not d is Dictionary: return
	coins = int(d.get('coins',20)); site = clampi(int(d.get('site',0)),0,2); rod = clampi(int(d.get('rod',0)),0,3); reel = clampi(int(d.get('reel',0)),0,3)
	bait = clampi(int(d.get('bait',0)),0,2); caught = int(d.get('caught',0))
	unlocked = d.get('unlocked',[true,false,false]); local_catches = d.get('local',[0,0,0])
	journal = d.get('journal',journal); kept = d.get('kept',kept); best = d.get('best',best); pending = d.get('pending',{})
	muted = d.get('muted',false); reduced = d.get('reduced',false)

func self_test():
	mode = 'idle'; coins = 20; rod = 0; reel = 0; site = 0; caught = 0
	journal.fill(0); kept.fill(false); best.fill(0.0); local_catches = [0,0,0]; pending = {}
	assert(pick_species() == 0)
	start_cast(); _process(1); _process(2.5)
	assert(mode == 'bite')
	hook()
	assert(hook_bonus)
	for i in range(1800):
		if mode != 'reel': break
		holding = tension < 0.62 and not surging
		fight_step(1.0/60)
	assert(mode == 'land')
	complete_catch(); assert(caught == 1 and journal[0] == 1 and pending.new)
	var expected = coins+pending.price
	resolve_catch(false); assert(coins == expected and mode == 'idle')
	var balance = coins
	action('rod'); assert(rod == 0 and coins == balance)
	coins = 1000; action('rod'); action('rod'); action('rod'); action('rod'); assert(rod == 3)
	action('site:1'); assert(site == 1 and unlocked[1]); mode = 'idle'
	action('site:2'); assert(site == 2 and unlocked[2])
	local_catches[2] = 4; assert(pick_species() == 11)
	mode = 'land'; species = 11; peak = 0.4; hook_bonus = true
	complete_catch(); var before = coins; resolve_catch(true)
	assert(kept[11] and coins == before)
	mode = 'reel'; progress = 0; tension = 1; danger = 0; fight_time = 2; holding = true
	fight_step(1); assert(mode == 'idle')
	save_game(); var saved = coins; load_save(); assert(coins == saved and kept[11])
	print('WILLOWLINE QA PASS: cast/bite/hold-release catch, sell/keep, affordability, upgrade cap, sites, legendary gate, free failure, save')
	get_tree().quit()
