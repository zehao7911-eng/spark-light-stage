extends SceneTree

func _initialize(): call_deferred('run')

func catch_with_input(game):
	game.mode = 'idle'
	game.start_cast()
	game._process(1)
	game._process(3)
	assert(game.mode == 'bite')
	game.hook()
	for i in range(3600):
		if game.mode != 'reel': break
		game.holding = game.tension < 0.62 and not game.surging
		game.fight_step(1.0/60.0)
	assert(game.mode == 'land')
	game.complete_catch()
	assert(game.mode == 'result')
	var count = game.caught
	game.complete_catch()
	assert(game.caught == count)

func run():
	var game = load('res://main.gd').new()
	root.add_child(game)
	game.mode = 'idle'; game.site = 0; game.rod = 0; game.reel = 0; game.coins = 20
	game.caught = 0; game.journal.fill(0); game.kept.fill(false); game.best.fill(0.0)
	game.unlocked = [true,false,false]; game.local_catches = [0,0,0]; game.pending = {}
	# Starter rod must comfortably land all three initial discoveries.
	for i in range(3):
		catch_with_input(game)
		assert(game.pending.id == i)
		game.resolve_catch(false)
	assert(game.coins >= 145 and game.caught == 3)
	game.action('rod'); game.action('reel')
	assert(game.rod == 1 and game.reel == 1)
	for i in range(2): catch_with_input(game); game.resolve_catch(false)
	assert(game.journal[3] == 1 and game.coins >= 90)
	game.action('site:1'); assert(game.unlocked[1])
	game.mode = 'idle'; game.action('rod'); assert(game.rod == 2)
	for i in range(5): catch_with_input(game); game.resolve_catch(false)
	assert(game.journal[7] == 1 and game.coins >= 360)
	game.action('site:2'); game.mode = 'idle'; game.action('rod')
	assert(game.site == 2 and game.rod == 3)
	for i in range(5):
		catch_with_input(game)
		game.resolve_catch(i == 4)
	assert(game.journal[11] > 0 and game.kept[11])
	for n in game.journal: assert(n >= 1)
	# Pending rewards must survive a reload and settle once only.
	catch_with_input(game)
	game.save_game()
	var restored = load('res://main.gd').new()
	root.add_child(restored)
	assert(restored.pending.id == game.pending.id and restored.caught == game.caught)
	restored.mode = 'result'
	var expected = restored.coins+restored.pending.price
	restored.resolve_catch(false); restored.resolve_catch(false)
	assert(restored.coins == expected)
	# A missed bite repeats, and menus freeze a live encounter.
	game.mode = 'bite'; game.phase = 3.95; game._process(0.1); assert(game.mode == 'wait')
	game.mode = 'reel'; game.progress = 0.2; game.holding = true; game.paused = true
	game._process(1); assert(game.progress == 0.2)
	print('EXTENDED WILLOWLINE QA PASS: funded starter-to-all-waters progression, all12 species, 3legends, keep, pending reload, no duplicate payment, missed bite recovery, pause')
	quit()
