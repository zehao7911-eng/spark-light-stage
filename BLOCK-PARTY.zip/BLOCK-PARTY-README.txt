BLOCK PARTY — STACK & BANK

A self-contained, mobile-friendly voxel arcade game.

HOW TO PLAY
1. Choose a stake in Bits.
2. Tap START RUN, then tap DROP BLOCK when the moving block lines up.
3. Keep the stack going to grow your boost. BANK whenever you want to lock in the shown Bits.
4. A badly placed block ends the run and clears its unbanked payout.

CONTROLS
Touch: Tap the screen or DROP BLOCK.
Keyboard: Space to drop; Escape to bank.

Bits are fictional in-game tokens. No purchase or real-money payout.
Sound is off until you enable it with the music-note button.

Open block-party.html in a modern browser, or use the GitHub Pages game link.
