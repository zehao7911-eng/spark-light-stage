CRASH: CRATEQUAKE
Original unofficial fan mini-game, not affiliated with Activision or the Crash Bandicoot franchise.

Drag anywhere to move and spin. Lift to stop spinning. Break every crate and enter the gate at the far end of the island. Flying wooden crates strike other crates and ignite TNT. A lit TNT detonates after 1.3 seconds, clears nearby metal crates and can knock you back. Its orange circle shows the danger area. There are no lives or forced restarts; recover and keep smashing.

Six consecutive breaks trigger a brief larger tornado spin. Fruit flies into your character. Three stars: finish / no bonks / chain at least six breaks. Your highest stars per numbered island save, so replay does not farm stars. Six total stars unlock a following wooden mask; twelve unlock golden sneakers. Eight authored layouts repeat with alternating mirrors, numbered up to 999. Best completion times, stars, mute and the active island save locally. A reloaded active island starts paused. No ads, accounts, purchases or network dependencies.

Keyboard: WASD/arrows move and spin; Space brakes; Escape pauses. Interrupted/cancelled touches stop spinning and never trigger a release attack. The note button toggles original synthesized sound. Storage-blocked browsers still support session play.

Open index.html in a current WebGL browser. It is fully self-contained, with editable source modules also included. For hosting upload the folder, or use the standalone cratequake.html. Original procedural fan character, island, textures, effects, code and synthesized audio; no commercial model, texture, sampled voice, music or game code was extracted. Three.js r147 MIT license in THREE-LICENSE.txt.

Mobile portrait and landscape layouts are checked in browser automation. Rendering DPR capped at 1.5, 40 crate slots, 50 fruit, 140 debris particles, six shockwave rings and twelve audio voices. Background/pause stops the simulation, rendering and sound. A lost WebGL context offers Retry. Physical handset performance varies.
