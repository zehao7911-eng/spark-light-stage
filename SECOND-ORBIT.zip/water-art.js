/* Pixel workshop drawings for the Second Orbit water concession. */
window.WaterArt=(()=>{
  const ink='#171e29',shadow='#28383d',green='#3e5b55',enamel='#657b66',rim='#a5a38a',
    copper='#a96d4d',brass='#cb9663',gold='#efc890',glass='#356569',teal='#54938a',cyan='#92e5cc',
    pale='#d5f2ce',amber='#d5a16b';
  const icons=[];
  function grid(canvas,width,height){
    if(canvas.width!==width)canvas.width=width;if(canvas.height!==height)canvas.height=height;
    const c=canvas.getContext('2d');if(!c)return;
    c.imageSmoothingEnabled=false;c.clearRect(0,0,width,height);
    function r(x,y,w,h,color){c.fillStyle=color;c.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));}
    function o(x,y,rx,ry,color){for(let j=-ry;j<ry;j++){const d=rx*Math.sqrt(1-((j+.5)/ry)**2);r(x-d,y+j,2*d,1,color);}}
    function l(x,y,u,v,color,k=1){let dx=Math.abs(u-x),dy=-Math.abs(v-y),s=x<u?1:-1,t=y<v?1:-1,err=dx+dy;
      while(true){r(x,y,k,k,color);if(x===u&&y===v)break;let e=2*err;if(e>=dy){err+=dy;x+=s;}if(e<=dx){err+=dx;y+=t;}}}
    function p(color,...points){let top=1000,bottom=-1000;
      for(let i=1;i<points.length;i+=2){top=Math.min(top,points[i]);bottom=Math.max(bottom,points[i]);}
      for(let y=top;y<bottom;y++){const crossings=[];for(let i=0,j=points.length-2;i<points.length;j=i,i+=2){
        if((points[i+1]>y+.5)===(points[j+1]>y+.5))continue;
        crossings.push(points[j]+(y+.5-points[j+1])*(points[i]-points[j])/(points[i+1]-points[j+1]));}
        crossings.sort((a,b)=>a-b);for(let i=0;i<crossings.length;i+=2){const left=Math.ceil(crossings[i]-.5);r(left,y,Math.ceil(crossings[i+1]-.5)-left,1,color);}}
    }
    function bolt(x,y){r(x,y,3,3,shadow);r(x,y,2,2,rim);r(x+1,y+1,1,1,green);}
    return {r,o,l,p,bolt,c};
  }
  function bottle(d,x,y){const {r,p}=d;
    r(x+3,y,4,2,brass);r(x+3,y+2,4,2,teal);p(glass,x+3,y+3,x+7,y+3,x+9,y+5,x+9,y+14,x+1,y+14,x+1,y+5);
    r(x+2,y+6,6,7,'#6db5a3');r(x+3,y+4,1,7,pale);r(x+1,y+8,8,4,'#dcbe8f');r(x+3,y+9,3,1,'#56827a');}
  function icon(canvas,n=0){if(!canvas)return;const d=grid(canvas,32,32);if(!d)return;const {p,r,o,l,c}=d;
    n=Math.max(0,Math.min(2,n|0));if(icons[n]){c.drawImage(icons[n],0,0);return;}
    if(n===0){
      p(ink,5,12,9,7,11,7,11,4,19,3,22,6,24,7,27,11,27,26,22,29,7,28,4,25);
      p(green,6,12,11,8,21,8,25,12,24,25,20,27,8,26);p(teal,8,13,11,10,20,10,22,13,21,24,8,24);
      r(12,5,7,3,brass);r(14,6,3,2,ink);r(9,11,5,2,cyan);r(7,15,2,7,teal);r(21,13,3,12,glass);
      r(10,14,10,8,'#bec7a8');p(glass,15,15,18,18,18,20,16,21,13,20,13,18);r(14,18,1,2,cyan);r(7,25,16,1,rim);
    }else if(n===1){
      p(ink,5,24,11,18,15,17,23,5,26,3,29,5,28,8,22,16,20,23,13,29,7,29);
      l(13,21,26,5,amber,3);l(16,19,26,6,pale);p(glass,6,24,12,18,16,18,19,21,18,24,12,28,8,27);
      p(amber,8,24,13,20,15,20,17,22,12,26,9,26);l(10,24,14,21,gold);r(16,18,3,2,copper);r(21,11,2,1,shadow);r(23,8,2,1,shadow);
    }else{
      for(let i=0;i<3;i++)bottle(d,5+i*7,4);
      for(let i=0;i<3;i++)bottle(d,2+i*8,9);
      p(copper,2,20,25,20,29,17,29,24,24,28,2,26);p(brass,3,21,23,22,23,26,3,25);r(10,22,5,2,green);
    }
    const v=document.createElement('canvas');v.width=v.height=32;v.getContext('2d').drawImage(canvas,0,0);icons[n]=v;
  }
  function normalize(v,defaultValue){
    if(typeof v==='string'){if(v==='clean'||v==='pure')return 1;if(v==='dirty'||v==='tainted')return .2;}
    v=Number(v);return Number.isFinite(v)?Math.max(0,Math.min(1,v>1?v/100:v)):defaultValue;
  }
  function machine(canvas,state={}){
    if(!canvas)return;const d=grid(canvas,200,90);if(!d)return;
    const {r,p,l,o,bolt}=d,stage=state.stage||'empty',t=Number(state.time)||0;
    const working=stage==='filtering',testing=stage==='testing',ready=stage==='ready';
    const fill=normalize(state.fill,stage==='empty'?0:.72),purity=normalize(state.quality,.73);
    const water=purity>.65?'#559c96':'#9b9564',foam=purity>.65?cyan:'#d6c193';
    // Buried utility sockets and the sloped, bolted steel mounting bed.
    o(100,83,91,4,'#121e25');r(7,44,185,25,'#24383d');r(9,46,181,19,'#34494a');
    for(let x=10;x<190;x+=11){r(x,50,7,9,'#273a3c');r(x+1,50,6,1,'#53605b');}
    for(const x of [14,64,129,177]){r(x,72,8,11,shadow);r(x+1,76,5,7,enamel);r(x-1,83,11,2,ink);}
    p(ink,7,70,17,66,181,66,191,70,190,77,184,80,12,80,5,76);
    p(enamel,8,70,17,67,179,67,188,70,180,73,14,73);p(green,8,73,179,75,189,71,187,76,181,78,12,78);
    r(14,74,166,1,rim);for(const x of [15,38,81,125,166,181])bolt(x,75);
    // Intake reservoir and its two circular hoops.
    r(20,17,41,48,ink);o(41,19,21,6,'#293d40');r(22,20,37,42,glass);o(41,62,19,5,glass);
    r(24,22,33,37,'#284e55');o(41,60,17,4,'#35575b');
    const y=60-Math.round(fill*36);
    if(fill>.01){r(24,y,33,60-y,water);o(41,60,17,4,water);o(41,y,17,4,foam);o(42,y+1,14,2,water);
      for(let j=0;j<7;j++){const rise=(t*(working?12:4)+j*6)%36,by=58-Math.floor(rise);
        if(by>y+1){let bx=29+(j*7)%24+Math.round(Math.sin(t+j));r(bx,by,j%3?1:2,1,foam);}}
    }
    r(22,23,2,36,'#729e94');r(25,24,1,18,'#a9cdb3');r(54,25,2,32,'#38686a');r(58,22,2,39,shade());
    for(let i=0;i<8;i++)r(48+(i%2)*2,27+i*4,i%2?3:5,1,'#acbeb0');
    for(const yy of [18,61]){o(41,yy+2,21,5,ink);o(41,yy,21,4,brass);o(40,yy-1,20,3,enamel);r(21,yy-1,39,1,rim);}
    o(40,17,15,2,green);r(37,8,8,7,copper);o(41,9,5,2,gold);r(23,63,37,3,green);r(27,66,27,3,shadow);
    // Supply manifold to three replaceable filter cartridges.
    l(58,25,66,25,ink,5);l(66,25,70,19,ink,5);l(70,19,115,19,ink,5);
    l(58,25,66,25,brass,2);l(66,25,70,19,brass,2);l(70,19,115,19,rim,2);
    for(let j=0;j<3;j++){
      const x=77+j*15,yy=j===1?2:0;
      r(x-3,21,6,6,brass);p(ink,x-5,26+yy,x+4,26+yy,x+7,30+yy,x+7,57,x+4,62,x-3,62,x-7,57,x-7,32+yy);
      r(x-5,30+yy,10,26-yy,[glass,'#6c7865','#68776f'][j]);r(x-3,32+yy,6,23-yy,[teal,'#aea37a','#92a18a'][j]);
      for(let k=0;k<6;k++){const fy=33+yy+k*3;r(x-3,fy,6,1,j===1?'#7e7861':'#49676a');}
      r(x-5,32+yy,1,17,pale);r(x+3,31+yy,1,21,'#537674');
      r(x-6,28+yy,12,3,enamel);r(x-6,28+yy,12,1,rim);r(x-5,57,10,3,copper);r(x-2,60,5,6,brass);
    }
    r(75,65,47,4,ink);r(75,65,47,1,rim);r(115,48,5,18,brass);r(116,50,1,14,gold);
    // Porcelain pressure dial with printed graduations and live pointer.
    r(125,29,8,15,shadow);o(129,22,14,14,ink);o(129,21,13,13,brass);o(129,21,11,11,'#ded1ad');o(129,21,9,9,'#d5c3a3');
    for(let k=0;k<9;k++){const a=(140+k*32)*Math.PI/180;r(129+Math.round(8*Math.cos(a)),21+Math.round(8*Math.sin(a)),1,2,k>5?'#ad7160':green);}
    const ang=(-2.96+3.25*(testing?.5+Math.sin(t*5)*.23:working?.73+.04*Math.sin(t*7):ready?.88:.1));
    l(129,22,129+Math.round(8*Math.cos(ang)),22+Math.round(8*Math.sin(ang)),'#99534b');o(129,22,2,2,shadow);r(128,21,1,1,gold);
    p(ink,122,40,132,34,149,36,155,43,155,65,149,70,122,69,118,64,118,47);
    p(enamel,122,43,130,37,145,37,151,43,151,62,146,67,123,66,121,62,121,47);
    for(let i=0;i<4;i++){r(123,48+i*4,23,2,green);r(124,48+i*4,21,1,rim);}
    r(123,41,12,4,shadow);r(125,42,3,1,working?cyan:amber);r(130,42,3,1,'#749285');
    // Handwheel, curved outlet and a real bottle in the bottling cradle.
    r(142,29,5,12,brass);o(144,30,7,6,ink);o(144,29,6,5,'#bc715a');o(144,29,3,3,shadow);
    const angle=working?t*2:.4;
    for(let j=0;j<3;j++){const a=angle+j*2.094;l(144,29,144+Math.round(5*Math.cos(a)),29+Math.round(4*Math.sin(a)),'#dfa076');}
    r(142,28,3,2,brass);
    l(151,45,155,40,ink,5);l(155,40,172,40,ink,5);l(172,40,176,44,ink,5);r(175,45,5,7,ink);
    l(152,45,156,40,brass,3);l(156,40,172,40,brass,3);l(172,40,176,44,brass,3);r(176,45,3,6,copper);r(174,49,7,2,rim);
    for(const x of [158,168])r(x,39,3,6,green);r(165,66,22,4,green);r(166,66,20,1,rim);
    if(working||ready)bottle(d,172,53);
    if(working){r(177,51,1,3,cyan);r(177,52+(Math.floor(t*12)%5),1,2,pale);}
    if(testing){const pos=20+(Math.floor(t*22)%38);r(21,pos,39,1,cyan);}
  }
  function shade(){return '#304b4e';}
  return Object.freeze({icon,machine});
})();
