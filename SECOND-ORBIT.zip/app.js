'use strict';
const $=s=>document.querySelector(s), esc=s=>String(s).replace(/[&<>"']/g,k=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[k]));
const seed=()=>crypto.getRandomValues(new Uint32Array(1))[0];
const practice=location.hash==='#counter-practice';
let stageKey='',stageAt=0;
const localKey='second-orbit.exchange.v1';
let profile={v:1,revision:0,run:makeRun(seed()),rewards:{},mute:false,best:0}, sdk,session=false,modalKind='',pulseUntil=0,lastDraw=-1,scanUntil=0,visitorKey='',approachAt=0,plantUntil=0;
const phases=['bell','ready','trade','receipt','audit','night','failed','owned'];
function isLot(l){return l&&Number.isInteger(l.item)&&!!GOODS[l.item]&&Number.isInteger(l.grade)&&!!GRADES[l.grade]&&Number.isFinite(l.id)&&Number.isFinite(l.cost);}
function validRun(s){
 if(!s||!phases.includes(s.phase)||!['seed','cash','day','turn','limit','paid','scans','nonce','heat','deals','totalSales'].every(k=>Number.isFinite(s[k]))||s.day<1||!Array.isArray(s.stock)||!s.stock.every(isLot)||!Array.isArray(s.reps)||s.reps.length!==3||!s.reps.every(Number.isFinite)||!['gear','ledger','served','serials'].every(k=>Array.isArray(s[k])))return false;
 if(!Number.isInteger(s.day)||s.stock.length>20||(s.kit&&!KITS.some(q=>q.id===s.kit))||s.ledger.some(e=>!e||typeof e.text!=='string'||!Number.isInteger(e.day)||!Number.isFinite(e.amount)))return false;
 if(['trade','receipt'].includes(s.phase)&&(!s.patron||!isLot(s.patron.lot)||!PEOPLE[s.patron.person]||!Number.isFinite(s.patron.offer)||!Number.isFinite(s.patron.ask)))return false;
 if(s.phase==='trade'&&(!Number.isInteger(s.patron.patience)||s.patron.patience<1||s.patron.patience>3))return false;
 if(s.phase==='audit'&&(!s.audit||!Number.isFinite(s.audit.levy)))return false;
 return !['night','failed','owned'].includes(s.phase)||!!s.recap;
}
function persist(){try{if(practice)sessionStorage.setItem(localKey+'.practice',JSON.stringify(profile));else localStorage.setItem(localKey,JSON.stringify(profile));}catch{}}
function merge(data,remote=false){
 if(!data||typeof data!=='object')return;
 for(const k of ['like','comment'])if(data.rewards?.[k]===true)profile.rewards[k]=true;
 if(Number.isFinite(data.best)&&data.best>0)profile.best=profile.best?Math.min(profile.best,data.best):data.best;
 if(!remote&&typeof data.mute==='boolean')profile.mute=data.mute;
 if(Number.isFinite(data.revision)&&data.revision>profile.revision&&validRun(data.run)){
  if(remote&&session){sdk?.end();session=false;} profile.run=typeof structuredClone==='function'?structuredClone(data.run):JSON.parse(JSON.stringify(data.run));profile.revision=data.revision;
  if(remote&&$('#modal').open)$('#modal').close();
 }
}
try{merge(JSON.parse(practice?sessionStorage.getItem(localKey+'.practice'):localStorage.getItem(localKey)));}catch{}
const run=()=>profile.run;window.shopState=()=>JSON.parse(JSON.stringify(profile));
function save(){profile.revision=Math.max(Date.now(),profile.revision+1);persist();sdk?.save();}
function hostStart(){if(session)return;session=true;sdk?.prepare();sdk?.start();}
function raiseShutters(){run().phase='bell';CounterSound.play('open');}
function begin(){hostStart();beginShift(run());CounterSound.play('open');}
function delta(text){
 const el=$('#delta');el.textContent=text;
 if(text==='SOLD'||text==='PURCHASED'){
  const cash=$('#meters');cash.classList.remove('cashPulse');void cash.offsetWidth;cash.classList.add('cashPulse');
  return;
 }
 el.classList.remove('show');void el.offsetWidth;el.classList.add('show');pulseUntil=performance.now()+1200;
}
function action(label,fn,cls='primary',id='primary'){const b=document.createElement('button');b.id=id;b.className=cls;b.textContent=label;b.onclick=()=>{if(!b.isConnected||b.disabled)return;CounterSound.wake();fn();save();render();};return b;}
function actions(...buttons){const d=document.createElement('div');d.className='actions';d.append(...buttons);$('#desk').append(d);}
const goodsIcon=i=>'<canvas class="icon" width="48" height="48" data-icon="'+i+'" aria-hidden="true"></canvas>';
function drawIcon(c,i){if(i===12&&window.WaterArt)WaterArt.icon(c,2);else CounterArt.icon(c,i);}
function icons(root=document){root.querySelectorAll('[data-icon]').forEach(c=>drawIcon(c,+c.dataset.icon));}
function meter(label,val,icon){
 return '<div>'+pict(icon,18)+'<span>'+esc(label)+'</span><strong>'+esc(String(val))+'</strong></div>';
}
function render(){
 const s=run(),v=s.patron,desk=$('#desk'),cnt=s.stock.length,night=['night','failed','owned'].includes(s.phase);
 $('#time').textContent=s.phase==='ready'?'PORT 09':'SHIFT '+String(s.day).padStart(2,'0');
 $('#sector').textContent=profile.rewards.like?'GOLD TRADER':'DOCK 09';
 $('#cabinet').dataset.phase=s.phase;$('#cabinet').classList.toggle('inked',!!profile.rewards.comment);
 const tray=$('#trayHit'),loose=$('#looseItem'),atDesk=s.phase==='trade'&&v;
 tray.hidden=!atDesk&&s.phase!=='bell';loose.hidden=!atDesk||v.buyer||trayReady(v);
 tray.setAttribute('aria-label',s.phase==='bell'?'Ring the counter bell':'Use the deal tray');
 tray.onclick=()=>{if(s.phase==='bell')$('#primary')?.click();else if(atDesk&&!trayReady(v))$('#primary')?.click();else if(atDesk&&v.buyer)showModal('swap');else if(atDesk)readOnCounter(s);};
 loose.onclick=()=>{if(atDesk&&!trayReady(v))placeOnCounter(s,v.lot.id);};
 const bill=rentInfo(s);
 const opening=s.day===1&&s.turn<=2&&!['night','owned','failed','audit'].includes(s.phase);
 $('#meters').innerHTML=meter('Cash',money(s.cash),'coin')+(opening?'':meter(bill.amount?(bill.due?'Rent due':'Rent · '+bill.daysLeft+'d'):'Rent',money(bill.amount),'rent'))+
  (opening?'':s.day===1?meter('Guests',s.turn+'/'+s.limit,'bell'):meter('Heat',s.heat+'/5','stamp'));
 $('#cabinet').classList.toggle('firstDeal',opening);
 $('#world').dataset.focus=s.phase==='bell'?'bell':atDesk&&!trayReady(v)?(v.buyer?'shelf':'loose'):atDesk&&firstSeller(s)&&!v.lot.sealRead?'stamp':'';
 $('#cabinet').classList.toggle('practiceMode',practice);
 $('#supplyFace').classList.toggle('windowOpen',s.day>=2);
 $('#supplyFace').setAttribute('aria-label',s.day>=2?'Open the display window':'Inspect shelf stock');
 $('#stockCount').textContent=cnt;$('#sound').innerHTML='<svg viewBox="0 0 24 24"><path d="M3 9h4l5-4v14l-5-4H3z"/>'+(profile.mute?'<path d="m16 9 6 6m0-6-6 6"/>':'<path d="M16 9q4 3 0 6m3-9q6 6 0 12"/>')+'</svg>';$('#sound').setAttribute('aria-label',profile.mute?'Turn sound on':'Mute sound');
 if(s.phase==='ready'){
  desk.innerHTML='<div class="intro"><h1>SECOND<br>ORBIT</h1><p class="lede">'+(practice?'Practice sale':'Buy low. Sell high.')+'</p></div>';
  actions(buttonFace(action('',raiseShutters),'shutter','Open shop'));
 }else if(s.phase==='bell'){
  desk.innerHTML='<div class="bellCue">'+pict('bell',56)+'<h2>Shop open</h2></div>';
  actions(buttonFace(action('',begin),'bell','Ring bell'));
 }else if(s.phase==='trade'){
  renderTrade(s,desk);
 }else if(s.phase==='receipt'){
  renderTicket(s,desk,()=>{
   if(practice&&s.patron.lessonCoil&&s.turn===2){returnFromPractice();return;}
   hostStart();if(s.turn>=s.limit){requestClose(s);if(s.phase!=='audit'){sdk?.end();session=false;}CounterSound.play(s.phase==='audit'?'alert':s.phase==='failed'?'lose':'stamp');}
   else{nextGuest(s);CounterSound.play('arrival');}
  });
  if(practice&&s.patron.lessonCoil&&s.turn===2)buttonFace($('#primary'),'shutter','Back to shop');
 }else if(s.phase==='audit'){
  const wanted=s.stock.find(l=>l.id===s.audit.lotId);
  desk.innerHTML='<div class="receiptHead">'+pict('stamp',34)+'<h2>Customs check</h2></div><div class="panel"><p>'+esc(wanted?'Flagged: '+GOODS[wanted.item][0]:'Tagged goods sold.')+'</p><p>'+esc(wanted?'Hand it in to cut the fine.':'Pay the fine to close the shop.')+'</p></div>';
  const resolve=kind=>{hostStart();if(answerAudit(s,kind)){sdk?.end();session=false;CounterSound.play(s.phase==='failed'?'lose':'stamp');}};
  const buttons=[action('Pay '+money(s.audit.levy),()=>resolve(false))];if(wanted)buttons.push(action('Hand in · '+money(3),()=>resolve(true),'secondary','surrender'));actions(...buttons);
 }else if(night){
  const r=s.recap;
  if(s.phase==='failed'){
   desk.innerHTML='<h2 class="resultTitle loss">Shop closed</h2><p class="body">Rent short by '+money(-s.cash)+'.</p>';
   actions(action('Try again',()=>{profile.run=makeRun(seed());begin();}));
  }else if(s.phase==='owned'){
   const ending=s.charter===0?'The foreman bolts a union plaque beside your door.':s.charter===1?'The Survey Office files your shop among the ring’s permanent landmarks.':s.charter===2?'The evening convoy blinks its running lights in salute.':s.water?.bottles?'The dock crew raises a toast with water from your own line.':'The broker slides the brass keys across the counter.';
   desk.innerHTML='<span class="kicker">DEED ISSUED · DOCK 09</span><h2 class="resultTitle">The shop is yours!</h2><p class="body">'+ending+' Day '+s.day+' · '+s.deals+' deals.</p>';
   actions(action('Trade after hours',()=>{s.extended=true;s.day++;begin();}));
  }else{
   desk.innerHTML='<h2 class="resultTitle">Day '+s.day+' totals</h2><div class="daybill"><span>In / Out</span><b>+'+money(s.earned)+' / −'+money(s.spent)+'</b><span>Rent'+(s.extended?' rebate':'')+'</span><b>'+money(r.rent)+'</b>'+(r.fine?'<span>Customs'+(r.seized?' · seized '+esc(r.seized):'')+'</span><b>−'+money(r.fine)+'</b>':'')+(r.liquidation?'<span>Emergency stock sale</span><b>+'+money(r.liquidation)+'</b>':'')+'</div><div class="panel"><p><strong>'+(s.paid>=DEED?'Shop owned':'Deed '+money(s.paid)+' / '+money(DEED))+'</strong></p><div class="bookbar"><i style="width:'+Math.min(100,s.paid/DEED*100)+'%"></i></div></div>';
   const next=action('Day '+(s.day+1)+' →',()=>{s.day++;begin();}),bench=action('Workbench',()=>showModal('bench'),'secondary','bench');actions(next,bench);
   if(s.paid<DEED){const due=Math.min(DEED-s.paid,60),b=action('Buy shop · '+money(due),()=>{s.cash-=due;s.paid+=due;logTrade(s,'Deed installment',-due);CounterSound.play('upgrade');if(s.paid===DEED){s.phase='owned';profile.best=profile.best?Math.min(profile.best,s.day):s.day;}},'secondary','deposit');const waiting=s.deskVersion===2&&s.paid+due>=DEED&&s.day<7;
    if(waiting)b.textContent='Final deed · Day 7';b.disabled=s.cash<due||waiting;actions(b);}
  }
 }
 if(s.phase==='night'&&s.deskVersion===2&&s.paid<DEED){
  const nextBill=rentInfo({...s,day:s.day+1}),note=document.createElement('p');
  note.className='rentNote';note.textContent='Rent '+money(nextBill.amount)+' · Day '+(s.day+1+nextBill.daysLeft);
  desk.querySelector('.daybill').after(note);
 }
 if(s.phase==='night'&&s.recap.bonus?.amount){const badge=document.createElement('p');badge.className='bonus';badge.textContent='✓ '+s.recap.bonus.title+' paid '+money(s.recap.bonus.amount);desk.querySelector('.daybill').after(badge);}
 if(s.phase==='night'&&s.day<=4){
   const unlock=document.createElement('p');unlock.className='unlock';
   unlock.textContent=['Unlock: haggling & workshop','Unlock: pair orders','Unlock: drones & prisms','Unlock: rare relics'][s.day-1];
   desk.querySelector('.panel').append(unlock);
 }
 if(s.phase==='trade'&&s.day===2&&s.turn===1){
   const button=document.createElement('button');button.className='permit';button.textContent='New · Water plant';button.onclick=()=>showModal('water');desk.append(button);
 }
 icons(desk);renderDrawer();draw(performance.now());if($('#modal').open&&modalKind)modalContents();
}
function renderDrawer(){
 const d=$('#drawer'),s=run();d.replaceChildren();
 for(let i=0;i<Math.max(5,Math.min(s.stock.length,6));i++){
  const l=s.stock[i],b=document.createElement(l?'button':'div');b.className='bin';
  if(l){b.innerHTML=goodsIcon(l.item)+'<span>'+money(l.cost)+'</span>';b.title=GOODS[l.item][0];b.setAttribute('aria-label','View '+b.title);
   const buyer=s.phase==='trade'&&s.patron.buyer;
   if(buyer){
    b.setAttribute('aria-label','Place '+b.title+' on the tray');
    if(s.patron.lessonCoil===l.id)b.classList.add('requested');
    if(s.patron.lessonCoil&&s.patron.lessonCoil!==l.id)b.disabled=true;
    if(trayReady(s.patron)&&s.patron.lot.id===l.id)b.classList.add('ontray');
   }
   if(CounterWindow.featured(s)?.id===l.id)b.classList.add('featured');
   const choose=()=>{if(!b.disabled&&(!trayReady(s.patron)||s.patron.lot.id!==l.id))placeOnCounter(s,l.id);};
   if(buyer&&!b.disabled)handleLift(b,l,choose);
   b.onclick=()=>{if(b.dataset.dragged==='true')return;if(buyer)choose();else showModal('shelf');};}
  d.append(b);
 }icons(d);
}
function handleLift(b,l,choose){
 let down=null,ghost=null;b.style.touchAction='none';b.title='Show '+GOODS[l.item][0]+' to this buyer';
 b.onpointerdown=e=>{down=[e.clientX,e.clientY];b.dataset.dragged='';b.setPointerCapture(e.pointerId);};
 b.onpointermove=e=>{if(!down)return;if(!ghost&&Math.hypot(e.clientX-down[0],e.clientY-down[1])<7)return;
   if(!ghost){ghost=document.createElement('canvas');ghost.className='lifted';drawIcon(ghost,l.item);document.body.append(ghost);$('#world').classList.add('dropzone');}
   ghost.style.left=(e.clientX-24)+'px';ghost.style.top=(e.clientY-38)+'px';};
 function end(e,drop){if(ghost){ghost.remove();ghost=null;b.dataset.dragged='true';$('#world').classList.remove('dropzone');
   const r=$('#world').getBoundingClientRect(),lot=$('.lot')?.getBoundingClientRect();const inside=q=>q&&e.clientX>=q.left&&e.clientX<=q.right&&e.clientY>=q.top&&e.clientY<=q.bottom;
   if(drop&&(inside(r)||inside(lot))){choose();if(e.pointerType==='touch')drawerReleaseUntil=performance.now()+1800;}}down=null;}
 b.onpointerup=e=>end(e,true);b.onpointercancel=e=>end(e,false);b.onlostpointercapture=e=>end(e,false);
}


const modal=$('#modal');
if(typeof modal.showModal!=='function'){
 modal.classList.add('simple-dialog');
 modal.showModal=()=>{modal.setAttribute('open','');modal.open=true;};
 modal.close=()=>{modal.removeAttribute('open');modal.open=false;modal.dispatchEvent(new Event('close'));};
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&modal.open)modal.close();});
}
$('#looseItem').addEventListener('pointerdown',e=>{
 const b=e.currentTarget,s=run(),v=s.patron;if(!v||v.buyer||trayReady(v))return;
 const start=[e.clientX,e.clientY];let ghost=null;b.setPointerCapture(e.pointerId);
 const move=ev=>{if(ev.pointerId!==e.pointerId||Math.hypot(ev.clientX-start[0],ev.clientY-start[1])<7&&!ghost)return;
  if(!ghost){ghost=document.createElement('canvas');ghost.className='lifted';drawIcon(ghost,v.lot.item);document.body.append(ghost);$('#world').classList.add('dropzone');}
  ghost.style.left=(ev.clientX-20)+'px';ghost.style.top=(ev.clientY-30)+'px';};
 const finish=ev=>{if(ev.pointerId!==e.pointerId)return;
  b.removeEventListener('pointermove',move);b.removeEventListener('pointerup',finish);b.removeEventListener('pointercancel',finish);
  if(!ghost)return;ghost.remove();$('#world').classList.remove('dropzone');
  const rect=$('#trayHit').getBoundingClientRect(),hit=ev.clientX>=rect.left-8&&ev.clientX<=rect.right+8&&ev.clientY>=rect.top-8&&ev.clientY<=rect.bottom+8;
  const ignore=ev=>{ev.stopImmediatePropagation();};b.addEventListener('click',ignore,{capture:true,once:true});setTimeout(()=>b.removeEventListener('click',ignore,true),350);
  if(hit&&ev.type==='pointerup')placeOnCounter(s,v.lot.id);
 };b.addEventListener('pointermove',move);b.addEventListener('pointerup',finish);b.addEventListener('pointercancel',finish);
});
function showModal(kind){modalKind=kind;modalContents();if(!modal.open)modal.showModal();$('#dismiss').focus();}
function tile(i,h,sub,button=''){return '<div class="row">'+(i==null?'':goodsIcon(i))+'<div><b>'+h+'</b><small>'+sub+'</small></div>'+button+'</div>';}
function modalContents(){
 const s=run(),v=s.patron,body=$('#modalBody'),sup=sdk?.support()||{},k=modalKind;let text='';
 $('#modalTitle').textContent=({help:'How to play',talk:'Customer',scan:'Check stamp',shelf:'Shelf stock',swap:'Show another lot',ledger:'Station ledger',bench:'Night workbench',water:'Condensate plant',kits:'Opening licenses',restart:'A new lease',guide:'Salvage field guide',charter:'Trade charters'})[k]||'Station';
 if(k==='talk'&&v){
  $('#modalTitle').textContent=PEOPLE[v.person][0];
  text='<p class="talkquote">“'+esc(customerSpeech(s).replace(/^[“"]|[”"]$/g,''))+'”</p>';
 }else if(k==='help'){
  text='<article class="manual pictureManual"><div>'+pict('tray',32)+'<b>Place the item</b></div><div>'+pict('lens',32)+'<b>Check its stamp</b></div><div>'+pict('profit',32)+'<b>Buy low. Sell high.</b></div></article>'+
   (practice?'<button id="practiceExit">Back to shop</button>':'<button id="tryDeal">Practice one sale</button><small class="tiny">Your shop stays saved.</small>');
 }else if(k==='scan'&&v&&s.phase==='trade'){
  const l=v.lot,item=GOODS[l.item],mark=SEALS[l.item];const actual=l.fake?mark.slice(0,-1)+(Number(mark.at(-1))+2)%10:mark;
  const read=l.sealRead===true;
  text=tile(l.item,item[0],GRADES[l.grade][0])+'<canvas class="specimen" width="256" height="66" aria-label="Factory handbook specimen"></canvas><canvas class="loupe" tabindex="0" aria-label="Inspection lens. Touch the marked serial plate, use arrow keys, or press Enter to focus the plate."></canvas><p id="lensHint" class="mono">'+(read?'Stamp found':'Tap the glowing stamp.')+'</p><div class="sealpair"><div><span class="tiny">Guide</span><b>'+mark+'</b></div><div><span class="tiny">Item</span><b id="readCode">'+(read?actual:'····')+'</b></div></div><div class="panel" id="scanReport" '+(read?'':'hidden')+'><p><strong>'+(l.fake?'Copy':'Genuine')+'</strong></p><p>'+'Value '+money(lotValue(l,demand(s,l.item)))+(l.tag?' · Flagged':'')+'</p></div>';
  text+='<div id="stampChoice" hidden><button data-match="yes">= Same</button><button data-match="no">≠ Different</button></div>';
  text+='<button id="returnDeal" '+(read?'':'hidden')+'>Back to deal</button>';
  if(l.tag)text+='<button data-act="report" '+(read?'':'hidden')+'>Report · +₵5</button>'; }else if(k==='shelf'||k==='swap'){
  if(k==='shelf'&&s.day>=2)text='<p class="mono">Display an item to attract a buyer.</p>';if(k==='swap'&&v)text='<p class="mono">Wanted: '+['machine parts','survey gear','freight goods'][v.wants]+'.</p>';
  text+=s.stock.length?s.stock.map(l=>tile(l.item,GOODS[l.item][0],GRADES[l.grade][0]+' · cost '+money(l.cost)+(l.sealRead&&l.tag?' · tagged':'')+(l.sealRead&&l.fake?' · replica':''),k==='swap'?'<button data-lot="'+l.id+'" '+(v.lessonCoil&&l.id!==v.lessonCoil?'disabled':'')+'>Place</button>'+(v.pairOrder&&l.id!==v.lot.id?'<button data-pair="'+l.id+'">Pair</button>':''):(s.day>=2?'<button data-window="'+l.id+'">'+(CounterWindow.featured(s)?.id===l.id?'In window ✓':'Display')+'</button>':'<span class="tiny">'+money(lotValue(l,demand(s,l.item)))+'</span>'))).join(''):'<p class="mono">Shelf empty. Buy an item.</p>';
 }else if(k==='charter'){
  const effects=['Rent −₵6','+2 checks · rare stock','Matched sales +15%'];
  text='<p class="mono">Choose one crew. Needs 4 stars.</p>'+CREWS.map((name,i)=>tile([1,4,7][i],name,effects[i],'<button data-crew="'+i+'" '+(s.reps[i]<4||s.charter!=null?'disabled':'')+'>'+(s.charter===i?'Signed':s.reps[i]>=4?'Sign':s.reps[i]+'/4')+'</button>')).join('');
 }else if(k==='guide'){
  text='<p class="mono">'+s.serials.length+' / '+GOODS.length+' items found.</p>'+GOODS.map((g,i)=>tile(i,g[0],g[3]+' '+g[4],'<span class="tiny">'+(s.serials.includes(i)?'Logged':'Unseen')+'</span>')).join('');
 }else if(k==='kits'){
  text=KITS.map(kit=>tile(kit.item,kit.name,kit.desc,'<button data-kit="'+kit.id+'">'+((s.kit||'salvage')===kit.id?'Selected':'Select')+'</button>')).join('');
 }else if(k==='restart'){
  text='<p class="mono">Start over? This shop will be replaced. Your best score and rewards stay.</p><button id="newLease">Start a fresh lease</button>';
 }else if(k==='water'){
  const w=CounterWater.status(s),options=({uninstalled:[['install','Install · ₵16',16]],idle:[['source','Order tank · ₵7',7]],raw:[['sample','Draw sample',0]],sampled:[['gravity','Gravity bed · ₵3',3],['polish','Polish · ₵5',5]],filtered:[['bottle','Seal and stock',0]]})[w.phase]||[];
  const desc=({locked:'Opens on Day 2.',uninstalled:'Filter water to sell.',idle:'One batch per day.',raw:'Test the water.',sampled:w.sampleText,filtered:w.quality===2?'Clear · premium water.':'Cloudy · basic water.',bottled:'Bottled. More tomorrow.'})[w.phase];
  text='<canvas id="plantFace" aria-label="Water filtration machinery"></canvas><p class="mono">'+desc+'</p><div class="daybill"><span>Available cash</span><b>'+money(s.cash)+'</b>'+(w.contaminant?'<span>Assay</span><b>'+esc(w.contaminant)+'</b>':'')+'</div>'+
    options.map(([act,label,price])=>'<button class="plantAction" data-plant="'+act+'" '+(s.cash<price||act==='bottle'&&s.stock.length>=7?'disabled':'')+'>'+label+'</button>').join('')+(w.phase==='filtered'&&s.stock.length>=7?'<p class="danger">Shelf full. Sell an item.</p>':'');
 }else if(k==='bench'){
  const worked=s.recap?.worked,broken=s.stock.find(l=>l.grade<2&&!l.fake),cheap=s.stock.find(l=>l.item===0),coil=s.stock.find(l=>l.item===1);
  const button=(act,label,disabled)=>'<button data-act="'+act+'" '+(disabled?'disabled':'')+'>'+label+'</button>';
  text='<p class="mono">One repair or build per night.</p>'+
   tile(1,'Restore a lot',broken?GOODS[broken.item][0]+' · raise condition one grade':'No damaged authentic stock',button('repair','₵4',worked||!broken||s.cash<4))+
   tile(8,'Build a micro drone','Pulse Cell + Relay Coil',button('craft','Build',worked||!cheap||!coil))+
   tile(2,'Assay reader','3 → 5 scans per day',button('reader',s.gear.includes('reader')?'Fitted':'₵32',s.cash<32||s.gear.includes('reader')))+
   tile(0,'Order a parts crate','One serviceable Pulse Cell and Relay Coil.',button('supply','₵44',worked||s.cash<44||s.stock.length>5));
 }else if(k==='ledger'){
  const ev=EVENTS[(s.day-1)%6],news=CounterContracts.headline(s),order=CounterContracts.status(s);
  text='<details class="logDetail"><summary>Station news</summary><article class="bulletin"><small>THE RING GAZETTE</small><h3>'+news.title+'</h3><p>'+news.body+'</p></article></details>'+(order?'<div class="panel"><p><strong>'+order.title+' · '+order.progress+'/'+order.goal+'</strong></p><p>'+order.brief+'</p></div>':'')+'<div class="panel"><p><strong>'+ev[0]+'</strong></p><p>'+ev[1]+'</p></div>'+
   '<div class="daybill"><span>Shop deed</span><b>'+money(s.paid)+' / '+money(DEED)+'</b>'+CREWS.map((c,i)=>'<span>'+c+'</span><b>'+s.reps[i]+' / 9</b>').join('')+'</div>'+
   (profile.best?'<p class="accent">Fastest deed · '+profile.best+' shifts</p>':'')+
   (s.ledger.length?'<details class="logDetail"><summary>Receipts · '+s.ledger.length+'</summary>'+s.ledger.slice(0,8).map(e=>tile(null,esc(e.text),'Shift '+e.day,'<span class="tiny">'+(e.amount>0?'+':'')+money(e.amount)+'</span>')).join('')+'</details>':'')+
   ((sup.like||sup.comment||profile.rewards.like||profile.rewards.comment)?'<div class="panel"><p>'+[profile.rewards.like?'Gold Trader plate fitted':sup.like?'Like in GameWave to fit a Gold Trader plate.':'',profile.rewards.comment?'Violet receipt ink fitted':sup.comment?'Comment in GameWave to unlock violet receipt ink.':''].filter(Boolean).join(' ')+'</p></div>':'');
 }
 body.innerHTML=text;icons(body);if(k==='scan'&&body.querySelector('.loupe')){const l=v.lot;CounterStamps.page(body.querySelector('.specimen'),l);const sync=bindAppraisal(body,s,v);AssayGlass.install(body.querySelector('.loupe'),l,()=>{CounterSound.play('stamp');save();const mark=SEALS[l.item];document.getElementById("readCode").textContent=l.fake?mark.slice(0,-1)+(Number(mark.at(-1))+2)%10:mark;sync();});}body.querySelectorAll('[data-lot]').forEach(b=>b.onclick=()=>{
  if(s.phase!=='trade'||!v?.buyer)return;const l=s.stock.find(q=>q.id===Number(b.dataset.lot));if(!l)return;if(!stageLot(s,l.id))return;hostStart();modal.close();CounterSound.play('tap');save();render();});
 body.querySelectorAll('[data-pair]').forEach(b=>b.onclick=()=>{const extra=s.stock.find(l=>l.id===Number(b.dataset.pair));if(!v?.buyer||!v.pairOrder||!extra||extra.id===v.lot.id)return;if(!stageLot(s,extra.id,'extra'))return;hostStart();save();modal.close();CounterSound.play('tap');render();});
 if(k==='scan')$('#returnDeal').onclick=()=>{modal.close();render();};
 if(k==='shelf')body.querySelectorAll('[data-window]').forEach(b=>b.onclick=()=>{const id=Number(b.dataset.window);if(CounterWindow.pin(s,CounterWindow.featured(s)?.id===id?null:id)){save();CounterSound.play('tap');render();}});
 if(k==='help'){if(practice)$('#practiceExit').onclick=returnFromPractice;else $('#tryDeal').onclick=enterPractice;}
 if(k==='shelf'||k==='ledger'){const guide=document.createElement('button');guide.textContent='Field guide · '+s.serials.length+'/'+GOODS.length;guide.onclick=()=>showModal('guide');body.append(guide);}
 if(k==='kits')body.querySelectorAll('[data-kit]').forEach(b=>b.onclick=()=>{openingKit(s,b.dataset.kit);save();modal.close();render();});
 if(k==='ledger'){
  if(s.phase==='ready'){const kits=document.createElement('button');kits.textContent='Choose an opening license';kits.onclick=()=>showModal('kits');body.prepend(kits);}
  if(s.day>=2){const charter=document.createElement('button');charter.textContent=s.charter!=null?'Charter · '+CREWS[s.charter]:'Trade charters';charter.onclick=()=>showModal('charter');body.prepend(charter);}
  const reset=document.createElement('button');reset.textContent='Apply for a new lease';reset.onclick=()=>showModal('restart');body.append(reset);
 }
 if(k==='charter')body.querySelectorAll('[data-crew]').forEach(b=>b.onclick=()=>{const i=Number(b.dataset.crew);if(s.charter!=null||s.day<2||s.reps[i]<4)return;s.charter=i;logTrade(s,CREWS[i]+' charter');save();CounterSound.play('stamp');render();});
 if(k==='restart')$('#newLease').onclick=()=>{if(session){sdk?.end();session=false;}profile.run=makeRun(seed());save();modal.close();render();};
 if((k==='shelf'||k==='bench')&&CounterWater.status(s).available){let b=document.createElement('button');b.textContent='Water plant';b.id='water';b.onclick=()=>showModal('water');body.prepend(b);}
 if(k==='water'){paintPlant(performance.now());body.querySelectorAll('[data-plant]').forEach(b=>b.onclick=()=>{const a=b.dataset.plant;if(s.phase==='trade'||s.phase==='receipt')hostStart();
   const result=(a==='gravity'||a==='polish')?CounterWater.filter(s,a):CounterWater[a](s);
   if(result.ok){if(a==='gravity'||a==='polish')plantUntil=performance.now()+1200;CounterSound.play(a==='sample'?'scan':a==='bottle'?'stamp':'upgrade');save();}render();
  });}
 body.querySelectorAll('[data-act]').forEach(b=>b.onclick=()=>{
  const act=b.dataset.act;
  if(act==='report'&&s.phase==='trade'&&v&&!v.buyer&&v.scanned&&v.lot.sealRead&&v.lot.tag){hostStart();pass(s,true);modal.close();CounterSound.play('stamp');}
  else if(s.phase==='night'&&k==='bench'){
   const r=s.recap;
   if(act==='reader'&&s.cash>=32&&!s.gear.includes('reader')){s.cash-=32;s.gear.push('reader');logTrade(s,'Assay reader fitted',-32);}
   else if(act==='repair'&&!r.worked&&s.cash>=4){const l=s.stock.find(q=>q.grade<2&&!q.fake);if(!l)return;s.cash-=4;l.cost+=4;l.grade++;r.worked=true;logTrade(s,'Restored '+GOODS[l.item][0],-4);}
   else if(act==='craft'&&!r.worked){const a=s.stock.find(l=>l.item===0),b=s.stock.find(l=>l.item===1);if(!a||!b)return;s.stock=s.stock.filter(l=>l!==a&&l!==b);s.stock.push({id:++s.nonce,item:8,cost:a.cost+b.cost,grade:2,fake:false,tag:a.tag||b.tag});r.worked=true;logTrade(s,'Built a micro drone');}
   else if(act==='supply'&&!r.worked&&s.cash>=44&&s.stock.length<=5){s.cash-=44;for(const item of [0,1])s.stock.push({id:++s.nonce,item,cost:22,grade:1,fake:false,tag:false});r.worked=true;logTrade(s,'Parts crate',-44);}
   else return;CounterSound.play('upgrade');
  }else return;
  save();render();
 });
}
// A lens swipe can suppress the next synthesized mouse click on some touch
// browsers. Complete a deliberate tap on release and consume that tap's
// compatibility click even if closing the dialog exposes another button.
let lastModalTouch=null,modalPress=null,drawerReleaseUntil=0;
document.addEventListener('pointerdown',e=>{
 lastModalTouch=null;modalPress=null;
 if(e.pointerType!=='touch'||!e.isPrimary)return;
 const drawerSale=!modal.open&&run().phase==='trade'&&run().patron?.buyer&&performance.now()<drawerReleaseUntil;
 const button=modal.open?e.target.closest?.('#dismiss,#returnDeal,[data-match],[data-act="report"]'):drawerSale?e.target.closest?.('#primary'):null;
 if(button&&!button.disabled)modalPress={button,id:e.pointerId,x:e.clientX,y:e.clientY,dialog:modal.open};
},true);
document.addEventListener('pointercancel',()=>{modalPress=null;},true);
document.addEventListener('pointermove',e=>{
 if(modalPress?.id===e.pointerId&&Math.hypot(e.clientX-modalPress.x,e.clientY-modalPress.y)>8)modalPress=null;
},true);
document.addEventListener('pointerup',e=>{
 const p=modalPress;if(!p||p.id!==e.pointerId)return;modalPress=null;
 if(p.dialog!==modal.open||!p.button.isConnected||!p.button.contains(document.elementFromPoint(e.clientX,e.clientY)))return;
 if(!p.dialog)drawerReleaseUntil=0;
 lastModalTouch={x:e.clientX,y:e.clientY,time:performance.now()};
 e.preventDefault();p.button.click();
},true);
document.addEventListener('click',e=>{
 const p=lastModalTouch;
 if(p&&e.detail>0&&performance.now()-p.time<750&&Math.hypot(e.clientX-p.x,e.clientY-p.y)<20){
  e.preventDefault();e.stopImmediatePropagation();lastModalTouch=null;
 }
},true);
let practiceFrame=null;
function enterPractice(){
 if(practice||practiceFrame)return;
 try{sessionStorage.removeItem(localKey+'.practice');}catch{}
 if(modal.open)modal.close();
 const overlay=document.createElement('dialog');overlay.className='practiceOverlay';
 const frame=document.createElement('iframe');frame.title='Practice one sale';frame.src=location.href.split('#')[0]+'#counter-practice';
 const leave=document.createElement('button');leave.className='leavePractice';leave.textContent='Leave practice';leave.onclick=closePractice;
 overlay.append(leave,frame);document.body.append(overlay);practiceFrame=frame;
 if(overlay.showModal)overlay.showModal();else overlay.setAttribute('open','');frame.focus();
 overlay.addEventListener('cancel',e=>{e.preventDefault();closePractice();});
}
function closePractice(){if(!practiceFrame)return;const overlay=practiceFrame.parentElement;practiceFrame=null;overlay.remove();$('#help').focus();}
window.addEventListener('message',e=>{if(practiceFrame&&e.source===practiceFrame.contentWindow&&e.data==='second-orbit.practice-finished')closePractice();});
function returnFromPractice(){
 try{sessionStorage.removeItem(localKey+'.practice');}catch{}
 if(parent!==window){parent.postMessage('second-orbit.practice-finished','*');return;}
 history.replaceState(null,'',location.href.split('#')[0]);location.reload();
}
$('#help').innerHTML=pict('help',22);$('#help').onclick=()=>showModal('help');
$('#shelf').prepend(makeSmallIcon('shelf'));$('#ledger').prepend(makeSmallIcon('ledger'));
function makeSmallIcon(name){const span=document.createElement('span');span.className='navGlyph';span.innerHTML=pict(name,19);return span;}
$('#dismiss').onclick=()=>{modal.close();render();};modal.addEventListener('close',()=>{modalKind='';});
$('#shelf').onclick=()=>showModal('shelf');$('#ledger').onclick=()=>showModal('ledger');
function worldControl(id,label,open){const b=document.createElement('button');b.id=id;b.className='worldControl';b.setAttribute('aria-label',label);b.title=label;b.onclick=open;$('#world').append(b);}
worldControl('registerFace','Open the register ledger',()=>showModal('ledger'));
worldControl('supplyFace','Inspect shelf stock',()=>showModal('shelf'));
$('#sound').onclick=()=>{profile.mute=!profile.mute;CounterSound.mute(profile.mute);if(!profile.mute){CounterSound.wake();CounterSound.play('tap');}save();render();};
function hostSize(){const v=sdk?.viewport();for(const [key,val] of [['--hostw',v?.width],['--hosth',v?.height]])if(val)document.documentElement.style.setProperty(key,val+'px');else document.documentElement.style.removeProperty(key);}
function draw(ts){
 const s=run(),v=s.patron;const t=matchMedia('(prefers-reduced-motion: reduce)').matches?0:ts/1000;
 const id=(v?s.day+'/'+s.turn:'')+(!v?s.phase:'');if(id!==visitorKey){visitorKey=id;approachAt=ts;}
 const arrive=v&&t?Math.min(1,(ts-approachAt)/420):1;
 const phaseKey=s.day+'/'+s.turn+'/'+s.phase+(v?'/'+trayReady(v):'');
 if(stageKey!==phaseKey){stageKey=phaseKey;stageAt=ts;}
 const showLot=v&&s.phase==='trade'&&trayReady(v);
 const ceremony=s.phase==='owned',crew=s.charter??s.reps.indexOf(Math.max(...s.reps));
 CounterArt.draw($('#shopArt'),{time:t,celebration:t?Math.min(1,Math.max(0,(ts-approachAt)/1000)):1,shutter:s.turn===1&&arrive<1?(1-arrive)**2:0,approach:arrive,extra:showLot?sideOf(v)?.item:null,progress:s.turn/s.limit,reader:s.gear.includes('reader'),heat:s.heat,charter:s.charter,receipt:false,water:s.water?.installed,patron:ceremony?[1,3,6][crew]:s.phase==='audit'?2:v?v.person:0,item:s.phase==='audit'?10:showLot?v.lot.item:null,mood:ceremony?'happy':s.phase==='audit'?'angry':v?v.mood:'idle',day:s.day,stock:s.stock.map(l=>l.item),scan:ts<scanUntil,scene:ceremony?'award':['night','failed','ready'].includes(s.phase)?'closed':s.phase==='bell'?'empty':'shop'});
 CounterStage.draw($('#shopArt').getContext('2d'),{run:s,now:ts,age:Math.max(0,(ts-stageAt)/1000),reduced:matchMedia('(prefers-reduced-motion: reduce)').matches,trayReady:!!v&&trayReady(v)});
 if(ts>pulseUntil)$('#delta').classList.remove('show');
}
function paintPlant(ts){const c=$('#plantFace');if(!c)return;const w=CounterWater.status(run());
 WaterArt.machine(c,{time:ts/1000,fill:['raw','sampled','filtered'].includes(w.phase)?.83:0,quality:w.quality===2?1:w.clarity/100||.2,stage:ts<plantUntil&&w.phase==='filtered'?'filtering':({raw:'testing',sampled:'testing',filtered:'ready',bottled:'ready'})[w.phase]||'empty'});}
function animate(ts){if(!document.hidden&&ts-lastDraw>=65){lastDraw=ts;draw(ts);if(modal.open&&modalKind==='water')paintPlant(ts);}requestAnimationFrame(animate);}
CounterSound.mute(profile.mute);
sdk=practice?null:bridge({read:()=>profile,write:(d,rem)=>{merge(d,rem);persist();},changed:e=>{
 if(e.type==='reward'){profile.revision=Math.max(Date.now(),profile.revision+1);persist();delta(e.kind==='like'?'GOLD PLATE':'VIOLET INK');}
 if(e.type==='support'||e.type==='reward'||e.type==='cloud'){render();}if(e.type==='connected')hostSize();
}});
document.addEventListener('pointerdown',hostSize,{passive:true});window.addEventListener('resize',hostSize);
window.addEventListener('pagehide',e=>{if(!e.persisted)sdk?.stop();});
hostSize();render();requestAnimationFrame(animate);





