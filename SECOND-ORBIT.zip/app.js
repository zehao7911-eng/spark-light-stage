'use strict';
const $=s=>document.querySelector(s), esc=s=>String(s).replace(/[&<>"']/g,k=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[k]));
const seed=()=>crypto.getRandomValues(new Uint32Array(1))[0];
const localKey='second-orbit.exchange.v1';
let profile={v:1,revision:0,run:makeRun(seed()),rewards:{},mute:false,best:0}, sdk,session=false,modalKind='',pulseUntil=0,lastDraw=-1,scanUntil=0,visitorKey='',approachAt=0;
const phases=['ready','trade','receipt','audit','night','failed','owned'];
function isLot(l){return l&&Number.isInteger(l.item)&&!!GOODS[l.item]&&Number.isInteger(l.grade)&&!!GRADES[l.grade]&&Number.isFinite(l.id)&&Number.isFinite(l.cost);}
function validRun(s){
 if(!s||!phases.includes(s.phase)||!['seed','cash','day','turn','limit','paid','scans','nonce','heat','deals','totalSales'].every(k=>Number.isFinite(s[k]))||s.day<1||!Array.isArray(s.stock)||!s.stock.every(isLot)||!Array.isArray(s.reps)||s.reps.length!==3||!s.reps.every(Number.isFinite)||!['gear','ledger','served','serials'].every(k=>Array.isArray(s[k])))return false;
 if(!Number.isInteger(s.day)||s.stock.length>20||(s.kit&&!KITS.some(q=>q.id===s.kit))||s.ledger.some(e=>!e||typeof e.text!=='string'||!Number.isInteger(e.day)||!Number.isFinite(e.amount)))return false;
 if(['trade','receipt'].includes(s.phase)&&(!s.patron||!isLot(s.patron.lot)||!PEOPLE[s.patron.person]||!Number.isFinite(s.patron.offer)||!Number.isFinite(s.patron.ask)))return false;
 if(s.phase==='trade'&&(!Number.isInteger(s.patron.patience)||s.patron.patience<1||s.patron.patience>3))return false;
 if(s.phase==='audit'&&(!s.audit||!Number.isFinite(s.audit.levy)))return false;
 return !['night','failed','owned'].includes(s.phase)||!!s.recap;
}
function persist(){try{localStorage.setItem(localKey,JSON.stringify(profile));}catch{}}
function merge(data,remote=false){
 if(!data||typeof data!=='object')return;
 for(const k of ['like','comment'])if(data.rewards?.[k]===true)profile.rewards[k]=true;
 if(Number.isFinite(data.best)&&data.best>0)profile.best=profile.best?Math.min(profile.best,data.best):data.best;
 if(!remote&&typeof data.mute==='boolean')profile.mute=data.mute;
 if(Number.isFinite(data.revision)&&data.revision>profile.revision&&validRun(data.run)){
  if(remote&&session){sdk?.end();session=false;} profile.run=structuredClone(data.run);profile.revision=data.revision;
  if(remote&&$('#modal').open)$('#modal').close();
 }
}
try{merge(JSON.parse(localStorage.getItem(localKey)));}catch{}
const run=()=>profile.run;window.shopState=()=>JSON.parse(JSON.stringify(profile));
function save(){profile.revision=Math.max(Date.now(),profile.revision+1);persist();sdk?.save();}
function hostStart(){if(session)return;session=true;sdk?.prepare();sdk?.start();}
function begin(){hostStart();beginShift(run());CounterSound.play('open');}
function slotMotion(item,buy){if(matchMedia('(prefers-reduced-motion: reduce)').matches)return;
 const tray=$('#trayHit').getBoundingClientRect(),drawer=$('#drawer').getBoundingClientRect();
 const a=[tray.left+tray.width/2,tray.top+tray.height/2],b=[drawer.left+drawer.width*.44,drawer.top+18];
 const from=buy?a:b,to=buy?b:a,c=document.createElement('canvas');c.className='travelling';drawIcon(c,item);document.body.append(c);c.style.left=(from[0]-18)+'px';c.style.top=(from[1]-18)+'px';
 const dx=to[0]-from[0],dy=to[1]-from[1];const animation=c.animate([{transform:'translate(0,0) scale(.8)',opacity:0},{offset:.18,transform:'translate(0,-11px) scale(1.1)',opacity:1},{offset:.85,opacity:1},{transform:'translate('+dx+'px,'+dy+'px) scale(.64)',opacity:0}],{duration:560,easing:'cubic-bezier(.26,.5,.65,1)'});animation.onfinish=()=>c.remove();
}
function delta(text){
 const v=run().patron;if(v&&(text==='SOLD'||text==='PURCHASED'))slotMotion(v.lot.item,!v.buyer);
 const el=$('#delta');el.textContent=text;el.classList.remove('show');void el.offsetWidth;el.classList.add('show');pulseUntil=performance.now()+1200;
}
function action(label,fn,cls='primary',id='primary'){const b=document.createElement('button');b.id=id;b.className=cls;b.textContent=label;b.onclick=()=>{CounterSound.wake();fn();save();render();};return b;}
function actions(...buttons){const d=document.createElement('div');d.className='actions';d.append(...buttons);$('#desk').append(d);}
const goodsIcon=i=>'<canvas class="icon" width="48" height="48" data-icon="'+i+'" aria-hidden="true"></canvas>';
function drawIcon(c,i){if(i===12&&window.WaterArt)WaterArt.icon(c,2);else CounterArt.icon(c,i);}
function icons(root=document){root.querySelectorAll('[data-icon]').forEach(c=>drawIcon(c,+c.dataset.icon));}
function meter(label,val){return '<div><span>'+label+'</span><strong>'+val+'</strong></div>';}
function render(){
 const s=run(),v=s.patron,desk=$('#desk'),cnt=s.stock.length,night=['night','failed','owned'].includes(s.phase);
 $('#time').textContent=s.phase==='ready'?'PORT 09':'SHIFT '+String(s.day).padStart(2,'0');
 $('#sector').textContent=profile.rewards.like?'GOLD TRADER':'DOCK 09';
 $('#cabinet').dataset.phase=s.phase;$('#cabinet').classList.toggle('inked',!!profile.rewards.comment);
 $('#trayHit').hidden=s.phase!=='trade';$('#trayHit').onclick=()=>$('#inspect')?.click();
 $('#meters').innerHTML=meter('Till',money(s.cash))+meter('Rent',money(rentDue(s)))+meter('Heat',s.heat+' / 5');
 $('#stockCount').textContent=cnt;$('#sound').innerHTML='<svg viewBox="0 0 24 24"><path d="M3 9h4l5-4v14l-5-4H3z"/>'+(profile.mute?'<path d="m16 9 6 6m0-6-6 6"/>':'<path d="M16 9q4 3 0 6m3-9q6 6 0 12"/>')+'</svg>';$('#sound').setAttribute('aria-label',profile.mute?'Turn sound on':'Mute sound');
 if(s.phase==='ready'){
  desk.innerHTML='<div class="intro"><span class="kicker">ORBITAL PAWNSHOP</span><h1>SECOND<br>ORBIT</h1><p class="lede">Buy salvage. Read the seals. Name your price. Pay off the lease and this counter is yours.</p></div><div class="panel"><p><strong>'+KITS.find(kit=>kit.id===(s.kit||'salvage')).name+'</strong> · Opening float '+money(s.cash)+'</p></div>';
  actions(action('Open the shutters',begin),action('Kits',()=>showModal('kits'),'secondary','kits'));
 }else if(s.phase==='trade'){
  const l=v.lot,item=GOODS[l.item],p=PEOPLE[v.person],ref=Math.round(item[1]*demand(s,l.item));
  let note=v.response||(v.buyer?'“Looking for '+['machine parts','survey gear','freight goods'][v.wants]+'. What can you show me?”':(s.day===1&&s.turn===1?'“A relay coil from my last run. Check it if you like.”':'“'+p[3]+'”'));
  desk.innerHTML='<div class="dialogue"><b>'+p[0]+'</b><small>'+p[1]+' · '+s.turn+'/'+s.limit+'</small><p>'+esc(note)+'</p></div><div class="lot">'+goodsIcon(l.item)+'<div><span class="kicker">'+(v.buyer?'BUYER REQUEST':'INCOMING LOT')+'</span><h3>'+item[0]+'</h3><div class="tiny">'+(v.buyer?'Your cost '+money(l.cost):'Board price ~'+money(ref))+'</div></div><button id="inspect">'+(v.buyer?'Swap lot':v.scanned?'Findings':'Scan · '+s.scans)+'</button></div><div class="pricehead"><label for="price">'+(v.buyer?'YOUR SALE PRICE':'YOUR BUY OFFER')+'</label><b id="value"></b></div><div class="dial"><button id="minus" aria-label="Lower offer">−</button><input id="price" type="range" aria-label="Offer in credits"><button id="plus" aria-label="Raise offer">+</button></div>';
  const range=$('#price'),min=v.buyer?v.ask:Math.max(1,Math.floor(v.ask*.35)),max=v.buyer?Math.max(v.ask+8,Math.round(v.opening*1.65)):v.ask;
  range.min=min;range.max=max;range.step=1;range.value=v.offer;const upd=()=>{v.offer=+range.value;$('#value').textContent=money(v.offer);const b=$('#primary');if(b){b.textContent=(v.buyer?'Sell':'Buy')+' for '+money(v.offer);b.disabled=!v.buyer&&v.offer>s.cash;}};
  range.oninput=upd;range.onchange=()=>{CounterSound.play('tap');save();};$('#minus').onclick=()=>{range.value=+range.value-1;upd();save();};$('#plus').onclick=()=>{range.value=+range.value+1;upd();save();};
  $('#inspect').disabled=!v.buyer&&!v.scanned&&s.scans<1;
  $('#inspect').onclick=()=>{CounterSound.wake();if(v.buyer){showModal('swap');return;}hostStart();const fresh=inspectLot(s);if(fresh){CounterSound.play('scan');scanUntil=performance.now()+1700;save();render();}showModal('scan');};
  const quote=action('Counter',()=>{hostStart();v.offer=v.buyer?Math.max(v.ask,Math.round(v.ask*1.15)):Math.max(1,Math.min(s.cash,Math.round(v.ask*.83)));if(v.offer>0&&(!v.buyer&&s.cash===0))return;const result=trade(s);CounterSound.play(result||'tap');if(s.phase==='receipt')delta(s.patron.ticket);},'secondary','haggle');
  actions(action('Make offer',()=>{hostStart();const result=trade(s);if(result){CounterSound.play(result);if(s.phase==='receipt')delta(s.patron.ticket);}}),quote,action('Pass',()=>{hostStart();pass(s);CounterSound.play('pass');},'secondary','pass'));upd();
 }else if(s.phase==='receipt'){
  const l=v.lot,amt=v.tender;desk.innerHTML='<span class="kicker">COUNTER TICKET '+String(s.day*100+s.turn)+'</span><div class="receipt"><h2 class="resultTitle">'+esc(v.ticket)+'</h2><b>'+((amt>0?'+':'')+money(amt))+'</b></div><div class="lot">'+goodsIcon(l.item)+'<div><h3>'+GOODS[l.item][0]+'</h3><span class="tiny">'+PEOPLE[v.person][0]+' · '+CREWS[PEOPLE[v.person][2]]+'</span></div></div><p class="body break">'+esc(v.response)+'</p>';
  actions(action(s.turn>=s.limit?'Close the shutters':'Next customer',()=>{hostStart();if(s.turn>=s.limit){requestClose(s);if(s.phase!=='audit'){sdk?.end();session=false;}CounterSound.play(s.phase==='audit'?'alert':s.phase==='failed'?'lose':'stamp');}else{nextGuest(s);CounterSound.play('arrival');}}));
 }else if(s.phase==='audit'){
  const wanted=s.stock.find(l=>l.id===s.audit.lotId);
  desk.innerHTML='<span class="kicker">STATION CUSTOMS · INSPECTION</span><h2 class="resultTitle loss">Serial alert.</h2><p class="body">A customs officer stops the shutters. The filing shows '+s.heat+' heat marks.</p><div class="panel"><p><strong>Ruling · '+money(s.audit.levy)+'</strong></p><p>'+(wanted?'Customs will also seize the '+GOODS[wanted.item][0]+'. Turn it in yourself to reduce the fee to ₵3.':'The goods have left your shop. A handling fine is due.')+'</p></div>';
  const resolve=kind=>{hostStart();if(answerAudit(s,kind)){sdk?.end();session=false;CounterSound.play(s.phase==='failed'?'lose':'stamp');}};
  const buttons=[action('Accept ruling',()=>resolve(false))];if(wanted)buttons.push(action('Turn it in',()=>resolve(true),'secondary','surrender'));actions(...buttons);
 }else if(night){
  const r=s.recap;
  if(s.phase==='failed'){
   desk.innerHTML='<span class="kicker">LEASE TERMINATED</span><h2 class="resultTitle loss">Shutters down.</h2><p class="body">Even after clearing your shelf, the till came up '+money(-s.cash)+' short on rent. You completed '+s.deals+' deals.</p>';
   actions(action('Start a new lease',()=>{profile.run=makeRun(seed());begin();}));
  }else if(s.phase==='owned'){
   desk.innerHTML='<span class="kicker">DEED ISSUED · DOCK 09</span><h2 class="resultTitle">Yours, in writing.</h2><p class="body">The landlord hands over the brass keys. After '+s.day+' shifts and '+s.deals+' deals, Second Orbit belongs to you.</p>';
   actions(action('Trade after hours',()=>{s.extended=true;s.day++;begin();}));
  }else{
   desk.innerHTML='<span class="kicker">SHIFT '+String(s.day).padStart(2,'0')+' · CASHOUT</span><h2 class="resultTitle">Shutters down.</h2><div class="daybill"><span>Sales / purchases</span><b>+'+money(s.earned)+' / −'+money(s.spent)+'</b><span>Rent'+(s.extended?' rebate':'')+'</span><b>'+money(r.rent)+'</b>'+(r.fine?'<span>Customs'+(r.seized?' · seized '+esc(r.seized):'')+'</span><b>−'+money(r.fine)+'</b>':'')+(r.liquidation?'<span>Emergency stock sale</span><b>+'+money(r.liquidation)+'</b>':'')+'</div><div class="panel"><p><strong>'+(s.paid>=DEED?'Shop owned':'Deed '+money(s.paid)+' / '+money(DEED))+'</strong></p><div class="bookbar"><i style="width:'+Math.min(100,s.paid/DEED*100)+'%"></i></div><p>'+esc(EVENTS[s.day%6][1])+' Tomorrow.</p></div>';
   const next=action('Open shift '+(s.day+1),()=>{s.day++;begin();}),bench=action('Workbench',()=>showModal('bench'),'secondary','bench');actions(next,bench);
   if(s.paid<DEED){const due=Math.min(DEED-s.paid,60),b=action('Pay '+money(due)+' toward deed',()=>{s.cash-=due;s.paid+=due;logTrade(s,'Deed installment',-due);CounterSound.play('upgrade');if(s.paid===DEED){s.phase='owned';profile.best=profile.best?Math.min(profile.best,s.day):s.day;}},'secondary','deposit');b.disabled=s.cash<due;actions(b);}
  }
 }
 if(s.phase==='trade'){
  const order=CounterContracts.status(s),line=document.createElement('div');line.className='terms';
  line.innerHTML='<span>Patience <b>'+('▮'.repeat(v.patience))+('▯'.repeat(Math.max(0,3-v.patience)))+'</b></span><span>'+esc(EVENTS[(s.day-1)%6][0])+'</span>';desk.prepend(line);
  const tip=document.createElement('button');tip.className='orderline';tip.textContent=(s.turn===1&&s.day===1)?'↳ Counter to bid below the asking price.':order?'✉ '+order.title+' · '+order.progress+'/'+order.goal:'Station notices';tip.onclick=()=>showModal('ledger');desk.append(tip);
 }
 if(s.phase==='night'&&s.recap.bonus?.amount){const badge=document.createElement('p');badge.className='bonus';badge.textContent='✓ '+s.recap.bonus.title+' paid '+money(s.recap.bonus.amount);desk.querySelector('.daybill').after(badge);}
 icons(desk);renderDrawer();draw(performance.now());if($('#modal').open&&modalKind)modalContents();
}
function renderDrawer(){
 const d=$('#drawer'),s=run();d.replaceChildren();
 for(let i=0;i<Math.max(5,Math.min(s.stock.length,6));i++){
  const l=s.stock[i],b=document.createElement(l?'button':'div');b.className='bin';
  if(l){b.innerHTML=goodsIcon(l.item)+'<span>'+money(l.cost)+'</span>';b.title=GOODS[l.item][0];b.setAttribute('aria-label','View '+b.title);
   const buyer=s.phase==='trade'&&s.patron.buyer;
   const choose=()=>{if(s.patron.lot.id!==l.id){hostStart();assignSale(s,s.patron,l);CounterSound.play('tap');save();render();}};
   if(buyer)handleLift(b,l,choose);
   b.onclick=()=>{if(b.dataset.dragged==='true')return;if(buyer)choose();else showModal('shelf');};}
  d.append(b);
 }icons(d);
}
function handleLift(b,l,choose){
 let down=null,ghost=null;b.style.touchAction='none';b.title='Show '+GOODS[l.item][0]+' to this buyer';
 b.onpointerdown=e=>{down=[e.clientX,e.clientY];b.dataset.dragged='';b.setPointerCapture(e.pointerId);};
 b.onpointermove=e=>{if(!down)return;if(!ghost&&Math.hypot(e.clientX-down[0],e.clientY-down[1])<7)return;
   if(!ghost){ghost=document.createElement('canvas');ghost.className='lifted';drawIcon(ghost,l.item);document.body.append(ghost);$('#world').classList.add('dropzone');}
   ghost.style.left=(e.clientX-24)+'px';ghost.style.top=(e.clientY-38)+'px';};
 function end(e,drop){if(ghost){ghost.remove();ghost=null;b.dataset.dragged='true';$('#world').classList.remove('dropzone');
   const r=$('#world').getBoundingClientRect(),lot=$('.lot')?.getBoundingClientRect();const inside=q=>q&&e.clientX>=q.left&&e.clientX<=q.right&&e.clientY>=q.top&&e.clientY<=q.bottom;
   if(drop&&(inside(r)||inside(lot))){choose();if(e.pointerType==='touch')drawerReleaseUntil=performance.now()+1800;}}down=null;}
 b.onpointerup=e=>end(e,true);b.onpointercancel=e=>end(e,false);b.onlostpointercapture=e=>end(e,false);
}


const modal=$('#modal');
function showModal(kind){modalKind=kind;modalContents();if(!modal.open)modal.showModal();$('#dismiss').focus();}
function tile(i,h,sub,button=''){return '<div class="row">'+(i==null?'':goodsIcon(i))+'<div><b>'+h+'</b><small>'+sub+'</small></div>'+button+'</div>';}
function modalContents(){
 const s=run(),v=s.patron,body=$('#modalBody'),sup=sdk?.support()||{},k=modalKind;let text='';
 $('#modalTitle').textContent=({scan:'Assay reader',shelf:'Shelf stock',swap:'Show another lot',ledger:'Station ledger',bench:'Night workbench',water:'Condensate plant',kits:'Opening licenses',restart:'A new lease',guide:'Salvage field guide',charter:'Trade charters'})[k]||'Station';
 if(k==='scan'&&v&&s.phase==='trade'){
  const l=v.lot,item=GOODS[l.item],mark=SEALS[l.item];const actual=l.fake?mark.slice(0,-1)+(Number(mark.at(-1))+2)%10:mark;
  const read=l.sealRead===true;
  text=tile(l.item,item[0],GRADES[l.grade][0]+' condition')+'<canvas class="loupe" tabindex="0" aria-label="Inspection lens. Touch the marked serial plate, use arrow keys, or press Enter to focus the plate."></canvas><p id="lensHint" class="mono">'+(read?'Serial resolved.':'Move the glass onto the little brass plate.')+'</p><div class="sealpair"><div><span class="tiny">Factory register</span><b>'+mark+'</b></div><div><span class="tiny">Stamped serial</span><b id="readCode">'+(read?actual:'····')+'</b></div></div><div class="panel" id="scanReport" '+(read?'':'hidden')+'><p><strong>'+(l.fake?'Replica · seal mismatch':'Authentic · seal matched')+'</strong></p><p>Estimated resale '+money(lotValue(l,demand(s,l.item)))+' today. '+(l.tag?'Tagged by station customs. Buying adds heat.':'Serial cleared for resale.')+'</p></div>';
  if(l.tag)text+='<button data-act="report" '+(read?'':'hidden')+'>Report tagged goods · +₵5</button>'; }else if(k==='shelf'||k==='swap'){
  if(k==='swap'&&v)text='<p class="mono">The buyer pays more for '+['machine parts','survey gear','freight goods'][v.wants]+'.</p>';
  text+=s.stock.length?s.stock.map(l=>tile(l.item,GOODS[l.item][0],GRADES[l.grade][0]+' · cost '+money(l.cost)+(l.tag?' · tagged':'')+(l.fake?' · replica':''),k==='swap'?'<button data-lot="'+l.id+'">Show</button>':'<span class="tiny">'+money(lotValue(l,demand(s,l.item)))+'</span>')).join(''):'<p class="mono">Empty shelf. Buy salvage from the next seller.</p>';
 }else if(k==='charter'){
  const effects=['Rent costs six fewer credits every shift.','Two extra assay charges and a rare opening lot each shift.','Matched-class buyers will bid up to 15% more.'];
  text='<p class="mono">Sign one permanent charter for this lease. A crew needs four standing to sponsor you.</p>'+CREWS.map((name,i)=>tile([1,4,7][i],name,effects[i],'<button data-crew="'+i+'" '+(s.reps[i]<4||s.charter!=null?'disabled':'')+'>'+(s.charter===i?'Signed':s.reps[i]>=4?'Sign':s.reps[i]+'/4')+'</button>')).join('');
 }else if(k==='guide'){
  text='<p class="mono">'+s.serials.length+' / '+GOODS.length+' entries in your trading log. Board prices move each shift.</p>'+GOODS.map((g,i)=>tile(i,g[0],g[3]+' '+g[4],'<span class="tiny">'+(s.serials.includes(i)?'Logged':'Unseen')+'</span>')).join('');
 }else if(k==='kits'){
  text=KITS.map(kit=>tile(kit.item,kit.name,kit.desc,'<button data-kit="'+kit.id+'">'+((s.kit||'salvage')===kit.id?'Selected':'Select')+'</button>')).join('');
 }else if(k==='restart'){
  text='<p class="mono">Start another shop? This replaces the current lease. Your fastest deed and GameWave cosmetics stay in the ledger.</p><button id="newLease">Start a fresh lease</button>';
 }else if(k==='water'){
  const w=CounterWater.status(s),options=({uninstalled:[['install','Install · ₵16',16]],idle:[['source','Order tank · ₵7',7]],raw:[['sample','Draw sample',0]],sampled:[['gravity','Gravity bed · ₵3',3],['polish','Polish · ₵5',5]],filtered:[['bottle','Seal and stock',0]]})[w.phase]||[];
  const desc=({locked:'License opens on shift 2.',uninstalled:'Test dock water, choose a filter, then stock a sealed six-pack for sale.',idle:'Intake empty. One batch can ship per shift.',raw:'Tank connected. Draw a vial to check for grit or dissolved pigment.',sampled:w.sampleText,filtered:w.quality===2?'Clear sample. Ready to bottle at premium grade.':'Tint remains. A utility-grade batch is ready to bottle.',bottled:'Shipment stocked. Next delivery arrives tomorrow.'})[w.phase];
  text='<canvas id="plantFace" aria-label="Water filtration machinery"></canvas><p class="mono">'+desc+'</p><div class="daybill"><span>Available cash</span><b>'+money(s.cash)+'</b>'+(w.contaminant?'<span>Assay</span><b>'+esc(w.contaminant)+'</b>':'')+'</div>'+
    options.map(([act,label,price])=>'<button class="plantAction" data-plant="'+act+'" '+(s.cash<price||act==='bottle'&&s.stock.length>=7?'disabled':'')+'>'+label+'</button>').join('')+(w.phase==='filtered'&&s.stock.length>=7?'<p class="danger">Sell a lot to make room on the shelf.</p>':'');
 }else if(k==='bench'){
  const worked=s.recap?.worked,broken=s.stock.find(l=>l.grade<2&&!l.fake),cheap=s.stock.find(l=>l.item===0),coil=s.stock.find(l=>l.item===1);
  const button=(act,label,disabled)=>'<button data-act="'+act+'" '+(disabled?'disabled':'')+'>'+label+'</button>';
  text='<p class="mono">One bench job each night. Equipment purchases are permanent for this lease.</p>'+
   tile(1,'Restore a lot',broken?GOODS[broken.item][0]+' · raise condition one grade':'No damaged authentic stock',button('repair','₵4',worked||!broken||s.cash<4))+
   tile(8,'Build a micro drone','Consumes one Pulse Cell and one Relay Coil',button('craft','Build',worked||!cheap||!coil))+
   tile(2,'Assay reader','Next shifts get five scans instead of three.',button('reader',s.gear.includes('reader')?'Fitted':'₵32',s.cash<32||s.gear.includes('reader')))+
   tile(0,'Order a parts crate','One serviceable Pulse Cell and Relay Coil.',button('supply','₵44',worked||s.cash<44||s.stock.length>5));
 }else if(k==='ledger'){
  const ev=EVENTS[(s.day-1)%6],news=CounterContracts.headline(s),order=CounterContracts.status(s);
  text='<article class="bulletin"><small>THE RING GAZETTE</small><h3>'+news.title+'</h3><p>'+news.body+'</p></article>'+(order?'<div class="panel"><p><strong>'+order.title+' · '+order.progress+'/'+order.goal+'</strong></p><p>'+order.brief+'</p></div>':'')+'<div class="panel"><p><strong>'+ev[0]+'</strong></p><p>'+ev[1]+'</p></div><p class="mono">Bid below the seller’s ask. Quote above the buyer’s bid. Three rejected offers cost the customer. Two heat marks trigger customs at closing.</p>'+
   '<div class="daybill"><span>Shop deed</span><b>'+money(s.paid)+' / '+money(DEED)+'</b>'+CREWS.map((c,i)=>'<span>'+c+'</span><b>'+s.reps[i]+' / 9</b>').join('')+'</div>'+
   (profile.best?'<p class="accent">Fastest deed · '+profile.best+' shifts</p>':'')+
   (s.ledger.length?s.ledger.slice(0,8).map(e=>tile(null,esc(e.text),'Shift '+e.day,'<span class="tiny">'+(e.amount>0?'+':'')+money(e.amount)+'</span>')).join(''):'<p class="tiny">Your trades will appear here.</p>')+
   ((sup.like||sup.comment||profile.rewards.like||profile.rewards.comment)?'<div class="panel"><p>'+[profile.rewards.like?'Gold Trader plate fitted':sup.like?'Like in GameWave to fit a Gold Trader plate.':'',profile.rewards.comment?'Violet receipt ink fitted':sup.comment?'Comment in GameWave to unlock violet receipt ink.':''].filter(Boolean).join(' ')+'</p></div>':'');
 }
 body.innerHTML=text;icons(body);if(k==='scan'&&body.querySelector('.loupe')){const l=v.lot;AssayGlass.install(body.querySelector('.loupe'),l,()=>{CounterSound.play('stamp');save();const mark=SEALS[l.item];document.getElementById("readCode").textContent=l.fake?mark.slice(0,-1)+(Number(mark.at(-1))+2)%10:mark;document.getElementById("scanReport").hidden=false;document.getElementById("lensHint").textContent='Serial resolved.';const rb=body.querySelector('[data-act=report]');if(rb)rb.hidden=false;});}body.querySelectorAll('[data-lot]').forEach(b=>b.onclick=()=>{
  if(s.phase!=='trade'||!v?.buyer)return;const l=s.stock.find(q=>q.id===Number(b.dataset.lot));if(!l)return;hostStart();assignSale(s,v,l);modal.close();CounterSound.play('tap');save();render();});
 if(k==='shelf'||k==='ledger'){const guide=document.createElement('button');guide.textContent='Field guide · '+s.serials.length+'/'+GOODS.length;guide.onclick=()=>showModal('guide');body.append(guide);}
 if(k==='kits')body.querySelectorAll('[data-kit]').forEach(b=>b.onclick=()=>{openingKit(s,b.dataset.kit);save();modal.close();render();});
 if(k==='ledger'){
  if(s.day>=2){const charter=document.createElement('button');charter.textContent=s.charter!=null?'Charter · '+CREWS[s.charter]:'Trade charters';charter.onclick=()=>showModal('charter');body.prepend(charter);}
  const reset=document.createElement('button');reset.textContent='Apply for a new lease';reset.onclick=()=>showModal('restart');body.append(reset);
 }
 if(k==='charter')body.querySelectorAll('[data-crew]').forEach(b=>b.onclick=()=>{const i=Number(b.dataset.crew);if(s.charter!=null||s.day<2||s.reps[i]<4)return;s.charter=i;logTrade(s,CREWS[i]+' charter');save();CounterSound.play('stamp');render();});
 if(k==='restart')$('#newLease').onclick=()=>{if(session){sdk?.end();session=false;}profile.run=makeRun(seed());save();modal.close();render();};
 if((k==='shelf'||k==='bench')&&CounterWater.status(s).available){let b=document.createElement('button');b.textContent='Water plant';b.id='water';b.onclick=()=>showModal('water');body.prepend(b);}
 if(k==='water'){paintPlant(performance.now());body.querySelectorAll('[data-plant]').forEach(b=>b.onclick=()=>{const a=b.dataset.plant;if(s.phase==='trade'||s.phase==='receipt')hostStart();
   const result=(a==='gravity'||a==='polish')?CounterWater.filter(s,a):CounterWater[a](s);
   if(result.ok){CounterSound.play(a==='sample'?'scan':a==='bottle'?'stamp':'upgrade');save();}render();
  });}
 body.querySelectorAll('[data-act]').forEach(b=>b.onclick=()=>{
  const act=b.dataset.act;
  if(act==='report'&&s.phase==='trade'&&v&&!v.buyer&&v.scanned&&v.lot.sealRead&&v.lot.tag){hostStart();pass(s,true);modal.close();CounterSound.play('stamp');}
  else if(s.phase==='night'&&k==='bench'){
   const r=s.recap;
   if(act==='reader'&&s.cash>=32&&!s.gear.includes('reader')){s.cash-=32;s.gear.push('reader');logTrade(s,'Assay reader fitted',-32);}
   else if(act==='repair'&&!r.worked&&s.cash>=4){const l=s.stock.find(q=>q.grade<2&&!q.fake);if(!l)return;s.cash-=4;l.cost+=4;l.grade++;r.worked=true;logTrade(s,'Restored '+GOODS[l.item][0],-4);}
   else if(act==='craft'&&!r.worked){const a=s.stock.find(l=>l.item===0),b=s.stock.find(l=>l.item===1);if(!a||!b)return;s.stock=s.stock.filter(l=>l!==a&&l!==b);s.stock.push({id:++s.nonce,item:8,cost:a.cost+b.cost,grade:2,fake:false,tag:a.tag||b.tag});r.worked=true;logTrade(s,'Built a micro drone');}
   else if(act==='supply'&&!r.worked&&s.cash>=44&&s.stock.length<=5){s.cash-=44;for(const item of [0,1])s.stock.push({id:++s.nonce,item,cost:22,grade:1,fake:false,tag:false});r.worked=true;logTrade(s,'Parts crate',-44);}
   else return;CounterSound.play('upgrade');
  }else return;
  save();render();
 });
}
// A lens swipe can suppress the next synthesized mouse click on some touch
// browsers. Complete a deliberate tap on release and consume that tap's
// compatibility click even if closing the dialog exposes another button.
let lastModalTouch=null,modalPress=null,drawerReleaseUntil=0;
document.addEventListener('pointerdown',e=>{
 lastModalTouch=null;modalPress=null;
 if(e.pointerType!=='touch'||!e.isPrimary)return;
 const drawerSale=!modal.open&&run().phase==='trade'&&run().patron?.buyer&&performance.now()<drawerReleaseUntil;
 const button=modal.open?e.target.closest?.('#dismiss,[data-act="report"]'):drawerSale?e.target.closest?.('#primary'):null;
 if(button&&!button.disabled)modalPress={button,id:e.pointerId,x:e.clientX,y:e.clientY,dialog:modal.open};
},true);
document.addEventListener('pointercancel',()=>{modalPress=null;},true);
document.addEventListener('pointermove',e=>{
 if(modalPress?.id===e.pointerId&&Math.hypot(e.clientX-modalPress.x,e.clientY-modalPress.y)>8)modalPress=null;
},true);
document.addEventListener('pointerup',e=>{
 const p=modalPress;if(!p||p.id!==e.pointerId)return;modalPress=null;
 if(p.dialog!==modal.open||!p.button.isConnected||!p.button.contains(document.elementFromPoint(e.clientX,e.clientY)))return;
 if(!p.dialog)drawerReleaseUntil=0;
 lastModalTouch={x:e.clientX,y:e.clientY,time:performance.now()};
 e.preventDefault();p.button.click();
},true);
document.addEventListener('click',e=>{
 const p=lastModalTouch;
 if(p&&e.detail>0&&performance.now()-p.time<750&&Math.hypot(e.clientX-p.x,e.clientY-p.y)<20){
  e.preventDefault();e.stopImmediatePropagation();lastModalTouch=null;
 }
},true);
$('#dismiss').onclick=()=>modal.close();modal.addEventListener('close',()=>{modalKind='';});
$('#shelf').onclick=()=>showModal('shelf');$('#ledger').onclick=()=>showModal('ledger');
$('#sound').onclick=()=>{profile.mute=!profile.mute;CounterSound.mute(profile.mute);if(!profile.mute){CounterSound.wake();CounterSound.play('tap');}save();render();};
function hostSize(){const v=sdk?.viewport();for(const [key,val] of [['--hostw',v?.width],['--hosth',v?.height]])if(val)document.documentElement.style.setProperty(key,val+'px');else document.documentElement.style.removeProperty(key);}
function draw(ts){
 const s=run(),v=s.patron;const t=matchMedia('(prefers-reduced-motion: reduce)').matches?0:ts/1000;
 const id=(v?s.day+'/'+s.turn:'')+(!v?s.phase:'');if(id!==visitorKey){visitorKey=id;approachAt=ts;}
 const arrive=v&&t?Math.min(1,(ts-approachAt)/420):1;
 CounterArt.draw($('#shopArt'),{time:t,approach:arrive,patron:s.phase==='audit'?2:v?v.person:0,item:s.phase==='audit'?10:v?v.lot.item:1,mood:s.phase==='audit'?'angry':v?v.mood:'idle',day:s.day,stock:s.stock.map(l=>l.item),scan:ts<scanUntil,scene:['night','owned','failed'].includes(s.phase)?'closed':'shop'});
 if(ts>pulseUntil)$('#delta').classList.remove('show');
}
function paintPlant(ts){const c=$('#plantFace');if(!c)return;const w=CounterWater.status(run());
 WaterArt.machine(c,{time:ts/1000,fill:['raw','sampled','filtered'].includes(w.phase)?.83:0,quality:w.quality===2?1:w.clarity/100||.2,stage:({raw:'testing',sampled:'testing',filtered:'ready',bottled:'ready'})[w.phase]||'empty'});}
function animate(ts){if(!document.hidden&&ts-lastDraw>=65){lastDraw=ts;draw(ts);if(modal.open&&modalKind==='water')paintPlant(ts);}requestAnimationFrame(animate);}
CounterSound.mute(profile.mute);
sdk=bridge({read:()=>profile,write:(d,rem)=>{merge(d,rem);persist();},changed:e=>{
 if(e.type==='reward'){profile.revision=Math.max(Date.now(),profile.revision+1);persist();delta(e.kind==='like'?'GOLD PLATE':'VIOLET INK');}
 if(e.type==='support'||e.type==='reward'||e.type==='cloud'){render();}if(e.type==='connected')hostSize();
}});
document.addEventListener('pointerdown',hostSize,{passive:true});window.addEventListener('resize',hostSize);
window.addEventListener('pagehide',e=>{if(!e.persisted)sdk?.stop();});
hostSize();render();requestAnimationFrame(animate);





