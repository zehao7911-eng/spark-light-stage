'use strict';

globalThis.CounterWindow = (() => {
  // The window holds a reference to one physical lot. The lot still occupies
  // its normal stock slot and can be traded, seized, restored or repacked.
  function featured(s){
    const id=s?.displayLotId;
    if(s?.day<2||!Number.isSafeInteger(id)||id<1||!Array.isArray(s.stock))return null;
    return s.stock.find(l=>l.id===id)||null;
  }
  function pin(s,lotId){
    if(!s||s.day<2||!Array.isArray(s.stock)||s.phase==='failed')return false;
    if(lotId===null){delete s.displayLotId;return true;}
    if(!Number.isSafeInteger(lotId)||lotId<1)return false;
    const matches=s.stock.filter(l=>l.id===lotId);
    if(matches.length!==1)return false;
    s.displayLotId=lotId;return true;
  }
  function preferred(s,v){
    // The second scheduled visitor is a natural buying slot whenever stock
    // exists. Other visitors and existing negotiations keep their own orders.
    if(!v?.buyer||v.lessonCoil||s?.turn!==2)return null;
    return featured(s);
  }
  function recordSale(s,soldIds){
    if(!s||!Array.isArray(soldIds)||!Number.isSafeInteger(s.displayLotId))return false;
    if(!soldIds.includes(s.displayLotId))return false;
    delete s.displayLotId;return true;
  }
  return Object.freeze({featured,pin,preferred,recordSale});
})();
