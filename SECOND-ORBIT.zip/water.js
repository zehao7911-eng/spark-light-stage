'use strict';

globalThis.CounterWater = (() => {
  const costs = {installCost:16, sourceCost:7, gravityCost:3, polishCost:5};
  const samples = [
    {contaminant:'Hull grit',clarity:32,color:'#bd986b',recommended:'gravity',
      text:'Heavy bronze grains settle at the bottom. Use the gravity bed.'},
    {contaminant:'Halo pigment',clarity:68,color:'#bb82bc',recommended:'polish',
      text:'A violet film follows the light. Use the polishing cartridge.'},
    {contaminant:'Dock silt',clarity:44,color:'#97a572',recommended:'gravity',
      text:'Soft green flecks sink when the vial stops spinning. Use the gravity bed.'},
    {contaminant:'Comet tint',clarity:74,color:'#e0ac77',recommended:'polish',
      text:'Amber rings stay suspended in the sample. Use the polishing cartridge.'}
  ];
  const unavailable=message=>({ok:false,message});
  const success=(message,extra={})=>({ok:true,message,...extra});
  const available=s=>Number.isInteger(s?.day)&&(s.day>=2||s.kit==='water')&&!['ready','failed','owned'].includes(s.phase);

  function status(s){
    const w=s?.water, batch=w?.batch, example=samples[batch?.kind];
    const installed=w?.installed===true, bottledToday=w?.bottledDay===s?.day && !!s;
    const phase=!available(s)?'locked':!installed?'uninstalled':batch?.phase||(bottledToday?'bottled':'idle');
    const revealed=!!example&&['sampled','filtered'].includes(phase), filtered=phase==='filtered';
    return {...costs,available:available(s),installed,phase,bottledToday,
      clarity:example?(filtered?(batch.grade===2?98:81):example.clarity):0,
      color:example?(filtered?(batch.grade===2?'#92e5d7':'#a7c9b4'):example.color):'#536170',
      contaminant:revealed?example.contaminant:null, sampleText:revealed?example.text:'',
      recommended:revealed?example.recommended:null, filter:batch?.filter||null,
      quality:filtered?batch.grade:null, bottles:w?.bottles||0};
  }

  function spend(s,price,description){
    s.cash-=price;s.spent+=price;logTrade(s,description,-price);
  }

  function install(s){
    if(status(s).phase!=='uninstalled')return unavailable('The bench cannot be installed now.');
    if(s.cash<costs.installCost)return unavailable('The till needs 16 credits.');
    spend(s,costs.installCost,'Condensate bench');
    s.water={installed:true,bottles:0,bottledDay:0,batch:null};
    return success('Condensate bench online.');
  }

  function source(s){
    if(status(s).phase!=='idle')return unavailable('The next tank is not available yet.');
    if(s.cash<costs.sourceCost)return unavailable('Tank delivery costs 7 credits.');
    spend(s,costs.sourceCost,'Dock condensate tank');
    const sequence=((s.seed>>>0)^Math.imul(s.day,2654435761)^Math.imul(s.water.bottles,2246822519))>>>0;
    const kind=((sequence^(sequence>>>16))>>>0)%samples.length;
    s.water.batch={day:s.day,kind,phase:'raw',filter:null,grade:null,cost:costs.sourceCost};
    return success('Tank delivered. Draw a sample.');
  }

  function sample(s){
    if(status(s).phase!=='raw')return unavailable('There is no fresh sample to draw.');
    const batch=s.water.batch;batch.phase='sampled';
    return success(samples[batch.kind].text);
  }

  function filter(s,mode){
    if(status(s).phase!=='sampled')return unavailable('Read the sample first.');
    if(!['gravity','polish'].includes(mode))return unavailable('Select a treatment.');
    const price=mode==='gravity'?costs.gravityCost:costs.polishCost;
    if(s.cash<price)return unavailable('The till cannot cover that filter.');
    const batch=s.water.batch, matched=mode===samples[batch.kind].recommended;
    spend(s,price,mode==='gravity'?'Gravity mesh':'Polishing cartridge');
    batch.cost+=price;batch.filter=mode;batch.grade=matched?2:0;batch.phase='filtered';
    return success(matched?'Clear chromatogram. Premium batch.':'Tint remains. Utility batch.');
  }

  function bottle(s){
    if(status(s).phase!=='filtered')return unavailable('Finish the tank before bottling.');
    if(s.stock.length>=7)return unavailable('Make room on your shelf first.');
    const batch=s.water.batch;
    const lot={id:++s.nonce,item:12,grade:batch.grade,fake:false,tag:false,cost:batch.cost};
    s.stock.push(lot);s.water.bottledDay=s.day;s.water.bottles++;s.water.batch=null;
    return success('Sealed and stocked. Show the bottle to a buyer.',{lot});
  }

  return Object.freeze({status,install,source,sample,filter,bottle});
})();
