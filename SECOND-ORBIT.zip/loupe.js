/* The counter loupe magnifies the same punched pixels as the printed handbook. */
const AssayGlass=(()=>{
 const sessions=new WeakMap();
 function install(c,lot,onRead,{channel='stamp'}={}){
  if(!c)return;sessions.get(c)?.();
  const uv=channel==='uv',flag=uv?'uvRead':'sealRead';
  const width=256,height=114,board=document.createElement('canvas');board.width=c.width=width;board.height=c.height=height;
  const plate=board.getContext('2d'),screen=c.getContext('2d');if(!plate||!screen)return;
  const target=uv?{x:76+lot.item%3,y:81+lot.item%2}:{x:166+(lot.id%3),y:68+(lot.item%2)};
  const start=uv?{x:125,y:37}:{x:99,y:51};
  const real=SEALS[lot.item],code=lot.fake?real.slice(0,-1)+(Number(real.at(-1))+2)%10:real;
  let x=start.x,y=start.y,locked=!!lot[flag],manual=false,frame=0;
  const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches,started=performance.now();
  const rect=(ctx,x,y,w,h,color)=>{ctx.fillStyle=color;ctx.fillRect(x,y,w,h);};
  c.setAttribute('aria-label',uv?'UV lamp. Move to the strip on the object, or press Enter to sample.':'Inspection lens. Touch the maker plate or press Enter to focus.');
  function backdrop(){
   rect(plate,0,0,256,114,'#14252c');rect(plate,8,7,240,101,'#0d1e25');
   rect(plate,8,5,240,101,'#465d60');rect(plate,10,7,236,96,'#355053');
   rect(plate,10,7,236,2,'#6c827b');rect(plate,12,100,231,2,'#223a40');
   const icon=document.createElement('canvas');
   if(lot.item===12&&globalThis.WaterArt)WaterArt.icon(icon,lot.grade);else CounterArt.icon(icon,lot.item);
   plate.imageSmoothingEnabled=false;plate.drawImage(icon,28,13,93,87);
   if(lot.grade===0){rect(plate,53,86,6,1,'#b4b2a0');rect(plate,58,85,3,1,'#b4b2a0');}
   if(uv){
    // Oblique ultraviolet light reveals only the fibres inside its cone.
    rect(plate,10,7,236,96,'rgba(41,31,75,.64)');
    rect(plate,target.x-23,target.y-7,46,14,'#292838');
    rect(plate,target.x-21,target.y-6,42,11,'#4f4661');
    rect(plate,target.x-17,target.y-4,34,7,'#414057');
    for(const sx of [-21,19])rect(plate,target.x+sx,target.y-2,2,2,'#b8aab7');
    // An instrument on the opposite side repeats the tiny reading at phone size.
    rect(plate,137,21,100,71,'#231f32');rect(plate,137,19,100,71,'#80758c');
    rect(plate,139,21,96,66,'#514a60');rect(plate,144,38,87,34,'#23263a');
    rect(plate,145,39,85,32,'#1b2d37');CounterStamps.drawCode(plate,147,25,'UV','#e3d4bd');
    for(const sx of [220,225])rect(plate,sx,27,3,2,'#a29ab3');
    return;
   }
   const left=target.x-16,top=target.y-17;
   rect(plate,left-3,top-2,97,39,'#243436');rect(plate,left-2,top-3,96,39,'#937c59');
   rect(plate,left,top,92,33,'#ebd9b3');rect(plate,left+1,top+1,90,1,'#fff1c9');
   CounterStamps.drawMark(plate,target.x-10,target.y-10,lot.item,lot.fake,3);
   CounterStamps.drawCode(plate,target.x+27,target.y-6,code,'#344338',2);
  }
  function corners(color,pad){
   const left=target.x-(uv?26:20)-pad,right=target.x+(uv?26:78)+pad;
   const top=target.y-(uv?12:22)-pad,bottom=target.y+(uv?12:20)+pad;
   for(const [cx,dx] of [[left,1],[right,-1]])for(const [cy,dy] of [[top,1],[bottom,-1]]){
    rect(screen,dx>0?cx:cx-6,dy>0?cy:cy-1,7,2,color);rect(screen,dx>0?cx:cx-1,dy>0?cy:cy-6,2,7,color);
   }
  }
  function lens(cx,cy){
   const r=24,m=1.55;screen.save();screen.lineCap='round';
   screen.beginPath();screen.moveTo(cx-16,cy+16);screen.lineTo(cx-30,cy+30);screen.lineWidth=8;screen.strokeStyle='#182c32';screen.stroke();
   screen.lineWidth=4;screen.strokeStyle='#ba9868';screen.stroke();
   screen.beginPath();screen.arc(cx,cy,r,0,Math.PI*2);screen.clip();
   screen.drawImage(board,cx-r/m,cy-r/m,2*r/m,2*r/m,cx-r,cy-r,2*r,2*r);
   screen.restore();
   screen.beginPath();screen.arc(cx,cy,r,0,Math.PI*2);screen.lineWidth=4;screen.strokeStyle=locked?'#ede1ae':'#bfad88';screen.stroke();
   screen.beginPath();screen.arc(cx,cy,r-3,3.57,5.06);screen.lineWidth=1;screen.strokeStyle='#eff1d9';screen.stroke();
  }
  function lamp(cx,cy,powered){
   screen.save();
   screen.beginPath();screen.arc(cx,cy,24,0,Math.PI*2);screen.clip();
   rect(screen,cx-24,cy-24,48,48,'rgba(159,116,255,.25)');
   screen.beginPath();screen.arc(cx,cy,22,0,Math.PI*2);screen.lineWidth=1;screen.strokeStyle='#b5a7ee';screen.stroke();
   if(powered)CounterStamps.drawBand(screen,target.x-9,target.y-2,lot.item,lot.fake,1,'#c4ffdf');
   screen.restore();
   if(locked){
    CounterStamps.drawBand(screen,149,45,lot.item,lot.fake,4,'#b4f8d2');
    const accent=lot.tag?'#ffc080':'#b1cebd';
    // The customs transponder has a different purpose from the manufacturer's fibres.
    CounterStamps.drawCode(screen,147,77,lot.tag?'ID FLAG':'ID CLEAR',accent);
   }else{
    for(let i=0;i<3;i++)rect(screen,177+i*9,53,5,2,'#61817d');
   }
  }
  function draw(now=performance.now()){
   const time=(now-started)/1000;screen.imageSmoothingEnabled=false;screen.drawImage(board,0,0);
   corners(locked?'#d9c8a1':uv?'#cbb6ff':'#ffce73',!manual&&!locked&&!reduced?Math.round((1+Math.sin(time*3))*1.1):0);
   if(uv){
    const progress=manual||reduced?0:Math.max(0,Math.min(1,((time%3.8)-.65)/1.4));
    const t=progress*progress*(3-2*progress);
    lamp(locked?target.x:manual?x:start.x-24*t,locked?target.y:manual?y:start.y+21*t,manual||locked);
    return;
   }
   if(locked){
    // Park the lens at the punch instead of over the serial. Both remain legible.
    lens(target.x,target.y);
   }else if(!manual){
    const phase=reduced?0:Math.min(1,Math.max(0,((time%3.8)-.65)/1.4)),t=phase*phase*(3-2*phase);
    // Demonstration stops just before the seal. Only user input can read it.
    for(let i=0;i<4;i++)rect(screen,117+i*6,54+i*2,2,2,'#c9aa74');
    lens(start.x+37*t,start.y+9*t);
   }else lens(x,y);
  }
  function stop(){if(frame)cancelAnimationFrame(frame);frame=0;}
  function hint(now){
   frame=0;if(!c.isConnected||c.closest('dialog:not([open])')||document.hidden||manual||locked)return;
   draw(now);frame=requestAnimationFrame(hint);
  }
  function move(nx,ny){
   if(locked)return;
   manual=true;stop();x=Math.max(24,Math.min(232,nx));y=Math.max(24,Math.min(90,ny));
   const hit=uv?Math.abs(x-target.x)<=25&&Math.abs(y-target.y)<=16:x>=target.x-20&&x<=target.x+76&&Math.abs(y-target.y)<=21;
   if(hit){
    locked=true;lot[flag]=true;draw();onRead?.(uv?'uv':'stamp');return;
   }
   draw();
  }
  function pointer(e){const bounds=c.getBoundingClientRect();if(bounds.width&&bounds.height)move((e.clientX-bounds.left)*width/bounds.width,(e.clientY-bounds.top)*height/bounds.height);}
  c.onpointerdown=e=>{if(!locked){c.setPointerCapture?.(e.pointerId);pointer(e);}};
  c.onpointermove=e=>{if(!locked&&c.hasPointerCapture?.(e.pointerId))pointer(e);};
  c.onkeydown=e=>{
   const delta={ArrowLeft:[-8,0],ArrowRight:[8,0],ArrowUp:[0,-8],ArrowDown:[0,8]}[e.key];
   if(delta){e.preventDefault();move(x+delta[0],y+delta[1]);}
   else if(e.key==='Enter'||e.key===' '){e.preventDefault();move(target.x,target.y);}
  };
  sessions.set(c,stop);backdrop();draw();if(!manual&&!locked&&!reduced)frame=requestAnimationFrame(hint);
 }
 return {install};
})();

