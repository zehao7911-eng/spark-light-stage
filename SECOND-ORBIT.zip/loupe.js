/* The counter loupe magnifies the same punched pixels as the printed handbook. */
const AssayGlass=(()=>{
 const sessions=new WeakMap();
 function install(c,lot,onRead){
  if(!c)return;sessions.get(c)?.();
  const width=256,height=114,board=document.createElement('canvas');board.width=c.width=width;board.height=c.height=height;
  const plate=board.getContext('2d'),screen=c.getContext('2d');if(!plate||!screen)return;
  const target={x:166+(lot.id%3),y:68+(lot.item%2)},start={x:99,y:51};
  const real=SEALS[lot.item],code=lot.fake?real.slice(0,-1)+(Number(real.at(-1))+2)%10:real;
  let x=start.x,y=start.y,locked=!!lot.sealRead,manual=false,frame=0;
  const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches,started=performance.now();
  const rect=(ctx,x,y,w,h,color)=>{ctx.fillStyle=color;ctx.fillRect(x,y,w,h);};
  function backdrop(){
   rect(plate,0,0,256,114,'#14252c');rect(plate,8,7,240,101,'#0d1e25');
   rect(plate,8,5,240,101,'#465d60');rect(plate,10,7,236,96,'#355053');
   rect(plate,10,7,236,2,'#6c827b');rect(plate,12,100,231,2,'#223a40');
   const icon=document.createElement('canvas');
   if(lot.item===12&&globalThis.WaterArt)WaterArt.icon(icon,lot.grade);else CounterArt.icon(icon,lot.item);
   plate.imageSmoothingEnabled=false;plate.drawImage(icon,28,13,93,87);
   if(lot.grade===0){rect(plate,53,86,6,1,'#b4b2a0');rect(plate,58,85,3,1,'#b4b2a0');}
   const left=target.x-16,top=target.y-17;
   rect(plate,left-3,top-2,97,39,'#243436');rect(plate,left-2,top-3,96,39,'#937c59');
   rect(plate,left,top,92,33,'#ebd9b3');rect(plate,left+1,top+1,90,1,'#fff1c9');
   CounterStamps.drawMark(plate,target.x-10,target.y-10,lot.item,lot.fake,3);
   CounterStamps.drawCode(plate,target.x+27,target.y-6,code,'#344338',2);
  }
  function corners(color,pad){
   const left=target.x-20-pad,right=target.x+78+pad,top=target.y-22-pad,bottom=target.y+20+pad;
   for(const [cx,dx] of [[left,1],[right,-1]])for(const [cy,dy] of [[top,1],[bottom,-1]]){
    rect(screen,dx>0?cx:cx-6,dy>0?cy:cy-1,7,2,color);rect(screen,dx>0?cx:cx-1,dy>0?cy:cy-6,2,7,color);
   }
  }
  function lens(cx,cy){
   const r=24,m=1.55;screen.save();screen.lineCap='round';
   screen.beginPath();screen.moveTo(cx-16,cy+16);screen.lineTo(cx-30,cy+30);screen.lineWidth=8;screen.strokeStyle='#182c32';screen.stroke();
   screen.lineWidth=4;screen.strokeStyle='#ba9868';screen.stroke();
   screen.beginPath();screen.arc(cx,cy,r,0,Math.PI*2);screen.clip();
   screen.drawImage(board,cx-r/m,cy-r/m,2*r/m,2*r/m,cx-r,cy-r,2*r,2*r);
   screen.restore();
   screen.beginPath();screen.arc(cx,cy,r,0,Math.PI*2);screen.lineWidth=4;screen.strokeStyle=locked?'#ede1ae':'#bfad88';screen.stroke();
   screen.beginPath();screen.arc(cx,cy,r-3,3.57,5.06);screen.lineWidth=1;screen.strokeStyle='#eff1d9';screen.stroke();
  }
  function draw(now=performance.now()){
   const time=(now-started)/1000;screen.imageSmoothingEnabled=false;screen.drawImage(board,0,0);
   corners(locked?'#d9c8a1':'#ffce73',!manual&&!locked&&!reduced?Math.round((1+Math.sin(time*3))*1.1):0);
   if(locked){
    // Park the lens at the punch instead of over the serial. Both remain legible.
    lens(target.x,target.y);
   }else if(!manual){
    const phase=reduced?0:Math.min(1,Math.max(0,((time%3.8)-.65)/1.4)),t=phase*phase*(3-2*phase);
    // Demonstration stops just before the seal. Only user input can read it.
    for(let i=0;i<4;i++)rect(screen,117+i*6,54+i*2,2,2,'#c9aa74');
    lens(start.x+37*t,start.y+9*t);
   }else lens(x,y);
  }
  function stop(){if(frame)cancelAnimationFrame(frame);frame=0;}
  function hint(now){
   frame=0;if(!c.isConnected||c.closest('dialog:not([open])')||document.hidden||manual||locked)return;
   draw(now);frame=requestAnimationFrame(hint);
  }
  function move(nx,ny){
   if(locked)return;
   manual=true;stop();x=Math.max(24,Math.min(232,nx));y=Math.max(24,Math.min(90,ny));
   if(x>=target.x-20&&x<=target.x+76&&Math.abs(y-target.y)<=21){
    locked=true;lot.sealRead=true;draw();onRead();return;
   }
   draw();
  }
  function pointer(e){const bounds=c.getBoundingClientRect();if(bounds.width&&bounds.height)move((e.clientX-bounds.left)*width/bounds.width,(e.clientY-bounds.top)*height/bounds.height);}
  c.onpointerdown=e=>{if(!locked){c.setPointerCapture?.(e.pointerId);pointer(e);}};
  c.onpointermove=e=>{if(!locked&&c.hasPointerCapture?.(e.pointerId))pointer(e);};
  c.onkeydown=e=>{
   const delta={ArrowLeft:[-8,0],ArrowRight:[8,0],ArrowUp:[0,-8],ArrowDown:[0,8]}[e.key];
   if(delta){e.preventDefault();move(x+delta[0],y+delta[1]);}
   else if(e.key==='Enter'||e.key===' '){e.preventDefault();move(target.x,target.y);}
  };
  sessions.set(c,stop);backdrop();draw();if(!manual&&!locked&&!reduced)frame=requestAnimationFrame(hint);
 }
 return {install};
})();

