/* Counter magnifier. The entire inspection is drawn on a low-resolution test tray.
   The lens samples the very same pixels as the proof; no network textures. */
const AssayGlass=(()=>{
 function install(c,l,onRead){
  const w=256,h=114,board=document.createElement('canvas');board.width=c.width=w;board.height=c.height=h;
  const g=board.getContext('2d'),v=c.getContext('2d'),target={x:165+(l.id%3)*2,y:67+(l.item%3)*2};
  let x=105,y=58,locked=!!l.sealRead;const mark=SEALS[l.item],stamped=l.fake?mark.slice(0,-1)+(Number(mark.at(-1))+2)%10:mark;
  const tiny=(t,x,y,color='#8ba7a1',size=8)=>{g.fillStyle=color;g.font='bold '+size+'px monospace';g.fillText(t,x,y);};
  function paint(){
   g.fillStyle='#182933';g.fillRect(0,0,w,h);g.lineWidth=1;
   for(let i=0;i<w;i+=8){g.fillStyle=i%32?'#213139':'#2d4045';g.fillRect(i,0,1,h);}
   for(let j=0;j<h;j+=8){g.fillStyle=j%32?'#213139':'#2d4045';g.fillRect(0,j,w,1);}
   g.fillStyle='#3a4d4d';g.fillRect(62,17,132,86);g.fillStyle='#73887b';g.fillRect(62,17,132,2);g.fillStyle='#263c3c';g.fillRect(65,21,126,78);
   const icon=document.createElement('canvas');CounterArt.icon(icon,l.item);g.imageSmoothingEnabled=false;g.drawImage(icon,77,21,80,78);
   if(l.grade===0){g.strokeStyle='#9a9a7d';for(let i=0;i<4;i++){let xx=92+i*7,yy=52+(l.item*3+i*8)%16;g.beginPath();g.moveTo(xx,yy);g.lineTo(xx+4,yy-3);g.stroke();}}
   g.fillStyle='#ab9d75';g.fillRect(target.x-15,target.y-6,30,13);g.fillStyle='#dbd1a3';g.fillRect(target.x-14,target.y-5,28,10);tiny(stamped,target.x-7,target.y+2,'#293d38',6);
   for(let j=0;j<12;j++){g.fillStyle='#7c846c';g.fillRect(74+j*3,91,1+((j+l.item)%2),j%3?3:5);}
   tiny(['G / III','G / II','G / I'][l.grade],155,92,'#9caa8d');
   for(const [qx,qy] of [[67,24],[185,24],[67,93],[185,93]]){g.fillStyle='#879484';g.fillRect(qx,qy,3,3);g.fillStyle='#48574f';g.fillRect(qx,qy+1,2,1);}
   tiny('ASSAY',6,12);tiny('2.5x',225,12);tiny('A-'+(100+l.id),6,104);tiny('M6',234,104);
   for(let i=0;i<92;i+=4){g.fillStyle='#59716e';g.fillRect(5,17+i,i%12?3:6,1);}
  }
  function draw(){
   v.imageSmoothingEnabled=false;v.drawImage(board,0,0);
   v.strokeStyle=locked?'#a1dbac':'#dbba77';v.setLineDash([3,3]);v.strokeRect(target.x-18,target.y-10,36,20);v.setLineDash([]);
   const lX=x,lY=y,r=23;v.save();v.strokeStyle='#182630';v.lineWidth=9;v.beginPath();v.moveTo(lX+15,lY+16);v.lineTo(lX+31,lY+34);v.stroke();v.strokeStyle='#9c9272';v.lineWidth=5;v.stroke();
   v.beginPath();v.arc(lX,lY,r,0,Math.PI*2);v.clip();v.drawImage(board,lX-r/2.5,lY-r/2.5,2*r/2.5,2*r/2.5,lX-r,lY-r,2*r,2*r);v.fillStyle='#a3e4d00d';v.fillRect(lX-r,lY-r,2*r,2*r);v.restore();
   v.beginPath();v.arc(lX,lY,r,0,Math.PI*2);v.lineWidth=4;v.strokeStyle='#98a89a';v.stroke();v.lineWidth=1;v.strokeStyle='#263c42';v.stroke();v.beginPath();v.arc(lX,lY,r-3,3.6,5.2);v.strokeStyle='#e4e2ba';v.stroke();
  }
  function move(nx,ny){x=Math.max(23,Math.min(w-24,nx));y=Math.max(23,Math.min(h-24,ny));
    if(!locked&&Math.hypot(x-target.x,y-target.y)<18){locked=true;x=target.x;y=target.y;l.sealRead=true;onRead();}draw();}
  function pos(e){const b=c.getBoundingClientRect();move((e.clientX-b.left)*w/b.width,(e.clientY-b.top)*h/b.height);}
  c.onpointerdown=e=>{c.setPointerCapture?.(e.pointerId);pos(e);};c.onpointermove=e=>{if(c.hasPointerCapture(e.pointerId))pos(e);};
  c.onkeydown=e=>{const d={ArrowLeft:[-8,0],ArrowRight:[8,0],ArrowUp:[0,-8],ArrowDown:[0,8]}[e.key];if(d){e.preventDefault();move(x+d[0],y+d[1]);}else if(e.key==='Enter'||e.key===' '){e.preventDefault();move(target.x,target.y);}};
  paint();if(locked){x=target.x;y=target.y;}draw();
 }
 return {install};
})();

