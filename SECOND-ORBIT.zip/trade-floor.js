'use strict';

const pict=(name,size=22)=>CounterIcons.html(name,size);
function buttonFace(button,name,label){
 button.innerHTML=pict(name)+'<span>'+esc(label)+'</span>';button.classList.add('pictureButton');return button;
}
function actionsMap(steps,current){
 return '<div class="actionMap stops'+steps.length+'" aria-label="'+esc(steps.map(q=>q[1]).join(', '))+'">'+steps.map(([icon,label],idx)=>
  '<div class="mapStop '+(idx===current?'now':idx<current?'done':'')+'"'+(idx===current?' aria-current="step"':'')+'>'+pict(icon,27)+'<span>'+esc(label)+'</span></div>').join('<i aria-hidden="true">›</i>')+'</div>';
}
function firstSeller(s) {
 return s.deskVersion===2 && s.day===1 && s.turn===1 && !s.patron?.buyer;
}
function sideOf(v) { return v.buyer?v.extra:v.includeSide?v.sideLot:null; }
const signedCredits=n=>(n<0?'−':'+')+money(Math.abs(n));
function placeOnCounter(s, id, position='primary') {
 if(!stageLot(s,id,position))return false;
 hostStart();s.patron.negotiating=false;CounterSound.play('tap');save();render();return true;
}
function readOnCounter(s) {
 const v=s.patron;
 if(v.buyer||!trayReady(v))return;
 if(!v.scanned&&!s.scans)return;
 hostStart();CounterSound.wake();
 if(inspectLot(s)){if(!firstSeller(s))v.manualCheck=true;CounterSound.play('scan');scanUntil=performance.now()+1400;save();}
 render();showModal('scan');
}
function bindAppraisal(body,s,v){
 const l=v.lot,manual=!!v.manualCheck;
 const panel=body.querySelector('#scanReport'),back=body.querySelector('#returnDeal');
 const report=body.querySelector('[data-act="report"]'),judge=body.querySelector('#stampChoice'),note=body.querySelector('#lensHint');
 function sync(){
  const read=!!l.sealRead,judged=!manual||typeof l.stampCall==='boolean';
  judge.hidden=!read||judged;panel.hidden=!read||!judged;back.hidden=panel.hidden;
  if(report)report.hidden=panel.hidden;
  if(read)note.textContent=!judged?'Same code?':!manual?'Match ✓':(l.stampCall===!l.fake?'Correct ✓':(l.fake?'Different codes':'Same code'));
 }
 for(const b of judge.querySelectorAll('button'))b.onclick=()=>{
  if(!l.sealRead||typeof l.stampCall==='boolean')return;
  l.stampCall=b.dataset.match==='yes';CounterSound.play(l.stampCall===!l.fake?'stamp':'counter');save();sync();back.scrollIntoView({block:'nearest'});
 };
 sync();return sync;
}
function printDeal(s) {
 const v=s.patron;
 if(firstSeller(s)&&!v.lot.sealRead){readOnCounter(s);return;}
 hostStart();const outcome=trade(s);
 if(!outcome)return;
 CounterSound.play(outcome);if(s.phase==='receipt')delta(v.ticket);
}
function customerSpeech(s){
 const v=s.patron,who=PEOPLE[v.person];
 return v.response||(v.windowLot?'I saw it in your window.':v.lessonCoil?'I’ll pay '+money(38)+' for Pip’s coil.':firstSeller(s)?'I want '+money(22)+' for my coil.':v.trainingCase?'Take a look at the lens.':v.buyer?'I need '+['machine parts','survey gear','freight goods'][v.wants]+'.':who[3]);
}
function renderTrade(s,desk) {
 const v=s.patron,person=PEOPLE[v.person],lot=v.lot,name=GOODS[lot.item][0],staged=trayReady(v);
 const fresh=firstSeller(s),lesson=fresh||!!v.lessonCoil,scanning=fresh&&staged&&!lot.sealRead;
 const firstWeekday=s.deskVersion===2&&s.day===1;
 const second=sideOf(v),cost=lot.cost+(v.extra?.cost||0);
 const category=['machine parts','survey gear','freight goods'][v.wants];
 const prefix=v.buyer?'You sell':'You buy';
 const steps=v.buyer?[['shelf','Pick'],['sell','Sell']]:[['tray','Place'],['lens','Check'],['buy','Buy']];
 const current=!staged?0:v.buyer?1:scanning?1:2;
 const watch=v.buyer?(v.windowLot?'Window request':v.pairOrder?'Two items welcome':!v.lessonCoil?'Wants '+category:''):(v.trainingCase&&!lot.sealRead?'Check the stamp':'');
 desk.innerHTML='<div class="slipTop"><span class="direction '+(v.buyer?'selling':'buying')+'">'+pict(v.buyer?'sell':'buy',18)+prefix+'</span><button class="talkchip" id="talk" aria-label="Talk to '+esc(person[0])+'">'+esc(person[0])+' ···</button></div>'+
  (lesson?actionsMap(steps,current):'')+(watch?'<p class="wish">'+esc(watch)+'</p>':'')+
  (v.response?'<p class="wish">'+esc(v.patience<3?'Counteroffer '+money(v.ask):'Need more cash')+'</p>':'');
 $('#talk').onclick=()=>showModal('talk');
 if(!staged) {
  const expected=v.lessonCoil||v.windowLot||(!v.buyer?lot.id:null);
  if(expected)desk.insertAdjacentHTML('beforeend','<div class="stockline">'+goodsIcon(lot.item)+'<div><strong>'+esc(name)+'</strong></div><b>'+money(v.ask)+'</b></div>');
  actions(buttonFace(action('',()=>{
   if(expected)placeOnCounter(s,expected);else showModal('swap');
  }),v.buyer?'shelf':'tray',v.lessonCoil?'Pick the coil':v.buyer?'Pick an item':'Place on tray'),...skipButtons(s,lesson));
  return;
 }
 const assessed=lot.sealRead&&(!v.manualCheck||typeof lot.stampCall==='boolean');
 const reference=assessed?lotValue(lot,demand(s,lot.item)):Math.round(GOODS[lot.item][1]*demand(s,lot.item));
 desk.insertAdjacentHTML('beforeend','<div class="stockline paperLot">'+goodsIcon(lot.item)+'<div><strong>'+esc(name)+(second?' + '+esc(GOODS[second.item][0]):'')+'</strong>'+
  '<small>'+(v.buyer?'Cost '+money(cost):'Value ~'+money(reference)+(second?' (first item)':''))+'</small></div>'+
  (scanning?'':!lesson?'<button id="unplace" aria-label="Remove goods from tray">Lift off</button>':'')+'</div>');
 if($('#unplace'))$('#unplace').onclick=()=>{if(unstageLot(s)){v.negotiating=false;CounterSound.play('tap');save();render();}};
 if(scanning){actions(buttonFace(action('',()=>readOnCounter(s)),'lens','Check stamp'));return;}
 const readonly=firstWeekday||!!v.lessonCoil;
 const custom=!readonly&&(!!v.negotiating||(v.staged===undefined&&v.offer!==v.ask));
 if(!custom&&v.staged!==undefined)v.offer=v.ask;
 const label=v.buyer?'Buyer offers':'Asking price';
 if(custom)desk.insertAdjacentHTML('beforeend','<div class="offerline"><span>'+label+'</span><b>'+money(v.ask)+'</b></div>');
 if(custom){
  const low=v.buyer?v.ask:Math.max(1,(v.includeSide?v.sideAsk:0)+1,Math.floor(v.ask*.35));
  const high=v.buyer?Math.max(v.ask+8,Math.round(v.opening*1.65)):v.ask;
  desk.insertAdjacentHTML('beforeend','<div class="pricehead"><label for="price">YOUR PRICE</label><b id="value"></b></div><div class="dial"><button id="minus" aria-label="Decrease offer">−</button><input id="price" type="range" aria-label="Counteroffer"><button id="plus" aria-label="Increase offer">+</button></div><p class="patience">Patience '+v.patience+' / 3</p>');
  const range=$('#price');range.min=low;range.max=high;range.value=v.offer;
  function update(){v.offer=+range.value;$('#value').textContent=money(v.offer);updateConfirm();}
  range.oninput=update;range.onchange=()=>{CounterSound.play('tap');save();};
  for(const [id,inc] of [['#minus',-1],['#plus',1]])$(id).onclick=()=>{range.value=+range.value+inc;update();save();};
  $('#value').textContent=money(v.offer);
 }
 const main=action('',()=>printDeal(s));actions(main,...skipButtons(s,lesson));
 function updateConfirm(){
  const b=$('#primary');if(!b)return;
  buttonFace(b,v.buyer?'sell':'buy',(custom&&v.offer!==v.ask?'Offer ':v.buyer?'Sell ':'Buy ')+money(v.offer));
  b.disabled=!v.buyer&&v.offer>s.cash;
  const net=$('#net');if(net)net.textContent=signedCredits(v.offer-cost);
 }
 updateConfirm();
 if(v.buyer)desk.insertAdjacentHTML('beforeend','<div class="marginline"><span>Profit</span><b id="net">'+signedCredits(v.offer-cost)+'</b></div>');
 else if(v.offer>s.cash)desk.insertAdjacentHTML('beforeend','<p class="cashwarning">You have '+money(s.cash)+'.</p>');
 if(!lesson){
  const tools=document.createElement('div');tools.className='dealtools';
  function tool(id,label,fn,disabled=false){const b=action(label,fn,'tool',id);b.disabled=disabled;tools.append(b);}
  if(!v.buyer)tool('inspect',v.scanned?'Stamp':'Check · '+s.scans,()=>readOnCounter(s),!v.scanned&&!s.scans);
  if(v.buyer)tool('inspect',v.pairOrder?'Pair items':'Swap',()=>showModal('swap'));
  if(v.extra)tool('unpair','Unpack pair',()=>unstageLot(s,'extra'));
  if(!v.buyer&&v.sideLot)tool('bundle',(v.includeSide?'Remove ':'Add ')+GOODS[v.sideLot.item][0]+' · '+money(v.sideAsk),()=>{toggleSide(s);});
  if(!readonly)tool('haggle',custom?'Reset price':'Name price',()=>{v.negotiating=!v.negotiating;v.offer=v.ask;});
  desk.append(tools);
 }
}
function skipButtons(s,lesson){
 return lesson?[]:[action('Pass',()=>{hostStart();pass(s);CounterSound.play('pass');},'secondary','pass')];
}
function renderTicket(s,desk,next){
 const v=s.patron,l=v.lot,paid=v.ticket==='PURCHASED',sold=v.ticket==='SOLD',extra=sideOf(v);
 const cost=l.cost+(v.extra?.cost||0),margin=v.tender-cost;
 const title=paid?'Bought':sold?'Sold':v.ticket==='PASSED'?'Passed':v.ticket==='CUSTOMS TIP'?'Reported':'Left';
 desk.innerHTML='<div class="receiptHead">'+pict(paid?'shelf':sold?'profit':'pass',38)+'<h2 class="resultTitle">'+title+'</h2></div>'+
  '<div class="stockline">'+goodsIcon(l.item)+'<div><strong>'+esc(GOODS[l.item][0])+(extra?' + '+esc(GOODS[extra.item][0]):'')+'</strong></div></div>'+
  (sold?'<div class="slipmath"><span>Paid<b>'+money(cost)+'</b></span><span>Sold<b>'+money(v.tender)+'</b></span><span>Profit<b>'+signedCredits(margin)+'</b></span></div>':v.tender?'<div class="offerline"><span>'+(paid?'Paid':'Earned')+'</span><b>'+signedCredits(v.tender)+'</b></div>':'');
 actions(buttonFace(action('',next),s.turn>=s.limit?'shutter':'bell',s.turn>=s.limit?'Close shop':'Next customer'));
}
