'use strict';

function firstSeller(s) {
 return s.deskVersion===2 && s.day===1 && s.turn===1 && !s.patron?.buyer;
}
function sideOf(v) { return v.buyer?v.extra:v.includeSide?v.sideLot:null; }
const signedCredits=n=>(n<0?'−':'+')+money(Math.abs(n));
function placeOnCounter(s, id, position='primary') {
 if(!stageLot(s,id,position))return false;
 hostStart();s.patron.negotiating=false;CounterSound.play('tap');save();render();return true;
}
function readOnCounter(s) {
 const v=s.patron;
 if(v.buyer||!trayReady(v))return;
 if(!v.scanned&&!s.scans)return;
 hostStart();CounterSound.wake();
 if(inspectLot(s)){if(!firstSeller(s))v.manualCheck=true;CounterSound.play('scan');scanUntil=performance.now()+1400;save();}
 render();showModal('scan');
}
function bindAppraisal(body,s,v){
 const l=v.lot,manual=!!v.manualCheck;
 const panel=body.querySelector('#scanReport'),back=body.querySelector('#returnDeal');
 const report=body.querySelector('[data-act="report"]'),judge=body.querySelector('#stampChoice'),note=body.querySelector('#lensHint');
 function sync(){
  const read=!!l.sealRead,judged=!manual||typeof l.stampCall==='boolean';
  judge.hidden=!read||judged;panel.hidden=!read||!judged;back.hidden=panel.hidden;
  if(report)report.hidden=panel.hidden;
  if(read)note.textContent=!judged?'Compare the two serials. Is this a factory stamp?':
   !manual?'The two serials match. Review the deal.':(l.stampCall===!l.fake?'Correct. ':'Check the last digit. ')+(l.fake?'The stamped code differs from the register.':'Both codes match the register.');
 }
 for(const b of judge.querySelectorAll('button'))b.onclick=()=>{
  if(!l.sealRead||typeof l.stampCall==='boolean')return;
  l.stampCall=b.dataset.match==='yes';CounterSound.play(l.stampCall===!l.fake?'stamp':'counter');save();sync();back.scrollIntoView({block:'nearest'});
 };
 sync();return sync;
}
function printDeal(s) {
 const v=s.patron;
 if(firstSeller(s)&&!v.lot.sealRead){readOnCounter(s);return;}
 hostStart();const outcome=trade(s);
 if(!outcome)return;
 CounterSound.play(outcome);if(s.phase==='receipt')delta(v.ticket);
}
function renderTrade(s,desk) {
 const v=s.patron,person=PEOPLE[v.person],lot=v.lot,name=GOODS[lot.item][0],staged=trayReady(v);
 const fresh=firstSeller(s),lesson=fresh||!!v.lessonCoil,scanning=fresh&&staged&&!lot.sealRead;
 const firstWeekday=s.deskVersion===2&&s.day===1;
 const second=sideOf(v),cost=lot.cost+(v.extra?.cost||0);
 const category=['machine parts','survey gear','freight goods'][v.wants];
 const prefix=v.buyer?'CUSTOMER BUYS':'CUSTOMER SELLS';
 const message=v.response||(fresh?'“This coil’s genuine. Twenty-two credits and it’s yours.”':
  v.lessonCoil?'“Pip said you have a relay coil. I’ll give you '+money(38)+' for it.”':
  v.trainingCase?'“I found this lens in a survey pod. Is it worth my asking price?”':
  v.windowLot&&s.stock.some(q=>q.id===v.windowLot)?'“I saw the '+GOODS[s.stock.find(q=>q.id===v.windowLot).item][0]+' in your window. Can I see it?”':
  v.buyer?'“I’m buying '+category+'. '+(v.pairOrder?'Got two? I’ll pay a rush bonus.':'What have you got?')+'”':
  '“'+person[3]+'”');
 const step=!staged?(v.buyer?'Pick stock to sell':'Move the goods to your tray'):scanning?'Check the brass stamp':v.buyer?'Make the sale':'Review the price';
 const detail=!staged?(v.lessonCoil?'Tap the glowing coil on your shelf.':v.buyer?'Tap a shelf item or drag it to the tray.':'Tap the loose item or drag it onto the center tray.'):
  scanning?'The stamp tells you if the coil is genuine.':
  v.lessonCoil?'Same coil. Your cost '+money(cost)+' · Buyer offers '+money(v.ask)+'.':
  fresh?'The serial matches. Pay Pip to keep the coil.':
  v.trainingCase?(lot.sealRead&&(!v.manualCheck||typeof lot.stampCall==='boolean')?(lot.fake?'Replica stamp. Compare its scrap value with the asking price.':'Factory stamp matched. Compare its value with the asking price.'):'Try the lens, then decide whether to buy or pass.'):
  v.buyer?'Compare the offer with what you paid.':'Compare the asking price with the guide value.';
 desk.innerHTML='<div class="slipTop"><span class="direction '+(v.buyer?'selling':'buying')+'">'+prefix+'</span><small>VISITOR '+s.turn+' / '+s.limit+'</small></div>'+
  '<div class="dialogue clerk"><b>'+esc(person[0])+'</b><small>'+esc(person[1])+'</small><p>'+esc(message)+'</p></div>'+
  '<div class="taskline"><i aria-hidden="true">'+(!staged?'▣':scanning?'◎':'✓')+'</i><div><h3>'+step+'</h3><p>'+esc(detail)+'</p></div></div>';
 if(!staged) {
  const expected=v.lessonCoil||v.windowLot||(!v.buyer?lot.id:null);
  if(expected)desk.insertAdjacentHTML('beforeend','<div class="stockline">'+goodsIcon(lot.item)+'<div><small>'+(!v.buyer?'OFFERED ITEM':'REQUESTED ITEM')+'</small><strong>'+esc(name)+'</strong></div><b>'+money(v.ask)+'</b></div>');
  actions(action(expected?'Place '+name.toLowerCase()+' on tray':'Choose from shelf',()=>{
   if(expected)placeOnCounter(s,expected);else showModal('swap');
  }),...skipButtons(s,lesson));
  return;
 }
 const assessed=lot.sealRead&&(!v.manualCheck||typeof lot.stampCall==='boolean');
 const reference=assessed?lotValue(lot,demand(s,lot.item)):Math.round(GOODS[lot.item][1]*demand(s,lot.item));
 desk.insertAdjacentHTML('beforeend','<div class="stockline paperLot">'+goodsIcon(lot.item)+'<div><small>ON THE TRAY</small><strong>'+esc(name)+(second?' + '+esc(GOODS[second.item][0]):'')+'</strong>'+
  '<small>'+(v.buyer?'You paid '+money(cost):'Guide ~'+money(reference)+(second?' for main lot':''))+'</small></div>'+
  (scanning?'':!lesson?'<button id="unplace" aria-label="Remove goods from tray">Lift off</button>':'')+'</div>');
 if($('#unplace'))$('#unplace').onclick=()=>{if(unstageLot(s)){v.negotiating=false;CounterSound.play('tap');save();render();}};
 if(scanning){actions(action('Inspect the stamp',()=>readOnCounter(s)));return;}
 const readonly=firstWeekday||!!v.lessonCoil;
 const custom=!readonly&&(!!v.negotiating||(v.staged===undefined&&v.offer!==v.ask));
 if(!custom&&v.staged!==undefined)v.offer=v.ask;
 const label=v.buyer?'Buyer offers':'Asking price';
 desk.insertAdjacentHTML('beforeend','<div class="offerline"><span>'+label+'</span><b>'+money(v.ask)+'</b></div>');
 if(custom){
  const low=v.buyer?v.ask:Math.max(1,(v.includeSide?v.sideAsk:0)+1,Math.floor(v.ask*.35));
  const high=v.buyer?Math.max(v.ask+8,Math.round(v.opening*1.65)):v.ask;
  desk.insertAdjacentHTML('beforeend','<div class="pricehead"><label for="price">YOUR COUNTEROFFER</label><b id="value"></b></div><div class="dial"><button id="minus" aria-label="Decrease offer">−</button><input id="price" type="range" aria-label="Counteroffer"><button id="plus" aria-label="Increase offer">+</button></div><p class="patience">Patience '+v.patience+' / 3</p>');
  const range=$('#price');range.min=low;range.max=high;range.value=v.offer;
  function update(){v.offer=+range.value;$('#value').textContent=money(v.offer);updateConfirm();}
  range.oninput=update;range.onchange=()=>{CounterSound.play('tap');save();};
  for(const [id,inc] of [['#minus',-1],['#plus',1]])$(id).onclick=()=>{range.value=+range.value+inc;update();save();};
  $('#value').textContent=money(v.offer);
 }
 const main=action('',()=>printDeal(s));actions(main,...skipButtons(s,lesson));
 function updateConfirm(){
  const b=$('#primary');if(!b)return;
  b.textContent=custom&&v.offer!==v.ask?'Offer '+money(v.offer):(v.buyer?'Sell for ':'Buy for ')+money(v.offer);
  b.disabled=!v.buyer&&v.offer>s.cash;
  const net=$('#net');if(net)net.textContent=signedCredits(v.offer-cost);
 }
 updateConfirm();
 if(v.buyer)desk.insertAdjacentHTML('beforeend','<div class="marginline"><span>Profit if sold</span><b id="net">'+signedCredits(v.offer-cost)+'</b></div>');
 else if(v.offer>s.cash)desk.insertAdjacentHTML('beforeend','<p class="cashwarning">You have '+money(s.cash)+'. Choose another offer or pass.</p>');
 if(!lesson){
  const tools=document.createElement('div');tools.className='dealtools';
  function tool(id,label,fn,disabled=false){const b=action(label,fn,'tool',id);b.disabled=disabled;tools.append(b);}
  if(!v.buyer)tool('inspect',v.scanned?'Read stamp':'Inspect · '+s.scans,()=>readOnCounter(s),!v.scanned&&!s.scans);
  if(v.buyer)tool('inspect',v.pairOrder?'Pack a pair':'Change stock',()=>showModal('swap'));
  if(v.extra)tool('unpair','Unpack pair',()=>unstageLot(s,'extra'));
  if(!v.buyer&&v.sideLot)tool('bundle',(v.includeSide?'Remove ':'Add ')+GOODS[v.sideLot.item][0]+' · '+money(v.sideAsk),()=>{toggleSide(s);});
  if(!readonly)tool('haggle',custom?'Use asking price':'Negotiate',()=>{v.negotiating=!v.negotiating;v.offer=v.ask;});
  desk.append(tools);
 }
}
function skipButtons(s,lesson){
 return lesson?[]:[action('Pass',()=>{hostStart();pass(s);CounterSound.play('pass');},'secondary','pass')];
}
function renderTicket(s,desk,next){
 const v=s.patron,l=v.lot,paid=v.ticket==='PURCHASED',sold=v.ticket==='SOLD',extra=sideOf(v);
 const cost=l.cost+(v.extra?.cost||0),margin=v.tender-cost;
 const title=paid?'Stock received.':sold?'Sale complete.':v.ticket==='PASSED'?'Offer declined.':v.ticket==='CUSTOMS TIP'?'Report filed.':'Customer left.';
 const hint=paid?(firstSeller(s)?'The coil is yours. Ring for the mechanic who wants to buy it.':'The goods are on your shelf, ready for a buyer.'):
  sold?(v.lessonCoil?'You bought low and sold high. The next deal is yours.':'The buyer takes the goods. Your till has been credited.'):v.response;
 desk.innerHTML='<div class="slipTop"><span class="direction">'+(paid?'PURCHASE RECEIPT':sold?'SALES RECEIPT':'COUNTER RECEIPT')+'</span><small>NO. '+String(s.day*100+s.turn)+'</small></div><h2 class="resultTitle">'+title+'</h2>'+
  '<div class="stockline">'+goodsIcon(l.item)+'<div><strong>'+esc(GOODS[l.item][0])+(extra?' + '+esc(GOODS[extra.item][0]):'')+'</strong><small>'+esc(PEOPLE[v.person][0])+'</small></div></div>'+
  (sold?'<div class="slipmath"><span>You paid <b>'+money(cost)+'</b></span><span>Sold for <b>'+money(v.tender)+'</b></span><span>Profit <b>'+signedCredits(margin)+'</b></span></div>':v.tender?'<div class="offerline"><span>'+(paid?'Paid from till':'Paid to you')+'</span><b>'+signedCredits(v.tender)+'</b></div>':'')+
  '<p class="ticketHint">'+esc(hint)+'</p>';
 actions(action(s.turn>=s.limit?'Close the shutters':firstSeller(s)?'Ring for the buyer':'Ring for next customer',next));
}
