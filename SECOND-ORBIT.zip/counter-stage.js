/* Second Orbit: short exchanges layered onto the live 320 × 185 counter. */
globalThis.CounterStage=(()=>{
  const items=new Map();
  const people=[
    ['#895a4d','#d99669','#c1a18b'],['#425e59','#88947b','#93a984'],
    ['#656f82','#a2b2ac','#b7bdab'],['#665668','#b49194','#d7b59a'],
    ['#735674','#b38f9f','#c7aab0'],['#5b6867','#9fac92','#d4ba8c'],
    ['#5c536b','#a1889b','#d69a7f'],['#426366','#86a798','#c18373']
  ];
  const clamp=x=>Math.max(0,Math.min(1,x)),ease=x=>{x=clamp(x);return x*x*(3-2*x);};
  const between=(a,b,t)=>Math.round(a+(b-a)*t);
  function tile(id){
    if(items.has(id))return items.get(id);
    const c=document.createElement('canvas');c.width=c.height=32;
    if(id===12){if(!globalThis.WaterArt)return null;WaterArt.icon(c,2);}
    else{if(!globalThis.CounterArt)return null;CounterArt.icon(c,id);}
    items.set(id,c);return c;
  }
  function draw(ctx,{run,now=0,age=0,reduced=false,trayReady}={}){
    if(!ctx||!run||!['bell','night','trade','receipt'].includes(run.phase))return;
    const v=run.patron;if(!v&&['trade','receipt'].includes(run.phase))return;
    ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.imageSmoothingEnabled=false;
    try{
      const t=reduced?3:Math.max(0,Number(age)||0),clock=reduced?0:(Number(now)||0)/1000;
      const ink='#26343a',till='#315747',mint='#b6dfaa',paper='#e5d7b2',gold='#e7bd7e';
      const [sleeve,cuff,skin]=people[(v?.person|0)%8]||people[0];
      const r=(x,y,w,h,c)=>{ctx.fillStyle=c;ctx.fillRect(Math.round(x),Math.round(y),w,h);};
      function poly(c,...points){
        let min=185,max=0;
        for(let j=1;j<points.length;j+=2){min=Math.min(min,points[j]);max=Math.max(max,points[j]);}
        for(let y=Math.floor(min);y<max;y++){let cuts=[];
          for(let j=0,k=points.length-2;j<points.length;k=j,j+=2){const a=points[k+1],b=points[j+1];
            if((a>y+.5)!==(b>y+.5))cuts.push(points[k]+(y+.5-a)*(points[j]-points[k])/(b-a));}
          cuts.sort((a,b)=>a-b);for(let j=0;j<cuts.length;j+=2){const left=Math.ceil(cuts[j]-.5);r(left,y,Math.ceil(cuts[j+1]-.5)-left,1,c);}
        }
      }
      function hand(progress,open){
        // Attached to the near right cuff. Wrist and thumb move together.
        const x=between(194,193,progress),y=between(119,135,progress);
        poly(ink,194,109,202,112,205,119,x+7,y-1,x+4,y+3,x-6,y+3,x-7,y-1,194,117);
        poly(sleeve,195,111,201,113,203,119,x+5,y-2,x-4,y-2,196,116);
        poly(cuff,x-3,y-4,x+6,y-3,x+5,y,x-4,y);
        poly(skin,x-5,y-1,x+3,y-1,x+5,y+1,x+3,y+4,x-4,y+4,x-6,y+2);
        r(x-3,y,4,1,'#e8c4a1');
        for(let n=0;n<3;n++){r(x-5+n*3,y+3,2,open?4-n%2:2,skin);r(x-5+n*3,y+(open?6-n%2:4),2,1,'#94786d');}
      }
      function ticket(open,good){
        // Fan-fold paper advances beneath the physical printer lip.
        const len=Math.round(18*open);if(len<2)return;
        const d=Math.round(len*.48);poly(ink,249,144,266,143,264-d,145+len,246-d,146+len);
        poly(paper,250,143,264,142,263-d,143+len,248-d,144+len);
        for(let i=3;i<len-1;i+=3){const a=250-Math.round(i*.48);
          r(a,143+i,Math.min(9,4+(i*7)%8),1,'#938e78');r(a+11,142+i,1,1,'#a99d7f');}
        if(open>.85){let x=249-d,y=139+len;
          r(x,y,8,4,good?'#65987f':'#bb8469');r(x+2,y+1,4,1,good?'#a5c5a1':'#e7b593');}
        r(248,143,16,1,ink);
      }
      function credit(x,y,flip,stack){
        const dy=flip?2:0;
        if(stack){poly(ink,x-8,y,x+4,y-4,x+10,y,x+8,y+4,x-4,y+6,x-9,y+3);
          poly('#997a55',x-8,y+2,x+7,y-2,x+8,y+2,x-5,y+5);}
        poly(ink,x-9,y-1,x+5,y-5+dy,x+10,y-2,x+9,y+1,x-5,y+5-dy,x-10,y+2);
        poly(mint,x-8,y-1,x+5,y-4+dy,x+8,y-2,x+8,y,x-5,y+3-dy);
        poly('#82a677',x-6,y,x+5,y-3+dy,x+6,y-2,x-4,y+2-dy);
        r(x-1,y-1,3,2,till);r(x+3,y-2,2,1,paper);r(x-6,y+1,2,1,gold);
      }
      function lot(x,y,scale,opacity=1){
        if(opacity<=0)return;ctx.save();ctx.globalAlpha*=opacity;
        const side=v.buyer?v.extra:(v.includeSide?v.sideLot:null);
        const one=tile(v.lot.item),two=side&&tile(side.item),w=Math.round(32*scale);
        if(one)ctx.drawImage(one,x-(two?27:16)*scale,y-27*scale,w,w);
        if(two)ctx.drawImage(two,x+scale,y-26*scale,w,w);
        ctx.restore();
      }
      function tray(){
        // Empty jade felt dish. Space inside it stays blank until the item is laid down.
        poly('#243c41',113,130,128,124,185,124,204,133,200,141,117,143,108,139);
        poly('#839185',114,130,129,125,184,125,202,133,198,139,118,141,110,138);
        poly('#506e64',116,131,129,126,182,126,199,133,196,138,119,140,113,138);
        poly('#38564f',118,132,131,127,181,127,196,133,194,137,121,139,116,137);
        for(let i=0;i<5;i++){r(131+i*10,128,4,1,'#537168');r(125+i*12,137,4,1,'#547269');}
        r(129,125,10,1,paper);r(182,126,4,1,'#c3c9af');r(114,137,7,1,'#bac0a8');
      }
      function chevron(x,y,down,color){
        if(down){
          poly(ink,x-7,y-5,x,y-1,x+7,y-5,x+7,y,x,y+6,x-7,y);
          poly(color,x-6,y-3,x,y+1,x+6,y-3,x+6,y-1,x,y+4,x-6,y);
        }else{
          poly(ink,x+5,y-7,x+5,y-2,x+2,y,x+5,y+2,x+5,y+7,x-5,y);
          poly(color,x+4,y-5,x+4,y-3,x,y,x+4,y+3,x+4,y+5,x-3,y);
        }
      }
      if(run.day>=2&&globalThis.CounterWindow){
        const displayed=globalThis.CounterWindow.featured(run);
        // A wall-mounted shadow box sits above the stock shelf. The glass and
        // vacant velvet cushion remain visible when a displayed lot is sold.
        poly(ink,12,73,18,68,58,68,61,72,61,102,54,108,14,107,11,104);
        poly('#6f7667',13,73,19,70,58,70,59,72,53,75);
        r(13,74,40,29,'#455c52');r(15,76,37,25,'#263d3d');r(16,77,35,23,'#354d47');
        poly('#2b4542',53,75,60,72,60,100,53,104);
        poly('#9d8663',14,102,52,103,59,100,58,103,53,106,15,105);
        poly('#657664',18,100,25,96,46,95,52,98,47,101,20,102);
        r(23,99,23,1,'#87927a');r(17,76,33,1,'#b9ae85');r(21,77,25,1,'#80937f');
        if(displayed){
          const image=tile(displayed.item);if(image)ctx.drawImage(image,22,75,27,27);
          // The punch in the tiny paper price tag and its brass wire are part of the sprite.
          r(43,98,1,3,'#b7996e');poly(paper,40,101,45,100,50,103,46,106,40,104);
          r(42,101,1,1,'#9d856a');r(44,103,4,1,'#747a65');
        }else{
          poly('#6a7a68',31,94,35,92,39,94,36,96,32,96);
        }
        // Reflection lives on the glass near the edge, clear of the merchandise.
        r(16,77,1,22,'#789589');r(17,78,5,1,'#bfc3a4');r(17,79,3,1,'#88a599');
        r(53,76,1,25,'#7e9280');r(56,75,1,12,'#5f7b70');r(15,104,4,1,'#c7b494');
        if(displayed&&Math.sin(clock*.95)>.9){r(50,74,3,1,paper);r(51,73,1,3,paper);}
      }
      if(run.phase==='bell'){
        // A polished service bell occupies the inspection pad between visitors.
        poly('rgba(18,29,32,.62)',134,138,147,134,176,134,185,139,176,143,143,143);
        poly(ink,137,136,141,132,147,131,148,125,151,120,156,116,162,116,168,120,172,125,173,131,181,133,183,137,179,140,143,141,137,139);
        poly('#ad7e55',143,132,148,126,150,121,156,117,164,118,169,122,171,127,172,132,178,134,177,136,143,137);
        poly('#d9ac78',146,130,149,124,151,122,156,119,161,118,163,120,157,120,154,123,153,128,150,130);
        r(149,126,3,2,paper);r(152,122,4,2,paper);r(166,125,2,4,'#8d705b');r(145,132,27,1,'#f4d897');
        r(156,113,7,3,'#91775b');r(155,112,9,2,gold);r(158,112,4,1,paper);
        r(140,136,39,2,'#79674f');r(142,137,34,1,'#c5ab76');r(143,139,34,1,'#39423c');
        const q=Math.round(Math.sin(clock*2)*1.5);
        chevron(160,104+q,true,gold);return;
      }
      if(run.phase==='night'){
        // The bookkeeper leaves the rent envelope on the night counter.
        poly('#29383a',122,138,163,128,188,141,146,153);
        poly('#b59a78',122,136,163,127,186,139,144,150);
        poly('#e2c399',124,136,163,128,183,139,144,148);
        poly('#b79772',124,136,160,138,163,128,158,141);
        poly('#e5cba3',124,136,162,128,158,138);
        poly('#904e42',152,137,157,135,161,137,161,140,156,142,152,140);r(155,137,3,1,'#c57b58');
        const pulse=(Math.sin(clock*1.3)+1)*.04+.08;
        poly('rgba(248,187,105,'+pulse+')',104,19,120,19,185,148,99,146);return;
      }
      if(run.phase==='trade'){
        const staged=typeof trayReady==='boolean'?trayReady:(typeof globalThis.trayReady==='function'?globalThis.trayReady(v):v.staged!==false);
        if(!staged){
          tray();
          if(v.buyer){
            // The stock drawer lies below the cabinet. Leave both the tray and counter empty.
            for(let i=0;i<2;i++)chevron(158,151+i*7+Math.round(Math.sin(clock*2)*1.5),true,i===0?'#9cad96':gold);
          }else{
            // The seller sets the loose lot in a shallow cardboard transit case.
            poly(ink,202,125,217,119,238,119,247,126,246,130,219,133,202,129);
            poly('#91765c',204,125,217,120,237,120,244,126,219,131);
            poly('#bd9c73',204,125,218,121,236,121,242,125,219,129);
            lot(225,128,1.12);
            const off=Math.round(Math.sin(clock*3.2)*1.5);
            chevron(202+off,122,false,'#ffd67b');chevron(192+off,126,false,'#ffdf84');
          }
          return;
        }
        // A simple loupe pointing at the tray only on the very first unexamined offer.
        if(run.day===1&&run.turn===1&&!v.buyer&&!v.scanned&&t>.45){
          const x=185,y=123+Math.round(Math.sin(clock*3.4)*1.2);
          poly(ink,x-5,y-5,x+1,y-5,x+4,y-2,x+4,y+2,x+7,y+5,x+5,y+7,x+1,y+4,x-4,y+4,x-7,y+1,x-7,y-2);
          r(x-4,y-4,5,1,gold);r(x-6,y-2,1,3,gold);r(x+2,y-2,1,4,gold);r(x-4,y+2,5,1,gold);
          r(x-4,y-2,4,3,'#4e7d75');r(x-3,y-2,2,1,mint);r(x+3,y+3,2,2,gold);r(x+5,y+5,1,1,gold);
        }
        return;
      }
      const buying=v.ticket==='PURCHASED',selling=v.ticket==='SOLD',paid=buying||selling,tip=v.ticket==='CUSTOMS TIP';
      const reach=ease(t/.31)*(1-ease((t-1.13)/.34));
      if(reach>0&&v.ticket!=='WALKED AWAY')hand(reach,t<.77||selling);
      // Positive actions send the goods and banknote in opposite directions.
      // On a walk-away each party takes its own goods back.
      const shelf=buying||(!paid&&v.buyer),slide=ease((t-.21)/.79);
      const x=between(157,shelf?44:193,slide),y=between(135,shelf?116:124,slide)-Math.round(8*Math.sin(Math.PI*slide));
      const shrinking=1-.37*slide,fade=1-ease((t-.82)/.25);
      if(fade>0){const width=Math.max(5,Math.round(17*shrinking));
        ctx.save();ctx.globalAlpha=fade*.28;r(x-width,between(139,shelf?120:129,slide),width*2,2,ink);ctx.restore();
        lot(x,y,shrinking,fade);}
      if(paid||tip){
        const a=ease((t-.49)/.64);
        if(t>=.48&&t<1.22){
          const endX=buying?193:250,startX=buying?250:193;
          const cx=between(startX,endX,a),cy=between(buying?141:132,buying?132:141,a)-Math.round(8*Math.sin(Math.PI*a));
          credit(cx,cy,a>.4&&a<.58,Math.abs(v.tender||0)>=45);
        }
        if(t>1.03&&t<1.36){const d=Math.round((t-1.03)*21),xx=buying?194:251,yy=buying?132:139;
          r(xx-6-d,yy-3-d,2,1,gold);r(xx+6+d,yy-d,2,1,mint);r(xx,yy-6-d,1,2,paper);}
      }
      ticket(ease((t-(paid?.90:.60))/.4),paid||tip);
    }finally{ctx.restore();}
  }
  return Object.freeze({draw});
})();
