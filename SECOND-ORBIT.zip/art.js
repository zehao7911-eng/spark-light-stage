/* Second Orbit. Hand-pixelled counter, customers and appraisal sprites.
   All silhouettes are scan converted on the same integer grid. */
window.CounterArt = (() => {
  const W=320,H=185, ink='#121827', deep='#212532', brass='#c4874f', gold='#f2c378', aqua='#7ce2d0', cream='#ffe2a8';
  const sprites=new Map(),rooms=new Map();
  const sheet=(w,h)=>Object.assign(document.createElement('canvas'),{width:w,height:h});
  const glyphs={
    A:'27255',B:'65656',C:'34443',D:'65556',E:'74647',F:'74644',G:'34553',H:'55755',I:'72227',J:'11152',K:'55655',L:'44447',M:'57755',N:'57775',O:'25552',P:'65644',Q:'25573',R:'65655',S:'34216',T:'72222',U:'55557',V:'55552',W:'55775',X:'55255',Y:'55222',Z:'71247','0':'75557','1':'26227','2':'71247','3':'71217','4':'55711','5':'74617','6':'74757','7':'71122','8':'75757','9':'75717','-':'00700','.':'00002'
  };
  function pen(ctx) {
    function rect(x,y,w,h,color){ctx.fillStyle=color;ctx.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));}
    function poly(color,...v){
      let min=v[1],max=min;for(let j=3;j<v.length;j+=2){min=Math.min(v[j],min);max=Math.max(v[j],max);}
      ctx.fillStyle=color;
      for(let y=Math.ceil(min);y<max;y++){const cuts=[],py=y+.5;
        for(let i=0,p=v.length-2;i<v.length;p=i,i+=2){const a=v[p+1],b=v[i+1];if((a>py)===(b>py))continue;cuts.push(v[p]+(py-a)*(v[i]-v[p])/(b-a));}
        cuts.sort((a,b)=>a-b);for(let i=0;i<cuts.length;i+=2){let x=Math.ceil(cuts[i]-.5);ctx.fillRect(x,y,Math.ceil(cuts[i+1]-.5)-x,1);}
      }
    }
    function oval(x,y,rx,ry,color){
      ctx.fillStyle=color;
      for(let i=-ry;i<ry;i++){const d=Math.sqrt(Math.max(0,1-((i+.5)/ry)**2))*rx;ctx.fillRect(Math.round(x-d),y+i,Math.max(1,Math.round(2*d)),1);}
    }
    function line(x,y,ex,ey,color,w=1){
      const dx=Math.abs(ex-x),dy=-Math.abs(ey-y),sx=x<ex?1:-1,sy=y<ey?1:-1;let err=dx+dy;
      for(;;){rect(x,y,w,w,color);if(x===ex&&y===ey)break;const e=2*err;if(e>=dy){err+=dy;x+=sx;}if(e<=dx){err+=dx;y+=sy;}}
    }
    function word(x,y,s,c,n=1){for(const ch of s){const v=glyphs[ch];if(v)for(let k=0;k<5;k++)for(let j=0;j<3;j++)if(+v[k] & 4>>j)rect(x+j*n,y+k*n,n,n,c);x+=4*n;}}
    function screw(x,y){rect(x,y,3,2,'#69675c');rect(x,y,1,1,'#c8b398');rect(x+1,y+1,1,1,ink);}
    return{r:rect,p:poly,o:oval,l:line,w:word,s:screw};
  }
  function iconSheet(id){
    if(id===12&&globalThis.WaterArt){if(!sprites.has(12)){const bottle=sheet(32,32);WaterArt.icon(bottle,2);sprites.set(12,bottle);}return sprites.get(12);}
    id=((id|0)%12+12)%12;if(sprites.has(id))return sprites.get(id);
    const c=sheet(32,32),{r,p,o,l}=pen(c.getContext('2d'));
    const dark='#202c3f',mid='#657580',glint='#d5dbb3',steel='#899f9e',cold='#45839a',purple='#ad81a1',rust='#a25e48';
    if(id===0){ // faceted glass cell in stamped metal end caps
      p(ink,7,7,12,3,21,3,25,7,25,25,21,29,10,29,7,25);r(9,9,14,15,cold);r(11,9,3,14,'#286675');r(14,10,5,12,aqua);r(15,11,2,9,'#d5fff0');
      for(const y of [5,23]){r(9,y,14,3,brass);r(11,y,10,1,gold);r(8,y+3,16,2,dark);r(19,y+1,3,2,rust);}r(14,3,5,2,steel);r(20,11,1,8,glint);
    }else if(id===1){ // winding with ferrite flanges
      p(ink,3,13,8,7,22,5,29,12,28,20,22,25,10,27,3,21);p(mid,4,14,9,9,14,13,14,22,10,25,5,20);
      for(let k=0;k<5;k++){let x=10+k*3,y=12-(k>>1);p(rust,x-2,y,x+1,y-3,x+4,y,x+4,y+9,x+1,y+12,x-2,y+9);l(x,y-1,x+2,y,gold);r(x,y+2,2,8,brass);}
      r(24,8,3,2,steel);l(26,10,28,14,glint);r(5,16,5,3,dark);
    }else if(id===2){o(16,17,14,12,ink);o(16,16,12,10,brass);o(16,16,10,9,dark);o(16,16,8,7,cold);o(17,17,6,5,'#39566e');p(aqua,9,15,15,10,18,10,10,18);r(18,19,3,2,'#db99a7');for(let i=0;i<3;i++)r(5+i*3,22+i,2,2,gold);
    }else if(id===3){p(ink,5,10,8,8,14,8,15,2,17,2,17,8,25,8,28,12,26,27,5,27);r(7,11,18,13,steel);r(8,12,14,6,dark);r(9,13,10,3,aqua);for(let k=0;k<5;k++)r(9+k*2,20,1,3,dark);r(20,20,4,3,brass);r(8,8,5,2,brass);l(15,8,18,2,steel);
    }else if(id===4){p(ink,2,7,11,4,19,8,28,5,30,24,20,28,11,24,4,27);p('#b28e6b',4,9,11,6,12,22,5,24);p(cream,11,6,19,10,20,25,12,22);p('#779c92',19,10,27,7,28,22,20,25);l(7,17,12,12,cold);l(12,12,19,19,cold);l(19,19,25,13,cold);r(24,12,2,2,cream);
    }else if(id===5){p(ink,10,2,21,2,23,10,24,22,20,30,10,30,9,23,7,17,9,8);r(12,3,7,25,rust);o(16,16,10,10,brass);o(16,16,8,8,dark);o(16,16,6,6,'#3e7070');l(16,16,16,11,glint);l(16,16,20,18,gold);r(25,14,2,4,gold);
    }else if(id===6){p(ink,6,13,12,10,12,5,15,2,21,2,23,6,23,13,27,17,26,26,8,28,5,24);o(17,8,5,5,steel);r(13,7,8,11,cold);r(15,5,2,10,glint);p(mid,7,17,21,14,25,17,11,21);p('#455466',7,17,11,21,11,25,7,23);p(brass,11,21,25,17,24,24,11,26);r(15,20,3,3,dark);
    }else if(id===7){p(ink,4,9,11,4,18,6,21,12,20,15,29,22,26,28,21,27,20,24,16,24,14,19,7,20,3,16);o(12,12,7,6,brass);o(12,12,3,3,dark);p(gold,15,15,18,14,27,23,25,25);r(22,23,2,3,brass);r(19,21,2,3,brass);
    }else if(id===8){l(7,9,24,20,steel,2);l(6,21,25,8,steel,2);for(const [x,y] of [[6,8],[25,8],[5,22],[25,21]]){o(x,y,5,3,dark);o(x,y-1,4,2,steel);r(x-1,y-1,2,2,ink);}p('#60838e',10,12,15,9,21,12,21,18,16,22,11,18);o(16,15,4,3,ink);r(14,14,4,2,aqua);
    }else if(id===9){p(ink,5,19,11,6,20,2,25,8,27,19,17,29,9,27);p('#605888',7,19,13,7,19,4,16,19,12,25);p('#b78dad',19,4,24,9,23,18,16,23,16,19);p(cold,23,18,25,18,16,27,12,25,16,23);l(15,10,19,5,'#f6c3bf');l(8,19,12,24,aqua);
    }else if(id===10){p(ink,3,12,16,6,28,11,29,23,16,28,3,23);p('#61616d',5,12,16,8,26,12,15,16);p('#4b4258',15,16,26,12,26,21,15,25);p('#354254',5,12,15,16,15,25,5,21);l(10,11,20,15,brass,2);l(20,15,20,22,brass,2);r(6,16,2,2,'#ec986a');r(9,18,2,1,aqua);
    }else{p(ink,6,28,8,22,10,20,8,14,8,8,11,3,14,7,19,7,23,3,25,9,24,16,21,20,24,27);p(brass,10,9,12,6,15,10,20,9,23,6,22,15,19,19,13,18,10,15);r(12,12,3,2,aqua);r(18,12,3,2,aqua);r(15,15,3,2,rust);p('#9b6753',13,19,19,20,22,25,9,25);r(8,26,16,2,gold);}
    sprites.set(id,c);return c;
  }
  function backdrop(day){
    const variant=(day-1+6)%6;
    if(rooms.has(variant))return rooms.get(variant);
    const room=sheet(W,H),ctx=room.getContext('2d'),{r,p,o,l,w,s}=pen(ctx);
    const wall='#294845',wallHi='#446057',goldShadow='#795844',panel='#1e3337',pipe='#556862';
    r(0,0,W,H,'#162032');
    // Vista through the station's band of reinforced observation glass.
    const sky=['#24283e','#302943','#252e47','#2b2b46','#28283d','#392d46'][variant];
    r(64,4,197,114,sky);
    for(let n=0;n<57;n++){const x=68+(n*67%184),y=4+(n*31%89);r(x,y,n%8===0?2:1,1,n%6?'#575971':'#ac9598');}
    const moonx=213-variant*4;
    o(moonx,27,22,21,'#9f7b83');o(moonx-4,23,17,16,'#cf9e91');o(moonx-7,20,10,9,'#d9ae96');
    for(let j=0;j<8;j++){const y=15+j*3,x=moonx-17+(j%3)*5;r(x,y,10+(j%4)*3,1,'#bb9290');}
    p('#716579',moonx-32,39,moonx-23,34,moonx+22,17,moonx+31,15,moonx+24,19,moonx-23,38);
    l(moonx-27,38,moonx+25,17,'#d4b59e');l(moonx+21,18,moonx+31,15,'#b5a1a0');
    for(let j=0;j<22;j++){
      const x=62+j*9,y=52+(j*17%32),h=114-y;
      r(x,y,8,h,j%2?'#34394c':'#393b51');r(x+2,y-3,j%4+2,4,'#383b50');
      for(let k=0;k<4;k++)if((j+k)%3)r(x+2,y+4+k*6,3,1,(j+k)%5?'#565467':'#9e7b76');
    }
    for(let j=0;j<10;j++){
      const x=62+j*20,y=70+(j*29%33);r(x,y,15,117-y,'#263345');r(x+1,y+2,2,17,'#3a4853');
      for(let k=0;k<3;k++){r(x+6,y+4+k*4,3,1,'#77827e');r(x+11,y+4+k*4,2,1,'#495865');}
    }
    for(const x of [74,246]){r(x,2,4,117,'#1a2936');r(x+2,2,1,117,'#52645f');}
    // A high station gantry cuts across the distant skyline.
    l(72,75,247,57,'#474656',2);l(73,82,247,64,'#363b48',2);
    for(let i=0;i<11;i++){const x=77+15*i,y=75-(i*3>>1);l(x,y,x+6,y+5,'#4b4856');l(x+6,y+5,x+12,y-1,'#4b4856');}
    // Enamel wall plates, top conduits and flaking primer.
    r(0,0,66,119,wall);r(255,0,65,119,wall);
    p(wallHi,0,0,320,0,320,7,250,7,241,14,78,14,65,7,0,7);
    p('#1c3134',0,0,320,0,320,4,248,4,239,10,80,10,72,5,0,5);
    for(const x of [65,249]){r(x,11,7,109,ink);r(x+2,11,4,107,'#51665c');r(x+5,11,2,109,'#334647');}
    for(const x of [0,289]){r(x,3,28,4,pipe);r(x,3,29,1,'#708076');for(let j=0;j<3;j++)r(x+j*11,2,3,7,panel);}
    for(const x of [36,269]){
      let y=3;for(let i=0;i<26;i++){const ny=3+Math.floor(6*(1-Math.pow((i-12)/13,2)));
        l(x+i,y,x+i+1,ny,ink,2);y=ny;}
    }
    r(70,109,180,12,'#243937');r(70,110,180,2,'#638275');r(70,114,180,3,'#344c49');
    // Weathered, hand-lettered enamel hanging sign. Its warm field balances the dark shelf.
    p(ink,4,13,52,9,63,13,63,42,55,47,5,48);p('#956949',6,15,53,11,61,14,61,40,54,44,6,45);
    p('#d9a567',8,16,54,13,58,16,58,39,53,41,8,43);
    r(13,18,40,1,'#9e694c');r(12,38,39,1,'#97674c');w(13,21,'SECOND','#4e3840');w(12,27,'ORBIT','#382d38',2);
    for(const [x,y] of [[7,15],[56,14],[7,41],[55,39]])s(x,y);
    // Intercom and shop statements pinned to a perforated metal board.
    r(4,50,56,51,ink);r(6,52,53,47,'#364a48');
    for(let y=55;y<98;y+=5)for(let x=9;x<57;x+=5)r(x,y,1,1,'#253a3b');
    r(9,56,19,29,'#897665');r(9,57,17,24,'#c6ae88');w(11,60,'LOT','#634f46');r(13,68,8,5,'#847f70');r(12,74,12,1,'#8e7e63');r(13,78,9,1,'#8e7e63');r(17,55,4,3,brass);
    p('#a06054',27,69,46,66,47,88,29,90);p('#d28d6e',29,70,43,68,44,85,30,87);w(31,73,'06',ink);r(32,81,8,1,rustColor());r(34,68,3,2,gold);
    r(45,48,16,21,ink);r(47,50,12,17,'#697771');for(let y=53;y<61;y+=3)r(49,y,8,1,'#34494a');r(49,63,3,2,aqua);
    // Right ribbed rack with boxed stock, speaker, labels and glassware.
    r(257,10,61,105,ink);r(260,12,55,101,'#53635a');r(263,16,49,94,'#232e35');
    for(const y of [31,57,81,106]){r(261,y,53,3,'#5e6e61');r(261,y,53,1,'#a39a78');r(263,y+3,49,3,'#161f2b');}
    w(267,21,'SPECIAL','#809e89');for(let i=0;i<5;i++){let x=265+i*9;r(x,39+i%3,7,17-i%3,[goldShadow,'#59635b','#747260'][i%3]);r(x+1,40+i%3,5,2,'#aea387');r(x+2,49,3,3,i%2?'#87a69a':brass);}
    for(const [x,y,cl] of [[266,66,'#598580'],[276,63,'#b7816c'],[288,69,'#769587'],[300,65,'#ad9d79']]){
      r(x+2,y-3,3,4,'#959784');r(x+1,y,5,2,cl);r(x,y+2,7,79-y-2,cl);r(x+1,y+3,1,5,'#c2c3a6');r(x+1,75,5,3,'#405252');}
    for(let j=0;j<3;j++){let x=265+j*15;r(x,90-j%2,13,15+j%2,j%2?'#766450':'#506964');r(x,91,13,2,'#aca283');r(x+2,97,5,3,'#b8b395');r(x+9,95,2,9,'#454e4e');}
    for(const xx of [258,313]){for(let yy=15;yy<113;yy+=22)s(xx,yy);}
    // Narrow suspended amber lamp. Bare pins cast a triangular shaft of light.
    r(109,0,2,12,ink);r(110,3,1,9,'#87745c');p('#39463f',102,14,107,10,115,10,121,15,120,18,102,18);r(103,16,17,2,gold);r(107,18,9,1,cream);
    p('rgba(248,192,108,.035)',104,19,119,19,149,97,80,97);
    for(const xx of [3,309]){for(let k=0;k<3;k++){r(xx+k,108-k*2,4,1,'#788275');}}
    // Air hoses terminate at the aperture clamp, with a small pressure gauge.
    for(let j=0;j<2;j++){
      const y=92+j*4;l(0,y,15,y,'#112a2e',3);l(15,y,20,y+4,'#112a2e',3);l(20,y+4,38,y+4,'#112a2e',3);
      l(0,y,15,y,'#7b7a66');l(20,y+4,38,y+4,'#626e61');
    }
    o(47,103,8,8,'#17292d');o(47,102,7,7,'#8a8b76');o(47,102,5,5,'#d1c096');
    l(47,103,50,99,'#8d574d');r(46,102,2,2,ink);r(42,101,2,1,'#5b625a');r(49,104,2,1,'#5b625a');
    w(83,17,'D-08','#546269');r(82,24,17,1,'#414954');
    for(const [x,y] of [[66,23],[254,91],[65,60],[257,50]]){r(x,y,4,2,'#927f62');r(x+1,y,1,1,'#d0ae7e');}
    rooms.set(variant,room);return room;
  }
  function rustColor(){return '#895b52';}
  const clothes=[
    ['#573c40','#a85f45','#de8d59','#efd098'],
    ['#273d44','#46635f','#819178','#e6ae73'],
    ['#384359','#677789','#9faab0','#bde6d1'],
    ['#41394b','#675163','#ac8585','#d9b787'],
    ['#443548','#6e506f','#aa8198','#f6d59e'],
    ['#333a41','#4c6265','#84968a','#e8ac66'],
    ['#3b364d','#5c5370','#968399','#efbe88'],
    ['#283e47','#436369','#80918a','#f1ac7c']
  ];
  function portrait(context,n,t,mood){
    const {r,p,o,l,w}=pen(context),[shade,base,light,accent]=clothes[n];
    const happy=mood==='happy',angry=mood==='angry',inspect=mood==='inspect';
    const bob=Math.round(Math.sin(t*2.05+n)*.75)+(happy?-1:0),lean=angry?-2:inspect?2:0;
    // Back layer. A different outer silhouette for each guild.
    context.save();context.translate(165+lean,125+bob);
    if(n===0){p(ink,-20,-41,-38,-39,-43,-22,-39,-4,-19,-1);p('#715144',-24,-37,-35,-35,-40,-21,-37,-8,-26,-6);for(let y=-32;y<-12;y+=5)r(-36,y,8,2,'#ae8661');}
    if(n===1){for(let i=0;i<5;i++)p('#99a38a',-18-i*2,-65+i*7,-29-i*2,-68+i*8,-23-i*2,-59+i*8);}
    if(n===4){ // silk moth wings, eye-spots and ribbing
      for(const a of [-1,1]){context.save();context.scale(a,1);
        p(ink,15,-35,37,-65,51,-74,53,-70,50,-42,45,-20,33,-8,17,-7);
        p('#796174',20,-35,39,-61,49,-69,48,-48,40,-24,29,-14);
        p('#b7868e',25,-30,42,-59,48,-66,43,-48,35,-34);o(42,-50,5,6,'#4c475b');o(42,-50,2,3,'#d8b5a2');
        for(let i=0;i<3;i++)l(23,-23,43-i*4,-44+i*2,'#ae858b');context.restore();}
    }
    // Tailored jackets. Layered shoulder panel, collar, harness and seams.
    p(ink,-14,-49,9,-49,16,-43,25,-40,34,-34,41,-18,44,-3,39,4,-40,4,-44,-4,-40,-23,-33,-36,-19,-41);
    p(shade,-13,-46,10,-46,19,-40,31,-35,37,-23,40,-8,35,0,-38,0,-41,-8,-36,-27,-27,-35,-17,-38);
    p(base,-15,-41,5,-40,19,-37,28,-34,25,-27,22,-16,22,-1,-26,-1,-25,-21,-31,-29,-24,-35);
    p(light,-28,-33,-19,-37,-12,-38,-13,-34,-22,-31,-27,-21,-34,-23);r(-33,-23,4,2,accent);
    p(base,23,-34,31,-31,36,-21,38,-11,32,-10,27,-19,22,-22);
    l(-33,-19,-28,-16,shade);l(29,-24,34,-20,light);l(29,-8,35,-9,shade);
    p(ink,-14,-43,-8,-46,8,-45,18,-38,11,-27,2,-31,-7,-29,-16,-36);
    p(light,-15,-40,-8,-43,0,-37,-6,-31,-11,-35);p(shade,1,-37,10,-43,17,-38,11,-31);
    l(-7,-29,-1,-21,light);l(-2,-22,-1,-2,shade);r(0,-20,1,18,light);
    // Per-character equipment reads as a silhouette, not just a palette swap.
    if(n===0||n===6){p(ink,-23,-35,-18,-38,15,-5,12,0,7,-1);p('#75694f',-22,-34,-18,-35,14,-5,10,-2);l(-16,-32,9,-7,'#bc9b67');
      r(-7,-24,8,6,ink);r(-6,-23,6,4,gold);r(-4,-22,3,2,'#59665b');}
    if(n===1||n===5){p('#9a825b',-19,-39,-14,-39,-9,-21,-7,0,-13,0,-15,-21);p('#8f775d',12,-39,17,-37,14,-24,13,-2,6,-1);
      r(-15,-22,28,16,shade);r(-12,-20,22,2,light);r(-10,-15,10,7,base);r(-9,-15,8,1,accent);}
    if(n===2){for(let j=0;j<4;j++){p(j%2?shade:light,-17,-23+j*5,1,-19+j*5,18,-24+j*5,17,-21+j*5,1,-16+j*5,-16,-19+j*5);}r(-1,-22,5,5,ink);r(0,-21,3,3,aqua);}
    if(n===3||n===7){p(light,-17,-44,-24,-40,-12,-22,-2,-16,-6,-33);p(base,11,-44,25,-41,16,-28,3,-16,6,-33);
      for(let j=0;j<3;j++){r(-2,-16+j*5,3,2,brass);r(0,-16+j*5,1,1,gold);}}
    if(n===4){o(0,-32,13,9,'#c9af9d');p('#8b7280',-12,-31,-5,-28,1,-30,7,-28,12,-32,10,-26,4,-23,-4,-24);}
    r(9,-26,7,4,shade);r(10,-26,5,1,accent);
    for(let k=0;k<3;k++)r(-25+k*3,-13+(k%2),2,2,light);
    // Sewn pockets, battered piping, serial patches and wrist hardware.
    l(-37,-19,-34,-22,light);l(-36,-17,-32,-20,base);l(30,-18,34,-15,shade);
    l(14,-17,21,-18,shade);r(13,-16,8,1,light);r(13,-15,1,3,light);r(19,-16,1,2,accent);
    if(n===0||n===6){l(16,-30,22,-31,accent);r(20,-29,4,2,'#65464a');r(15,-28,4,1,'#e2c797');}
    if(n===1){l(-34,-26,-29,-29,gold);l(-32,-24,-26,-28,shade,2);}
    if(n===5){r(-16,-22,3,8,brass);r(-16,-23,4,2,gold);r(-9,-19,2,4,aqua);}
    // Portrait root follows the motion of the torso while the counter stays still.
    context.save();context.translate(0,Math.round(inspect?2:Math.sin(t*1.4+n)*.55));const blink=((t+1.7*n)%4.8)>.0&&((t+1.7*n)%4.8)<.13;
    if(n===0||n===3||n===6){
      const skin=[['#89524b','#cf8a71','#ecaf88'],['#8d665d','#b99580','#d9b99c'],['#804b43','#ba715e','#de9376']][n===0?0:n===3?1:2];
      const hair=n===3?'#d6c9ae':n===6?'#963e3c':'#513a40',hairShadow=n===3?'#807b7e':n===6?'#623942':'#352e39';
      p(ink,-19,-75,-10,-84,6,-86,16,-80,22,-68,21,-53,13,-44,3,-38,-9,-39,-18,-48,-23,-59);
      p(skin[0],-17,-73,-8,-80,7,-81,16,-75,19,-67,18,-57,14,-47,4,-40,-5,-41,-14,-49,-17,-60);
      p(skin[1],-11,-76,1,-80,11,-75,15,-69,16,-60,19,-57,16,-54,13,-53,12,-48,4,-44,-3,-44,-10,-50,-12,-60);
      p(skin[2],1,-75,9,-73,13,-69,11,-64,3,-65,-3,-67);p(skin[2],10,-62,13,-61,17,-57,14,-56,11,-57);
      p('#ab6d60',-9,-56,-4,-57,2,-54,-2,-52,-7,-53);o(-15,-59,4,6,skin[0]);r(-16,-61,3,5,skin[1]);
      l(-5,-65,1,-66,hairShadow,2);l(9,-66,15,-65,hairShadow);
      if(!blink){r(-4,-62,7,2,ink);r(-3,-62,3,1,cream);r(0,-62,2,2,n===6?'#a6d6b9':ink);r(9,-62,6,2,ink);r(10,-62,2,1,cream);}
      else{r(-4,-60,6,1,ink);r(10,-60,5,1,ink);}
      if(angry){l(-5,-66,1,-64,hairShadow,2);l(10,-64,15,-66,hairShadow);}
      l(6,-51,12,-51+(happy?-2:0),'#7a4846');r(8,-49,4,1,skin[2]);
      if(happy){p('#794b4c',3,-52,7,-51,15,-53,13,-49,7,-48);r(7,-51,5,1,cream);}
      if(angry){l(-7,-64,-2,-62,skin[0]);l(4,-51,11,-53,'#68444a');}
      p(hairShadow,-20,-72,-15,-81,-7,-87,4,-87,12,-83,17,-77,12,-73,6,-76,-4,-71,-8,-65,-14,-63,-18,-56,-20,-61);
      p(hair,-18,-75,-12,-82,-3,-85,8,-83,14,-78,6,-80,-2,-76,-10,-72,-14,-65,-17,-65);
      if(n===0){
        p(ink,-22,-63,-23,-74,-17,-83,-8,-89,5,-91,14,-87,19,-80,18,-75,7,-78,-7,-76,-17,-67);
        p('#b36649',-21,-71,-17,-79,-8,-86,3,-88,12,-85,17,-79,13,-78,4,-81,-7,-78,-16,-70,-17,-64,-21,-62);
        p('#e39b61',-16,-78,-8,-84,1,-86,9,-84,3,-84,-4,-81,-12,-76);
        p('#365556',-19,-69,-13,-76,-1,-81,10,-81,15,-78,13,-74,3,-76,-7,-73,-15,-67);
        p('#79b9a4',-14,-73,-4,-78,2,-79,-1,-76,-11,-71);r(4,-79,5,1,'#d6dfbb');
        o(-17,-61,6,8,ink);o(-18,-61,4,6,brass);r(-19,-64,2,6,cream);l(-17,-54,-12,-48,shade,2);
        for(const [x,y] of [[-6,-56],[-3,-55],[0,-57],[12,-55]])r(x,y,1,1,hair);
      }else if(n===3){o(-16,-79,7,7,hairShadow);o(-17,-81,6,5,hair);l(-16,-85,-9,-84,cream);
        for(const x of [-5,10]){o(x+2,-61,6,5,brass);o(x+2,-61,4,3,'#4a6064');r(x,-63,3,1,'#cae4ce');}r(1,-62,6,1,gold);
        l(-11,-54,-6,-52,skin[0]);l(-9,-51,-4,-49,skin[0]);r(-15,-53,2,3,gold);
      }else{p('#b75442',-18,-76,-14,-85,1,-91,16,-88,22,-81,13,-80,18,-76,9,-75,1,-69,-5,-66,-2,-72,-12,-67);
        p('#de7753',-13,-81,1,-88,13,-86,3,-84,-6,-79,-11,-77);p(hairShadow,-19,-72,-16,-62,-14,-51,-19,-47,-23,-51,-22,-61);
        r(-16,-57,3,5,brass);r(-15,-56,1,3,cream);l(4,-58,7,-54,skin[2]);}
    }else if(n===1){ // amber-eyed crocodilian spacer
      p(ink,-21,-72,-13,-80,0,-81,13,-77,21,-68,29,-65,31,-59,28,-51,21,-47,8,-44,0,-39,-13,-41,-23,-51,-26,-64);
      p('#547b72',-23,-68,-12,-78,-2,-79,12,-75,18,-66,26,-63,28,-57,24,-52,12,-48,1,-43,-10,-44,-19,-50,-23,-59);
      p('#81a189',-15,-72,-6,-77,3,-76,12,-72,15,-66,10,-64,1,-65,-6,-62,-14,-64);
      p('#9cb39b',1,-62,14,-64,26,-61,26,-57,22,-55,11,-55,4,-53,-4,-55);
      l(22,-61,25,-60,ink,2);l(-3,-50,21,-54,ink,2);p(cream,15,-53,19,-54,18,-49);
      o(3,-67,7,4,ink);o(4,-67,5,blink?1:3,gold);r(4,-69,1,4,ink);l(-3,-72,7,-71,shade,2);
      for(let k=0;k<6;k++){let x=-17+(k%3)*4,y=-61+(k>>1)*3;r(x,y,2,2,'#8eaa91');}
      p('#935849',-20,-74,-15,-81,-2,-84,9,-82,13,-78,5,-77,-5,-79,-17,-72);l(-18,-76,4,-81,gold);p(brass,-19,-75,-26,-69,-23,-66,-16,-71);
    }else if(n===2||n===5){
      const metal=n===2?'#c9c4ab':'#a48260',side=n===2?'#829491':'#745c52';
      p(ink,-22,-77,-13,-85,8,-85,19,-78,23,-65,20,-48,10,-42,0,-38,-12,-43,-21,-52,-25,-65);
      p(side,-21,-75,-11,-82,8,-82,17,-76,20,-64,18,-51,8,-45,0,-42,-12,-46,-18,-54,-21,-63);
      p(metal,-14,-76,-6,-81,8,-80,15,-75,18,-65,13,-56,12,-49,3,-44,-5,-46,-13,-58);
      p('#dae0c3',-12,-76,-6,-79,5,-79,12,-75,5,-76,-3,-76,-9,-71);
      if(n===2){
        p('#6d7d81',-14,-69,-6,-68,0,-64,7,-67,17,-69,17,-61,10,-58,5,-59,0,-56,-7,-58,-13,-62);
        p(ink,-12,-66,-5,-66,1,-61,-4,-60,-12,-62);p(ink,5,-62,11,-66,17,-66,15,-62,10,-60);
        l(-10,-63,-4,-62,blink?side:aqua);l(7,-62,14,-64,blink?side:aqua);p(side,-1,-60,2,-62,5,-55,2,-52,-2,-53);
        for(let j=0;j<3;j++)r(-3+j*3,-49,2,1,ink);r(-18,-68,4,12,ink);r(-17,-65,1,7,brass);l(13,-77,16,-73,cream);
      }else{
        p('#504b51',-19,-75,-14,-77,16,-75,20,-69,17,-57,-10,-56,-16,-61);
        p(ink,-14,-71,13,-72,16,-69,13,-60,-9,-60,-13,-63);p('#4a6c73',-9,-68,12,-69,11,-64,-8,-63);
        l(-7,-65,2,-68,'#a3d6bc');r(5,-66,5,1,aqua);for(let j=0;j<3;j++)r(-5+j*4,-52,2,4,ink);
        r(-23,-68,6,11,brass);r(-23,-68,6,2,cream);l(-10,-76,12,-76,brass);l(8,-77,11,-80,cream);
      }
    }else if(n===4){
      for(const d of [-1,1]){
        l(d*8,-74,d*14,-84,'#87728c',2);l(d*14,-84,d*23,-88,'#bf9d9c',2);
        for(let j=0;j<5;j++)l(d*(13+j*2),-82-j,d*(15+j*2),-88-j,'#c8aea3');
      }
      p(ink,-20,-69,-14,-77,-4,-76,1,-78,12,-77,19,-68,19,-57,12,-47,3,-41,-5,-43,-17,-51,-22,-61);
      p('#ba99a4',-18,-68,-12,-74,0,-73,12,-74,17,-66,16,-57,8,-47,0,-43,-9,-48,-16,-54,-19,-62);
      p('#dcc0aa',-11,-73,-3,-75,5,-73,9,-69,3,-62,2,-54,-2,-50,-7,-56);
      for(const x of [-11,11]){o(x,-62,7,8,'#474053');o(x,-62,5,blink?1:6,'#625075');r(x-2,-66,3,2,'#d3d2be');r(x+1,-61,2,2,'#a09eab');}
      p('#796078',-4,-52,3,-52,1,-48,-1,-47);r(-3,-47,5,1,'#edd1bb');
    }else{
      p(ink,-21,-69,-14,-79,-3,-85,8,-84,16,-78,22,-70,21,-60,15,-51,12,-41,6,-39,0,-43,-7,-38,-14,-41,-17,-54,-24,-60);
      p('#bc7364',-19,-68,-11,-78,0,-82,9,-80,17,-74,20,-67,18,-61,12,-55,8,-44,4,-43,-1,-49,-6,-42,-10,-41,-12,-52,-18,-57,-21,-62);
      p('#e29a78',-15,-70,-10,-76,0,-80,9,-77,16,-71,14,-65,7,-63,0,-65,-7,-64);
      for(let i=0;i<4;i++){const x=-13+i*7,wig=Math.round(Math.sin(t*2+i)*2);p('#b06c6c',x,-56,x+6,-58,x+6,-47,x+4+wig,-42-i%2*4,x+wig,-41-i%2*4,x+1,-47);r(x+2,-52,2,5,'#d68b78');}
      p(ink,-18,-65,-13,-67,13,-66,18,-64,15,-59,-6,-57,-14,-59);l(-10,-62,12,-63,'#af979a');r(4,-64,7,2,angry?'#fa9577':aqua);
      for(let i=0;i<3;i++)r(-10+i*6,-71-(i%2)*3,2,2,'#f1aa86');
    }
    context.restore();
    // Cuffed hands grasp the lip of the sales counter.
    for(const side of [-1,1]){
      const x=side*(n===1?30:26),dy=happy&&side===1?-3:0;
      p(ink,x-8,-6+dy,x-4,-11+dy,x+4,-10+dy,x+9,-5+dy,x+8,1+dy,x-7,1+dy);
      r(x-7,-6+dy,14,5,shade);r(x-5,-8+dy,10,3,light);for(let j=0;j<3;j++)r(x-5+j*4,-3+dy,3,4,n===1?'#8da98d':n===2?'#c6bfa8':'#bc9278');
    }
    context.restore();
  }
  function counter(ctx,stock,item,t,scan,mood,closed,extra){
    const {r,p,o,l,w,s}=pen(ctx);
    // Walnut-edged stainless counter; beveled shoulders and inset magnetic mat.
    p(ink,0,124,48,117,267,117,320,123,320,185,0,185);
    p('#6e766b',0,125,49,119,266,119,320,125,320,163,0,163);
    p('#879287',0,126,49,120,264,120,319,126,319,128,0,128);
    p('#586565',0,129,320,129,320,152,0,152);r(0,151,320,3,'#829081');
    p('#34454b',0,149,74,135,82,136,6,152);p('#9a9983',8,150,66,140,69,140,15,150);
    p('#486164',222,125,277,126,300,137,242,135);
    r(0,154,320,5,'#354342');r(0,155,320,2,'#a28a69');r(0,158,320,3,'#514a42');
    r(0,161,320,24,'#23333a');r(3,164,314,19,'#34494a');
    for(let j=0;j<5;j++){let x=j*63+5;r(x,165,58,16,'#2a3d40');r(x+2,166,55,1,'#51615b');for(let k=0;k<5;k++)r(x+6+k*5,171,3,5,'#1c3033');s(x+51,177);}
    w(150,172,'ORBITAL SALVAGE','#8e9a83');r(148,169,67,1,'#687469');
    // Waiting stock stands on a small two-tier glass display at the left.
    p(ink,3,113,39,108,76,112,76,131,43,137,3,133);
    p('#506560',5,114,38,110,73,113,42,119);p('#273f43',5,115,43,120,43,133,5,130);p('#324d4b',43,120,74,114,74,129,43,134);
    const shelf=stock.filter(a=>Number.isInteger(a)&&a>=0&&a<12).slice(-5);
    shelf.forEach((v,i)=>{let x=6+i*11;ctx.drawImage(iconSheet(v),x,101+(i%2)*2,18,18);});
    l(4,117,43,122,'#7b9f96');l(43,122,74,116,'#72a296');r(4,117,2,15,'#547471');r(42,122,2,12,'#75978a');r(72,117,2,13,'#5b7c76');l(6,129,43,134,'#6f8374');
    // Embedded appraisal turntable and a stack of docket slips.
    p(ink,98,133,113,124,208,124,225,141,220,150,89,150,89,144);
    p('#53675f',100,134,114,125,206,125,222,140,216,147,93,147,93,144);
    p('#344c4d',102,134,116,127,204,127,218,140,212,144,97,144);
    o(157,137,33,6,'#233a40');o(157,136,29,4,'#506a63');o(157,136,23,3,'#344c4d');
    for(const [x,y] of [[101,140],[112,130],[197,130],[207,141]]){r(x,y,4,1,'#71c3b0');r(x,y,1,2,'#71c3b0');}
    r(190,146,14,1,'#8f9682');r(207,146,6,1,brass);
    for(let i=0;i<2;i++){p(i?'#d4c09b':'#a49982',64+i*2,143-i*2,82+i*2,141-i*2,88+i*2,149-i*2,68+i*2,152-i*2);}
    l(70,144,81,143,'#8b8a79');r(75,146,8,1,'#96927c');
    if(!closed&&item!=null&&item>=0){
      const itemY=mood==='happy'?Math.round(Math.sin(t*8)*1.5):0;
      ctx.drawImage(iconSheet(item),extra==null?141:130,108+itemY,32,32);
      if(extra!=null){ctx.drawImage(iconSheet(extra),158,109+itemY,32,32);}
      if(scan){const y=111+Math.floor((t*17)%26);
        p('rgba(109,244,207,.12)',133,y,182,y,181,y+4,135,y+4);r(133,y,49,1,aqua);r(136,y+1,42,1,'#aac8a6');}
    }
    // Counter terminal: phosphor bar graph, mechanical keypad and receipt roll.
    p(ink,250,118,259,105,287,105,294,113,302,136,299,146,250,149,238,140);
    p('#62766c',249,126,258,109,285,107,290,112,295,129,288,136,246,136);
    p('#889386',252,124,260,110,283,109,288,113,291,124,283,129,249,130);
    p('#253c41',255,123,261,112,282,111,285,115,285,122,281,124);
    for(let j=0;j<5;j++){let hh=1+Math.floor(3*(1+Math.sin(t*1.8+j*.7)));r(259+j*4,122-hh,2,hh,j>2?'#8eb094':aqua);}
    p('#455952',246,134,287,132,294,140,250,144,241,140);
    for(let j=0;j<2;j++)for(let i=0;i<5;i++)r(250+i*6,135+j*3-(i>>2),4,2,i===4?brass:'#93a395');
    l(292,137,298,141,'#a89573');r(247,144,16,2,ink);r(249,144,10,1,'#b8af91');r(290,135,4,2,'#d7a06c');
    l(298,131,309,135,ink,2);l(309,135,319,135,ink,2);
  }
  function draw(canvas,state={}){
    if(!canvas)return;if(canvas.width!==W)canvas.width=W;if(canvas.height!==H)canvas.height=H;
    const ctx=canvas.getContext('2d');if(!ctx)return;
    ctx.imageSmoothingEnabled=false;
    const t=Number(state.time)||0,day=Math.max(1,state.day|0),award=state.scene==='award',closed=state.scene==='closed',n=((state.patron|0)%8+8)%8;
    ctx.drawImage(backdrop(day),0,0);const {r,p,o,l,w}=pen(ctx);
    // One slow public transport passes the panorama in the far plane.
    const travel=Math.floor((t*7+day*13)%260)-25;
    ctx.save();ctx.beginPath();ctx.rect(77,12,168,97);ctx.clip();
    p('#455362',travel,53,travel+5,49,travel+19,49,travel+24,52,travel+19,54,travel+3,54);
    r(travel+6,50,6,1,'#a29a8b');r(travel+14,50,4,1,'#a29a8b');r(travel,52,3,1,'#d59776');
    for(let k=0;k<2;k++){const x=95+k*106,y=22+k*13;let phase=(t+k*2)%5;if(phase<.8){r(x-1,y,3,1,'#baac9e');r(x,y-1,1,3,'#b7ab9c');}}
    if((state.progress||0)>.50){const twilight=Math.min(.28,((state.progress||0)-.50)*.55);ctx.fillStyle='rgba(76,33,61,'+twilight+')';ctx.fillRect(76,13,170,94);}
    ctx.restore();
    if(closed){for(let y=15;y<111;y+=7){r(73,y,175,7,'#374d4d');r(73,y+4,175,2,'#1e343c');r(73,y,175,1,'#65726a');}r(139,50,48,20,ink);r(141,52,44,16,'#74594c');w(151,57,'CLOSED',cream);}
    else if(state.scene!=='empty'){ctx.save();ctx.beginPath();ctx.rect(72,15,178,113);ctx.clip();const a=state.approach??1,dx=Math.round((1-a)*(1-a)*42);ctx.translate(dx,Math.round((1-a)*6));portrait(ctx,n,t,state.mood||'idle');ctx.restore();}
    counter(ctx,Array.isArray(state.stock)?state.stock:[],award?null:state.item,t,!!state.scan,state.mood,closed,state.extra);
    if(award){
      // The broker slides the actual ownership deed and its brass key across the tray.
      const q=Math.min(1,Math.max(0,state.celebration??1)),dy=Math.round((1-q)*(1-q)*-18);
      ctx.save();ctx.translate(0,dy);
      p('#283439',125,123,159,119,179,132,141,138);
      p('#d4bc92',125,121,159,117,178,129,141,136);l(131,123,158,120,'#968b72');
      l(137,127,154,124,'#9e9075');l(141,130,153,127,'#93846a');r(159,128,5,3,'#b26455');
      o(157,113,6,4,'#6b543d');o(157,111,6,4,'#d2a564');o(157,111,3,2,'#665b4f');
      p('#926d43',160,114,163,112,178,119,177,122);l(162,112,179,119,'#f4cb7d',2);
      l(174,120,172,123,'#dfad69',2);l(178,121,177,124,'#ebbc73',2);ctx.restore();
      for(let i=0;i<23;i++){const y=15+(i*19+t*(7+i%4))%92,x=81+((i*49+Math.sin(t+i)*6+172)%155);
        r(Math.round(x),Math.round(y),i%3===0?2:1,2,['#d4a164','#a0c3a1','#db9d91'][i%3]);}
    }
    if(!closed&&!award&&state.shutter>0){ctx.save();ctx.beginPath();ctx.rect(73,13,175,Math.round(98*state.shutter));ctx.clip();
      for(let y=13;y<116;y+=7){r(73,y,175,7,'#374d4d');r(73,y+4,175,2,'#1e343c');r(73,y,175,1,'#65726a');}ctx.restore();}
    if(state.reader){p('#1c3034',192,132,200,126,218,126,220,130,212,136,195,137);p('#91ada1',196,131,201,127,214,127,210,132,196,134);r(201,128,9,2,'#496f77');r(202,128,3,1,'#a3ede2');}
    if(state.charter!=null){r(9,83,18,14,'#223036');r(10,83,16,12,'#b69b68');r(12,85,12,8,['#447367','#765a77','#805a51'][state.charter]);w(16,87,['U','S','F'][state.charter],cream);}
    if(state.heat>0){for(let i=0;i<Math.min(5,state.heat);i++){r(253+i*4,139,3,2,(Math.floor(t*3)%3)?'#e0956c':'#b96157');}}
    if(state.receipt){const slip=2+Math.round(t*6)%2;p('#243a39',247,143,260,142,257,148+slip,243,149+slip);p('#e2d5aa',247,143,258,142,256,147+slip,244,148+slip);l(248,145,254,144,'#8c8876');l(248,147,253,146,'#9a8c77');}
    if(state.water){r(35,89,13,15,'#23383e');r(36,90,11,13,'#557c80');r(38,91,7,10,'#71b5b2');r(39,92,2,7,'#a5d5bb');r(35,88,13,3,'#8c8266');r(35,101,13,3,'#555d52');l(47,95,53,95,'#9c8564',2);l(52,95,52,100,'#746951',2);}
    if(!closed&&(state.approach??1)>.85){
      const lift=state.mood==='happy'?1:0;
      // Fingers overlap the far edge of the countertop, grounding the visitor.
      const fingers=n===1?'#96a78a':n===2||n===5?'#b8b89f':n===4?'#c7aeb0':n===7?'#d48d79':'#d4a187';
      for(const side of [-1,1]){
        const x=165+side*(n===1?31:26),y=118-Math.round(Math.sin(t*2+n)*.6)-lift;
        p('#333738',x-6,y-1,x-3,y-3,x+3,y-3,x+6,y,x+5,y+3,x-5,y+3);
        for(let i=0;i<3;i++){r(x-4+i*3,y-1,2,3,fingers);r(x-4+i*3,y+2,2,1,'#8c796b');}
      }
      if(state.mood==='happy'){
        const a=210,b=52+Math.round(Math.sin(t*3));l(a,b,a+3,b+3,gold);l(a+3,b+3,a+9,b-5,gold,2);r(a+12,b-6,1,2,cream);
      }else if(state.mood==='angry'){
        const a=209,b=49;r(a,b,2,6,'#ee946d');r(a,b+8,2,2,'#ee946d');l(a+4,b+1,a+6,b-1,'#c48c6b');
      }
    }
  }
  function icon(canvas,id){
    if(!canvas)return;if(canvas.width!==32)canvas.width=32;if(canvas.height!==32)canvas.height=32;
    const ctx=canvas.getContext('2d');if(ctx){ctx.clearRect(0,0,32,32);ctx.imageSmoothingEnabled=false;ctx.drawImage(iconSheet(id),0,0);}
  }
  return Object.freeze({draw,icon});
})();
