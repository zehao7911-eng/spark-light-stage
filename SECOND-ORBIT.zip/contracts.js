'use strict';

globalThis.CounterContracts = (() => {
  // Sponsors rotate with the daily dock bulletin. Their orders accept broad
  // classes of transactions, so drawing a particular item is never required.
  const orders = [
    {name:'Brack’s night crew', brief:'Sell one lot to any buyer.', goal:1, bonus:7, crew:0, test:e=>e.type==='sell',
      done:'Brack’s tug now has a working bench light.'},
    {name:'Vale’s paper trail', brief:'Scan a lot before buying or selling it.', goal:1, bonus:8, crew:1,
      test:e=>e.scanned===true && (e.type==='buy'||e.type==='sell'), done:'Vale has pinned your first assay slip in the public archive.'},
    {name:'Pip’s second trip', brief:'Sell two lots. Any buyer can sign for them.', goal:2, bonus:9, crew:2, test:e=>e.type==='sell',
      done:'Pip caught the night courier with both parcels.'},
    {name:'Ferro’s spare shelf', brief:'Buy two lots for the dock workshop.', goal:2, bonus:10, crew:0, test:e=>e.type==='buy',
      done:'Two new bins at Ferro’s bench carry your shop mark.'},
    {name:'Vel’s fair exchange', brief:'Sell one lot for more than you paid.', goal:1, bonus:8, crew:1,
      test:e=>e.type==='sell' && Number.isFinite(e.lot?.cost) && e.amount>e.lot.cost, done:'Vel chalked your exchange rate beside the airlock.'},
    {name:'Rook’s bonded cargo', brief:'Complete two trades with authentic, unflagged goods.', goal:2, bonus:11, crew:2,
      test:e=>(e.type==='sell'||e.type==='buy') && e.lot?.fake===false && e.lot?.tag===false, done:'Rook loaded both lots without holding up customs.'},
    {name:'Ione’s calibration', brief:'Scan two lots and complete their deals.', goal:2, bonus:12, crew:0,
      test:e=>e.scanned===true && (e.type==='sell'||e.type==='buy'), done:'Ione’s rebuilt test rig just passed its own inspection.'},
  ];
  const news = [
    ['Lights out at Dock Nine','Tug crews are patching their lamps with parts from the night market.'],
    ['Comet watch opens','The survey office has set a kettle on the roof and invited the whole lower deck.'],
    ['Courier lift running late','A freighter has borrowed the passenger lift. Parcels are riding up the stairs.'],
    ['Refit behind schedule','The yard whistle rang on time. The second shift is still looking for its boots.'],
    ['Mirrors turn to shadow','For seven minutes the station gardens will have their first proper night in a year.'],
    ['Last ferry takes mail','Letters posted before the closing bell leave on the last outbound boat.'],
    ['Dawn over the old ring','The café beneath the landing gear is serving breakfast to both shifts.'],
  ];

  function status(s) {
    const a=s?.contracts?.active;
    if(!a || a.day!==s.day || !orders[a.index]) return null;
    const o=orders[a.index];
    return {title:o.name,brief:o.brief,progress:a.progress,goal:o.goal,paid:a.paid};
  }

  function start(s) {
    if(!s.contracts) s.contracts={active:null,previous:null,rotation:s.seed>>>0};
    const book=s.contracts, current=status(s);
    if(current)return current;
    if(book.active?.paid)book.previous={day:book.active.day,index:book.active.index};
    // The first week teaches one action at a time. Later weeks give different
    // desks a different rotation while each save preserves its own timetable.
    const cycle=Math.floor((s.day-1)/orders.length);
    const offset=cycle?1+((book.rotation+cycle*3)%6):0;
    const index=(s.day-1+offset)%orders.length;
    book.active={day:s.day,index,progress:0,paid:false,closed:false,visits:[]};
    return status(s);
  }

  function record(s,event) {
    const a=s.contracts?.active;
    if(!a||a.day!==s.day||a.closed||!event||!Number.isInteger(s.turn))return false;
    const o=orders[a.index];
    if(a.progress>=o.goal || !o.test(event))return false;
    // A patron signs one receipt per visit; workshop actions have their own slot.
    const visit=s.turn+(['repair','craft'].includes(event.type)?'/bench':'/counter');
    if(a.visits.includes(visit))return false;
    a.visits.push(visit);a.progress++;return true;
  }

  function settle(s) {
    const a=s.contracts?.active;
    if(!a||a.day!==s.day)return {title:'No commission',amount:0};
    const o=orders[a.index];
    if(a.closed)return {title:o.name,amount:0};
    a.closed=true;
    if(a.progress<o.goal)return {title:o.name,amount:0};
    a.paid=true;s.cash+=o.bonus;s.earned+=o.bonus;
    s.reps[o.crew]=Math.min(9,s.reps[o.crew]+1);
    logTrade(s,o.name+' commission',o.bonus);
    return {title:o.name,amount:o.bonus};
  }

  function headline(s) {
    const day=Math.max(1,s?.day||1), [title,body]=news[(day-1)%news.length];
    const last=s?.contracts?.previous;
    return {title,body:body+(last?.day===day-1?' '+orders[last.index].done:'')};
  }

  return Object.freeze({start,record,settle,status,headline});
})();
