/* Second Orbit. Maker's punches and inspection handbook art. */
globalThis.CounterStamps=(()=>{
  const ink='#394943',oxide='#9c5c45',paper='#e8d4aa';
  // Each paired drawing is a real die and an imitation cut by another hand.
  // Each row is a seven-bit, MSB-first impression. Whitespace is unprinted paper.
  const dies=[
    [[8,24,48,126,12,24,16],[8,12,6,63,24,12,4]],                  // forked charge
    [[54,73,73,54,73,73,54],[28,34,65,28,65,34,28]],               // double winding
    [[0,28,34,73,34,28,0],[0,28,42,85,42,28,0]],                  // lens countermark
    [[8,28,42,8,8,28,62],[8,20,34,65,8,28,62]],                  // transmitter crown
    [[8,8,42,28,127,28,8],[8,28,127,28,42,8,8]],                  // star atlas
    [[62,34,20,8,20,34,62],[62,34,20,8,8,28,62]],                 // escapement
    [[34,34,42,42,28,8,28],[34,42,54,42,34,8,28]],               // split cathode
    [[24,36,36,24,8,14,8],[24,36,36,24,8,56,8]],                 // right cut
    [[99,85,42,28,42,85,99],[99,85,42,8,20,34,65]],              // four fans
    [[8,20,42,73,42,20,8],[8,20,34,127,34,20,8]],                // prism cut
    [[127,65,93,85,93,65,127],[127,65,85,73,85,65,127]],        // sealed recorder
    [[14,24,48,48,49,27,14],[56,12,6,6,70,108,56]],              // crescent
    [[8,20,20,34,65,34,28],[8,20,34,65,93,34,28]]                // condensate
  ];
  const glyph={
    A:[14,17,17,31,17,17,17],B:[30,17,17,30,17,17,30],C:[15,16,16,16,16,16,15],D:[30,17,17,17,17,17,30],
    E:[31,16,16,30,16,16,31],F:[31,16,16,30,16,16,16],G:[14,17,16,23,17,17,14],H:[17,17,17,31,17,17,17],
    I:[31,4,4,4,4,4,31],J:[7,2,2,2,18,18,12],K:[17,18,20,24,20,18,17],L:[16,16,16,16,16,16,31],
    M:[17,27,21,21,17,17,17],N:[17,25,21,21,19,17,17],O:[14,17,17,17,17,17,14],P:[30,17,17,30,16,16,16],
    Q:[14,17,17,17,21,18,13],R:[30,17,17,30,20,18,17],S:[15,16,16,14,1,1,30],T:[31,4,4,4,4,4,4],
    U:[17,17,17,17,17,17,14],V:[17,17,17,17,17,10,4],W:[17,17,17,21,21,21,10],X:[17,17,10,4,10,17,17],
    Y:[17,17,10,4,4,4,4],Z:[31,1,2,4,8,16,31],'-':[0,0,0,14,0,0,0],
    '0':[14,17,19,21,25,17,14],'1':[4,12,4,4,4,4,14],'2':[14,17,1,2,4,8,31],'3':[30,1,1,14,1,1,30],
    '4':[2,6,10,18,31,2,2],'5':[31,16,16,30,1,1,30],'6':[14,16,16,30,17,17,14],'7':[31,1,2,4,8,8,8],
    '8':[14,17,17,14,17,17,14],'9':[14,17,17,15,1,1,14],'.':[0,0,0,0,0,0,4]
  };
  const spares=['EB-4','HN-7','LM-2','RX-1','AT-8','TM-5','VA-9','KY-3','DR-4','PR-6','BX-2','MN-8','FW-1'];
  // Three fluorescent fibres run across each maker's tamper strip. Shape carries
  // the signal in every lighting condition, including a monochrome display.
  const fibreNames=['Ring','Fork','Dash','Cross'];
  const fibreGlyphs=['○','Y','−','+'];
  function bandGlyph(name){
    return String(name||'').split('·').map(part=>{
      const id=fibreNames.findIndex(n=>n.toLowerCase()===part.trim().toLowerCase());
      return fibreGlyphs[id]||'';
    }).filter(Boolean).join(' ');
  }
  const fibres=[[14,17,17,17,14],[17,17,10,4,4],[0,0,31,0,0],[4,4,31,4,4]];
  const strips=['012','030','102','223','130','201','312','322','013','132','023','231','301'];
  function stripFor(id,copy){
    const values=Array.from(strips[id]||strips[0],Number);
    if(copy){const index=id%3;values[index]=(values[index]+1+id%2)%4;}
    return values;
  }
  function drawBand(ctx,x,y,id,copy,scale,color){
    ctx.save();ctx.fillStyle=color;
    for(const [i,v] of stripFor(id,copy).entries())rows(ctx,x+i*7*scale,y,fibres[v],5,scale);
    ctx.restore();
  }
  function evidence(lot){
    const id=lot.item,factoryCode=(typeof SEALS!=='undefined'&&SEALS[id])||spares[id]||spares[0];
    const code=lot.fake?factoryCode.slice(0,-1)+(Number(factoryCode.at(-1))+2)%10:factoryCode;
    const band=(copy)=>stripFor(id,copy).map(n=>fibreNames[n]).join(' · ');
    return {factoryCode,itemCode:lot.sealRead?code:null,factoryBand:band(false),itemBand:lot.uvRead?band(lot.fake):null,customs:lot.uvRead?(lot.tag?'Flagged':'Clear'):null};
  }
  function rows(ctx,x,y,bits,columns,scale){
    for(let row=0;row<bits.length;row++)for(let col=0;col<columns;col++)
      if(bits[row]&(1<<(columns-col-1)))ctx.fillRect(x+col*scale,y+row*scale,scale,scale);
  }
  function drawMark(ctx,x,y,itemId,isFake,scale=1){
    if(!ctx)return;const pair=dies[itemId]||dies[0];ctx.save();ctx.fillStyle=ink;
    rows(ctx,Math.round(x),Math.round(y),pair[isFake?1:0],7,Math.max(1,Math.round(scale)));ctx.restore();
  }
  function drawCode(ctx,x,y,text,color,scale=1){
    ctx.save();ctx.fillStyle=color;
    for(const ch of String(text).toUpperCase()){if(glyph[ch])rows(ctx,x,y,glyph[ch],5,scale);x+=6*scale;}
    ctx.restore();
  }
  function page(canvas,lot,channel='stamp'){
    if(!canvas)return;canvas.width=256;canvas.height=66;
    const ctx=canvas.getContext('2d');if(!ctx)return;
    const id=dies[lot?.item]?lot.item:0, code=(typeof SEALS!=='undefined'&&SEALS[id])||spares[id];
    ctx.imageSmoothingEnabled=false;
    function r(x,y,w,h,c){ctx.fillStyle=c;ctx.fillRect(x,y,w,h);}
    r(0,0,256,66,'#ddcba9');r(4,3,248,60,'#f3dfb7');r(4,60,248,3,'#cab48e');r(9,3,2,57,'#c6ae85');
    for(const y of [15,44]){r(4,y,10,4,ink);r(7,y,6,1,'#a49a7b');}
    drawCode(ctx,27,29,'GUIDE',ink,2);
    r(100,16,1,35,'#bbaa85');
    if(channel==='uv'){
      r(115,12,128,41,'#4d515a');r(117,14,124,37,'#263344');
      drawBand(ctx,133,22,id,false,4,'#a7f1cf');
      canvas.setAttribute('aria-label','Guide. Factory UV pattern: '+evidence(lot).factoryBand+'.');
      return;
    }
    // Same left-to-right reading order as the metal badge under the glass.
    drawMark(ctx,117,19,id,false,4);drawCode(ctx,161,24,code,ink,3);
    canvas.setAttribute('aria-label','Guide. Factory seal '+code+'.');
  }
  return Object.freeze({drawMark,drawCode,drawBand,bandGlyph,evidence,page});
})();
