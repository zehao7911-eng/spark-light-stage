'use strict';
const GOODS=[
 ['Pulse Cell',34,0,'Ceramic ribs keep the charge stable.','An EB-4 stamp belongs on the brass lip.'],
 ['Relay Coil',41,0,'Silver wire is wound in pairs.','Factory windings carry the HN-7 seal.'],
 ['Pilot Lens',51,1,'The amber lens should show two reflections.','The glass ring is signed LM-2.'],
 ['Signal Radio',47,2,'Listen for a clean three-note carrier.','Dock radios ship under RX-1.'],
 ['Star Chart',63,1,'Its constellations bloom in ultraviolet.','The survey office stamps AT-8.'],
 ['Chrono Watch',75,2,'The fork ticks twice per station second.','The case is etched TM-5.'],
 ['Vacuum Amp',68,0,'Filaments must glow without flicker.','A genuine tube reads VA-9.'],
 ['Cargo Key',58,2,'One notch opens a single freight class.','Union keys are stamped KY-3.'],
 ['Micro Drone',94,0,'Four silent rotors deploy in sequence.','The frame bears DR-4.'],
 ['Prism Shard',122,1,'Six narrow bands split off the cut edge.','The cutter signs each mount PR-6.'],
 ['Black Box',108,0,'The last flight is sealed in amber resin.','Recorder certification reads BX-2.'],
 ['Moon Idol',139,1,'A pale mineral vein circles the face.','Lunar exports bear MN-8.'],
 ['Filtered Water',23,2,'A sealed six-pack from the dock condensate bench.','Filtered batches carry FW-1.']
];
const SEALS=['EB-4','HN-7','LM-2','RX-1','AT-8','TM-5','VA-9','KY-3','DR-4','PR-6','BX-2','MN-8','FW-1'];
const GRADES=[['Worn',.72],['Serviceable',.94],['Mint',1.18]];
const CREWS=['Dock Union','Star Survey','Freight Guild'];
const PEOPLE=[
 ['Pip','Parcel runner',2,'I took the long way past customs.','The airlock closes in ten.'],
 ['Brack','Freighter foreman',0,'Still useful. That counts for something.','My crew cannot fly on promises.'],
 ['Ione','Service unit',0,'Transfer request. Sentiment value omitted.','My requisition buffer is open.'],
 ['Miss Vale','Station archivist',1,'It has a story. I would prefer a price.','Something in your window caught my eye.'],
 ['Vel','Night navigator',1,'Stars fade. Good hardware lasts.','I leave on the next dark tide.'],
 ['Ferro','Hull welder',0,'Heavy? That is usually a good sign.','My bench has been missing one of these.'],
 ['Rook','Union pilot',2,'Pulled it out before the hull cooled.','I have fuel for precisely one more stop.'],
 ['Orr','Orbital broker',1,'An unusual consignment, even for me.','For the right specimen, I can stretch.']
];
const EVENTS=[
 ['Dockside blackout','Power components are trading high.',0],
 ['A comet returns','Survey instruments are in demand.',1],
 ['Convoy at Gate 5','Freight crews are stocking up.',2],
 ['Yard refit','Mechanics are buying spare parts.',0],
 ['Mirror eclipse','Observatories are restocking.',1],
 ['The last ferry','Couriers have a rush booking.',2]
];
const DEED=240,START=104;
const money=n=>'₵'+Math.round(n);
const lotValue=(lot,demand=1)=>CounterEconomy.resale(GOODS[lot.item][1],GRADES[lot.grade][1]*(lot.fake?.53:1),demand);
const shiftRent=d=>Math.min(40,11+d*2);
const rentDue=s=>s.paid>=DEED||s.extended?0:Math.max(0,shiftRent(s.day)-(s.charter===0?6:0));
const catalogSize=d=>d<2?4:d<3?6:d<4?8:d<5?10:12;
const demand=(s,i)=>CounterEconomy.market(s.day,GOODS[i][2],i)*(EVENTS[(s.day-1)%EVENTS.length][2]===GOODS[i][2]?1.26:1);
function makeRun(seed){
 return {seed:seed>>>0,day:1,cash:START,paid:0,phase:'ready',turn:0,limit:6,nonce:2,stock:[
 {id:1,item:0,grade:1,fake:false,tag:false,cost:20},{id:2,item:3,grade:1,fake:false,tag:false,cost:26}],
 reps:[0,0,0],heat:0,scans:3,gear:[],patron:null,deals:0,sold:0,totalSales:0,
 earned:0,spent:0,ledger:[],intel:null,recap:null,served:[],serials:[],extended:false};
}
const KITS=[
 {id:'salvage',name:'Salvage dealer',item:1,desc:'₵104 in the till. A power cell and a radio ready to sell.'},
 {id:'assay',name:'Assay clerk',item:2,desc:'₵78, a pilot lens and an upgraded five-charge reader. The survey office knows you.'},
 {id:'water',name:'Water merchant',item:12,desc:'₵82, bottled water, a relay coil and a working filtration plant from shift one.'}
];
function openingKit(s,kit){
 if(s.phase!=='ready'||!KITS.some(k=>k.id===kit))return;
 s.kit=kit;s.cash=kit==='water'?82:kit==='assay'?78:START;
 s.gear=kit==='assay'?['reader']:[];s.reps=[0,kit==='assay'?2:0,0];
 s.water=kit==='water'?{installed:true,bottles:0,bottledDay:0,batch:null}:null;
 const ids=kit==='water'?[12,1]:kit==='assay'?[2,3]:[0,3];
 s.stock=ids.map((item,i)=>({id:i+1,item,grade:1,fake:false,tag:false,cost:[20,26][i]}));
}
function dice(s){s.seed=(Math.imul(s.seed,1664525)+1013904223)>>>0;return s.seed/4294967296;}
function logTrade(s,text,amount=0){s.ledger.unshift({day:s.day,text,amount});s.ledger=s.ledger.slice(0,32);}
function beginShift(s){
 s.phase='trade';s.turn=0;s.earned=0;s.spent=0;s.sold=0;s.served=[];s.audit=null;s.limit=Math.min(8,5+s.day);
 s.scans=(s.gear.includes('reader')?5:3)+(s.charter===1?2:0);s.recap=null;nextGuest(s);
 CounterContracts.start(s);
}
function nextGuest(s){
 s.turn++;s.phase='trade';s.intel=null;
 const first=s.day===1&&s.turn===1, second=s.day===1&&s.turn===2;
 const person=first?0:second?1:Math.floor(dice(s)*8), buyer=s.stock.length>0&&(s.turn%2===0||s.stock.length>=5||s.cash<16);
 const visitor={person,buyer,wants:buyer?GOODS[s.stock[Math.floor(dice(s)*s.stock.length)].item][2]:null,
 patience:3,scanned:false,mood:'idle',response:'',ticket:'',tender:0,offer:0};
 if(buyer){
   visitor.pairOrder=s.day>=3&&s.turn%4===0&&s.stock.length>=2;
   const fits=s.stock.filter(l=>GOODS[l.item][2]===visitor.wants);
   assignSale(s,visitor,fits[0]);
 }else{
   const item=first?1:s.charter===1&&s.turn===1?9+(s.day%3):Math.floor(dice(s)*catalogSize(s.day));
   const grade=first?2:Math.floor(dice(s)*3),fake=!first&&s.day>=2&&dice(s)<.21,tag=!first&&s.day>=2&&dice(s)<.26;
   const l={id:++s.nonce,item,grade,fake,tag,cost:0};visitor.lot=l;
   const v=lotValue(l,demand(s,item));
   visitor.floor=Math.max(5,Math.round(v*(tag?.40:.51)+dice(s)*5-s.reps[PEOPLE[person][2]]*.4));
   visitor.ask=Math.max(visitor.floor+3,Math.round(GOODS[item][1]*demand(s,item)*(tag?.60:.77+dice(s)*.24)));
   visitor.offer=visitor.ask;visitor.opening=visitor.ask;
 }
 s.patron=visitor;
}
function buyerLimit(s,v,l){
 const favored=GOODS[l.item][2]===v.wants,rep=s.reps[PEOPLE[v.person][2]];
 return Math.max(4,Math.round(lotValue(l,demand(s,l.item))*(favored?1.02:.75)*(1+Math.min(6,rep)*.014)*(s.charter===2&&favored?1.15:1)));
}
function assignSale(s,v,l,extra=null){
 v.lot=l;v.extra=v.pairOrder&&extra&&l.id!==extra.id&&s.stock.some(q=>q.id===extra.id)?extra:null;
 v.max=v.extra?Math.round((buyerLimit(s,v,l)+buyerLimit(s,v,v.extra))*1.12):buyerLimit(s,v,l);
 v.ask=Math.max(2,Math.round(v.max*.82));v.opening=v.ask;v.offer=v.ask;v.scanned=false;v.response='';
}
function inspectLot(s){
 const v=s.patron;if(s.phase!=='trade'||!v||v.buyer||v.scanned||s.scans<1)return false;
 v.scanned=true;s.scans--;v.mood='inspect';return true;
}
function trade(s){
 if(s.phase!=='trade')return false;
 const v=s.patron,crew=PEOPLE[v.person][2],l=v.lot,n=v.buyer?Math.max(v.ask,v.offer):Math.min(v.ask,v.offer);
 if(!v.buyer&&n>s.cash){v.response='Your till cannot cover that offer.';return 'reject';}
 // A buyer's ceiling is the mirror image of a seller's reserve.
 const ceiling=Math.max(500,v.max||0,n,v.ask)+200;
 const decision=v.buyer?CounterEconomy.offer(ceiling-v.ask,ceiling-v.max,ceiling-n,v.patience):CounterEconomy.offer(v.ask,v.floor,n,v.patience);
 if(decision.status!=='accepted'){
   v.patience=decision.patience;v.mood='angry';
   if(decision.status==='walked'){receipt(s,'WALKED AWAY','The airlock shuts. No credits changed hands.',0,'angry');return 'reject';}
   v.ask=v.buyer?ceiling-decision.price:decision.price;v.offer=v.ask;v.response='“'+[
     'Make it '+money(v.ask)+' and I can catch my lift.',money(v.ask)+'. My crew has to eat.',
     'Revised valuation: '+money(v.ask)+'.',money(v.ask)+'. I keep very good records.',
     'My star says '+money(v.ask)+'.','I can work with '+money(v.ask)+'.',
     'Fuel is not free. '+money(v.ask)+'.',money(v.ask)+'. A most civil compromise.'][v.person]+'”';return 'counter';
 }
 if(v.buyer){
   const batch=v.extra?[l,v.extra]:[l];if(!batch.every(a=>s.stock.some(b=>b.id===a.id)))return false;
   s.stock=s.stock.filter(q=>!batch.some(a=>q.id===a.id));s.cash+=n;s.earned+=n;s.sold+=batch.length;s.totalSales+=batch.length;
   for(const a of batch){s.served.push(a.item);if(!s.serials.includes(a.item))s.serials.push(a.item);}
   logTrade(s,'Sold '+batch.map(a=>GOODS[a.item][0]).join(' + '),n);
 }else{
   l.cost=n;s.cash-=n;s.spent+=n;s.stock.push(l);if(l.tag)s.heat=Math.min(5,s.heat+1);
   logTrade(s,'Bought '+GOODS[l.item][0],-n);
 }
 if(v.scanned)l.assayed=true;
 if(!s.serials.includes(l.item))s.serials.push(l.item);
 s.deals++;s.reps[crew]=Math.min(9,s.reps[crew]+1);
 CounterContracts.record(s,{type:v.buyer?'sell':'buy',lot:l,amount:n,scanned:v.scanned||l.assayed===true,lotCount:v.extra?2:1,crew});
 const margin=n-l.cost-(v.extra?.cost||0);
 const msg=v.buyer?(v.extra?'Two-lot shipment · ':'')+'Margin '+(margin>=0?'+':'')+money(margin)+' · '+CREWS[crew]+' standing +1':'Added to your shelf. Buyers can now bid on it.';
 receipt(s,v.buyer?'SOLD':'PURCHASED',msg,v.buyer?n:-n,'happy');return v.buyer?'sell':'buy';
}
function receipt(s,title,detail,amount,mood){
 s.phase='receipt';Object.assign(s.patron,{ticket:title,response:detail,tender:amount,mood});
}
function pass(s,report=false){
 if(s.phase!=='trade'||!s.patron)return false;
 const l=s.patron.lot,flag=report&&!s.patron.buyer&&s.patron.scanned&&l.tag;
 if(flag){s.heat=Math.max(0,s.heat-1);s.cash+=5;s.earned+=5;logTrade(s,'Customs tip',5);}
 receipt(s,flag?'CUSTOMS TIP':'PASSED',flag?'Serial verified. Customs paid a tip.':'You kept your credits and your shelf space.',flag?5:0,flag?'angry':'idle');
}
function requestClose(s){
 if(s.phase!=='receipt'||s.turn<s.limit)return;
 if(s.heat<2){closeShift(s);return;}
 s.phase='audit';s.audit={levy:6+s.heat*2,lotId:s.stock.find(l=>l.tag)?.id??null};
}
function answerAudit(s,surrender){
 if(s.phase!=='audit'||!s.audit)return false;const l=s.stock.find(q=>q.id===s.audit.lotId);
 if(surrender&&l){s.stock=s.stock.filter(q=>q.id!==l.id);s.audit.returned=GOODS[l.item][0];s.audit.levy=3;s.reps[2]=Math.max(0,s.reps[2]-1);s.reps[0]=Math.min(9,s.reps[0]+1);}
 closeShift(s);return true;
}
function closeShift(s){
 const bonus=CounterContracts.settle(s);
 const rent=rentDue(s),c=s.stock.find(l=>l.tag),fine=s.audit?s.audit.levy:s.heat>=2?6+s.heat*2:0;
 const seize=fine&&c&&!s.audit?.returned;
 if(fine){if(seize)s.stock=s.stock.filter(l=>l.id!==c.id);s.heat=Math.max(0,s.heat-2);}
 const before=s.cash;s.cash-=rent+fine;
 let liquidation=0;while(s.cash<0&&s.stock.length){const l=s.stock.shift();const coins=Math.max(1,Math.round(lotValue(l)*.48));s.cash+=coins;liquidation+=coins;}
 logTrade(s,'Dock rent',-rent);if(fine)logTrade(s,'Customs inspection',-fine);
 s.recap={rent,fine,seized:s.audit?.returned||(seize?GOODS[c.item][0]:''),liquidation,before,sold:s.sold,bonus};
 s.phase=s.cash<0?'failed':'night';s.patron=null;
}

