/* The station price wave and whole-credit floor are adapted from
   Autio/pazillionaire, classic/engine.js, MIT. See ECONOMY-LICENSE.txt. */
globalThis.CounterEconomy = (() => {
  const number = (value, fallback) => Number.isFinite(value) ? value : fallback;
  const clamp = (value, low, high) => Math.min(high, Math.max(low, value));
  const credits = value => Math.max(0, Math.round(number(value, 0)));

  function market(day, district = 0, article = 0) {
    return 1 + Math.sin(day * 1.7 + district * 3 + article * 2.3) * .23;
  }

  function resale(base, gradeMultiplier = 1, demand = 1) {
    const grade = clamp(number(gradeMultiplier, 1), .1, 2.5);
    return Math.max(1, Math.round(credits(base) * grade * clamp(number(demand, 1), .25, 3)));
  }

  function quote(base, gradeMultiplier = 1, demand = 1) {
    return Math.max(1, Math.round(resale(base, gradeMultiplier, demand) * .72));
  }

  function offer(ask, minimum, playerBid, patience) {
    const floor = Math.max(1, credits(minimum));
    const wanted = Math.max(floor, credits(ask));
    const bid = credits(playerBid);
    const chances = credits(patience);
    if (!chances) return {status: 'walked', price: 0, patience: 0};
    if (bid >= floor) return {status: 'accepted', price: Math.min(bid, wanted), patience: chances};
    if (chances === 1) return {status: 'walked', price: 0, patience: 0};
    // Close offers draw larger concessions. Even a poor bid moves the seller.
    const concession = Math.max(1, Math.ceil((wanted - floor) * (.28 + .42 * bid / floor)));
    return {status: 'counter', price: Math.max(floor, wanted - concession), patience: chances - 1};
  }

  function closeDay(balance, rent) {
    const cash = credits(balance);
    const due = credits(rent);
    const paid = Math.min(cash, due);
    return {balance: cash - paid, paid, shortfall: due - paid};
  }

  return Object.freeze({market, resale, quote, offer, closeDay});
})();
