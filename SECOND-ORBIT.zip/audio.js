/* Original score: Dockside After Midnight. No network audio dependencies. */
window.CounterSound = (() => {
  let context, master, music, effects, echo, noiseBuffer, muted = false;
  let timer = 0, step = 0, nextBeat = 0;
  const beat = 60 / 96 / 2;
  const chords = [[50,57,60,64], [46,53,57,60], [48,55,58,62], [45,52,55,61]];
  const tune = [76,null,null,72,69,null,67,null, 72,null,69,null,null,65,67,null,
                70,null,null,67,65,null,62,null, 64,null,67,null,73,null,69,null];
  const hz = n => 440 * Math.pow(2, (n-69)/12);
  function note(bus, pitch, time, length, gain, type='sine', end=0) {
    const osc=context.createOscillator(),env=context.createGain();
    osc.type=type; osc.frequency.setValueAtTime(hz(pitch),time);
    if(end) osc.frequency.exponentialRampToValueAtTime(hz(end),time+length);
    env.gain.setValueAtTime(.0001,time);
    env.gain.exponentialRampToValueAtTime(gain,time+.008);
    env.gain.exponentialRampToValueAtTime(.0001,time+length);
    osc.connect(env); env.connect(bus); osc.start(time); osc.stop(time+length+.012);
    osc.onended=()=>{osc.disconnect();env.disconnect();};
  }
  function noise(bus, time, length, gain, filterHz) {
    const src=context.createBufferSource(),filter=context.createBiquadFilter(),env=context.createGain();
    src.buffer=noiseBuffer; src.loop=true; filter.type='bandpass';filter.frequency.value=filterHz;
    filter.Q.value=.9;env.gain.setValueAtTime(gain,time);env.gain.exponentialRampToValueAtTime(.0001,time+length);
    src.connect(filter);filter.connect(env);env.connect(bus);src.start(time);src.stop(time+length+.015);
    src.onended=()=>{src.disconnect();filter.disconnect();env.disconnect();};
  }
  function tick(){
    if(!context||muted||document.hidden||context.state!=='running')return;
    if(nextBeat<context.currentTime)nextBeat=context.currentTime+.025;
    while(nextBeat<context.currentTime+.16){
      const i=step%32, eighth=i%8, chord=chords[Math.floor(i/8)], t=nextBeat+((i%2)*.035);
      if(eighth===0||eighth===4){note(music,chord[0]-12,t,.39,.25,'triangle');note(music,40,t,.095,.27,'sine',23);}
      if(eighth===3||eighth===6){for(const key of chord.slice(1))note(music,key,t,.26,.064,'triangle');}
      if(eighth===2||eighth===6)noise(music,t,.065,.14,1800);
      if(eighth%2)noise(music,t,.047,.070,5600);
      if(tune[i]!==null){note(music,tune[i],t,.39,.105);note(echo,tune[i]+12,t,.28,.028);}
      step++;nextBeat+=beat;
    }
  }
  function wake(){
    if(muted||document.hidden)return;
    try{
      if(!context){
        const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)return;
        context=new Audio();master=context.createGain();master.gain.value=.60;master.connect(context.destination);
        music=context.createGain();music.gain.value=.37;music.connect(master);
        effects=context.createGain();effects.gain.value=.86;effects.connect(master);
        echo=context.createDelay(.5);echo.delayTime.value=.22;echo.connect(music);
        noiseBuffer=context.createBuffer(1,context.sampleRate*.20,context.sampleRate);
        const raw=noiseBuffer.getChannelData(0);for(let i=0;i<raw.length;i++)raw[i]=Math.random()*2-1;
      }
      if(context.state!=='running')context.resume().then(tick).catch(()=>{});
      if(!timer)timer=window.setInterval(tick,75);tick();
    }catch{/* Audio availability does not affect trade settlement. */}
  }
  function mute(flag){
    muted=!!flag;
    if(context){master.gain.setTargetAtTime(muted?0:.60,context.currentTime,.025);}
    if(muted){clearInterval(timer);timer=0;}else if(context)wake();
  }
  const cues={
    tap:[[64,0,.063]],open:[[50,0,.14],[57,.08,.13],[62,.17,.27]],
    arrival:[[77,0,.18],[69,.11,.29]], scan:[[62,0,.09,82],[82,.105,.065],[89,.17,.13]],
    offer:[[59,0,.07],[66,.052,.12]],counter:[[69,0,.075],[66,.09,.13]],
    buy:[[69,0,.10],[64,.08,.13],[67,.155,.20]],sell:[[67,0,.10],[74,.073,.13],[79,.15,.27]],
    pass:[[60,0,.075],[55,.09,.10]],reject:[[58,0,.13,52],[46,.135,.19]],
    stamp:[[38,0,.11,30],[81,.065,.095]],alert:[[75,0,.13],[75,.18,.15]],
    upgrade:[[62,0,.13],[69,.08,.13],[74,.16,.16],[81,.28,.32]],
    win:[[62,0,.14],[66,.10,.15],[69,.21,.17],[74,.34,.43]],lose:[[62,0,.2],[58,.2,.22],[50,.4,.40]]
  };
  function play(name){
    if(muted||document.hidden)return;wake();if(!context)return;
    const t=context.currentTime+.015;
    for(const [p,delay,len,end] of cues[name]||cues.tap)note(effects,p,t+delay,len,.26,'triangle',end);
    if(name==='scan')noise(effects,t,.19,.13,4000);
    if(name==='stamp'||name==='sell'||name==='buy')noise(effects,t,.064,.39,860);
    music.gain.cancelScheduledValues(t);music.gain.setTargetAtTime(.21,t,.018);
    music.gain.setTargetAtTime(.37,t+.25,.13);
  }
  function park(){clearInterval(timer);timer=0;if(context&&context.state==='running')context.suspend().catch(()=>{});}
  document.addEventListener('visibilitychange',()=>{if(document.hidden)park();else if(context&&!muted)wake();});
  window.addEventListener('pagehide',park);
  return {wake,play,mute};
})();
