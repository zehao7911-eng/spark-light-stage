extends Node2D
const Art=preload('res://art.gd')
var g
var selected=-1
var w=400
var h=320
var t=0.0
var fx=[]
var rings=[]
var inspect=-1
func project(p):return Vector2(w/2+(p.x-p.y)*w*.002,h/2.0+(p.x+p.y-192)*w*.001)
func unproject(p):
	var a=(p.x-w/2)/(w*.002);var b=(p.y-h/2.0)/(w*.001)+192;return Vector2((a+b)/2,(b-a)/2)
func _draw():
	if g==null:return
	var season=int((g.year-1)/5)%4
	var ground=['#93a383','#b29c76','#8e9f9c','#b0baa9'][season];var light=Color(ground).lightened(.08)
	Art.b(self,0,0,w,h,'#c7cead');Art.b(self,0,0,w,h,Color(ground).lightened(.23))
	# Meandering water and stepping-stone banks surround the kingdom, all at native pixel resolution.
	for y in range(0,h,3):
		var xx=w*.83+sin(y*.022)*16
		Art.b(self,xx,y,w-xx,3,'#829f9d');Art.b(self,xx,y,3,3,'#adbbb0')
		if y%9==0:Art.b(self,xx+8+fmod(y*3+t*4,40),y+1,9,1,'#b4c8ba')
	for i in range(220):
		var x=(i*71+13)%w;var y=(i*53+19)%h
		if x>w*.79+sin(y*.022)*16:continue
		Art.b(self,x,y,1+i%3,1,Color(ground).darkened(.05 if i%3 else .12))
	# Background pines, shrubs and rocks stay outside the placement grid.
	for i in range(21):
		var x=(i*83+12)%w;var y=(i*59+4)%h;var grid=unproject(Vector2(x,y))
		if grid.x> -18 and grid.x<214 and grid.y> -18 and grid.y<214:continue
		if x>w*.8:continue
		if i%3==0:
			Art.diamond(self,Vector2(x,y+2),9,4,'#778e7e');Art.b(self,x-1,y-19,3,20,'#7d785f')
			for k in range(3):Art.poly(self,[Vector2(x,y-35+k*8),Vector2(x-10-k*2,y-16+k*8),Vector2(x+10+k*2,y-16+k*8)],['#648574','#7a8965','#6d8180','#9da99a'][season]);Art.b(self,x-4,y-23+k*8,7,1,'#a4b28d')
		else:Art.diamond(self,Vector2(x,y),7+i%3,4,'#98a48d');Art.b(self,x-3,y-5,7,3,'#bac0a2');Art.b(self,x-2,y-3,3,1,'#d5d5b1')
	var left=project(Vector2(-4,-4));var right=project(Vector2(196,196))
	Art.poly(self,[left+Vector2(0,5),project(Vector2(196,-4))+Vector2(0,5),right+Vector2(0,12),project(Vector2(-4,196))+Vector2(0,5)],'#707c69')
	Art.poly(self,[left,project(Vector2(196,-4)),right,project(Vector2(-4,196))],ground)
	for edge in range(2):
		for i in range(22):
			var point=Vector2(-7+i*9.4,-7) if edge==0 else Vector2(-7,-7+i*9.4)
			palisade(project(point),season)
	for row in range(3):
		for col in range(3):
			var i=row*3+col;var p=project(g.tile_pos(i));Art.diamond(self,p,w*.096,w*.048,light if (row+col)%2==0 else ground)
			for k in range(12):Art.b(self,p.x-25+(k*17+i*7)%49,p.y-8+(k*11)%15,2,1,Color(ground).lightened(.13 if k%3 else -.1))
			var valid=selected>=0 and g.can_place(selected,i)
			if selected>=0 or inspect==i:
				var col_=Color('#e6d99d') if valid else Color('#a4b18d');draw_polyline(PackedVector2Array([p+Vector2(0,-w*.048),p+Vector2(w*.096,0),p+Vector2(0,w*.048),p+Vector2(-w*.096,0),p+Vector2(0,-w*.048)]),col_,1,false)
			if g.board[i].id<0 and valid:
				Art.line(self,p+Vector2(-4,-1),p+Vector2(4,-1),'#f4e4b0');Art.line(self,p+Vector2(0,-5),p+Vector2(0,3),'#f4e4b0')
	# Buildings and troops share a stable isometric depth order.
	var ordered=[]
	for i in range(9):
		if g.board[i].id>=0:ordered.append({'z':g.tile_pos(i).x+g.tile_pos(i).y,'tile':i})
	for u in g.units:
		if u.hp>0:ordered.append({'z':u.x+u.y,'unit':u})
	ordered.sort_custom(func(a,b):return a.z<b.z)
	for o in ordered:
		if o.has('tile'):
			var i=int(o.tile);Art.building(self,int(g.board[i].id),project(g.tile_pos(i)),int(g.board[i].level),t)
			if inspect==i:
				var p=project(g.tile_pos(i))+Vector2(0,20);draw_string(Art.FONT,p-Vector2(16,0),'Lv '+str(int(g.board[i].level)),HORIZONTAL_ALIGNMENT_LEFT,-1,13,Color('#3a524c'))
		else:
			var u=o.unit;var p=project(Vector2(u.x,u.y));Art.diamond(self,p+Vector2(0,1),4,2,Color(0,0,0,.12));Art.soldier(self,p,int(u.kind),u.enemy,u.move,u.flash,u.ward)
			if u.hp<u.maxhp:Art.b(self,p.x-6,p.y-25,12,2,'#5d6659');Art.b(self,p.x-6,p.y-25,12*maxf(0,u.hp/u.maxhp),1,'#c78361' if u.enemy else '#d9dca7')
	if g.phase=='build':
		for i in range(mini(15,g.army_count())):
			var p=project(Vector2(35+(i%5)*15,210+int(i/5)*12));Art.soldier(self,p,1 if i%3==0 else 0,false,t*2+i)
	for edge in range(2):
		for i in range(22):
			if i in [9,10,11,12]:continue
			var point=Vector2(196,-7+i*9.4) if edge==0 else Vector2(-7+i*9.4,196)
			palisade(project(point),season)
	var gate=project(Vector2(196,96));Art.flag(self,gate+Vector2(-11,0),t);Art.flag(self,gate+Vector2(11,10),t)
	for a in g.shots:
		var p=project(Vector2(a.x,a.y));Art.line(self,p-Vector2(4,3),p+Vector2(3,1),'#bf815b' if a.enemy else '#f6df9f',2)
	for f in fx:Art.b(self,f.x,f.y,f.size,f.size,Color(f.col,clampf(f.life*2,0,1)))
	for r in rings:
		var p=project(Vector2(r.x,r.y));draw_arc(p,20+(1-r.life)*55,0,TAU,40,Color(.95,.86,.61,r.life),2,false)
	# Edge approach banner makes the next attack direction visible.
	if g.phase=='build':
		var side=(g.year-1)%4;var p=project([Vector2(244,96),Vector2(96,-53),Vector2(-53,96),Vector2(96,244)][side]);Art.flag(self,p,t,'#b16d56');Art.b(self,p.x-7,p.y+6,18,12,'#6e6556');draw_string(Art.FONT,p+Vector2(-4,16),str(g.enemy_count()),HORIZONTAL_ALIGNMENT_LEFT,-1,12,Color('#f4e6b5'))
func palisade(p,season):
	var wood='#7a7660' if season!=3 else '#7f8880';Art.b(self,p.x-2,p.y-12,5,15,wood);Art.b(self,p.x-1,p.y-13,3,3,'#d4cba8');Art.b(self,p.x-1,p.y-9,1,10,Color(wood).lightened(.25));Art.b(self,p.x+2,p.y-8,1,10,Color(wood).darkened(.18))
