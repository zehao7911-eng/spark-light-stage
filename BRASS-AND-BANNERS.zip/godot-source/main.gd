extends Node2D
const Sim=preload('res://sim.gd')
const World=preload('res://world.gd')
const Card=preload('res://card.gd')
const Art=preload('res://art.gd')
const SAVE='brass-banners.v1'
var g=Sim.new()
var ui:Control
var hud:Node2D
var vp:SubViewport
var world
var image:TextureRect
var view=Vector2.ZERO
var raw=Vector2.ZERO
var density=1.0
var safe=Vector2.ZERO
var scene=Rect2()
var hand_rect=Rect2()
var selected=-1
var inspect=-1
var buttons=[]
var popup=''
var overlay
var sync=0.0
var saving=0.0
var accumulator=0.0
var hidden_=false
var paused=false
var callback
var sounds={}
var players=[]
var audio_cd=0.0
var toast=''
var toast_time=0.0
var fixture=false
var pointer_start=Vector2.ZERO
var drag_card=-1
func _ready():
	Engine.max_fps=50;load_game()
	if '--art-qa' in OS.get_cmdline_user_args():
		fixture=true;g.new_run();g.year=8;g.gold=28;g.crowns=12;g.board=[{'id':1,'level':2},{'id':7,'level':1},{'id':3,'level':2},{'id':4,'level':1},{'id':0,'level':1},{'id':2,'level':3},{'id':8,'level':1},{'id':5,'level':1},{'id':6,'level':2}];g.hand=[2,3,1]
	for name_ in ['build','hit','horn','win','rally','lost','gold']:
		if ResourceLoader.exists('res://audio/'+name_+'.wav'):sounds[name_]=load('res://audio/'+name_+'.wav')
	for i in range(10):var p=AudioStreamPlayer.new();add_child(p);players.append(p)
	vp=SubViewport.new();vp.disable_3d=true;vp.render_target_update_mode=SubViewport.UPDATE_ALWAYS;add_child(vp);world=World.new();world.g=g;vp.add_child(world)
	image=TextureRect.new();image.expand_mode=TextureRect.EXPAND_IGNORE_SIZE;image.texture=vp.get_texture();image.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST;image.mouse_filter=Control.MOUSE_FILTER_IGNORE;add_child(image)
	hud=Node2D.new();hud.draw.connect(draw_hud);add_child(hud)
	ui=Control.new();ui.mouse_filter=Control.MOUSE_FILTER_IGNORE;add_child(ui);layout()
	if g.year==1 and g.plays==2:toast='Pick a card. Tap a plot.';toast_time=5
	if OS.has_feature('web'):
		callback=JavaScriptBridge.create_callback(lifecycle);JavaScriptBridge.get_interface('window').bannerLifecycle=callback;JavaScriptBridge.eval('window.bannerReady && window.bannerReady()')
	web_snapshot()
func text_(canvas,s,p,sz=20,col=Color('#f1e6c6')):canvas.draw_string(Art.FONT,p,str(s),HORIZONTAL_ALIGNMENT_LEFT,-1,sz,col)
func label_(parent,s,p,sz_,font_size=19):
	var l=Label.new();l.position=p;l.size=sz_;l.text=s;l.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;l.clip_text=true;l.mouse_filter=Control.MOUSE_FILTER_IGNORE;l.add_theme_font_override('font',Art.FONT);l.add_theme_font_size_override('font_size',font_size);l.add_theme_color_override('font_color',Color('#e9dfc0'));parent.add_child(l);return l
func button(parent,id,kind,r,title_='',sub='',action='',n=0,card_=false,dark_=false):
	var b=Card.new();b.position=r.position;b.size=r.size;b.kind=kind;b.title_=title_;b.sub=sub;b.card=card_;b.dark=dark_;b.set_meta('id',id);b.set_meta('action',action);b.set_meta('n',n);b.tooltip_text=title_+'\n'+sub;parent.add_child(b);b.pressed.connect(func():command(action,n),CONNECT_DEFERRED);buttons.append(b);return b
func layout():
	raw=get_viewport_rect().size;density=maxf(1,DisplayServer.screen_get_scale()) if OS.has_feature('web') else 1.0
	var insets=[0,0,0,0]
	if OS.has_feature('web'):
		var d=JSON.parse_string(str(JavaScriptBridge.eval('JSON.stringify(["--sal","--sat","--sar","--sab"].map(k=>parseFloat(getComputedStyle(document.documentElement).getPropertyValue(k))||0))')))
		if d is Array:insets=d
	safe=Vector2(insets[0],insets[1]);position=safe*density;scale=Vector2.ONE*density;view=raw/density-Vector2(insets[0]+insets[2],insets[1]+insets[3])
	for c in ui.get_children():c.free()
	buttons=[];drag_card=-1
	var wide=view.x>view.y and view.x>=600
	if wide:
		var side=clampf(view.x*.29,224,340);scene=Rect2(12,82,view.x-side-36,view.y-98);hand_rect=Rect2(view.x-side-12,126,side,110)
	else:scene=Rect2(10,94,view.x-20,maxf(120,minf(view.x*1.1,view.y-360)));hand_rect=Rect2(10,view.y-226,view.x-20,108)
	image.position=scene.position;image.size=scene.size;vp.size=Vector2i(400 if wide else 320,maxi(120,int((400 if wide else 320)*scene.size.y/scene.size.x)));world.w=vp.size.x;world.h=vp.size.y
	button(ui,'help',18,Rect2(view.x-104,12,44,44),'Guide','','help')
	button(ui,'menu',12,Rect2(view.x-52,12,44,44),'Menu','','menu')
	var cw=(hand_rect.size.x-16)/3
	for i in range(3):
		var id=int(g.hand[i]);var b=button(ui,'card-'+str(i),maxi(1,id),Rect2(hand_rect.position+Vector2(i*(cw+8),0),Vector2(cw,hand_rect.size.y)),Sim.NAMES[id] if id>0 else 'PLACED',str(Sim.COST[id])+' gold' if id>0 else '','select',i,true);b.disabled=id<1 or g.plays<=0 or g.phase!='build';b.selected=selected==i
	var y_=hand_rect.end.y+10
	button(ui,'reroll',16,Rect2(hand_rect.position.x,y_,48,44),'Reroll','2 gold','reroll')
	button(ui,'trade',17,Rect2(hand_rect.position.x+56,y_,48,44),'Trade card','+2 gold','trade')
	button(ui,'legacy',9,Rect2(hand_rect.position.x+112,y_,48,44),'Legacy','','legacy')
	var rr=Rect2(hand_rect.position.x,y_+54,hand_rect.size.x,44)
	if wide:rr=Rect2(hand_rect.position.x,minf(view.y-62,y_+68),hand_rect.size.x,48)
	button(ui,'go',10 if g.phase=='build' else (11 if g.phase=='battle' else 13),rr,'DEFEND' if g.phase=='build' else ('RALLY' if g.phase=='battle' else ('NEXT YEAR' if g.phase=='won' else 'NEW KINGDOM')),'','go',0,false,true)
	if popup!='':build_popup()
	refresh();web_snapshot();queue_redraw();hud.queue_redraw()
func refresh():
	for b in buttons:
		if not is_instance_valid(b):continue
		var a=b.get_meta('action');var n=int(b.get_meta('n'))
		if a=='select':b.selected=selected==n;b.disabled=g.phase!='build' or g.hand[n]<1 or g.plays<=0
		elif a=='reroll':b.disabled=g.phase!='build' or g.plays<=0 or g.gold<2
		elif a=='trade':b.disabled=g.phase!='build' or g.plays<=0 or selected<0
		elif a=='go' and g.phase=='battle':b.disabled=g.rally_cd>0;b.title_='RALLY' if g.rally_cd<=0 else str(int(ceil(g.rally_cd)))+'s'
		elif a=='upgrade':b.disabled=g.meta[n]>=5 or g.crowns<g.meta_price(n);b.sub=str(g.meta_price(n))+' crowns  '+str(g.meta[n])+'/5'
		b.queue_redraw()
func command(a,n=0):
	match a:
		'select':selected=n;inspect=-1;world.selected=n;layout()
		'reroll':
			if g.reroll():selected=-1;world.selected=-1;sound('gold');layout()
		'trade':
			if g.sell_card(selected):selected=-1;world.selected=-1;layout()
		'go':
			if g.phase=='build':g.begin();selected=-1;world.selected=-1;layout()
			elif g.phase=='battle':g.rally(Vector2(96,96))
			elif g.phase=='won':g.next_year();selected=-1;world.selected=-1;world.fx.clear();layout()
			else:open_popup('restart')
		'help','menu','legacy','restart':open_popup(a)
		'close':popup='';layout()
		'upgrade':
			if g.upgrade(n):sound('build');build_popup()
		'mute':g.muted=not g.muted;build_popup();if g.muted:for p in players:p.stop()
		'calm':g.calm=not g.calm;build_popup()
		'pause':paused=not paused;build_popup()
		'restart-confirm':g.new_run();popup='';selected=-1;world.selected=-1;world.fx.clear();layout()
		'export':export_save()
	refresh();save_game();web_snapshot()
func open_popup(s):popup=s;drag_card=-1;build_popup();web_snapshot()
func build_popup():
	if is_instance_valid(overlay):overlay.free()
	buttons=buttons.filter(func(b):return is_instance_valid(b))
	overlay=Control.new();overlay.size=view;overlay.mouse_filter=Control.MOUSE_FILTER_STOP;ui.add_child(overlay)
	var veil=ColorRect.new();veil.color=Color(.08,.14,.13,.92);veil.size=view;overlay.add_child(veil)
	var w=minf(480,view.x-24);var h=minf(600,view.y-24);var origin=(view-Vector2(w,h))/2
	var panel=Panel.new();panel.position=origin;panel.size=Vector2(w,h);var st=StyleBoxFlat.new();st.bg_color=Color('#304b49');st.border_color=Color('#c2ae7c');st.set_border_width_all(2);panel.add_theme_stylebox_override('panel',st);overlay.add_child(panel)
	label_(panel,{'help':'A SMALL KINGDOM. BIG PLANS.','menu':'TRAVEL CHEST','legacy':'THE ROYAL LEGACY','restart':'A NEW DYNASTY?'}.get(popup,''),Vector2(16,16),Vector2(w-80,48),25);button(panel,'close',14,Rect2(w-58,10,44,44),'Close','','close',0,false,true)
	var scroll=ScrollContainer.new();scroll.position=Vector2(14,78);scroll.size=Vector2(w-28,h-94);scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED;panel.add_child(scroll)
	var body=Control.new();var ww=w-42;body.custom_minimum_size=Vector2(ww,100);scroll.add_child(body);var yy=0.0
	if popup=='help':
		label_(body,'1  Pick a card. Tap a glowing plot.\n2  Place two cards, then DEFEND.\n3  Tap the battle to rally your troops.\n\nSame building? Upgrade it (up to Lv 5). A different card replaces the plot. The keep cannot be replaced.\n\nForge: boosts adjacent troop damage.\nChapel: boosts adjacent troop health.\nMill: boosts adjacent field income.\n\nRally heals and shields nearby soldiers. Legacy upgrades add a damaging volley.\n\nWin years to earn crowns. Spend them on permanent legacy upgrades. Restarting keeps your crowns, legacy and best year. Armies return at full strength each year.\n\nTrade a selected card for 2 gold if you cannot use it. Reroll costs 2 gold. Menus pause battle; no offline combat or income. Progress saves automatically.',Vector2(0,0),Vector2(ww,700),21);yy=710
	elif popup=='legacy':
		label_(body,str(g.crowns)+' crowns  /  Best year '+str(g.best),Vector2(0,0),Vector2(ww,40),24);yy=50
		for i in range(3):
			button(body,'upgrade-'+str(i),[1,2,11][i],Rect2(0,yy,ww,62),['Royal treasury','Veteran guard','Skyward volley'][i],'','upgrade',i,false,true);yy+=68
			label_(body,['+3 starting gold; +1 annual income','+1 keep defender; stronger troops & keep bolts','Rally damages enemies and grows in radius'][i],Vector2(6,yy),Vector2(ww-12,50),18);yy+=60
		label_(body,'Permanent across new kingdoms.\nCrowns earned: '+str(g.earned),Vector2(6,yy),Vector2(ww-12,70),20);yy+=80
	elif popup=='menu':
		for d in [['pause',13,'Resume' if paused else 'Pause'],['mute',15,'Sound on' if g.muted else 'Sound off'],['calm',11,'Full effects' if g.calm else 'Calm effects'],['legacy',9,'Royal legacy'],['help',0,'Field guide'],['export',1,'Export save'],['restart',16,'New dynasty']]:button(body,'setting-'+d[0],d[1],Rect2(0,yy,ww,54),d[2],'',d[0],0,false,true);yy+=62
		label_(body,'Best year '+str(g.best)+'  /  Victories '+str(g.wins),Vector2(6,yy),Vector2(ww-12,50),20);yy+=60
	elif popup=='restart':
		label_(body,'The current board and gold will restart. Your crowns, royal legacy and best year stay with you.',Vector2(0,0),Vector2(ww,130),23);yy=150;button(body,'restart-confirm',9,Rect2(0,yy,ww,58),'BEGIN AGAIN','','restart-confirm',0,false,true);yy+=75
	body.custom_minimum_size.y=yy;refresh()
func _input(e):
	if e is InputEventKey and e.pressed and not e.echo:
		if e.keycode==KEY_ESCAPE:command('close' if popup!='' else 'menu')
		elif e.keycode==KEY_SPACE and popup=='':command('go')
	if e is InputEventMouseButton and e.button_index==MOUSE_BUTTON_LEFT:
		var p=e.position/density-safe
		if e.pressed:
			pointer_start=p;drag_card=-1
			if popup=='':
				for b in buttons:
					if b.get_meta('action')=='select' and not b.disabled and Rect2(b.position,b.size).has_point(p):drag_card=int(b.get_meta('n'))
		elif popup=='' and scene.has_point(p):
			if drag_card>=0:selected=drag_card;world.selected=selected
			var wp=world.unproject((p-scene.position)/scene.size*Vector2(vp.size))
			if g.phase=='battle':g.rally(wp)
			elif g.phase=='build' and wp.x>=0 and wp.x<192 and wp.y>=0 and wp.y<192:
				var i=int(wp.y/64)*3+int(wp.x/64);inspect=i;world.inspect=i
				if selected>=0:
					if g.place(selected,i):selected=-1;world.selected=-1;layout();save_game()
					else:toast='Need gold, or plot is at max level';toast_time=2
			drag_card=-1;refresh();web_snapshot();get_viewport().set_input_as_handled()
func sound(s):
	if g.muted or hidden_ or not sounds.has(s):return
	for p in players:
		if not p.playing:p.stream=sounds[s];p.pitch_scale=randf_range(.96,1.04);p.play();return
func burst(x,y,col,n=7):
	if g.calm:return
	var p=world.project(Vector2(x,y))
	for i in range(n):
		if world.fx.size()<100:world.fx.append({'x':p.x,'y':p.y-8,'vx':randf_range(-35,35),'vy':randf_range(-65,-20),'size':randi_range(1,3),'col':Color(col),'life':randf_range(.2,.6)})
func _process(dt):
	if raw!=get_viewport_rect().size:layout()
	if hidden_:return
	audio_cd=maxf(0,audio_cd-dt);toast_time=maxf(0,toast_time-dt)
	if popup=='' and not paused:
		world.t+=minf(.1,dt);accumulator+=minf(.1,dt)
		while accumulator>=1.0/60:g.update(1.0/60);accumulator-=1.0/60
		for f in world.fx:f.life-=dt;f.x+=f.vx*dt;f.y+=f.vy*dt;f.vy+=120*dt
		world.fx=world.fx.filter(func(f):return f.life>0)
		for r in world.rings:r.life-=dt
		world.rings=world.rings.filter(func(r):return r.life>0)
	var changed=false
	for e in g.events:
		match e[0]:
			'build':burst(g.tile_pos(e[1]).x,g.tile_pos(e[1]).y,'#f6dfa6',12);sound('build')
			'hit':
				burst(e[1],e[2],'#e8d8aa',2)
				if audio_cd<=0:sound('hit');audio_cd=.1
			'fall':burst(e[1],e[2],'#bd8a64' if e[3] else '#83aca0',5)
			'horn':sound('horn')
			'rally':
				if world.rings.size()<5:world.rings.append({'x':e[1],'y':e[2],'life':1.0})
				sound('rally')
			'win':sound('win');toast='VICTORY   +'+str(e[1])+' gold   +'+str(e[2])+' crown';toast_time=4;changed=true
			'lost':sound('lost');toast='A brave last stand';toast_time=4;changed=true
			'breach':toast='KEEP UNDER ATTACK';toast_time=1.5
			'gold':sound('gold')
			'unlock':toast=e[1];toast_time=4;sound('win')
	g.events.clear()
	if changed:layout();save_game()
	sync+=dt;saving+=dt
	if sync>.15:sync=0;refresh();web_snapshot()
	if saving>4:saving=0;save_game()
	world.queue_redraw();queue_redraw();hud.queue_redraw()
func _draw():
	draw_rect(Rect2(Vector2.ZERO,view),Color('#253e3c'));draw_rect(Rect2(0,0,view.x,68),Color('#2f4e49'));draw_line(Vector2(0,69),Vector2(view.x,69),Color('#a58e64'),2)
	text_(self,'BRASS & BANNERS',Vector2(14,30),25);text_(self,'A kingdom in the making',Vector2(14,51),14,Color('#c7c6a7'))
	draw_rect(scene.grow(3),Color('#d2c49b'),false,2)
	var wide=view.x>view.y and view.x>=600
	var xp=hand_rect.position.x;var yy=hand_rect.position.y-15
	text_(self,('CHOOSE & PLACE  '+str(g.plays)+'/2') if g.phase=='build' else ('VICTORY' if g.phase=='won' else ('HOLD THE LINE' if g.phase=='battle' else 'DYNASTY ENDED')),Vector2(xp,yy),20)
	if wide:
		text_(self,'YEAR '+str(g.year),Vector2(xp,88),25,Color('#e9cc8a'))
		var yy_=hand_rect.end.y+180
		if yy_<view.y-40:
			text_(self,'INCOME  +'+str(g.income()),Vector2(xp,yy_),20);text_(self,'ARMY  '+str(g.army_count()),Vector2(xp,yy_+28),20)
	else:
		var free_=hand_rect.position.y-30-scene.end.y
		if free_>52:
			text_(self,'+'+str(g.income())+' / year       '+str(g.army_count())+' troops',Vector2(14,scene.end.y+31),21,Color('#d1d2ad'))
	if selected>=0 and g.hand[selected]>0:
		var hint=Sim.TIPS[g.hand[selected]];var yy_=scene.end.y+58 if not wide else hand_rect.end.y+205
		if (yy_<hand_rect.position.y-32 or wide) and yy_<view.y-12:text_(self,hint,Vector2(14 if not wide else xp,yy_),16,Color('#efc77d'))
func draw_hud():
	var p=scene.position+Vector2(9,20)
	text_(hud,'YEAR '+str(g.year),p,20,Color('#304c49'));text_(hud,str(g.gold)+' GOLD',p+Vector2(0,21),18,Color('#555c45'));text_(hud,str(g.crowns)+' CROWNS',p+Vector2(0,40),16,Color('#596653'))
	var x=scene.end.x-104;var yy=scene.position.y+12
	for i in range(6):
		var fill=Color('#ad6253') if g.hearts>i*2 else Color('#909c7e');hud.draw_rect(Rect2(x+i*16,yy,12,7),fill);hud.draw_rect(Rect2(x+i*16+2,yy-2,8,11),fill)
	if g.phase=='battle':
		var live=g.units.filter(func(u):return u.enemy and u.hp>0).size();text_(hud,str(live)+' ENEMIES',Vector2(x,yy+30),17,Color('#694e42'))
	if toast_time>0 and popup=='':
		var sz=Art.FONT.get_string_size(toast,HORIZONTAL_ALIGNMENT_LEFT,-1,18).x;var p_=Vector2(scene.get_center().x-sz/2,scene.end.y-14);hud.draw_rect(Rect2(p_-Vector2(8,20),Vector2(sz+16,28)),Color(.15,.23,.21,.94));text_(hud,toast,p_,18)
	if paused:text_(hud,'PAUSED',scene.get_center(),28)
func save_game():
	if fixture:return
	var d=g.snapshot();d.app_paused=paused;var data=JSON.stringify(d)
	if OS.has_feature('web'):JavaScriptBridge.eval('try{localStorage.setItem("'+SAVE+'",'+JSON.stringify(data)+')}catch(e){}')
	else:var f=FileAccess.open('user://brass-banners.json',FileAccess.WRITE);if f:f.store_string(data)
func load_game():
	var raw_=''
	if OS.has_feature('web'):raw_=str(JavaScriptBridge.eval('(()=>{try{return localStorage.getItem("'+SAVE+'")||""}catch(e){return ""}})()'))
	elif FileAccess.file_exists('user://brass-banners.json'):raw_=FileAccess.get_file_as_string('user://brass-banners.json')
	if raw_!='':
		var d=JSON.parse_string(raw_)
		if g.restore(d):paused=d.get('app_paused',false)==true
func lifecycle(args):
	if args.is_empty():return
	if str(args[0])=='away':hidden_=true;accumulator=0;drag_card=-1;for p in players:p.stop()
	elif str(args[0])=='back':hidden_=false;accumulator=0
	save_game()
func export_save():
	var data=JSON.stringify(g.snapshot())
	if OS.has_feature('web'):JavaScriptBridge.eval('(()=>{let a=document.createElement("a");a.href=URL.createObjectURL(new Blob(['+JSON.stringify(data)+'],{type:"application/json"}));a.download="brass-banners-save.json";a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000)})()')
func web_snapshot():
	if not OS.has_feature('web'):return
	var d={'year':g.year,'gold':g.gold,'crowns':g.crowns,'hearts':g.hearts,'phase':g.phase,'plays':g.plays,'board':g.board,'hand':g.hand,'meta':g.meta,'selected':selected,'army':g.army_count(),'income':g.income(),'enemy':g.units.filter(func(u):return u.enemy and u.hp>0).size(),'rally':g.rally_cd,'popup':popup,'paused':paused,'view':[view.x,view.y],'scene':[scene.position.x+safe.x,scene.position.y+safe.y,scene.size.x,scene.size.y],'tiles':[],'buttons':[]}
	for i in range(9):
		var p=world.project(g.tile_pos(i))/Vector2(vp.size)*scene.size+scene.position+safe;d.tiles.append({'i':i,'x':p.x,'y':p.y})
	for b in buttons:
		if not is_instance_valid(b) or not b.is_visible_in_tree():continue
		var p=b.global_position/density;var visible=true;var a=b.get_parent()
		while a!=null:
			if a is ScrollContainer and not Rect2(a.global_position/density,a.size).encloses(Rect2(p,b.size)):visible=false
			a=a.get_parent()
		if visible:d.buttons.append({'id':b.get_meta('id'),'x':p.x,'y':p.y,'w':b.size.x,'h':b.size.y,'disabled':b.disabled})
	JavaScriptBridge.eval('window.bannerSnapshot && window.bannerSnapshot('+JSON.stringify(d)+')')
