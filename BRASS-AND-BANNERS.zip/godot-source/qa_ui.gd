extends SceneTree
func _initialize():call_deferred('test')
func test():
	var game=load('res://main.tscn').instantiate();root.add_child(game);game.fixture=true;game.g=load('res://sim.gd').new();game.world.g=game.g
	for dimensions in [Vector2i(320,480),Vector2i(320,667),Vector2i(390,844),Vector2i(640,360),Vector2i(844,390),Vector2i(1280,720)]:
		root.size=dimensions;await process_frame;await process_frame;game.popup='';game.layout()
		assert(game.image.size==game.scene.size)
		var rects=[]
		for b in game.buttons:
			var r=Rect2(b.position,b.size);assert(Rect2(Vector2.ZERO,game.view).encloses(r),'Control outside screen')
			assert(b.size.x>=44 and b.size.y>=44,'Touch target too small')
			for q in rects:assert(not r.intersects(q),'Overlapping controls')
			rects.append(r)
		for i in range(9):
			var p=game.world.project(game.g.tile_pos(i));var back=game.world.unproject(p)
			assert(back.distance_to(game.g.tile_pos(i))<.001,'Isometric hit test must match picture')
		for menu in ['help','legacy','menu','restart']:game.open_popup(menu);await process_frame;assert(game.overlay.size==game.view)
	game.command('close');game.command('select',0);assert(game.selected==0)
	assert(game.g.place(0,5));game.g.begin();game.open_popup('menu');var time_=game.g.battle_time
	await create_timer(.15).timeout;assert(game.g.battle_time==time_,'Menus pause battle')
	game.command('mute');assert(game.g.muted);game.sound('hit');for p in game.players:assert(not p.playing)
	game.command('close');game.paused=true;await create_timer(.1).timeout;assert(game.g.battle_time==time_,'Pause stops battle')
	game.lifecycle(['away']);assert(game.hidden_);game.lifecycle(['back']);assert(not game.hidden_)
	print('BANNERS UI QA PASSED: six viewports, isometric selection, four menus, pause/mute/lifecycle')
	game.free();quit()
