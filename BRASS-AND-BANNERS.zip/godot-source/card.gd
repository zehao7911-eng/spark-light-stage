extends Button
const Art=preload('res://art.gd')
var kind=1
var title_=''
var sub=''
var detail=''
var selected=false
var card=false
var dark=false
func _ready():flat=true;mouse_default_cursor_shape=Control.CURSOR_POINTING_HAND
func _draw():
	var fill=Color('#ede4c9') if not dark else Color('#365c58')
	if disabled:fill=fill.darkened(.09)
	if is_hovered() and not disabled:fill=fill.lightened(.08)
	if is_pressed():fill=fill.darkened(.1)
	draw_rect(Rect2(0,3,size.x,size.y-3),Color('#695c49'));draw_rect(Rect2(0,0,size.x,size.y-3),fill);draw_rect(Rect2(2,2,size.x-4,size.y-7),Color('#c0ae88') if not dark else Color('#68877a'),false,1)
	if selected or has_focus():draw_rect(Rect2(1,1,size.x-2,size.y-4),Color('#e4b65d'),false,2)
	var ink=Color('#374c47') if not dark else Color('#f4e6be')
	if disabled:ink=ink.darkened(.1)
	if card:
		Art.icon(self,kind,Vector2(size.x/2-22,8),1)
		draw_string(Art.FONT,Vector2(2,72),title_,HORIZONTAL_ALIGNMENT_CENTER,size.x-4,20,ink)
		draw_string(Art.FONT,Vector2(2,94),sub,HORIZONTAL_ALIGNMENT_CENTER,size.x-4,18,ink)
	elif size.x<60:
		Art.icon(self,kind,Vector2((size.x-44)/2,(size.y-44)/2-2),1)
	else:
		Art.icon(self,kind,Vector2(6,(size.y-44)/2-3),.85)
		draw_string(Art.FONT,Vector2(48,25 if sub!='' else size.y/2+6),title_,HORIZONTAL_ALIGNMENT_LEFT,size.x-54,22,ink)
		if sub!='':draw_string(Art.FONT,Vector2(48,46),sub,HORIZONTAL_ALIGNMENT_LEFT,size.x-54,16,ink)
