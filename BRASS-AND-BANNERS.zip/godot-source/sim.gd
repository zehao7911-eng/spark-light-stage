extends RefCounted
const NAMES=['Keep','Wheatfield','Barracks','Archers','Forge','Chapel','Rampart','Windmill','Cavalry']
const COST=[0,3,4,5,5,5,3,6,7]
const TIPS=['The heart of your realm','+3 gold each year','Recruit 3 swordsmen','Recruit 2 ranged archers','Adjacent troops gain +35% damage','Adjacent troops gain +40% health','Recruit 2 sturdy guardians','Adjacent fields yield +3 gold','Recruit 2 swift knights']
var board=[]
var hand=[]
var year=1
var gold=10
var hearts=12.0
var crowns=0
var earned=0
var best=0
var wins=0
var meta=[0,0,0]
var phase='build'
var plays=2
var units=[]
var shots=[]
var events=[]
var elapsed=0.0
var battle_time=0.0
var rally_cd=0.0
var rng=RandomNumberGenerator.new()
var serial=0
var muted=false
var calm=false
var seed_=0
func _init():
	seed_=int(Time.get_unix_time_from_system())%10000000;rng.seed=seed_;new_run()
func new_run():
	board=[]
	for i in range(9):board.append({'id':0 if i==4 else -1,'level':1 if i==4 else 0})
	year=1;gold=10+meta[0]*3;hearts=12;phase='build';plays=2;units=[];shots=[];elapsed=0;battle_time=0;rally_cd=0;serial=0
	hand=[2,1,3];events.clear()
func tile_pos(i):return Vector2((i%3)*64+32,int(i/3)*64+32)
func adjacent(i,j):return abs(i%3-j%3)+abs(int(i/3)-int(j/3))==1
func bonus(i,kind):
	var v=0
	for j in range(9):
		if adjacent(i,j) and board[j].id==kind:v+=board[j].level
	return v
func price(id):return COST[id]
func can_place(h,i):
	if phase!='build' or plays<=0 or h<0 or h>=hand.size() or hand[h]<1 or i<0 or i>8 or i==4:return false
	var id=int(hand[h]);return gold>=price(id) and (board[i].id!=id or board[i].level<5)
func place(h,i):
	if not can_place(h,i):return false
	var id=int(hand[h]);gold-=price(id)
	if board[i].id==id:board[i].level+=1
	else:board[i]={'id':id,'level':1}
	hand[h]=-1;plays-=1;events.append(['build',i,id]);return true
func sell_card(h):
	if phase!='build' or plays<=0 or h<0 or h>=hand.size() or hand[h]<1:return false
	hand[h]=-1;plays-=1;gold+=2;events.append(['gold',2]);return true
func reroll():
	if phase!='build' or gold<2 or plays<=0:return false
	gold-=2;deal();return true
func deal():
	hand=[]
	var pool=[1,2,3,4,5,6]
	if year>=3:pool.append(7)
	if year>=5:pool.append(8)
	for i in range(3):hand.append(pool[rng.randi_range(0,pool.size()-1)])
func income():
	var v=4+meta[0]
	for i in range(9):
		if board[i].id==1:v+=board[i].level*(3+3*bonus(i,7))
	return v
func army_count():
	var n=4+meta[1]
	for b in board:
		if b.id in [2,3,6,8]:n+=([3,2,2,2][[2,3,6,8].find(int(b.id))])*b.level
	return mini(70,n)
func enemy_count():return mini(64,5+year*2)
func add_unit(p,enemy,kind,level,damage_bonus=0,health_bonus=0):
	serial+=1
	var hp=(10+minf(80,year*1.4)) if enemy else ([22,14,50,34,90][kind]+level*7)*(1+health_bonus*.4)
	var attack=(2.5+minf(18,year*.35)) if enemy else ([5,5,3.5,9,8][kind]+level*2+meta[1])*(1+damage_bonus*.35)
	units.append({'uid':serial,'x':p.x,'y':p.y,'hp':hp,'maxhp':hp,'enemy':enemy,'kind':kind,'level':level,'atk':attack,'cd':rng.randf_range(0,.6),'flash':0.0,'ward':0.0,'move':0.0})
func begin():
	if phase!='build':return false
	phase='battle';battle_time=0;units=[];shots=[];rally_cd=0
	for i in range(4+meta[1]):add_unit(Vector2(84+(i%3)*12,94+int(i/3)*10),false,0,1)
	for i in range(9):
		var b=board[i]
		if b.id not in [2,3,6,8]:continue
		var kind=[2,3,6,8].find(int(b.id));var n=mini(15,(3 if kind==0 else 2)*int(b.level))
		for j in range(n):
			if units.size()>=70:break
			add_unit(tile_pos(i)+Vector2((j%4)*9-12,int(j/4)*9),false,kind,int(b.level),bonus(i,4),bonus(i,5))
	var side=(year-1)%4
	for i in range(enemy_count()):
		var p=Vector2(230+(i%5)*12,18+int(i/5)*16)
		if side==1:p=Vector2(18+int(i/5)*16,-45-(i%5)*12)
		elif side==2:p=Vector2(-45-(i%5)*12,18+int(i/5)*16)
		elif side==3:p=Vector2(18+int(i/5)*16,230+(i%5)*12)
		add_unit(p,true,1 if year%3==0 else 0,1)
	if year%5==0:
		add_unit(Vector2(240,100),true,4,3);units[-1].hp*=5;units[-1].maxhp=units[-1].hp;units[-1].atk*=2
	events.append(['horn',year]);return true
func hit(u,amount):
	if u.hp<=0:return
	u.hp-=amount*(.5 if u.ward>0 else 1);u.flash=.12
	if u.hp<=0:events.append(['fall',u.x,u.y,u.enemy])
func rally(p):
	if phase!='battle' or rally_cd>0:return false
	rally_cd=5.5;var radius=60+meta[2]*10
	for u in units:
		if Vector2(u.x,u.y).distance_to(p)>radius or u.hp<=0:continue
		if u.enemy:
			if meta[2]>0:hit(u,5+meta[2]*4)
		else:u.hp=minf(u.maxhp,u.hp+5+meta[2]*3);u.ward=2;u.cd=0
	events.append(['rally',p.x,p.y,radius]);return true
func damage_keep(amount):
	hearts=maxf(0,hearts-amount);events.append(['breach',amount])
func update(dt):
	if phase!='battle':return
	dt=clampf(dt,0,.05);elapsed+=dt;battle_time+=dt;rally_cd=maxf(0,rally_cd-dt)
	for u in units:
		if u.hp<=0:continue
		u.cd-=dt;u.flash=maxf(0,u.flash-dt);u.ward=maxf(0,u.ward-dt)
		var p=Vector2(u.x,u.y);var target=null;var dist=INF
		for v in units:
			if v.enemy==u.enemy or v.hp<=0:continue
			var d=p.distance_squared_to(Vector2(v.x,v.y))
			if d<dist:dist=d;target=v
		var range_=75 if u.kind==1 else 13
		if target!=null and dist<range_*range_:
			if u.cd<=0:
				u.cd=.9 if u.kind==1 else .7
				if u.kind==1:shots.append({'x':u.x,'y':u.y,'target':target.uid,'damage':u.atk,'life':2.0,'enemy':u.enemy})
				else:hit(target,u.atk);events.append(['hit',target.x,target.y])
		else:
			var dest=Vector2(target.x,target.y) if target!=null else Vector2(96,96)
			if u.enemy and p.distance_to(Vector2(96,96))<16:
				if u.cd<=0:u.cd=1;damage_keep(1.5 if u.kind==4 else .5)
			else:
				var direction=p.direction_to(dest);var speed=(18 if u.kind!=3 else 33)*(1 if u.enemy else 1.1)
				u.x+=direction.x*speed*dt;u.y+=direction.y*speed*dt;u.move+=dt*10
		# Gentle separation keeps squads readable without an unbounded physics world.
		for v in units:
			if v.uid>=u.uid or v.enemy!=u.enemy or v.hp<=0:continue
			var diff=Vector2(u.x-v.x,u.y-v.y);var length_=diff.length()
			if length_>0 and length_<6:u.x+=diff.x/length_*10*dt;u.y+=diff.y/length_*10*dt
	for a in shots:
		a.life-=dt
		for u in units:
			if u.uid!=a.target or u.hp<=0:continue
			var p=Vector2(a.x,a.y).move_toward(Vector2(u.x,u.y),200*dt);a.x=p.x;a.y=p.y
			if p.distance_to(Vector2(u.x,u.y))<5:hit(u,a.damage);a.life=0;events.append(['hit',u.x,u.y])
	shots=shots.filter(func(a):return a.life>0)
	# The keep contributes a visible, modest defensive bolt every 0.8 seconds.
	if int(battle_time*1.25)!=int((battle_time-dt)*1.25):
		for u in units:
			if u.enemy and u.hp>0:shots.append({'x':96.0,'y':96.0,'target':u.uid,'damage':5.0+meta[1]*2,'life':2.0,'enemy':false});break
	var living=units.filter(func(u):return u.enemy and u.hp>0).size()
	if hearts<=0 or battle_time>75:phase='lost';best=maxi(best,year-1);events.append(['lost',year]);return
	if living==0:
		phase='won';var reward=income();gold+=reward;wins+=1;best=maxi(best,year);var c=1+(1 if year%5==0 else 0);crowns+=c;earned+=c;events.append(['win',reward,c])
func next_year():
	if phase!='won':return false
	year+=1;phase='build';plays=2;hearts=minf(12,hearts+1);units.clear();shots.clear();deal()
	if year in [3,5]:events.append(['unlock','WINDMILL UNLOCKED' if year==3 else 'CAVALRY UNLOCKED'])
	return true
func meta_price(i):return (3+i*2)*(meta[i]+1)
func upgrade(i):
	if i<0 or i>2 or meta[i]>=5 or crowns<meta_price(i):return false
	crowns-=meta_price(i);meta[i]+=1;events.append(['upgrade',i]);return true
func snapshot():
	return {'v':1,'board':board.duplicate(true),'hand':hand.duplicate(),'year':year,'gold':gold,'hearts':hearts,'crowns':crowns,'earned':earned,'best':best,'wins':wins,'meta':meta.duplicate(),'phase':phase,'plays':plays,'units':units.duplicate(true),'shots':shots.duplicate(true),'elapsed':elapsed,'battle_time':battle_time,'rally_cd':rally_cd,'serial':serial,'muted':muted,'calm':calm,'rng':str(rng.state),'seed':str(rng.seed)}
func restore(d):
	if not d is Dictionary or d.get('v')!=1:return false
	for key in ['board','hand','meta','units','shots']:
		if not d.get(key) is Array:return false
	if d.board.size()!=9 or d.hand.size()!=3 or d.meta.size()!=3 or d.units.size()>150 or d.shots.size()>500:return false
	for b in d.board:
		if not b is Dictionary or not (b.get('id') is float or b.get('id') is int) or not (b.get('level') is float or b.get('level') is int):return false
		if b.id!=floor(b.id) or b.id< -1 or b.id>8 or b.level!=floor(b.level) or b.level<0 or b.level>5:return false
	if d.board[4].id!=0:return false
	for x in d.hand:
		if not (x is float or x is int) or x!=floor(x) or x< -1 or x>8:return false
	for x in d.meta:
		if not (x is float or x is int) or x!=floor(x) or x<0 or x>5:return false
	for key in ['year','gold','hearts','crowns','earned','best','wins','plays','elapsed','battle_time','rally_cd','serial']:
		if not (d.get(key) is float or d.get(key) is int) or not is_finite(d[key]) or d[key]<0 or d[key]>1e9:return false
	if d.year<1 or d.hearts>12 or d.plays>2 or d.get('phase') not in ['build','battle','won','lost']:return false
	for u in d.units:
		if not u is Dictionary or not u.get('enemy') is bool:return false
		for key in ['uid','x','y','hp','maxhp','kind','level','atk','cd','flash','ward','move']:
			if not (u.get(key) is float or u.get(key) is int) or not is_finite(u[key]) or absf(u[key])>1e9:return false
		if u.kind<0 or u.kind>4 or u.kind!=floor(u.kind):return false
	for a in d.shots:
		if not a is Dictionary or not a.get('enemy') is bool:return false
		for key in ['x','y','target','damage','life']:
			if not (a.get(key) is float or a.get(key) is int) or not is_finite(a[key]):return false
	for key in ['year','gold','crowns','earned','best','wins','plays','serial']:set(key,int(d[key]))
	for key in ['hearts','elapsed','battle_time','rally_cd']:set(key,float(d[key]))
	board=d.board.duplicate(true);hand=d.hand.map(func(x):return int(x));meta=d.meta.map(func(x):return int(x));units=d.units.duplicate(true);shots=d.shots.duplicate(true);phase=d.phase;muted=d.get('muted')==true;calm=d.get('calm')==true
	for b in board:b.id=int(b.id);b.level=int(b.level)
	for u in units:u.uid=int(u.uid);u.kind=int(u.kind);u.level=int(u.level)
	for a in shots:a.target=int(a.target)
	rng.seed=int(d.get('seed','0'));rng.state=int(d.get('rng','0'));events.clear();return true
