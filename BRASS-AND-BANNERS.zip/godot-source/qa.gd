extends SceneTree
const Sim=preload('res://sim.gd')
var checks=0
func ck(b,msg):assert(b,msg);checks+=1
func ticks(g,n):
	for i in range(n):g.update(1.0/60);g.events.clear()
func play_cards(g):
	for unused in range(2):
		var score=-INF;var choice=Vector2i(-1,-1)
		for h in range(3):
			if g.hand[h]<1:continue
			for i in range(9):
				if not g.can_place(h,i):continue
				var id=int(g.hand[h]);var b=g.board[i];var s=0.0
				if b.id==id:s=12.0-b.level
				elif b.id== -1:s=7.0
				else:s=-10.0
				if id in [2,3,6,8]:s+=5
				if id==1:s+=6 if g.income()<10 else -4
				if id in [4,5]:
					for j in range(9):
						if g.adjacent(i,j) and g.board[j].id in [2,3,6,8]:s+=3
				if s>score:score=s;choice=Vector2i(h,i)
		if choice.x>=0:g.place(choice.x,choice.y)
		else:
			for h in range(3):
				if g.hand[h]>0:g.sell_card(h);break
func _initialize():
	var g=Sim.new();g.rng.seed=1207
	ck(not g.place(0,4),'Keep cannot be replaced')
	ck(g.place(0,5) and g.gold==6 and g.army_count()==7,'Barracks placement consumes gold and creates squad')
	ck(g.place(1,7) and g.gold==3 and g.income()==7,'Wheatfield increases annual income')
	ck(not g.place(2,0),'Two placements enforced')
	ck(g.begin(),'Battle starts');ticks(g,240)
	var restored=Sim.new();ck(restored.restore(JSON.parse_string(JSON.stringify(g.snapshot()))),'Mid-battle JSON restores')
	ck(restored.army_count()==7 and restored.income()==7,'JSON restoration retains typed building recruitment and income')
	ticks(g,600);ticks(restored,600)
	ck(g.phase==restored.phase and absf(g.hearts-restored.hearts)<.0001 and g.units.size()==restored.units.size(),'Mid-battle restoration preserves outcome')
	ck(g.phase=='won' and g.crowns==1 and g.gold==10,'Opening army wins actual collision simulation')
	ticks(g,600);ck(g.crowns==1 and g.gold==10,'Won state cannot double-grant rewards')
	ck(g.next_year() and not g.next_year() and g.year==2,'Year continuation guarded')
	g.board[1]={'id':1,'level':2};g.board[2]={'id':7,'level':1};ck(g.income()==19,'Adjacent mill multiplies field yield')
	g.board[5]={'id':2,'level':1};g.board[8]={'id':4,'level':1};ck(g.bonus(5,4)==1,'Forge adjacency excludes diagonals')
	g.gold=0;g.plays=2;g.hand=[2,3,6];ck(g.sell_card(0) and g.gold==2 and g.plays==1,'Trade prevents unaffordable hand lock')
	ck(g.reroll() and g.gold==0 and g.hand.size()==3,'Reroll spends exact price')
	g.crowns=20;ck(g.upgrade(2) and g.crowns==13 and g.meta[2]==1,'Legacy price and unlock')
	g.begin();var enemy=g.units.filter(func(u):return u.enemy)[0];var hp=enemy.hp
	ck(g.rally(Vector2(enemy.x,enemy.y)) and enemy.hp<hp and not g.rally(Vector2.ZERO),'Volley damages actual targets and has cooldown')
	var keep_crowns=g.crowns;g.best=8;g.new_run();ck(g.meta[2]==1 and g.crowns==keep_crowns and g.best==8 and g.year==1 and g.hearts==12,'New dynasty retains permanent growth')
	var bad=g.snapshot();bad.board[4].id=8;ck(not Sim.new().restore(bad),'Malformed keep rejected')
	bad=g.snapshot();bad.units=[{}];ck(not Sim.new().restore(bad),'Malformed actor rejected')
	var longest=0
	for seed_ in range(3):
		var run=Sim.new();run.rng.seed=seed_+200
		for year_ in range(18):
			play_cards(run);run.begin()
			for i in range(4501):
				if i%340==0:run.rally(Vector2(96,96))
				run.update(1.0/60);run.events.clear()
				if run.phase!='battle':break
			ck(run.phase in ['won','lost'],'Every battle terminates')
			ck(run.units.size()<=135 and run.shots.size()<200,'Battle actors bounded')
			if run.phase=='lost':break
			longest=maxi(longest,run.year)
			if run.crowns>=run.meta_price(1):run.upgrade(1)
			run.next_year()
	ck(longest>=10,'Reasonable placement strategy reaches later unlocks and seasons')
	print('BANNERS QA PASSED ',checks,' assertions; deepest simulated year=',longest)
	quit()
