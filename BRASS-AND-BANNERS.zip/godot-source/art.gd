extends RefCounted
const FONT=preload('res://fonts/pixel.ttf')
static func b(c,x,y,w,h,col):c.draw_rect(Rect2(floor(x),floor(y),w,h),Color(col))
static func poly(c,pts,col):c.draw_colored_polygon(PackedVector2Array(pts),Color(col))
static func diamond(c,p,w,h,col):poly(c,[p+Vector2(0,-h),p+Vector2(w,0),p+Vector2(0,h),p+Vector2(-w,0)],col)
static func line(c,a,z,col,width=1):c.draw_line(a,z,Color(col),width,false)
static func flag(c,p,t,col='#458d93'):
	b(c,p.x,p.y-22,1,24,'#64564b');poly(c,[p+Vector2(1,-22),p+Vector2(13,-22+int(sin(t*4)*2)),p+Vector2(11,-15+int(sin(t*4)*2)),p+Vector2(1,-16)],col);b(c,p.x+2,p.y-21,3,4,Color(col).lightened(.35))
static func tower(c,p,level=1,roof=true):
	var x=p.x;var y=p.y;var hh=20+level*3
	b(c,x-9,y-hh,18,hh,'#5d655f');b(c,x-8,y-hh,10,hh-1,'#c4c8ae');b(c,x+2,y-hh,7,hh-1,'#8d9f96');b(c,x-9,y-hh-2,19,4,'#dce0c3')
	for j in range(4):b(c,x-8+j*5,y-hh-5,3,5,'#d6dac0')
	for j in range(int(hh/5)):b(c,x-6+(j%2)*4,y-hh+4+j*5,4,1,'#9ba99c');b(c,x+4,y-hh+4+j*5,3,1,'#6e8983')
	b(c,x-2,y-hh+5,3,6,'#3b5659');b(c,x-2,y-hh+5,1,2,'#d4c385')
	if roof:poly(c,[Vector2(x-12,y-hh-4),Vector2(x,y-hh-18),Vector2(x+12,y-hh-4)],'#9a4e46');line(c,Vector2(x-9,y-hh-5),Vector2(x,y-hh-16),'#d18a62',2)
static func house(c,p,w=23,h=15,roof='#b46a51'):
	var x=p.x;var y=p.y
	poly(c,[Vector2(x-w/2,y-h),Vector2(x,y-h-5),Vector2(x+w/2,y-h),Vector2(x+w/2,y),Vector2(x,y+5),Vector2(x-w/2,y)],'#9eaa94')
	poly(c,[Vector2(x-w/2,y-h),Vector2(x,y-h-5),Vector2(x,y+5),Vector2(x-w/2,y)],'#d8d3b0')
	poly(c,[Vector2(x-w/2-3,y-h),Vector2(x,y-h-14),Vector2(x+w/2+3,y-h),Vector2(x,y-h+6)],roof)
	line(c,Vector2(x-w/2,y-h),Vector2(x,y-h-13),Color(roof).lightened(.4),2)
	for i in range(4):line(c,Vector2(x-w/2+i*3,y-h-i*2),Vector2(x+i*3,y-h+5-i*2),Color(roof).darkened(.13))
	b(c,x-4,y-h+8,4,h-6,'#695f50');b(c,x+4,y-h+7,3,4,'#436d70');b(c,x+4,y-h+7,1,3,'#e5ca90')
static func building(c,id,p,level=1,t=0.0):
	var x=p.x;var y=p.y
	diamond(c,p+Vector2(1,3),21,10,Color(0,0,0,.12))
	if id==0:
		house(c,p,40,24,'#788e91');tower(c,p+Vector2(-19,-5),1,false);tower(c,p+Vector2(18,-5),1,false);tower(c,p+Vector2(0,-17),2,true);flag(c,p+Vector2(1,-46),t)
		b(c,x-5,y-10,10,14,'#475e61');b(c,x-3,y-9,1,13,'#8fa49d');b(c,x+2,y-9,1,13,'#8fa49d');b(c,x-6,y+3,13,2,'#e6d5ad')
	elif id==1:
		diamond(c,p,24,12,'#a48956');diamond(c,p+Vector2(0,-1),23,11,'#bda56b')
		for row in range(5):
			for col in range(6):
				var xx=x+(col-row)*4-2;var yy=y+(col+row)*2-9;var sway=int(sin(t*2+col+row)*1.2)
				b(c,xx,yy-5,1,6,'#8c8d4e');b(c,xx-1+sway,yy-6,3,3,'#ead28a');b(c,xx+sway,yy-7,1,2,'#f5e6ad')
		b(c,x+16,y+2,5,4,'#8c6549');b(c,x+17,y+1,3,2,'#e6c57b')
	elif id==2:
		house(c,p,31,17,'#ac604e');flag(c,p+Vector2(-13,-17),t);b(c,x-14,y+1,6,5,'#725d4c');b(c,x-13,y+1,4,1,'#baa67b');line(c,p+Vector2(9,-1),p+Vector2(17,-16),'#d4dbce',2);line(c,p+Vector2(7,-8),p+Vector2(15,-5),'#7e6c4c',2)
	elif id==3:
		house(c,p+Vector2(-7,-1),21,14,'#658f8d');b(c,x+12,y-15,2,20,'#7b6650');c.draw_circle(p+Vector2(13,-14),7,Color('#ddd1ad'));c.draw_circle(p+Vector2(13,-14),5,Color('#aa6953'));c.draw_circle(p+Vector2(13,-14),3,Color('#f0dfb4'));b(c,x+12,y-15,2,3,'#526c67');b(c,x+8,y+3,12,2,'#696651')
	elif id==4:
		house(c,p,28,17,'#5c6b73');b(c,x+5,y-31,7,13,'#667c7a');b(c,x+5,y-31,7,3,'#a3a98f');b(c,x-9,y-8,8,6,'#7a4741');b(c,x-7,y-7,4,5,'#f0b66a');b(c,x-5,y-6,2,3,'#ffe2a0');b(c,x+11,y-1,12,4,'#445b63');b(c,x+9,y-4,16,3,'#8caaa6')
		for i in range(3):b(c,x+7+int(sin(t+i)*3),y-33-i*5-int(fmod(t*4,5)),3+i,3,Color(.55,.61,.58,.25-i*.05))
	elif id==5:
		house(c,p,24,19,'#b69269');tower(c,p+Vector2(0,-10),1,false);b(c,x-1,y-46,2,11,'#e8d59a');b(c,x-4,y-42,8,2,'#e8d59a');b(c,x-2,y-15,4,7,'#6b8b9b');b(c,x-1,y-14,2,4,'#b9cad1')
	elif id==6:
		for i in range(3):tower(c,p+Vector2((i-1)*14,(i%2)*6),level,false)
		flag(c,p+Vector2(-13,-24),t)
	elif id==7:
		house(c,p,24,21,'#d0b17a');b(c,x-5,y-28,10,25,'#d7ccb0');b(c,x+3,y-28,3,25,'#9f9d85');poly(c,[p+Vector2(-9,-28),p+Vector2(0,-39),p+Vector2(10,-28)],'#8b6252')
		for i in range(4):
			var a=t*.6+i*PI/2;var origin=p+Vector2(0,-22);var d=Vector2(cos(a),sin(a));line(c,origin,origin+d*23,'#75624f',2);line(c,origin+d*9+Vector2(-d.y,d.x)*2,origin+d*22+Vector2(-d.y,d.x)*2,'#f1deaa',4)
		b(c,x-2,y-24,4,4,'#8c7353')
	elif id==8:
		house(c,p,33,16,'#715d64');b(c,x-12,y-6,7,9,'#5c5652');b(c,x+6,y-6,7,9,'#5c5652');b(c,x-2,y+1,12,5,'#a87950');b(c,x+8,y-4,5,7,'#a87950');b(c,x+10,y-6,2,4,'#78583e');flag(c,p+Vector2(-17,-19),t)
	if level>1:
		for i in range(level):b(c,x-8+i*4,y+9,2,2,'#f7dc8f')
static func soldier(c,p,kind,enemy,t=0.0,flash=0.0,ward=0.0):
	var x=int(p.x);var y=int(p.y);var step=int(t)%4;var cloth='#b96956' if enemy else '#479a9b';var steel='#6d7778' if enemy else '#b5ccca';var skin='#b8b27e' if enemy else '#e7bf92'
	if flash>0:cloth='#f6edc8';steel='#fff4c5'
	if kind==4:
		b(c,x-8,y-23,16,22,'#605b56');b(c,x-10,y-17,20,12,'#8a7761');b(c,x-6,y-28,12,11,'#b3a27c');b(c,x-4,y-24,2,3,'#312d32');b(c,x+3,y-24,2,3,'#312d32');b(c,x-5,y-4,4,5,'#494c4b');b(c,x+2,y-4,4,5,'#494c4b');b(c,x-8,y-31,3,6,'#e4c38e');b(c,x+5,y-31,3,6,'#e4c38e');return
	if kind==3:
		b(c,x-8,y-7,16,6,'#a77c59');b(c,x+5,y-12,5,7,'#b98d66');b(c,x-8,y-2,3,5,'#685642');b(c,x+5,y-2,3,5,'#685642');y-=5
	b(c,x-4,y-13,8,9,'#3e5356');b(c,x-3,y-12,6,7,cloth);b(c,x-4,y-20,8,8,'#465c60');b(c,x-3,y-19,6,6,skin);b(c,x-4,y-21,8,4,steel);b(c,x+2,y-17,1,2,'#343f48');b(c,x-3,y-4,2,4+step%2,'#3e484b');b(c,x+1,y-4,2,4+(step+1)%2,'#3e484b')
	if kind==1:c.draw_arc(Vector2(x+5,y-11),5,-1.4,1.4,8,Color('#c6a16c'),1,false);line(c,Vector2(x+6,y-16),Vector2(x+6,y-6),'#ede3b8')
	elif kind==2:b(c,x-7,y-12,6,8,'#6a8b8e');b(c,x-6,y-11,4,5,'#d2c38c');b(c,x+5,y-18,1,12,'#e4dfc3')
	else:line(c,Vector2(x+4,y-8),Vector2(x+8+step%2*3,y-18),'#dfecda',2);b(c,x+4,y-10,5,1,'#bca36b')
	if ward>0:c.draw_arc(Vector2(x,y-10),12,PI,TAU,12,Color('#e7d99b'),1,false)
static func icon(c,id,p,s=1.0):
	var transform=Transform2D.IDENTITY;c.draw_set_transform(p,0,Vector2.ONE*s)
	if id>=0 and id<=8:building(c,id,Vector2(22,42),1,0)
	elif id==9:
		poly(c,[Vector2(3,13),Vector2(8,25),Vector2(15,16),Vector2(22,27),Vector2(30,16),Vector2(36,24),Vector2(41,12),Vector2(37,35),Vector2(7,35)],'#d9b46d');b(c,8,36,29,4,'#a6784d');b(c,20,24,5,6,'#b97259')
	elif id==10:
		line(c,Vector2(8,33),Vector2(34,7),'#8b6752',5);line(c,Vector2(8,7),Vector2(34,33),'#e3d7b2',4)
	elif id==11:
		poly(c,[Vector2(22,6),Vector2(39,12),Vector2(35,33),Vector2(22,43),Vector2(9,33),Vector2(5,12)],'#538f88');b(c,20,15,4,20,'#f0dfaa');b(c,13,22,18,4,'#f0dfaa')
	elif id==12:
		for i in range(3):b(c,6,10+i*10,32,3,'#5b625d')
	elif id==13:poly(c,[Vector2(9,5),Vector2(39,24),Vector2(9,42)],'#e7dcb6')
	elif id==14:line(c,Vector2(10,10),Vector2(34,34),'#e3d7b2',3);line(c,Vector2(10,34),Vector2(34,10),'#e3d7b2',3)
	elif id==15:
		b(c,9,18,8,12,'#e6d6a6');poly(c,[Vector2(17,18),Vector2(27,9),Vector2(27,38),Vector2(17,30)],'#e6d6a6');c.draw_arc(Vector2(25,24),13,-1,1,10,Color('#e6d6a6'),2,false)
	elif id==16:c.draw_arc(Vector2(22,24),14,0,TAU-1,16,Color('#e2d3ac'),3,false);poly(c,[Vector2(28,9),Vector2(41,14),Vector2(29,20)],'#e2d3ac')
	elif id==17:
		for i in range(3):b(c,7+i*9,20-i*5,10,13,'#ab874f');b(c,8+i*9,18-i*5,8,13,'#ead098');b(c,11+i*9,20-i*5,2,7,'#b7914f')
	elif id==18:
		b(c,8,7,28,31,'#d9ccaa');b(c,6,7,5,32,'#9a845d');b(c,11,7,23,2,'#f0dfb7');c.draw_string(FONT,Vector2(16,32),'?',HORIZONTAL_ALIGNMENT_LEFT,-1,30,Color('#4b6961'))
	c.draw_set_transform_matrix(transform)
