/* Carved and painted theatre puppets. Every silhouette has its own costume and bow. */
const Roles=[
 {id:'maestro',name:'Maestro',coat:0x254857,trim:0xf6c779,skin:0xf1bd91,hair:0x665046,reach:2.55},
 {id:'diva',name:'Soprano',coat:0xcf315e,trim:0xffbd80,skin:0x975639,hair:0x423044,reach:2.85},
 {id:'comic',name:'Harlequin',coat:0x169082,trim:0xf3b642,skin:0xf2b188,hair:0x753e35,reach:2.08},
 {id:'guard',name:'Drummer',coat:0x544284,trim:0xfbd065,skin:0xab6949,hair:0x393048,reach:2.15}
];
function actorModel(role,index){
 const R=Roles[role],o=g(),waist=g(o,0,.57,0),chest=g(waist),head=g(chest,0,1.07,.015),arms=[],legs=[];
 const coat=R.coat,trim=R.trim,skin=R.skin,hair=R.hair;
 const glove=0xffedcc,white=0xffe5b5,boot=0x332f40;
 // Stepped heels, tapered trousers and a welt along the shoes.
 for(const side of [-1,1]){
  const leg=g(o,side*.17,.67,0);legs.push(leg);
  rod(leg,role===2?side<0?trim:coat:ink,[0,0,0],[side*.028,-.49,.025],.111,.086);
  egg(leg,boot,side*.026,-.51,.08,.122,.11,.213);
  egg(leg,0xb68054,side*.026,-.585,.083,.123,.038,.206);
  cube(leg,trim,side*.026,-.485,.181,.11,.045,.045);
 }
 if(role===1){
  turned(waist,coat,0,-.46,0,[[.04,0],[.53,.015],[.57,.10],[.51,.28],[.34,.59],[.22,.82],[.01,.83]],.88);
  turned(waist,trim,0,-.46,0,[[.535,.035],[.572,.09],[.568,.116]],.885);
  for(let j=0;j<14;j++){let a=j*Math.PI/7;egg(waist,j%2?0xac2c55:0xf28d86,Math.sin(a)*.461,-.20,Math.cos(a)*.402,.047,.15,.045,0,a);}
 }else{
  turned(chest,coat,0,-.12,0,[[.01,0],[.29,0],[.35,.065],[.27,.28],[.32,.57],[.33,.68],[.19,.73],[.01,.75]],.78);
  if(role===0)for(const side of [-1,1])poly(chest,coat,side*.105,-.29,-.17,[[-.14,.4],[.14,.4],[.08,-.13],[-.06,-.2]],.05);
 }
 if(role===1)turned(chest,coat,0,.13,0,[[.04,0],[.24,0],[.29,.23],[.34,.42],[.26,.55],[.01,.56]],.82);
 egg(chest,white,0,.50,.18,.145,.208,.079);
 for(const side of [-1,1]){
  poly(chest,trim,0,.25,.242,[[side*.058,0],[side*.266,.362],[side*.149,.39],[side*.17,.29]],.018);
  if(role===3)for(let i=0;i<3;i++)cube(chest,trim,0,.24+i*.115,.252,.38,.028,.02);
 }
 if(role!==3)for(let i=0;i<3;i++)egg(chest,gold,.004,.19+i*.089,.241,.027,.027,.019);
 egg(chest,role===2?rose:ink,-.06,.664,.232,.098,.056,.043,0,0,-.25);
 egg(chest,role===2?rose:ink,.06,.664,.232,.098,.056,.043,0,0,.25);
 rod(chest,skin,[0,.63,0],[0,.86,0],.125);
 for(const side of [-1,1]){
  const arm=g(chest,side*.303,.601,.007);arms.push(arm);
  egg(arm,coat,side*.059,-.021,0,.135,.144,.14);
  rod(arm,coat,[side*.064,-.042,0],[side*.133,-.249,.06],.105,.075);
  rod(arm,coat,[side*.133,-.249,.06],[side*.094,-.367,.167],.078,.067);
  egg(arm,trim,side*.104,-.345,.141,.081,.061,.083);
  egg(arm,glove,side*.085,-.399,.184,.088,.094,.094);
  egg(arm,glove,side*.011,-.373,.205,.044,.059,.05);
  if(role===0&&side===1){rod(arm,ivory(),[.09,-.40,.20],[.36,-.27,.68],.023,.009);egg(arm,brass,.095,-.4,.20,.042,.05,.04);}
  if(role===3){rod(arm,brass,[side*.09,-.40,.20],[side*.15,-.22,.48],.025);egg(arm,white,side*.15,-.22,.48,.051,.05,.05);}
 }
 if(role===3){
  const drum=g(chest,0,.072,.37);drum.rotation.x=.22;
  turned(drum,0x97503b,0,-.14,0,[[.001,0],[.28,0],[.28,.25],[.001,.25]]);
  for(let j=0;j<8;j++){let a=j*Math.PI/4;rod(drum,gold,[.27*Math.sin(a),-.12,.27*Math.cos(a)],[.28*Math.sin(a+.32),.085,.28*Math.cos(a+.32)],.013);}
  ring(drum,cream,0,.115,0,.275,.02,Math.PI/2);ring(drum,trim,0,-.14,0,.275,.018,Math.PI/2);
 }
 // Heads have eyes set into lids, a separate jaw, carved nose and ears.
 silk(head,skin,0,0,.013,.312,.34,.261);
 egg(head,skin,0,-.167,.061,.233,.179,.208);
 for(const side of [-1,1]){
  egg(head,skin,side*.302,-.012,.013,.073,.097,.071);
  egg(head,0xc36f63,side*.306,-.019,.066,.036,.054,.022);
  egg(head,white,side*.115,.041,.241,.083,.081,.034);
  egg(head,ink,side*.116,.044,.269,.041,.057,.021);
  egg(head,0xfff7db,side*.119-.012,.064,.286,.014,.016,.008);
  egg(head,hair,side*.12,.145,.226,.085,.029,.041,0,0,side*.15);
  egg(head,role===1?0xea8174:0xde9280,side*.193,-.07,.208,.061,.033,.024,0,side*.25);
 }
 egg(head,skin,0,-.024,.275,.073,.08,.07);
 egg(head,role===1?0x9d324a:0x6f3733,0,-.15,.238,.061,.028,.015);
 if(role===0){
  for(const side of [-1,1])egg(head,0xe6ddc3,side*.058,-.09,.262,.085,.043,.033,0,0,side*.28);
  for(const s of [-1,1])for(let k=0;k<3;k++)egg(head,0xd8cfb7,s*(.24+.022*k),.13-.096*k,-.014,.106,.108,.127);
  egg(head,0xd8cfb7,0,.227,-.03,.273,.146,.223);
  for(let j=0;j<4;j++)egg(head,0xeee3c9,-.135+j*.083,.259,.123,.083,.073,.103,0,0,-.22);
 }else if(role===1){
  egg(head,hair,0,.211,-.041,.307,.171,.251);
  egg(head,hair,-.22,.265,-.09,.156,.176,.157);
  egg(head,hair,.15,.182,.142,.135,.085,.112,0,0,-.35);
  for(let k=0;k<5;k++){let a=(k-2)*.34;egg(head,gold,Math.sin(a)*.23,.307+Math.cos(a)*.032,Math.cos(a)*.164,.043,.054+(k===2?.055:0),.039);}
  for(const s of [-1,1]){egg(head,cream,s*.31,-.124,.049,.033,.048,.031);egg(head,gold,s*.305,-.188,.047,.019,.03,.021);}
 }else if(role===2){
  egg(head,coat,0,.235,0,.303,.134,.25);
  for(const s of [-1,1]){rod(head,s<0?trim:coat,[s*.10,.29,0],[s*.27,.493,.02],.119,.051);rod(head,s<0?trim:coat,[s*.27,.493,.02],[s*.40,.362,.04],.055,.017);egg(head,gold,s*.40,.337,.04,.053,.057,.052);}
  egg(head,rose,0,-.025,.309,.076,.067,.056);
 }else{
  turned(head,coat,0,.208,0,[[.23,0],[.31,.03],[.27,.30],[.225,.34],[.01,.34]],.85);
  turned(head,trim,0,.23,0,[[.31,0],[.302,.052]],.86);egg(head,ink,0,.228,.194,.237,.028,.135);
  egg(head,rose,.03,.592,0,.082,.16,.065,0,0,-.28);
 }
 finish(o);o.userData={waist,chest,head,arms,legs,role,index};return o;
}
function ivory(){return 0xffecca;}
function poseActor(actor,t,age,heading){
 const {waist,chest,arms,legs,head,role,index}=actor.userData;
 const walking=age<0, phase=t*(role===2?5.4:3.5)+index*2.17;
 const bend=walking?0:Math.sin(Math.PI*Math.min(1,age/1.65))**.85;
 const flourish=walking?0:Math.sin(Math.min(1,age/1.1)*Math.PI);
 actor.rotation.y=heading;
 waist.rotation.x=bend*(role===1?.54:1.04);
 waist.rotation.z=(walking?.027*Math.cos(phase):flourish*(role===2?-.34:.095));
 waist.position.y=.57+(walking?.027*Math.abs(Math.sin(phase)):Math.max(0,flourish)*(role===2?.26:.015));
 head.rotation.x=-.10*bend+(walking?.037*Math.sin(phase):0);
 head.rotation.y=.14*Math.sin(t*1.4+index);
 chest.rotation.y=walking?.055*Math.sin(phase):flourish*(role===1?-.43:.18);
 legs.forEach((a,i)=>{a.rotation.x=walking?Math.sin(phase+i*Math.PI)*.24:bend*(i===0?.14:-.09);});
 arms.forEach((a,i)=>{const s=i?1:-1;a.rotation.z=s*(walking?.055+Math.cos(phase+i)*.055:flourish*(role===1?1.53:role===2?1.24:.77));a.rotation.x=walking?(role===3?-.48+Math.sin(phase+i*Math.PI)*.27:Math.sin(phase+i*Math.PI)*.16):-flourish*(role===0?1.02:.48);});
}
function pigeon(){
 const o=g(),body=g(o),neck=g(body,0,.12,.22),wings=[];
 silk(body,0x7092a6,0,0,0,.243,.245,.371,-.16);
 egg(body,0xd6d7bc,0,-.046,.166,.206,.19,.23);
 for(let row=0;row<2;row++)for(let i=-2;i<=2;i++){
  const x=i*.057+(row?.015:0),z=.328-Math.abs(i)*.018;
  egg(body,row?0xc8cdbc:0xb6c3b8,x,-.073-row*.043,z,.035,.044,.012,-.40,x*.8);
 }
 egg(neck,0x268b88,0,.114,.026,.183,.207,.166);
 for(let i=0;i<11;i++){const a=(i-5)*.255;egg(neck,i%3===0?0x567a8e:i%3===1?0x4caaa2:0x447e86,Math.sin(a)*.16,.08+Math.cos(a)*.035,Math.cos(a)*.153+.025,.037,.062,.028,-.12,a);}
 silk(neck,0x708ba3,0,.257,.045,.196,.197,.18);
 for(const s of [-1,1]){
  egg(neck,0xffbe53,s*.155,.272,.142,.047,.047,.042);
  egg(neck,0xa7adb0,s*.158,.320,.124,.044,.016,.036,0,0,s*.18);
  egg(neck,ink,s*.169,.275,.157,.028,.03,.025);
  egg(neck,cream,s*.178,.287,.168,.009,.012,.009);
  const w=g(body,s*.15,.108,-.02);wings.push(w);
  egg(w,0x536781,s*.19,-.010,-.018,.233,.073,.183,0,s*.22);
  for(let i=0;i<4;i++)egg(w,i%2?0x42546e:0x69839a,s*(.27+.058*i),-.016,-.05-i*.044,.185,.044,.079,0,s*.29);
  for(let j=0;j<2;j++)egg(w,0x283a55,s*(.27+j*.074),.047,-.022-j*.041,.022,.024,.132,0,s*.23);
 }
 rod(neck,0x984d41,[0,.237,.188],[0,.217,.351],.065,.012);
 egg(neck,cream,0,.257,.203,.058,.045,.055);
 for(let j=-2;j<=2;j++){egg(body,j%2?0x526379:0x6b7b92,j*.044,-.035,-.30,.051,.040,.219,-.24,j*.12);egg(body,0x394c66,j*.052,-.001,-.442,.042,.027,.064,-.21,j*.12);}
 for(const s of [-1,1]){rod(body,0xce786b,[s*.075,-.17,.005],[s*.088,-.265,-.007],.021);for(let j=-1;j<=1;j++)rod(body,0xd68c70,[s*.088,-.262,0],[s*.088+j*.038,-.268,.081],.013,.005);}
 finish(o);o.userData={body,wings,neck};return o;
}

