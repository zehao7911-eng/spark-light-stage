const picture=(()=>{
 const surface=$('#screen'),main=$('#frame'),fx=$('#fx'),brush=fx.getContext('2d');
 const scene=new THREE.Scene(),camera=new THREE.OrthographicCamera(-5,5,10,-10,.1,100);
 const vec=new THREE.Vector3(),ray=new THREE.Raycaster(),floor=new THREE.Plane(new THREE.Vector3(0,1,0),0);
 let renderer=null,lite=null,W=1,H=1,stage=null,puppets=[],bird=null,birdPos=new THREE.Vector3(),cache={},beatTime=0;
 let focusZoom=1,ready=false,callouts=[],hornMeshes=[],floorShadows,shadowMat,returnFlight=null,shadowClock=0;
 try{
  renderer=new THREE.WebGLRenderer({canvas:surface,antialias:true,powerPreference:'high-performance',alpha:false,preserveDrawingBuffer:true});
  renderer.outputEncoding=THREE.sRGBEncoding;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.04;renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
 }catch{let replacement=document.createElement('canvas');surface.replaceWith(replacement);replacement.id='screen';lite=replacement.getContext('2d');}
 const hemi=new THREE.HemisphereLight(0xfff2da,0x80667a,.87);scene.add(hemi);
 const key=new THREE.DirectionalLight(0xffebd2,1.38);key.position.set(-5,13,7);key.castShadow=true;key.shadow.mapSize.set(1024,1024);
 Object.assign(key.shadow.camera,{left:-9,right:9,top:10,bottom:-10,near:.5,far:35});key.shadow.normalBias=.036;key.shadow.bias=-.00035;scene.add(key);
 const fill=new THREE.DirectionalLight(0xa2dde1,.51);fill.position.set(5,5,-3);scene.add(fill);
 const bounce=new THREE.DirectionalLight(0xffb191,.30);bounce.position.set(0,2,6);scene.add(bounce);
 const follow=new THREE.SpotLight(0xffe0a3,0,25,.37,.71,1);follow.position.set(-3.7,8.2,4.7);scene.add(follow,follow.target);
 const canvas=document.createElement('canvas');canvas.width=canvas.height=64;const cc=canvas.getContext('2d'),gd=cc.createRadialGradient(32,32,0,32,32,31);gd.addColorStop(0,'rgba(42,19,32,.56)');gd.addColorStop(.43,'rgba(42,19,32,.31)');gd.addColorStop(1,'rgba(42,19,32,0)');cc.fillStyle=gd;cc.fillRect(0,0,64,64);
 const tex=new THREE.CanvasTexture(canvas);shadowMat=new THREE.MeshBasicMaterial({map:tex,transparent:true,depthWrite:false});
 const shadowGeo=new THREE.PlaneGeometry(1,1);
 function cleanup(){if(stage)Craft.remove(stage);for(const p of puppets)Craft.remove(p);puppets=[];for(const h of hornMeshes)Craft.remove(h);hornMeshes=[];if(floorShadows){scene.remove(floorShadows);floorShadows=null;}if(bird)Craft.remove(bird);}
 function rebuild(){
  cleanup();callouts=[];returnFlight=null;focusZoom=1;
  scene.background=new THREE.Color(0x304850);scene.fog=new THREE.Fog(sets[level].sky,34,63);
  if(renderer){
   renderer.shadowMap.autoUpdate=false;renderer.shadowMap.needsUpdate=true;shadowClock=0;
   stage=theatre(sets[level]);scene.add(stage);
   for(const a of actors){let p=actorModel(a.role,a.i);tailor(p,a.role);let flower=handRose();p.userData.arms[0].add(flower);flower.position.set(-.095,-.36,.23);flower.rotation.x=-.4;flower.visible=false;p.userData.flower=flower;puppets.push(p);scene.add(p);}
   for(const h of horns){const m=hornModel();m.position.set(h.x,0,h.z);m.rotation.y=h.x<0?.54:-.54;hornMeshes.push(m);scene.add(m);}
   bird=pigeon();dressBird(bird);const bud=handRose();bird.userData.neck.add(bud);bud.position.set(0,.22,.30);bud.rotation.set(.18,0,-1.35);bud.scale.setScalar(1.14);bird.userData.bud=bud;bird.scale.setScalar(1.38);scene.add(bird);
   floorShadows=new THREE.Group();scene.add(floorShadows);
   for(let i=0;i<actors.length;i++){const s=new THREE.Mesh(shadowGeo,shadowMat);s.rotation.x=-Math.PI/2;s.scale.set(1.19,1,1);floorShadows.add(s);}
  }else if(lite){preload('stage-'+level);for(let j=0;j<4;j++)for(const frame of ['walk','stride','bow','lift'])preload('actor-'+j+'-'+frame);preload('bird');}
  ready=true;resize();
 }
 function preload(key){if(!cache[key]){const im=new Image();im.src=(typeof embeddedPlates!=='undefined'&&embeddedPlates[key])||'plates/'+key+'.webp';cache[key]=im;}return cache[key];}
 surface.addEventListener('webglcontextlost',e=>{
  e.preventDefault();if(!renderer)return;
  const img=document.createElement('canvas');img.className='backup-stage';surface.after(img);lite=img.getContext('2d');
  renderer=null;focusZoom=1;returnFlight=null;dropAim=null;resize();
 });
 function resize(){
  const box=main.getBoundingClientRect();W=Math.max(1,box.width);H=Math.max(1,box.height);const ratio=Math.min(window.devicePixelRatio||1,1.65);
  if(renderer){renderer.setPixelRatio(ratio);renderer.setSize(W,H,false);}
  else{lite.canvas.width=Math.round(W*ratio);lite.canvas.height=Math.round(H*ratio);lite.setTransform(ratio,0,0,ratio,0,0);}
  fx.width=Math.round(W*ratio);fx.height=Math.round(H*ratio);brush.setTransform(ratio,0,0,ratio,0,0);
  updateCam();
 }
 function updateCam(){
  const half=5.53,ar=W/H;const hh=Math.max(half/ar,7.85);
  camera.left=-hh*ar;camera.right=hh*ar;camera.top=hh;camera.bottom=-hh;camera.zoom=focusZoom;
  camera.position.set(shotX+shotFocus*2.05,15.0-shotFocus*6.4+shotY,19.6+shotZ);camera.lookAt(shotX,.76+shotY,-.38+shotZ);camera.updateProjectionMatrix();camera.updateMatrixWorld(true);
 }
 function project(x,y,z){
  vec.set(x,y,z).project(camera);return{x:(vec.x+1)*W/2,y:(1-vec.y)*H/2};
 }
 function aim(px,py){
  const rect=main.getBoundingClientRect(),sx=px-rect.left,sy=py-rect.top;
  // Touch a face or a torso; their overlapping hit ellipses favour the nearest centre.
  let nearest=-1,cost=1;for(const a of actors){if(a.hit)continue;const h=project(a.x,.97,a.z),feet=project(a.x,0,a.z),head=project(a.x,2.02,a.z);
   let dx=(sx-h.x)/Math.max(22,W*.059),dy=(sy-h.y)/Math.max(25,(feet.y-head.y)*.69),d=dx*dx+dy*dy;
   if(d<cost){cost=d;nearest=a.i;}}
  if(nearest>=0)return{x:actors[nearest].x,z:actors[nearest].z,actor:nearest};
  ray.setFromCamera({x:2*sx/W-1,y:1-2*sy/H},camera);const out=ray.ray.intersectPlane(floor,new THREE.Vector3());if(!out||Math.abs(out.x)>4.94||out.z< -5.02||out.z>6)return null;
  return{x:out.x,z:out.z,actor:-1};
 }
 function birdWorld(){return{x:birdPos.x,y:birdPos.y,z:birdPos.z};}
 function updateBird(t){
  let x=-3.43+.31*Math.sin(t*.93),z=-1.62+.19*Math.cos(t*.95),y=3.76+.19*Math.sin(t*2.8),tilt=-.11,heading=1.01,flap=8.1;
  if(mode==='flight'&&petals.length){
   const f=petals[0],u=clamp(f.t/f.duration,0,1),e=u*u*(3-2*u);
   x=mix(f.from.x,f.x*.79-.15,e);z=mix(f.from.z,f.z-.37,e);y=mix(f.from.y,2.76,e)+Math.sin(u*Math.PI)*.52;
   heading=Math.atan2(f.x-f.from.x,f.z-f.from.z);tilt=-.08-.25*Math.sin(u*Math.PI);flap=13;
   returnFlight={x,y,z,t,heading};
  }else if(returnFlight&&t-returnFlight.t<1.25){const f=returnFlight,u=clamp((t-f.t)/1.25,0,1),e=u*u*(3-2*u);
   x=mix(f.x,x,e);z=mix(f.z,z,e);y=mix(f.y,y,e)+Math.sin(u*Math.PI)*.43;heading=mix(f.heading,heading,e)+Math.sin(Math.PI*u)*1.18;}
  if(mode==='curtain'||mode==='result'){
   const u=clamp(finaleClock/1.12,0,1),smooth=u*u*(3-2*u);x=mix(x,0,smooth);z=mix(z,4.31,smooth);y=mix(y,.38,smooth)+Math.sin(u*Math.PI)*1.23;heading=mix(heading,.23,smooth);flap=mix(12,.7,smooth);
   if(encore&&finaleClock>1.18){const bow=Math.sin(Math.min(1,(finaleClock-1.18)/.80)*Math.PI);tilt=.88*bow;y+=.08*bow;}
  }
  if(mode==='cover'&&renderer){x=-1.13+.23*Math.cos(t*.87);z=.22;y=2.46+.12*Math.sin(t*2.65);heading=.89;}
  birdPos.set(x,y,z);
  if(bird){bird.position.copy(birdPos);bird.rotation.set(tilt,heading,Math.sin(t*2.1)*.075);bird.userData.wings.forEach((w,i)=>w.rotation.z=(i?1:-1)*(.22+Math.sin(t*flap)*.77));bird.userData.neck.rotation.y=Math.sin(t*1.87)*.22;
   bird.userData.bud.visible=mode==='cover'||mode==='aim'||mode==='pause'&&pausedFrom==='aim';}
 }
 function callout(x,z,word,depth){const near=callouts.filter(q=>q.age<.47&&Math.abs(q.x-x)<1.65&&Math.abs(q.z-z)<1.8);callouts.push({x,z,word,depth,age:0,lift:near.length*.52});}
 function drawLite(t){
  const c=lite;c.clearRect(0,0,W,H);c.fillStyle='#f2c496';c.fillRect(0,0,W,H);
  const bg=preload('stage-'+level), scale=(camera.right-camera.left)/2, width=W*(5.53/scale)*focusZoom,height=width*16/9;
  if(bg.complete&&bg.naturalWidth)c.drawImage(bg,(W-width)/2,(H-height)/2,width,height);
  else{c.fillStyle='#a7774f';let a=project(-5,0,-6),b=project(5,0,6);c.fillRect(a.x,a.y,b.x-a.x,b.y-a.y);}
  for(const h of horns){let p=project(h.x,0,h.z),im=preload('horn'),s=width*.122;if(im.complete&&im.naturalWidth)c.drawImage(im,p.x-s/2,p.y-s*.80,s,s);}
  const sorted=actors.slice().sort((a,b)=>a.z-b.z);for(const a of sorted){
   const q=project(a.x,0,a.z),h=project(a.x,2.28,a.z),zoom=width/390;const state=poseTime(a);
   const frame=state>=0?(state>.25&&state<1.48?'bow':'lift'):(Math.sin(t*4+a.i)>0?'walk':'stride');
   const img=preload('actor-'+a.role+'-'+frame);const spriteW=3.36*W/(2*camera.right)*focusZoom;
   c.fillStyle='rgba(55,35,41,.23)';c.beginPath();c.ellipse(q.x,q.y,.40*W/(2*camera.right),.15*W/(2*camera.right),0,0,TAU);c.fill();
   if(img.complete&&img.naturalWidth)c.drawImage(img,q.x-spriteW/2,q.y-spriteW*.81,spriteW,spriteW);
   else{c.fillStyle='#'+Roles[a.role].coat.toString(16);c.fillRect(q.x-8*zoom,h.y+12*zoom,16*zoom,q.y-h.y-12*zoom);}
  }
  const bp=project(birdPos.x,birdPos.y,birdPos.z),tier=outfitTier(),bi=preload(tier?'bird-'+tier:'bird');if(bi.complete&&bi.naturalWidth){const d=width*.145;c.drawImage(bi,bp.x-d/2,bp.y-d/2,d,d);}
 }
 function poseTime(a){if((mode==='curtain'||mode==='result')&&encore&&finaleClock>1.08)return Math.min(1.68,finaleClock-1.08);return a.hit?Math.min(1.68,showTime-a.hitTime):-1;}
 function ellipse(x,z,r,fill,stroke,weight,dash=false){
  const ctr=project(x,.08,z),side=project(x+r,.08,z),base=project(x,.08,z+r);
  const c=brush;c.beginPath();c.ellipse(ctr.x,ctr.y,Math.max(.01,side.x-ctr.x),Math.max(.01,base.y-ctr.y),0,0,TAU);
  if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=weight;c.setLineDash(dash?[3.3,5.3]:[]);c.stroke();c.setLineDash([]);}
 }
 function overlays(dt){
  const c=brush;c.clearRect(0,0,W,H);
  for(const p of pulses){if(p.age<0||p.r<.03)continue;const tint=p.echo?'239,199,106':p.role===1?'254,173,201':p.role===2?'130,244,216':'255,230,167';ellipse(p.x,p.z,p.r,'rgba('+tint+','+(.065*p.alpha)+')','rgba('+tint+','+(.91*p.alpha)+')',1.6);if(p.r>.29)ellipse(p.x,p.z,p.r-.09,null,'rgba(135,71,43,'+(.32*p.alpha)+')',1);}
  if(horns.length&&horns[0].flash>=0){const age=showTime-horns[0].flash;
   if(age>=0&&age<1.0){let h=horns[0],k=horns[1];for(let j=0;j<8;j++){let u=age*1.6-j*.054;if(u<0||u>1)continue;
    const p=project(mix(h.x,k.x,u),.84+Math.sin(u*Math.PI)*1.16,mix(h.z,k.z,u));c.save();c.translate(p.x,p.y);c.rotate(.16*Math.sin(u*8));c.fillStyle='#ffe6a2';c.strokeStyle='#9d6441';c.font='bold '+(12+j*.4)+'px Georgia';c.lineWidth=1.8;c.strokeText('♪',0,0);c.fillText('♪',0,0);c.restore();}}
  }
  let tgt=dropAim;if(mode==='aim'&&tgt){const a=actors[tgt.actor];if(a)tgt={...tgt,x:a.x,z:a.z};ellipse(tgt.x,tgt.z,1.21,'rgba(255,228,139,.12)','#fff0b7',2,true);}
  if(mode==='aim'&&tgt&&tgt.actor>=0){
   const lead=actors[tgt.actor];ellipse(lead.x,lead.z,Roles[lead.role].reach,null,'rgba(255,240,192,.82)',1.4,true);
   for(const a of actors){if(a.hit||a===lead||Math.hypot(a.x-lead.x,a.z-lead.z)>Roles[lead.role].reach+.2)continue;
    const p=project(a.x,2.30,a.z);c.save();c.translate(p.x,p.y);c.rotate(Math.PI/4);c.fillStyle='#ffe49b';c.strokeStyle='#9c6348';c.lineWidth=1.4;c.fillRect(-3,-3,6,6);c.strokeRect(-3,-3,6,6);c.restore();}
  }
  if(mode==='aim'&&throwCount===0&&!dropAim&&level===0){const a=actors[1],p=project(a.x,2.42+Math.sin(showTime*4)*.06,a.z);c.fillStyle='#fff3bd';c.strokeStyle='#643f46';c.lineWidth=2;c.beginPath();c.moveTo(p.x-6,p.y-6);c.lineTo(p.x+6,p.y-6);c.lineTo(p.x,p.y+1);c.closePath();c.fill();c.stroke();}
  for(const f of petals){const u=clamp(f.t/f.duration,0,1),w=f.from;const x=mix(w.x,f.x,u),z=mix(w.z,f.z,u),y=mix(w.y,.18,u)+Math.sin(Math.PI*u)*1.22;const q=project(x,y,z);
   c.save();c.translate(q.x,q.y);c.rotate(u*5.9);c.strokeStyle='#416d52';c.lineWidth=2.3;c.beginPath();c.moveTo(0,0);c.lineTo(-2,12);c.stroke();c.fillStyle='#e64155';c.strokeStyle='#882a3e';c.beginPath();c.arc(0,0,5.5,0,TAU);c.fill();c.stroke();c.fillStyle='#ffbc96';c.fillRect(-2,-3,3,2);c.restore();}
  for(const s of sparks){const p=project(s.x,s.y,s.z);c.save();c.translate(p.x,p.y);c.rotate(s.spin);c.globalAlpha=clamp(s.life*2,0,1);c.fillStyle='#'+s.c.toString(16).padStart(6,'0');c.beginPath();c.ellipse(0,0,Math.max(1.2,W*.09*s.r),Math.max(1,W*.045*s.r),0,0,TAU);c.fill();c.restore();}
  for(let i=callouts.length-1;i>=0;i--){const a=callouts[i];a.age+=dt;if(a.age>.87){callouts.splice(i,1);continue;}const p=project(a.x,2.18+a.lift+a.age*.42,a.z);c.save();c.translate(p.x,p.y);c.globalAlpha=Math.min(1,(.87-a.age)*5);c.font='italic bold '+Math.max(13,W*.036)+'px Georgia';c.textAlign='center';c.lineWidth=3.5;c.strokeStyle='#533346';c.strokeText(a.word,0,0);c.fillStyle='#fff2be';c.fillText(a.word,0,0);c.restore();}
 }
 function draw(dt){
  if(!ready)return;const t=stageTime;
  const intro=mode==='cover'?1:opening*opening,over=mode==='curtain'&&encore?Math.sin(Math.PI*clamp(finaleClock/3.4,0,1))**.75:0;
  const target=actors[litActor];const closeShot=!!renderer&&!matchMedia('(prefers-reduced-motion: reduce)').matches;
  shotFocus=closeShot?Math.max(intro*.91,over*.86):0;
  shotX=closeShot?(target?target.x*over*.52:0):0;shotY=closeShot?intro*.35+over*.19:0;
  shotZ=closeShot?intro*.46+(target?target.z*over*.50:0):0;
  const targetZoom=closeShot?1+intro*.78+over*.71:1;
  focusZoom=mix(focusZoom,targetZoom,1-Math.exp(-dt*5));updateCam();updateBird(t);
  if(renderer){
   for(const a of actors){const p=puppets[a.i],age=poseTime(a);p.position.set(a.x,a.hopY||0,a.z);poseActor(p,t,age,a.heading*(a.hit?.38:1));
    playFlourish(p,age,t);p.userData.flower.visible=a.hit;p.userData.flower.rotation.z=.4+Math.sin(t*2+a.i)*.13;
    if(a.role===2&&a.hopY)p.rotation.z=-.36*a.hopY;
    else p.rotation.z=0;
    if(a.hit&&age>1.48){p.userData.arms[0].rotation.x=-.53+.09*Math.sin(t*2.8+a.i);p.userData.head.rotation.z=.073*Math.sin(t*2.3+a.i);}
    floorShadows.children[a.i].position.set(a.x,.024,a.z);}
   hornMeshes.forEach((h,i)=>{const elapsed=showTime-horns[i].flash;h.rotation.z=horns[i].flash>=0&&elapsed<.7?Math.sin(elapsed*30)*.16*(1-elapsed/.7):0;});
   for(const [j,m] of (stage.userData.players||[]).entries()){
    const playing=mode==='chain'||mode==='curtain';m.rotation.x=(playing?.25:.07)*Math.sin(t*(playing?9.0:3.5)+j*.7);
    m.rotation.z=(playing?.09:.025)*Math.sin(t*4+j);
   }
   const star=actors[dropAim?.actor??litActor],lit=star&&['aim','chain','curtain'].includes(mode);
   follow.intensity=mix(follow.intensity,lit?1.12:0,1-Math.exp(-dt*7));
   if(star){follow.target.position.lerp(vec.set(star.x,.72,star.z),1-Math.exp(-dt*9));}
   shadowClock-=dt;if(shadowClock<=0){renderer.shadowMap.needsUpdate=true;shadowClock=.08;}
   renderer.render(scene,camera);
  }else drawLite(t);
  overlays(dt);
 }
 return{draw,resize,rebuild,aim,callout,birdWorld,project,info:()=>({renderer:renderer?'WebGL':'Illustrated',calls:renderer?.info.render.calls}),captureTools:()=>({scene,camera,renderer,puppets,bird,stage,floorShadows})};
})();
