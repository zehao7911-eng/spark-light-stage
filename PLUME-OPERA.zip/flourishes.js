/* Props expand, tip and tumble during the actual bow that propagates applause. */
function tailor(p,role){
 const {head,arms,chest}=p.userData;
 const extra=g(), trinket=g(), lids=g(head,0,.11,.004);
 for(const s of [-1,1])egg(lids,Roles[role].skin,s*.115,-.052,.252,.084,.058,.04);
 finish(lids);p.userData.lids=lids;
 if(role===0){
  ring(extra,0xb88845,.122,.046,.287,.083,.008);
  for(let i=0;i<6;i++)egg(extra,0xc8a66e,.191+.010*Math.sin(i*.62),.002-i*.030,.238-i*.009,.009,.015,.009);
  for(let i=0;i<4;i++)egg(trinket,i%2?0xe5d4ad:0xf0e2c1,(i-1.5)*.055,.305+Math.sin(i)*.032,.053,.085,.06,.068,0,0,-.32);
  head.add(extra,trinket);
 }else if(role===1){
  // A fan with individual silk gores, brass ribs and a scalloped edge.
  for(let i=0;i<8;i++){
   const a=-1.02+i*.29,b=a+.30,r=.36;
   const xy=angle=>[Math.sin(angle)*r,Math.cos(angle)*r];
   poly(trinket,i%2?0xc45a69:0xed9884,0,0,0,[[0,0],xy(a),xy(b)],.017);
   rod(trinket,0xf3c57b,[0,0,.024],[...xy(a),.024],.008);
   egg(trinket,0xf5c995,Math.sin((a+b)/2)*r,Math.cos((a+b)/2)*r,.01,.044,.036,.022);
  }
  trinket.position.set(.10,-.37,.25);arms[1].add(trinket);
 }else if(role===2){
  for(let i=0;i<3;i++){let b=g(trinket);silk(b,[0xed9651,0x4daca5,0xe16571][i],0,0,0,.066,.071,.063);ring(b,cream,0,0,0,.059,.007,.66);b.position.set((i-1)*.19,.74,0);}
  chest.add(trinket);
 }else{
  // Two rosettes sit at the lip of the shako; one ribbon flutters on a roll.
  egg(extra,gold,0,.399,.24,.088,.094,.038);egg(extra,0xc64955,0,.397,.267,.058,.057,.018);head.add(extra);
  poly(trinket,0xdb5969,-.053,0,0,[[-.038,0],[.035,0],[.08,-.20],[.015,-.17],[-.012,-.22]],.018);
  trinket.position.set(-.24,.46,.185);head.add(trinket);
 }
 finish(extra);finish(trinket);p.userData.detail=trinket;
}
function playFlourish(p,age,t){
 const d=p.userData.detail,r=p.userData.role,k=age<0?0:Math.sin(Math.PI*clamp(age/1.65,0,1));
 const blink=(t+p.userData.index*.793)%3.67;
 const closed=Math.max(blink<.15?Math.sin(Math.PI*blink/.15):0,k*.8);
 p.userData.lids.visible=closed>.10;p.userData.lids.scale.y=.16+closed*.92;
 if(r===0){d.position.y=.15*k;d.rotation.z=.13*k;}
 if(r===1){d.scale.x=.27+.73*k;d.rotation.z=-.39+.55*k;d.rotation.x=-.43-.27*k;}
 if(r===2){d.visible=age>=0&&age<1.62;if(d.visible){d.children.filter(q=>q.isGroup).forEach((ball,i)=>{let u=(age*1.35+i/3)%1;ball.position.set(Math.sin(u*TAU)*.32,.75+Math.sin(u*Math.PI)*.89,.35);});}}
 if(r===3){d.rotation.z=.3*Math.sin(t*4.1)+k*.54;}
}
const wardrobe=[
 {stars:0,name:'House pigeon'},{stars:4,name:'Velvet cravat'},{stars:8,name:'Usher cap'},{stars:13,name:'Golden wings'}
];
function outfitTier(){const points=profile.stars.reduce((a,b)=>a+b,0);return wardrobe.filter(w=>points>=w.stars).length-1;}
function dressBird(b){
 const body=b.userData.body,neck=b.userData.neck,tier=outfitTier(),garment=g(body);
 if(tier>=1){for(const s of [-1,1])egg(garment,0xbb324a,s*.066,.147,.365,.096,.055,.033,0,0,s*.26);egg(garment,gold,0,.146,.392,.032,.035,.027);}
 if(tier>=2){const cap=g(neck,0,.405,.037);turned(cap,0x286365,0,0,0,[[.09,0],[.179,.018],[.177,.088],[.14,.113],[.03,.128]],.92);
  egg(cap,ink,0,.009,.135,.139,.022,.095);turned(cap,gold,0,.015,0,[[.181,0],[.18,.022]],.92);egg(cap,gold,0,.061,.163,.026,.033,.016);finish(cap);}
 if(tier>=3){for(const s of [-1,1])for(let j=0;j<3;j++)egg(garment,0xf2c275,s*(.15+j*.027),.002-j*.019,.18-j*.036,.053,.023,.044,0,s*.32);}
 finish(garment);
}
function curtains(o){
 for(const side of [-1,1]){
  // A continuous ruled surface gathers into a knot and fans open at the hem.
  const pos=[],idx=[],columns=40,rows=18;
  for(let j=0;j<=rows;j++){
   const v=j/rows,y=.78+v*5.35,waist=Math.exp(-((v-.46)**2)/.011);
   const width=(.91+.49*v)*(1-.72*waist),outer=4.92+.10*Math.sin(v*3);
   for(let i=0;i<=columns;i++){
    const u=i/columns,fold=Math.cos(u*10*Math.PI),x=side*(outer-u*width);
    pos.push(x,y+.085*(1-v)**6*Math.cos(u*10*Math.PI),-4.15+fold*(.075+.15*(1-waist))+.07*Math.sin(v*4.4+u));
    if(i&&j){const a=j*(columns+1)+i;const face=[a-columns-2,a-1,a,a-columns-2,a,a-columns-1];if(side===-1)face.reverse();idx.push(...face);}
   }
  }
  const geom=new THREE.BufferGeometry();geom.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));geom.setIndex(idx);geom.computeVertexNormals();
  // Both-facing strips allow the ruffled face to receive directional light.
  const two=geom.clone();const rev=Array.from(idx).reverse();two.setIndex(rev);two.computeVertexNormals();
  Craft.part(o,geom,0xb3394e,0,0,0);Craft.part(o,two,0xb3394e,0,0,0);geom.dispose();two.dispose();
  for(let j=0;j<3;j++){let y=3.10+j*.048;rod(o,j%2?0xebba6d:0xb78949,[side*4.91,y,-3.90],[side*4.57,y-.054,-3.88],.023);}
 }
}
function floorInlay(o){
 const w=0xb38155;
 for(const z of [-3.3,3.9])for(const s of [-1,1]){
  for(let j=0;j<8;j++){let a=Math.PI*.1+j*.14,b=a+.12;let x=s*(3.45+.55*Math.cos(a)),zz=z+.55*Math.sin(a);
   rod(o,w,[x,.015,zz],[s*(3.45+.55*Math.cos(b)),.015,z+.55*Math.sin(b)],.013);}
 }
 for(let j=0;j<12;j++){let x=-4.39+j*.798;cube(o,0xc99565,x,.017,-4.99,.31,.006,.024);}
}

