/* Practical stage effects and their choreography. */
const HornCues={
 2:[[-3.25,-2.1],[2.85,3.52]],4:[[-3.0,1.7],[2.50,-3.45]],5:[[-3.1,-2.95],[2.70,3.45]]
};
let horns=[],relayed=false,hopQueue=[],litActor=-1,opening=0,shotFocus=0,shotX=0,shotZ=0,shotY=0;
function resetCues(){
 horns=(HornCues[level]||[]).map(([x,z])=>({x,z,flash:-1}));
 relayed=false;hopQueue=[];litActor=-1;opening=0;shotFocus=shotX=shotZ=shotY=0;
}
function hornModel(){
 const o=g();
 turned(o,0x1f6363,0,0,0,[[.25,.015],[.32,.04],[.32,.12],[.23,.19],[.14,.23],[.10,.58],[.17,.62]]);
 turned(o,brass,0,.13,0,[[.23,0],[.24,.04],[.14,.075]]);
 const horn=g(o,0,.59,0);horn.rotation.x=.72;
 turned(horn,gold,0,0,0,[[.049,0],[.075,.12],[.10,.21],[.16,.31],[.26,.40],[.35,.45],[.36,.48],[.31,.49],[.245,.453],[.13,.36],[.069,.25]],.92);
 egg(horn,0x83503c,0,.36,0,.115,.024,.112);
 for(let j=0;j<8;j++){const a=j*Math.PI/4;egg(horn,0xf5bd75,.318*Math.sin(a),.472,.301*Math.cos(a),.035,.027,.039);}
 for(let j=0;j<2;j++){egg(o,0x43916e,(j-.5)*.26,.34+j*.10,0,.15,.052,.071,0,0,(j?1:-1)*.4);}
 return finish(o);
}
function catchCue(b){
 if(relayed||!horns.length||b.age<0||b.alpha<=.25)return;
 const idx=horns.findIndex(h=>Math.hypot(h.x-b.x,h.z-b.z)<b.r+.23);
 if(idx<0)return;relayed=true;const other=horns[1-idx];for(const h of horns)h.flash=showTime;
 pulse(other.x,other.z,b.depth+1,1,.32);sound.note(440,.18,'triangle',.25);sound.note(660,.28,'triangle',.18,.25);
 picture.callout(other.x,other.z,'Brass relay!',b.depth+1);
}
function cuesFrame(dt){
 for(let i=hopQueue.length-1;i>=0;i--){const h=hopQueue[i];h.t+=dt;const a=actors[h.i],u=clamp(h.t/.61,0,1);a.x=mix(h.x,h.tx,u);a.z=mix(h.z,h.tz,u);a.hopY=Math.sin(Math.PI*u)*.74;
  if(u===1){a.hopY=0;hopQueue.splice(i,1);pulse(a.x,a.z,a.depth,a.role,.02);scatter(a.x,a.z,a.role,a.depth);}
 }
}
function comicHop(a){
 // A courteous leap into the nearest untouched actor's sightline.
 const next=actors.filter(x=>!x.hit).sort((p,q)=>Math.hypot(p.x-a.x,p.z-a.z)-Math.hypot(q.x-a.x,q.z-a.z))[0];
 if(!next)return false;let dx=next.x-a.x,dz=next.z-a.z,dist=Math.hypot(dx,dz);if(dist<.42)return false;
 const travel=Math.min(1.11,Math.max(.12,dist-.79));
 hopQueue.push({i:a.i,x:a.x,z:a.z,tx:a.x+dx/dist*travel,tz:a.z+dz/dist*travel,t:0});return true;
}
function handRose(){
 const o=g();
 rod(o,0x53815c,[0,0,0],[.035,.28,.015],.013,.008);egg(o,0x65a079,-.044,.119,0,.066,.022,.029,0,0,-.45);
 for(let i=0;i<6;i++){let a=i*TAU/6;egg(o,i%2?0xf47071:0xca3953,.036+Math.cos(a)*.056,.277+Math.sin(a)*.013,.015+Math.sin(a)*.045,.069,.052,.048,0,a,.16);}
 egg(o,0xfa9690,.038,.295,.016,.048,.043,.052);return finish(o);
}

