/* Painted timber, embossed brass, velvet seats and a working miniature orchestra. */
function auditorium(o,act){
 const side=0x204d50,deep=0x283b46,velvet=0x8d3046,wood=0x754232,glint=0xd69c58;
 cube(o,deep,0,-2.7,3.4,35,.3,38);
 for(let i=-6;i<=6;i++){
  cube(o,i%2?0x324a50:0x2c454b,i*1.36,3.0,-9.3,1.30,12,.4);
  cube(o,0x597071,i*1.36+.42,3.6,-9.04,.035,9.5,.035);
 }
 for(let i=0;i<3;i++){
  let y=5.1+i*.94;
  cube(o,i===1?0x365c5d:side,0,y,-8.7,23,.25,.65);cube(o,glint,0,y+.06,-8.36,23,.045,.04);
 }
 for(const s of [-1,1]){
  // The spectator wings taper towards the front of the stage.
  for(let i=0;i<3;i++){
   const z=-3.1+i*3.4;
   cube(o,side,s*5.12,.81,z,.52,1.56,2.98);cube(o,glint,s*4.91,1.46,z,.12,.10,2.99);
   for(let j=0;j<5;j++){let zz=z-1.15+j*.565;rod(o,glint,[s*4.95,.54,zz],[s*4.95,1.0,zz],.052,.045);}
  }
 }
 // Low orchestra pit. The music stands and their brass lamp stems face the stage.
 cube(o,0x392e39,0,-1.58,7.63,10.65,.28,2.7);
 for(let j=0;j<5;j++){
  const x=(j-2)*1.84,z=7.8+(j%2)*.24;
  const arms=g(o,x,-.84,z);o.userData.players=o.userData.players||[];o.userData.players.push(arms);
  for(const s of [-1,1]){
   rod(arms,0x3b5258,[s*.22,.13,0],[s*.34,-.04,-.05],.084,.071);
   rod(arms,0x40565b,[s*.34,-.04,-.05],[s*.21,.06,-.21],.072,.059);
   egg(arms,0xdba784,s*.20,.06,-.22,.074,.066,.074);
  }
  if(j===2)rod(arms,0xe8d1a3,[.21,.06,-.21],[.43,.42,-.30],.018,.005);
  egg(o,[0x474459,0x6d4148,0x344e53][j%3],x,-.89,z,.35,.44,.24);
  egg(o,[0xb67e59,0xd99c71,0xe5b586][j%3],x,-.37,z,.237,.267,.207);
  egg(o,[0x4c3839,0x574451,0x75513f][j%3],x,-.265,z+.066,.243,.191,.208);
  if(j===1||j===3){for(const s of [-1,1])egg(o,0xc2ae8e,x+s*.195,-.34,z+.014,.075,.089,.10);}
  rod(o,brass,[x+.48,-1.40,z-.44],[x+.48,-.60,z-.44],.039);
  cube(o,0x304c51,x+.48,-.53,z-.44,.62,.40,.048,-.25);
  cube(o,0xe8cfa2,x+.48,-.51,z-.404,.53,.32,.029,-.25);
  for(let k=0;k<3;k++)for(let l=0;l<2;l++)cube(o,0x8a7561,x+.36+l*.24,-.57+k*.055,z-.37,.17,.012,.012,-.25);
  rod(o,glint,[x+.27,-.38,z-.44],[x+.67,-.38,z-.44],.025);
  if(j===1||j===4){ // bent brass horn, bell lip, keys
   const tx=x-.39;ring(o,glint,tx,-.74,z,.14,.036);
   rod(o,glint,[tx+.12,-.7,z],[tx+.04,-.51,z-.18],.03,.06);rod(o,glint,[tx+.04,-.51,z-.18],[tx+.03,-.44,z-.38],.046,.146);
   egg(o,wood,tx+.03,-.44,z-.397,.12,.095,.025);
  }else{ // cellos
   const tx=x-.35;egg(o,0x9b5938,tx,-.95,z-.11,.21,.24,.088);egg(o,0xaf6940,tx,-.71,z-.11,.16,.17,.077);
   rod(o,0x59433b,[tx,-.80,z-.02],[tx-.13,-.16,z-.03],.038,.036);egg(o,glint,tx-.14,-.13,z-.03,.06,.091,.049);
   rod(o,0xf2d9aa,[tx-.21,-.86,z+.01],[tx+.21,-.63,z+.01],.012);
  }
 }
 // Staggered backs of the stalls, picked out by the edge of the footlights.
 for(let row=0;row<3;row++){
  let z=9.33+row*1.19,y=-1.35+row*.19;
  cube(o,side,0,y-.48,z,13.6,.58,1.31);
  for(let j=0;j<11;j++){
   let x=(j-5)*1.06+(row%2?.50:0);if(Math.abs(x)<.46)continue;
   egg(o,wood,x,y+.09,z+.24,.46,.53,.18);egg(o,row===0?velvet:0x704052,x,y+.12,z+.28,.393,.443,.16);
   egg(o,glint,x,y+.39,z+.403,.064,.05,.022);
   if((j+row)%4!==0){egg(o,[0x436a69,0x754a51,0x6c6175][(j+row)%3],x,y+.15,z-.10,.27,.29,.20);
    egg(o,[0xc28e63,0xe2b587,0xa97152][(j+row)%3],x,y+.53,z-.1,.20,.222,.176);
    egg(o,[0x493c43,0x725546,0x6f6573][(j+row)%3],x,y+.61,z-.039,.208,.168,.171);}
  }
 }
 // Cartouche, pin-striping and repeated fan ornaments in the architrave.
 for(const s of [-1,1]){
  for(let j=0;j<4;j++){
   let x=s*(.94+j*.94);ring(o,glint,x,6.30,-4.456,.107,.017);
   poly(o,0x6ca09a,x,6.30,-4.438,[[-.06,0],[0,.056],[.06,0],[0,-.056]],.015);
  }
  for(let j=0;j<4;j++){
   const y=1.04+j*1.16;poly(o,glint,s*4.81,y,-4.32,[[-.081,0],[0,.155],[.081,0],[0,-.155]],.025);
  }
 }
 // Elliptical inlaid dancing figure; the empty middle keeps performers readable.
 for(const s of [-1,1])for(let j=0;j<5;j++){
  const x=s*(3.9-j*.24),z=4.98+j*.10;
  poly(o,0xd7b283,x,.012,z,[[0,.095],[.16,.025],[.215,-.03],[.07,-.02]],.009,-Math.PI/2,s*.19,0);
 }
}
function paintedSet(o,act){
 const set=act.set,iv=0xf4ce8f,leaf=0x448377;
 // Cross-lit layers: near silhouettes have colour and shape, distant flats stay quiet.
 for(const s of [-1,1]){
  let x=s*3.55,z=-5.83;
  if(set==='sun'||set==='final'){
   cube(o,0xa36153,x,.56,z,1.58,1.07,.2);
   cube(o,0xe6b582,x,1.20,z,1.71,.16,.27);
   for(let j=0;j<4;j++){let dx=x+(j-1.5)*.35;cube(o,0x664a54,dx,.65,z+.121,.17,.53,.025);egg(o,0x664a54,dx,.91,z+.121,.085,.086,.021);}
   cube(o,0xce8d69,x,1.49,z,.84,.53,.16);egg(o,0x597775,x,1.77,z,.51,.41,.17);
   rod(o,glint(),[x,2.03,z],[x,2.38,z],.035,.013);egg(o,iv,x,2.39,z,.059,.06,.045);
  }else if(set==='garden'||set==='mask'){
   turned(o,0xa96c55,x,0,z,[[.24,0],[.31,.08],[.21,.54],[.34,.67],[.34,.75],[.01,.75]],.72);
   for(let j=0;j<3;j++)egg(o,j%2?leaf:0x5c927f,x+s*(j%2)*.14,1.01+j*.43,z,.72-j*.12,.57,.18);
   for(let j=0;j<7;j++)egg(o,j%2?0xffcb91:0xbd5b66,x+Math.sin(j*5)*.50,1.01+j*.18,z+.15,.061,.064,.025);
  }else{
   const c=set==='moon'?0x705c7c:0x476b75;
   poly(o,c,x,.02,z,[[-1,0],[-.70,.58],[-.46,.28],[-.20,1.04],[.19,.57],[.47,1.24],[.76,.36],[.98,0]],.11);
   for(let j=0;j<4;j++){let dx=x+s*j*.21;egg(o,set==='moon'?0xa18aaa:0x739894,dx,.30+j*.06,z+.11,.23,.14,.04);}
  }
 }
 function glint(){return 0xbf9157;}
}

