const musicIcon=muted=>'<svg viewBox="0 0 24 24"><path d="M4 9h4l5-4v14l-5-4H4z"/>'+(muted?'<path d="m17 9 5 6m0-6-5 6"/>':'<path d="M16 9q4 3 0 6m3-9q6 6 0 12"/>')+'</svg>';
const bloomIcon='<svg viewBox="0 0 24 28" aria-hidden="true"><path d="m7 26 6-16m-5 11 6-2" fill="none" stroke="#aec394" stroke-width="2"/><path d="m7 4 4 1 2-3 3 3 4-1-1 6-5 4-5-2-3-5z" fill="#ff9884" stroke="#f1ce97"/><path d="m10 6 5 4 2-5" fill="none" stroke="#a64a54"/></svg>';
function sheet(k,title,copy,primary,onMain,secondary,onAlt){
 $('#kicker').textContent=k;$('#title').textContent=title;$('#copy').textContent=copy;
 $('#mainAction').textContent=primary;$('#mainAction').onclick=onMain;$('#altAction').hidden=!secondary;$('#altAction').textContent=secondary||'';$('#altAction').onclick=onAlt||null;
}
function book(){
 mode='book';updateUI();
}
let castPage=0;
const castNotes=['A flick of the baton calls in the players nearby.','Her long note keeps a bow alive while others walk into range.','A little leap carries the bow toward a fresh partner.','The second drumbeat carries farther than the first.'];
function meetCast(){mode='cast';castPage=0;updateUI();}
function updateUI(){
 if(typeof picture==='undefined')return;
 const act=sets[level],m=mode;$('#frame').dataset.mode=m;
 const playing=['aim','flight','chain','curtain'].includes(m);
 $('#status').hidden=!playing;$('#tray').hidden=!playing;$('#sheet').hidden=playing;$('#pause').hidden=!['aim','flight','chain'].includes(m);$('#collection').replaceChildren();
 $('#sound').innerHTML=musicIcon(profile.muted);$('#sound').setAttribute('aria-label',profile.muted?'Turn sound on':'Mute sound');
 $('#acttag').textContent=guestNight?'GUEST PERFORMANCE':'ACT '+String(level+1).padStart(2,'0')+' / 06';$('#actname').textContent=guestNight?'One-rose waltz':act.name;
 $('#tally').innerHTML='<span class="pip">✦</span>'+bowed+'<span class="pipsmall"> / '+goal()+' bows</span>';
 $('#flowers').innerHTML=Array.from({length:roseCount()},(_,i)=>'<span class="'+(i<rosesLeft?'':'spent')+'">'+bloomIcon+'</span>').join('');
 $('#hint').textContent=m==='aim'?'Touch the stage to toss':m==='flight'?'Rose in flight':m==='chain'?'Pass the applause':'Curtain call';
 if(m==='cover'){const marked=validBookmark(profile.bookmark);sheet('A POCKET OPERETTA','Plume Opera',marked?'An unfinished act awaits. Your first rose is already on stage.':'Toss a rose. Make the actors bow. Let the applause travel. ',marked?'Continue act':'Raise the curtain',marked?resumeAct:begin,'Playbill',book);}
 if(m==='pause')sheet('INTERMISSION','Take a breath','The company will hold your place.','Resume',resume,'Leave act',exitRound);
 if(m==='result'){
  const total=profile.stars.reduce((a,b)=>a+b,0);
  const title=encore?(bowed===actors.length?'Standing ovation':'Bravo, company!'):'Dress rehearsal';
  const text=encore?bowed+' performers bowed · '+(unlockedOutfit?'New costume: '+unlockedOutfit:total+' / 18 rosettes'):'Try a rose between two performers when their paths meet.';
  const next=encore&&level<5;sheet(encore?'✦ '.repeat(resultStars).trim()+'   •   ACT '+(level+1):'CURTAIN DOWN',title,text,next?'Next act':encore?'Playbill':'Try again',next?()=>beginAct(level+1):encore?book:()=>beginAct(level),next?'Playbill':encore?'Replay act':'Playbill',next?book:encore?()=>beginAct(level):book);
  if(guestNight)sheet('SPECIAL ENGAGEMENT',encore?'Encore!':'Dress rehearsal',bowed+' of 9 bowed on one rose · Personal best '+profile.encoreBest,'New cast',guestShow,'Playbill',book);
 }
 if(m==='book'){
  const sup=sdk.support();let bonus=sup.like&&!profile.rewards.like?' A host like gilds your petals.':sup.comment&&!profile.rewards.comment?' A host comment adds ribbons.':'';
  sheet('THE ROSE COMPANY','Playbill','Clear each act to open the next. One rose for the entire cast earns all three rosettes.'+bonus,'Back',()=>{mode='cover';prepare(profile.act);},'Meet the cast',meetCast);
  Acts.forEach((s,i)=>{const b=document.createElement('button');b.className='stamp';b.disabled=i>unlocked();b.textContent=(i+1)+'. '+s.name;const stars=document.createElement('span');stars.textContent=b.disabled?'Sealed':('✦'.repeat(profile.stars[i])+'◇'.repeat(3-profile.stars[i]));b.append(stars);b.onclick=()=>beginAct(i);$('#collection').append(b);});
  if(profile.stars[5]){const b=document.createElement('button');b.className='stamp guest';b.textContent='One-rose waltz';b.onclick=guestShow;$('#collection').append(b);}
 }
 if(m==='cast'){
  const next=wardrobe[outfitTier()+1],r=Roles[castPage];
  sheet('COSTUME DEPARTMENT',r.name,castNotes[castPage],'Next performer',()=>{castPage=(castPage+1)%4;sound.bow(castPage,1);updateUI();},'Playbill',book);
  const strip=document.createElement('div');strip.className='cast-card';
  const art=document.createElement('img'),key='actor-'+castPage+'-lift';art.alt=r.name+' in costume';art.src=(typeof embeddedPlates!=='undefined'&&embeddedPlates[key])||'plates/'+key+'.webp';
  const note=document.createElement('div');const heading=document.createElement('strong');heading.textContent='Pigeon wardrobe';note.append(heading,document.createElement('br'),wardrobe[outfitTier()].name,document.createElement('br'),next?next.name+' at '+next.stars+' rosettes':'Complete collection');strip.append(art,note);$('#collection').append(strip);
 }
}
$('#sound').onclick=()=>{profile.muted=!profile.muted;persist();sound.wake();if(!profile.muted)sound.cue('open');updateUI();};$('#pause').onclick=pause;
let pointer=null,pressAt=null;
$('#screen').addEventListener('pointerdown',e=>{if(mode!=='aim'||pointer!==null)return;pointer=e.pointerId;e.currentTarget.setPointerCapture(e.pointerId);dropAim=picture.aim(e.clientX,e.clientY);pressAt={x:e.clientX,y:e.clientY,point:dropAim};sound.wake();});
$('#screen').addEventListener('pointermove',e=>{if(pointer===e.pointerId&&mode==='aim')dropAim=picture.aim(e.clientX,e.clientY);});
$('#screen').addEventListener('pointerup',e=>{if(pointer!==e.pointerId)return;pointer=null;const short=pressAt&&Math.hypot(e.clientX-pressAt.x,e.clientY-pressAt.y)<7;const p=short?pressAt.point:picture.aim(e.clientX,e.clientY);pressAt=null;dropAim=null;if(p)launch(p);});
$('#screen').addEventListener('pointercancel',()=>{pointer=null;dropAim=null;});
document.addEventListener('visibilitychange',()=>{if(document.hidden)pause();lastTs=0;});
window.addEventListener('pagehide',e=>{if(!e.persisted)sdk.stop();});
document.addEventListener('keydown',e=>{
 if(e.key==='Escape'){if(mode==='pause')resume();else pause();}
 if(mode==='aim'&&['ArrowRight','ArrowLeft','Enter',' '].includes(e.key)){e.preventDefault();let fresh=actors.filter(a=>!a.hit);if(!fresh.length)return;let i=fresh.findIndex(a=>a.i===hovered);if(e.key==='ArrowLeft'||e.key==='ArrowRight')i=(i+(e.key==='ArrowLeft'?-1:1)+fresh.length)%fresh.length;else if(i<0)i=0;let a=fresh[i];hovered=a.i;dropAim={x:a.x,z:a.z,actor:a.i};if(e.key==='Enter'||e.key===' ')launch(dropAim);}
});
new ResizeObserver(()=>picture.resize()).observe($('#frame'));
function hostSize(){
 const v=sdk.viewport(),root=document.documentElement;
 root.style.setProperty('--host-w',v?Math.min(innerWidth,v.width)+'px':'100vw');
 root.style.setProperty('--host-h',v?Math.min(innerHeight,v.height)+'px':'100dvh');
}
hostSize();window.addEventListener('resize',hostSize);window.addEventListener('focus',hostSize);document.addEventListener('pointerdown',hostSize,{passive:true});
prepare(level);updateUI();function loop(ts){const dt=lastTs?Math.min(.065,(ts-lastTs)/1000):.016;lastTs=ts;if(!document.hidden){step(dt);sound.music(dt);picture.draw(mode==='pause'?0:dt);}requestAnimationFrame(loop);}requestAnimationFrame(loop);

