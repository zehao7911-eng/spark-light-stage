const Acts=[
 {name:'First blush',set:'sun',back:0xf6ae78,sky:0xffd9a0,floor:0xb77746,accent:0xe55d54,target:3,roses:2, cast:[0,1,2,0],layout:[[-1.85,-.8],[-.4,-.55],[1.2,-.3],[1.3,2.35]],note:'Tap an actor to toss a rose.'},
 {name:'The garden party',set:'garden',back:0x82afa1,sky:0xd0dec0,floor:0xa97447,accent:0x248a77,target:5,roses:2,cast:[1,0,2,1,2,0],layout:[[-2.65,-2.65],[-.45,-1.9],[2.4,-2],[1.7,.35],[-1.1,1.05],[-.9,3.75]],note:'A soprano carries applause farther.'},
 {name:'The moon waltz',set:'moon',back:0x494b77,sky:0xb8adbe,floor:0x966247,accent:0x8b71b7,target:5,roses:2,cast:[0,2,1,0,2,1,0],layout:[[-2.5,-2.75],[.05,-2.9],[2.45,-2.15],[-1.7,.0],[1.05,.65],[-2.3,3.4],[1.2,3.55]],note:'The brass flowers carry bows across the stage.'},
 {name:'A little thunder',set:'storm',back:0x557c86,sky:0xa9c8c7,floor:0x987350,accent:0x3c9d9c,target:6,roses:2,cast:[3,1,2,3,0,2,1],layout:[[-2.7,-3],[.3,-3.15],[2.7,-1.38],[-1.62,-.35],[1.02,.65],[-1.9,2.74],[1.3,3.64]],note:'Drums send a second beat.'},
 {name:'Masquerade',set:'mask',back:0xbd7998,sky:0xf1bcb7,floor:0xaa7351,accent:0xb94c80,target:7,roses:2,cast:[2,1,3,0,2,1,3,0],layout:[[-2.5,-3.48],[0,-3.28],[2.55,-2.75],[-1.45,-.78],[1.4,-.5],[-2.5,2.18],[.07,2.78],[2.52,3.71]],note:'Wait for two paths to meet.'},
 {name:'The grand encore',set:'final',back:0xe59460,sky:0xffdeb0,floor:0xbe814f,accent:0xd95850,target:8,roses:2,cast:[0,2,1,3,2,1,0,3,1],layout:[[-2.58,-3.85],[.15,-3.75],[2.68,-2.68],[-2.4,-.98],[.1,-.67],[2.55,.64],[-2.65,2.38],[-.05,3.36],[2.64,4.0]],note:'Give the whole company a curtain call.'}
];
function theatre(act){
 const o=g(),set=act.set;
 const X=5.05,wood=act.floor,shade=0x713c37,edge=0x502a35,iv=0xffe0a0,green=0x356363;
 const front=6.15,back=-6.18;
 // The apron's cutaway shows its joinery and carved rosettes.
 cube(o,edge,0,-.70,.01,10.35,1.14,12.55);
 for(let j=0;j<23;j++){
  const zz=-6+j*.542,shift=(j%3)*.83;
  cube(o,[wood,wood,wood,0xb88051][j%4],0,-.069,zz,10.00,.14,.524);
  for(let i=-1;i<=1;i++){const xx=i*3.3+shift-.78;if(Math.abs(xx)<4.75){cube(o,0x94663e,xx,.006,zz,.021,.008,.49);cube(o,0xce9158,xx+.07,.006,zz-.155,.039,.009,.027);}}
 }
 for(const x of [-4.82,4.82]){cube(o,brass,x,.013,0,.12,.027,12.19);cube(o,iv,x,.029,0,.025,.012,12.18);}
 cube(o,brass,0,-.1,front,10.38,.28,.30);cube(o,iv,0,-.023,front+.155,10.34,.034,.035);
 for(let j=-4;j<=4;j++){cube(o,0x824838,j*1.10,-.70,front+.13,1.02,.61,.08);cube(o,shade,j*1.1,-.69,front+.178,.82,.40,.035);poly(o,gold,j*1.1,-.70,front+.202,[[-.12,0],[0,.115],[.12,0],[0,-.115]],.018);}
 // Brass footlights with an open shell and warm bulbs.
 for(let j=0;j<14;j++){let x=-4.65+j*.716;egg(o,green,x,.075,front-.14,.156,.133,.12);egg(o,iv,x,.112,front-.189,.106,.085,.091);}
 // False wings, carved capitals, and tasseled drapes.
 function column(x,z,height){
  cube(o,edge,x,height*.49,z,.73,height,.60);cube(o,green,x,height*.49,z+.13,.60,height*.94,.49);
  for(const dx of [-.22,.22])cube(o,gold,x+dx,height*.5,z+.399,.047,height*.88,.063);
  for(let j=0;j<4;j++){let y=.24+(height-.5)*j/3;cube(o,j%2?brass:gold,x,y,z+.08,.84,.12,.75);}
  egg(o,iv,x,height-.23,z+.4,.128,.13,.076);cube(o,gold,x,height+.043,z,.89,.15,.85);
 }
 for(const s of [-1,1]){
  column(s*4.81,-4.75,6.25);column(s*5.38,-6.96,6.77);
  cube(o,shade,s*5.24,3.10,-4.80,.42,6.17,1.05);
  for(let j=0;j<6;j++){
   const top=s*(4.6-j*.19),mid=s*(4.76+j*.027),bottom=s*(4.79-j*.114);
   rod(o,[0x902f47,0xae3753,0xd64c5b][j%3],[top,6.13,-4.53+j*.056],[mid,3.14,-4.42+j*.064],.215,.107);
   rod(o,[0x952d42,0xb9364c,0xd44b55][j%3],[mid,3.14,-4.42+j*.064],[bottom,.73,-4.45+j*.055],.12,.19);
  }
  egg(o,gold,s*4.78,3.08,-4.06,.21,.093,.124);rod(o,gold,[s*4.74,3.07,-4.02],[s*4.51,2.62,-3.97],.033);egg(o,iv,s*4.50,2.57,-3.96,.085,.16,.073);
 }
 cube(o,green,0,6.24,-4.84,10.42,.52,.67);cube(o,gold,0,6.51,-4.81,10.67,.13,.73);
 for(let j=-4;j<=4;j++){
  const h=.38+Math.cos(j*.74)*.12;
  egg(o,0x8d2a42,j*1.06,6.02,-4.62,.73,h,.25);egg(o,0xc83c52,j*1.06,6.07,-4.48,.66,h*.82,.18);
  egg(o,iv,j*1.06,6.10-h,-4.44,.043,.083,.043);
 }
 // A sunburst clock over the velvet valance.
 egg(o,green,0,6.54,-4.39,.78,.66,.12);ring(o,gold,0,6.54,-4.27,.489,.047);
 for(let i=0;i<12;i++){let a=i*Math.PI/6;rod(o,iv,[Math.sin(a)*.34,6.54+Math.cos(a)*.34,-4.26],[Math.sin(a)*.419,6.54+Math.cos(a)*.419,-4.26],.023);}
 rod(o,gold,[0,6.54,-4.23],[.20,6.7,-4.23],.026);rod(o,gold,[0,6.54,-4.23],[-.138,6.67,-4.23],.038);
 // Painted flats, cutout rooftops and wings. A painted moon changes into a wheel of roses.
 cube(o,act.back,0,2.46,-6.62,11.95,5.61,.17);
 const disc=set==='moon'?0xffe7b7:set==='storm'?0xd1ddce:0xffd78d;
 egg(o,disc,1.93,3.81,-6.44,.90,.90,.062);
 if(set==='moon')egg(o,act.back,2.27,4.04,-6.34,.77,.77,.044);
 const city=set==='moon'?0x655776:set==='storm'?0x587a80:0xc7806c;
 for(let j=0;j<15;j++){
  const x=-5.4+j*.78,h=.68+(Math.sin(j*8.23)+1)*.59;
  cube(o,city,x,h/2,-6.36,.72,h,.09);
  poly(o,city,x,h,-6.34,[[-.40,0],[.01,.31+(j%3)*.09],[.38,0]],.07);
  for(let k=0;k<2;k++)cube(o,disc,x+(k-.5)*.25,h*.63,-6.29,.09,.16,.04);
 }
 for(let i=0;i<18;i++){const x=-5.3+(i*1.735)%10.6,y=2.25+(i*.819)%2.68;if(Math.hypot(x-1.93,y-3.81)<1)continue;
  if(set==='moon'||set==='mask')poly(o,iv,x,y,-6.45,[[0,.089],[.026,.028],[.084,0],[.026,-.023],[0,-.08],[-.02,-.023],[-.07,0],[-.02,.025]],.006);
  else egg(o,set==='storm'?0x93aeb0:act.sky,x,y,-6.44,.24+(i%3)*.13,.078,.04);
 }
 // Wing boxes and silhouette audience. Their heads never overlap the touch area.
 for(const s of [-1,1])for(let j=0;j<3;j++){
  const z=-2.5+j*3.42;cube(o,green,s*5.80,.53,z,1.36,1.05,2.7);
  cube(o,brass,s*5.15,.81,z,.115,.32,2.83);cube(o,gold,s*5.12,1.02,z,.14,.09,2.85);
  for(let i=0;i<3;i++){
   let zz=z+(i-1)*.68;egg(o,[0x826483,0x446b71,0xa55b64][(i+j)%3],s*5.74,1.09,zz,.22,.25,.21);
   egg(o,[0xecba8c,0xb77852,0xe7ac83][(i+j)%3],s*5.73,1.37,zz,.16,.177,.154);
   egg(o,[0x5e4046,0x4d3b44,0x906958][(i+j)%3],s*5.73,1.48,zz-.019,.167,.099,.155);
  }
 }
 function urn(x,z){
  turned(o,green,x,0,z,[[.19,.02],[.23,.07],[.13,.19],[.22,.23],[.31,.42],[.34,.54],[.36,.58]],.9);
  for(let i=0;i<9;i++){let a=i*2.39,r=.17+i%3*.06,y=.68+(i%4)*.10,tx=x+Math.cos(a)*r,tz=z+Math.sin(a)*r;rod(o,0x44674f,[x,.46,z],[tx,y,tz],.023);egg(o,0x508166,tx,y-.04,tz,.09,.145,.06,0,a,.34);if(i%2===0)egg(o,set==='moon'?iv:act.accent,tx,y+.09,tz,.099,.093,.091);}
 }
 for(const s of [-1,1]){urn(s*4.27,-4.17);urn(s*4.63,5.69);}
 if(set==='garden'||set==='mask')for(const s of [-1,1])for(let j=0;j<6;j++){
  let x=s*(4.28-j*.36),y=4.01+Math.sin(j*.77)*.36;
  egg(o,0x477965,x,y,-6.03,.49,.30,.12);for(let k=0;k<3;k++)egg(o,k===1?cream:act.accent,x+(k-1)*.16,y+.12*Math.cos(k+j),-5.90,.081,.077,.06);
 }
 if(set==='storm')for(let j=0;j<5;j++){
  let x=-2.8+j*1.36,y=3.7+Math.sin(j)*.4;egg(o,0x718e99,x,y,-6.06,.69,.32,.12);rod(o,iv,[x,5.2,-6.09],[x,y+.23,-6.09],.009);
  for(let k=0;k<3;k++)egg(o,0xa0d6cd,x+(k-1)*.21,y-.52-(k%2)*.16,-6.05,.041,.106,.034,0,0,-.16);
 }
 if(set==='final')for(const s of [-1,1])for(let j=0;j<6;j++)poly(o,[rose,jade,gold][j%3],s*(.4+j*.64),4.13+j*.11,-6.02,[[-.23,0],[.23,0],[0,-.37]],.04);
 auditorium(o,act);paintedSet(o,act);curtains(o);floorInlay(o);return finish(o);
}

