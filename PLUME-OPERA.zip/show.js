/* The show runs in world units; the same choreography drives both renderers. */
const TAU=Math.PI*2;
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const mix=(a,b,t)=>a+(b-a)*t;
const profileKey='plume-opera.playbill.v1';
let profile={stars:Array(6).fill(0),chains:Array(6).fill(0),rewards:{},muted:false,act:0,bookmark:null,bookmarkedAt:0,encoreBest:0};
function validBookmark(b){
 if(!b||!Number.isInteger(b.level)||b.level<0||b.level>=Acts.length||b.roses!==1||!Number.isFinite(b.time)||b.time<0||b.time>86400)return false;
 return Array.isArray(b.cast)&&b.cast.length===Acts[b.level].cast.length&&b.cast.every(p=>Array.isArray(p)&&p.length===4&&p.every(Number.isFinite)&&Math.abs(p[0])<6&&Math.abs(p[1])<7&&(p[2]===0||p[2]===1)&&p[3]>=0&&p[3]<20);
}
function mergeProfile(raw,remote){
 if(!raw||typeof raw!=='object')return;
 for(const key of ['stars','chains'])for(let i=0;i<6;i++){const v=Number(raw[key]?.[i]);if(Number.isFinite(v))profile[key][i]=Math.max(profile[key][i],clamp(Math.floor(v),0,key==='stars'?3:9));}
 for(const k of ['like','comment'])if(raw.rewards?.[k]===true)profile.rewards[k]=true;
 if(Number.isFinite(raw.encoreBest))profile.encoreBest=Math.max(profile.encoreBest,clamp(Math.floor(raw.encoreBest),0,9));
 if(!remote&&typeof raw.muted==='boolean')profile.muted=raw.muted;
 if(!remote&&Number.isInteger(raw.act))profile.act=clamp(raw.act,0,unlocked());
 if(Number.isFinite(raw.bookmarkedAt)&&raw.bookmarkedAt>profile.bookmarkedAt){
  profile.bookmarkedAt=raw.bookmarkedAt;profile.bookmark=validBookmark(raw.bookmark)?raw.bookmark:null;
 }
}
function unlocked(){let i=0;while(i<5&&profile.stars[i]>0)i++;return i;}
function persist(){try{localStorage.setItem(profileKey,JSON.stringify(profile));}catch{}}
try{mergeProfile(JSON.parse(localStorage.getItem(profileKey)),false);}catch{}
const sdk=bridge({read:()=>profile,write:(p,cloud)=>{mergeProfile(p,cloud);persist();},changed:e=>{
 if(e.type==='reward'){toast(e.kind==='like'?'Gilt petals unlocked':'Ribbon confetti unlocked');}
 if(e.type==='cloud'||e.type==='support'||e.type==='reward')queueMicrotask(()=>{if(typeof updateUI==='function')updateUI();});
}});
const $=s=>document.querySelector(s);
let level=profile.act,mode='cover',actors=[],pulses=[],petals=[],sparks=[],stageTime=0,showTime=0,rosesLeft=2,bowed=0,bestDepth=0,longestChain=0,throwStart=0,resultStars=0,finaleClock=0,latched=false,pausedFrom='',lastTs=0,dropAim=null,hovered=-1,headlineTime=0,throwCount=0,encore=false;
const sets=Acts;
let guestNight=false,guestSeed=0,unlockedOutfit='';
function goal(){return guestNight?7:sets[level].target;}
function roseCount(){return guestNight?1:sets[level].roses;}
function placeActor(a,t){
 const row=sets[level].layout[a.i],role=a.role;
 const sway=level===0?.26:.42+level*.085;
 a.x=row[0]+Math.sin(t*(.47+(a.i%3)*.09)+a.i*1.91)*sway;
 a.z=row[1]+Math.sin(t*.49+a.i*1.73)*sway*(role===2?1.15:.60);
 a.heading=Math.sin(t*.62+a.i*1.9)*.43;
 if(guestNight){const angle=TAU*(a.i/actors.length)+t*.14+guestSeed;
  a.x=3.14*Math.sin(angle);a.z=3.80*Math.sin(angle*2+.48*guestSeed);a.heading=.48*Math.cos(angle);}
}
function spaceCast(){
 for(let pass=0;pass<3;pass++)for(let i=0;i<actors.length;i++)for(let j=0;j<i;j++){
  const a=actors[i],b=actors[j];if(a.hit&&b.hit)continue;
  let dx=a.x-b.x,dz=a.z-b.z,dist=Math.hypot(dx,dz),clearance=.78+(a.role===1?.15:0)+(b.role===1?.15:0);
  if(dist>=clearance)continue;if(dist<.001){dx=.001;dz=0;dist=.001;}
  const shift=(clearance-dist)/dist,k=a.hit?0:b.hit?1:.50;
  a.x+=dx*shift*k;a.z+=dz*shift*k;b.x-=dx*shift*(1-k);b.z-=dz*shift*(1-k);
 }
}
function prepare(n,special=false){
 guestNight=special;guestSeed=special?Math.random()*TAU:0;unlockedOutfit='';
 level=clamp(n,0,unlocked());profile.act=level;persist();sdk.prepare();
 actors=sets[level].cast.map((role,i)=>({i,role:special?(role+Math.floor(guestSeed+i*.5))%4:role,x:0,z:0,heading:0,hit:false,hitTime:0,depth:0}));
 stageTime=.15;showTime=0;rosesLeft=roseCount();bowed=0;bestDepth=0;longestChain=0;throwStart=0;throwCount=0;finaleClock=0;encore=false;latched=false;resultStars=0;pulses=[];sparks=[];petals=[];dropAim=null;hovered=-1;
 for(const a of actors)placeActor(a,stageTime);spaceCast();
 resetCues();picture.rebuild();updateUI();
}
function bookmark(keep){
 profile.bookmark=keep?{level,time:stageTime,roses:rosesLeft,cast:actors.map(a=>[a.x,a.z,+a.hit,a.depth]),chain:longestChain,relay:relayed}:null;
 profile.bookmarkedAt=Math.max(Date.now(),profile.bookmarkedAt+1);persist();sdk.save();
}
function resumeAct(){
 const b=profile.bookmark;if(!validBookmark(b)||b.level>unlocked()){begin();return;}
 prepare(b.level);stageTime=showTime=b.time;rosesLeft=1;throwCount=1;bowed=0;relayed=b.relay===true;
 longestChain=clamp(Number(b.chain)||0,0,actors.length);
 actors.forEach((a,i)=>{const p=b.cast[i];a.x=p[0];a.z=p[1];a.hit=!!p[2];a.depth=p[3];a.hitTime=showTime-2;if(a.hit)bowed++;});
 begin();toast('One rose left. Your cast is ready.');
}
function begin(){
 sound.wake();sound.cue('open');opening=1;mode='aim';latched=false;
 sdk.start();updateUI();toast(guestNight?'One rose. Catch the crossing.':sets[level].note,2.7);
}
function beginAct(n){mode='cover';bookmark(false);prepare(n);begin();}
function guestShow(){mode='cover';bookmark(false);prepare(5,true);begin();}
function launch(point){
 if(mode!=='aim'||!point||rosesLeft<=0)return;
 let {x,z}=point;const a=actors[point.actor??-1];if(a&&!a.hit){x=a.x;z=a.z;}
 dropAim=null;hovered=-1;throwStart=bowed;throwCount++;rosesLeft--;mode='flight';
 petals.push({x,z,t:0,duration:.58,target:a&&!a.hit?a.i:-1,from:picture.birdWorld()});
 sound.wake();sound.cue('flit');updateUI();
}
function pulse(x,z,depth,role=-1,delay=0,echo=false){
 // Runtime adaptation of Bloom's grow/hold/fade propagation and depth gain, in stage metres.
 const reach=role<0?1.21:Roles[role].reach;
 pulses.push({x,z,depth,role,age:-delay,grow:.46,hold:role===1?.92:.62,fade:.42,maxR:echo?reach*1.38:reach+Math.min(depth,6)*.052,r:0,alpha:1,echo});
}
function scatter(x,z,role,depth){
 const colors=[gold,cream,role<0?rose:Roles[role].coat,profile.rewards.like?0xf8cd56:0xf4a69c];
 for(let i=0;i<8+Math.min(depth,4);i++){
  const ang=i*2.399+Math.random()*.35,v=.44+Math.random()*.96;
  sparks.push({x,z,y:.38,vx:Math.cos(ang)*v,vz:Math.sin(ang)*v,vy:1.0+Math.random()*1.9,spin:Math.random()*6,life:.98+Math.random()*.29,c:colors[i%4],r:profile.rewards.comment&&i%3===0?.108:.057+Math.random()*.025});
 }
}
function catchActor(a,p){
 litActor=a.i;a.hit=true;a.depth=p.depth+1;a.hitTime=showTime;bowed++;bestDepth=Math.max(bestDepth,a.depth);
 sound.bow(a.role,a.depth);scatter(a.x,a.z,a.role,a.depth);
 const delay=a.role===3?.36:.26;if(a.role!==2||!comicHop(a))pulse(a.x,a.z,a.depth,a.role,delay);
 if(a.role===3)pulse(a.x,a.z,a.depth,a.role,.97,true);
 longestChain=Math.max(longestChain,bowed-throwStart);updateUI();
 picture.callout(a.x,a.z,a.depth===1?'Bravo!':a.role===3?'Drumroll!':a.role===2?'Ta-da!':'Encore!',a.depth);
}
function finishThrow(){
 if(bowed>=goal()||rosesLeft===0){mode='curtain';finaleClock=0;encore=bowed>=goal();
  resultStars=encore?1+(bowed===actors.length?1:0)+(bowed===actors.length&&throwCount===1?1:0):0;
  const before=outfitTier();
  if(guestNight)profile.encoreBest=Math.max(profile.encoreBest,bowed);
  else{profile.stars[level]=Math.max(profile.stars[level],resultStars);profile.chains[level]=Math.max(profile.chains[level],longestChain);}
  if(outfitTier()>before)unlockedOutfit=wardrobe[outfitTier()].name;
  if(encore)profile.act=Math.min(5,level+1);bookmark(false);sdk.end();
  sound.cue(encore?'win':'again');toast(encore?(bowed===actors.length?'Standing ovation!':'Curtain call!'):'One more rehearsal?',2.0);
 }else{mode='aim';bookmark(true);toast(bowed===throwStart?'Aim at a performer.':'One rose left. Find a fresh face.',2.6);}
 updateUI();
}
function step(dt){
 if(mode==='pause'||mode==='book'||mode==='cast')return;
 stageTime+=dt;showTime+=dt;opening=Math.max(0,opening-dt/1.15);
 if(headlineTime>0){headlineTime-=dt;if(headlineTime<=0)$('#message').classList.remove('on');}
 if(mode==='cover'||mode==='aim'||mode==='flight'||mode==='chain'){
  for(const a of actors)if(!a.hit)placeActor(a,stageTime);spaceCast();
 }
 if(mode==='flight'){
  const f=petals[0];f.t+=dt;
  if(f.target>=0){f.x=actors[f.target].x;f.z=actors[f.target].z;}
  if(f.t>=f.duration){mode='chain';pulse(f.x,f.z,0);scatter(f.x,f.z,-1,0);petals.length=0;sound.cue('petal');}
 }
 if(mode==='chain'){cuesFrame(dt);
  for(let i=pulses.length-1;i>=0;i--){
   const b=pulses[i];b.age+=dt;if(b.age<0)continue;
   if(b.age<=b.grow){b.r=(1-(1-b.age/b.grow)**5)*b.maxR;b.alpha=1;}
   else if(b.age<=b.grow+b.hold){b.r=b.maxR+Math.sin((b.age-b.grow)*8)*.033;b.alpha=1;}
   else{const k=(b.age-b.grow-b.hold)/b.fade;b.r=b.maxR*(1+k*.16);b.alpha=(1-Math.min(k,1))**3;if(k>=1){pulses.splice(i,1);continue;}}
   catchCue(b);if(b.alpha>.25)for(const a of actors){const dx=a.x-b.x,dz=a.z-b.z;if(!a.hit&&dx*dx+dz*dz<=(b.r+.20)**2)catchActor(a,b);}
  }
  if(!pulses.length&&!hopQueue.length)finishThrow();
 }
 for(let i=sparks.length-1;i>=0;i--){const s=sparks[i];s.life-=dt;if(s.life<=0){sparks.splice(i,1);continue;}s.x+=s.vx*dt;s.z+=s.vz*dt;s.y+=s.vy*dt;s.vy-=3.7*dt;if(s.y<.045){s.y=.045;s.vy=Math.abs(s.vy)*.2;}s.spin+=dt*3.3;}
 if(mode==='curtain'){
  finaleClock+=dt;
  if(encore&&!latched&&finaleClock>.55){latched=true;for(const a of actors)scatter(a.x,a.z,a.role,1);}
  if(finaleClock>3.40){mode='result';updateUI();}
 }
}
function toast(text,duration=1.8){const m=$('#message');if(!m)return;m.textContent=text;m.classList.add('on');headlineTime=duration;}
function pause(){if(!['aim','flight','chain'].includes(mode))return;pausedFrom=mode;mode='pause';dropAim=null;updateUI();}
function resume(){if(mode!=='pause')return;mode=pausedFrom;updateUI();}
function exitRound(){if(mode==='pause'){sdk.end();}mode='cover';prepare(level);}

