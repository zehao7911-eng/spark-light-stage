const sound=(()=>{
 let ac,bus,wet,clapBuffer,lowShot=0,beat=0;
 const scale=[261.63,329.63,392.00,523.25,659.25,783.99,1046.5,1318.51];
 function wake(){if(!ac){try{ac=new(window.AudioContext||window.webkitAudioContext)();bus=ac.createGain();bus.gain.value=.31;bus.connect(ac.destination);
  const echo=ac.createDelay();echo.delayTime.value=.126;wet=ac.createGain();wet.gain.value=.13;wet.connect(echo);echo.connect(bus);}catch{return;}}if(ac.state==='suspended')ac.resume().catch(()=>{});}
 function note(f,d=.19,type='triangle',amp=.21,delay=0,end=0){
  if(!ac||profile.muted||ac.state!=='running')return;const t=ac.currentTime+delay,o=ac.createOscillator(),v=ac.createGain();o.type=type;o.frequency.setValueAtTime(f,t);if(end)o.frequency.exponentialRampToValueAtTime(end,t+d);
  v.gain.setValueAtTime(.0001,t);v.gain.exponentialRampToValueAtTime(amp,t+.012);v.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(v);v.connect(bus);v.connect(wet);o.start(t);o.stop(t+d+.015);o.onended=()=>{o.disconnect();v.disconnect();};
 }
 function cue(k){
  if(k==='open')for(const [i,f] of [330,392,523].entries())note(f,.20,'triangle',.19,i*.075);
  if(k==='flit'){note(650,.14,'sine',.19,0,1270);note(980,.13,'sine',.15,.09,1470);}
  if(k==='petal')note(880,.26,'triangle',.18,0,554);
  if(k==='win'){for(const [i,f] of [392,494,587,784,988,1047].entries())note(f,i===5?.62:.25,'triangle',.23,i*.11);for(let j=0;j<18;j++)clap(.19+j*.045+Math.random()*.09,.11+(j%4)*.022);}
  if(k==='again'){note(392,.18,'triangle',.22);note(330,.29,'triangle',.19,.16);}
 }
 function clap(delay,amp){
  if(!ac||profile.muted||ac.state!=='running')return;
  if(!clapBuffer){clapBuffer=ac.createBuffer(1,Math.ceil(ac.sampleRate*.128),ac.sampleRate);const d=clapBuffer.getChannelData(0);for(let i=0;i<d.length;i++){let x=i/d.length;d[i]=(Math.random()*2-1)*Math.exp(-7*x)*(1+.55*Math.cos(x*62));}}
  const src=ac.createBufferSource(),filter=ac.createBiquadFilter(),v=ac.createGain();src.buffer=clapBuffer;filter.type='bandpass';filter.frequency.value=1150+Math.random()*800;filter.Q.value=.69;v.gain.value=amp;src.connect(filter);filter.connect(v);v.connect(bus);src.start(ac.currentTime+delay);src.onended=()=>{src.disconnect();filter.disconnect();v.disconnect();};
 }
 function bow(role,depth){let f=scale[Math.min(scale.length-1,depth)];note(f,.32,role===1?'sine':'triangle',.21);note(f*1.5,.24,'sine',.085,.052);if(role===3){for(let i=0;i<3;i++)note(160,.096,'triangle',.28,i*.075,70);}if(depth>1){clap(.025,.18);clap(.112,.12);}}
 function music(dt){if(mode==='cover'||mode==='pause'||mode==='book'||profile.muted||!ac)return;lowShot-=dt;if(lowShot>0)return;
  const bass=[130.81,98,110,87.31],chord=[261.63,293.66,329.63,349.23],bar=Math.floor(beat/3)%4,k=beat%3;
  note(k?chord[bar]*(k===1?1.25:1.5):bass[bar],k?.12:.27,'triangle',k?.065:.14);
  if(k===0)note(bass[bar]*2,.18,'sine',.09,.055);
  beat++;lowShot=mode==='chain'?.282:.341;
 }
 return{wake,note,cue,bow,music};
})();
