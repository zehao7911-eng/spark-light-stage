Shader "Penny/Toy" {Properties {_Color("Color",Color)=(1,1,1,1) _Gloss("Glaze",Range(0,1))=.4} SubShader {Tags {"RenderType"="Opaque"} Pass {Tags {"LightMode"="ForwardBase"} CGPROGRAM
#pragma vertex vert
#pragma fragment frag
#pragma multi_compile_fwdbase nolightmap nodirlightmap nodynlightmap novertexlight
#include "UnityCG.cginc"
#include "Lighting.cginc"
#include "AutoLight.cginc"
fixed4 _Color;float _Gloss;struct v2f{float4 pos:SV_POSITION;float3 n:TEXCOORD0;float3 w:TEXCOORD1;SHADOW_COORDS(2)};v2f vert(appdata_base v){v2f o;o.pos=UnityObjectToClipPos(v.vertex);o.n=UnityObjectToWorldNormal(v.normal);o.w=mul(unity_ObjectToWorld,v.vertex).xyz;TRANSFER_SHADOW(o);return o;}fixed4 frag(v2f i):SV_Target{float3 n=normalize(i.n),view=normalize(_WorldSpaceCameraPos-i.w),light=normalize(float3(-.35,1,-.4));float d=saturate(dot(n,light));float sh=SHADOW_ATTENUATION(i);float spec=pow(saturate(dot(n,normalize(view+light))),lerp(22,75,_Gloss))*_Gloss;float warm=lerp(.64,1,saturate(1-length(i.w.xz)/9));float ao=lerp(.78,1,saturate(i.w.y*3));float3 c=_Color.rgb*(.58+d*.54)*lerp(.72,1,sh)*warm*ao;c+=spec*float3(1,.86,.67)*.65;float rim=pow(1-saturate(dot(n,view)),4)*.05;c+=_Color.rgb*rim;return fixed4(c,1);}
ENDCG
}UsePass "Legacy Shaders/VertexLit/SHADOWCASTER"}FallBack "Diffuse"}
