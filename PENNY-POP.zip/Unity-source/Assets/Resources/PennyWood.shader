Shader "Penny/Wood" {SubShader {Tags {"RenderType"="Opaque"} Pass {Tags {"LightMode"="ForwardBase"} CGPROGRAM
#pragma vertex vert
#pragma fragment frag
#pragma multi_compile_fwdbase nolightmap nodirlightmap nodynlightmap novertexlight
#include "UnityCG.cginc"
#include "AutoLight.cginc"
struct v2f{float4 pos:SV_POSITION;float3 w:TEXCOORD0;SHADOW_COORDS(1)};v2f vert(appdata_base v){v2f o;o.pos=UnityObjectToClipPos(v.vertex);o.w=mul(unity_ObjectToWorld,v.vertex).xyz;TRANSFER_SHADOW(o);return o;}fixed4 frag(v2f i):SV_Target{float2 p=i.w.xz;float warp=sin(p.x*.7+p.y*.9)*.04+sin(p.x*1.3)*.025;float grain=sin((p.y+warp)*85+sin(p.x*1.3)*1.8)*.025+sin((p.y+warp)*17)*.04;float plank=frac((p.y+8)/1.4);float seam=smoothstep(.005,.018,min(plank,1-plank));float knot=sin(length((p-float2(-2,1.1))*float2(.45,2))*24)*exp(-length((p-float2(-2,1.1))*float2(.6,1.2))*1.8)*.05;float3 c=lerp(float3(.31,.15,.065),float3(.61,.36,.17),.6+grain+knot);c*=lerp(.72,1,seam);float spot=lerp(.55,1,saturate(1-length(p*float2(.75,.85))/10));float shadow=lerp(.64,1,SHADOW_ATTENUATION(i));return fixed4(c*spot*shadow,1);}
ENDCG
}}FallBack "Diffuse"}
