MELLOW — Little things, big feelings

An original p5.js tactile playground. All UI is English.
Drag a friend away from its starting position and release to launch it. Tap empty space to add a friend. Make waves launches a synchronized splash. Turn sound on for synthesized collision notes. Try all three palettes. Up to 12 friends are kept for bounded mobile performance.

Upload the contents of this folder to an HTTPS static host, or run node serve.cjs and open http://127.0.0.1:4200/. A web server is needed; no build or external CDN is required. p5.js is bundled locally. No images, videos, accounts, or API services are used. Audio starts only after a user tap. Background tabs stop rendering.

Mobile portrait layout tested in a desktop browser; real iOS/Android hardware and embedded game-platform browsers are not yet verified.

p5.js is distributed under LGPL-2.1; copyright and license references are retained in p5.min.js. Original reference video was used to understand tactile feedback only; its assets and code are not included.
