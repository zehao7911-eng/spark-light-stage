WALLACE: TOAST PANIC
Unofficial fan mini-game. Original code and procedural 3D artwork; not an official Aardman game. No extracted character models, recordings or commercial game assets.

Open index.html in a WebGL-capable browser, or upload the contents to static HTML5 hosting. All libraries are included; no CDN is required. Audio starts after a tap. Save data requires browser local storage; blocked storage falls back to the current session.

Tap one of the three POP buttons when its toast is GOLDEN. The dark marker shows heat. Pale toast and charred toast do not count. Burnt batches reload automatically; no lives or timer. Keyboard: 1 / 2 / 3; Escape pauses.

Gold zone: 56-88%; perfect: 66-78%. Perfect serves fill the butter meter twice as fast. Seven charges trigger 5 seconds of BUTTER FRENZY: double points, wider gold zone 45-94%, perfect 58-86%, and faster toasting. Each batch has a different heating speed; manage the three independently.

Complete a breakfast for one star, get at least half perfect for another, and make no more than two mistakes for the third. Only the best rating per breakfast counts. Nine stars unlock Wallace's chef hat, eighteen unlock gold toasters. Each new breakfast needs more toast and gradually cooks faster, capped at fourteen serves; progression continues to breakfast 999 with repeated timing patterns. No claim of 999 unique levels.

Pause or switch away to stop cooking and sound. Reload resumes the exact cooking state paused; flying toast and particles are cosmetic and reset. Highest stars and sound settings persist. Fresh Batch retries the current breakfast. No accounts, payments or analytics.

Mobile portrait and landscape layout; 44px+ controls, DPR capped at 1.5, 40FPS render cap, bounded effects. Tested with browser mobile touch emulation, not a physical handset. WebGL required; Retry reloads after context loss.

Steam inspiration: Cook, Serve, Delicious! https://store.steampowered.com/app/247020/Cook_Serve_Delicious/ . The simplified toast timing game is not a port of that game's recipes or assets.
Three.js r147 MIT: see THREE-LICENSE.txt.
