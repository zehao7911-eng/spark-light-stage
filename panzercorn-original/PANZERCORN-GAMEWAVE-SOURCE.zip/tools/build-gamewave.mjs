import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { build } from "./build.mjs";

const root = fileURLToPath(new URL("../", import.meta.url));
const output = path.resolve(process.argv[2] || path.join(root, "gamewave-dist"));
const stage = path.join(output, ".upstream-build");
await build({development:true,target:"both",outputDir:stage,temporaryDir:path.join(root,".gamewave-build")});
const source = file => fs.readFile(path.join(root,"src",file),"utf8");
const adapter = (await source("gamewave-bridge.mjs")).replace("export function bridge", "function bridge");
const wrapper = (await source("gamewave.mjs")).replace(/^import .*\r?\n/m,"");
const raw = await fs.readFile(path.join(stage,"index.html"),"utf8");
if (!raw.includes("<!--HOST-->")) throw Error("Host slot not found");
const bundle = raw.replace("<!--HOST-->", () => "<script>(()=>{\n"+adapter+"\n"+wrapper+"\n})();</script>");
await fs.writeFile(path.join(output,"index.html"),bundle);
await fs.writeFile(path.join(output,"standalone.html"),bundle);
