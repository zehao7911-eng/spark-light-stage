import { bridge } from "./gamewave-bridge.mjs";

const key = "panzercorn-profile-v1";
const note = document.getElementById("game-note");
const medals = document.getElementById("game-medals");

function sanitize(raw) {
  const number = value => Number.isSafeInteger(value) && value >= 0 ? value : 0;
  return {
    best: number(raw?.best),
    wave: number(raw?.wave),
    rewards: { like: raw?.rewards?.like === true, comment: raw?.rewards?.comment === true }
  };
}

let initial;
try { initial = JSON.parse(localStorage.getItem(key)); } catch {}
let profile = sanitize(initial);
let active = false;
let awake = false;
let adapter;

function render() {
  const support = adapter?.support() || {};
  const lines = [];
  if (profile.best) lines.push("BEST " + profile.best.toLocaleString("en"));
  if (profile.wave) lines.push("WAVE " + profile.wave);
  if (profile.rewards.like) lines.push("AURORA MEDAL");
  if (profile.rewards.comment) lines.push("PRISM MEDAL");
  if (!active && support.like && !profile.rewards.like) lines.push("Like to earn Aurora");
  if (!active && support.comment && !profile.rewards.comment) lines.push("Comment to earn Prism");
  medals.textContent = lines.join("  ·  ");
  medals.hidden = !lines.length;
  medals.classList.toggle("aurora", profile.rewards.like);
  medals.classList.toggle("prism", profile.rewards.comment);
}

function write(raw, merge = false) {
  const value = sanitize(raw);
  profile = merge ? {
    best: Math.max(profile.best, value.best),
    wave: Math.max(profile.wave, value.wave),
    rewards: {
      like: profile.rewards.like || value.rewards.like,
      comment: profile.rewards.comment || value.rewards.comment
    }
  } : value;
  try { localStorage.setItem(key, JSON.stringify(profile)); } catch {}
  render();
}

adapter = bridge({
  read: () => sanitize(profile),
  write,
  changed: render
});
render();

document.addEventListener("panzercorn:ready", () => {
  awake = true;
  note.textContent = "Tap Start. Hold and aim. Release to fire.";
});
document.addEventListener("panzercorn:start", () => {
  if (active) return;
  active = true;
  note.hidden = true;
  adapter.prepare();
  adapter.start();
  render();
});
document.addEventListener("panzercorn:finish", event => {
  if (!active) return;
  active = false;
  const { score, wave } = event.detail;
  write({ best: score, wave }, true);
  adapter.end();
  adapter.save();
  note.textContent = "Score " + score.toLocaleString("en") + "  ·  Wave " + wave;
  note.hidden = false;
});
addEventListener("pagehide", event => {
  if (!event.persisted) adapter.stop();
});
addEventListener("pageshow", () => adapter.connect());
if (!awake) note.hidden = false;
