HOMER: D'OH! BARBER
Original unofficial fan-made HTML5 barber game. No affiliation with The Simpsons or its owners.

Slide the electric clipper over pink curls. Blue hair is the requested style: avoid it. Accidentally shaved blue curls regrow; there is no game over or timer. Clear every pink tuft to finish. Three donuts hidden in the hair fly into Homer's mouth when uncovered. His nose is boopable, too.

Stars: finish, best continuous cut streak of at least 16 tufts, no more than 2 blue nicks. Best result per customer is saved locally. 3 stars add a donut badge, 6 unlock a gold clipper, 15 unlock a pink salon cape. Six styles repeat up to customer 999: Classic, Mohawk, Sideburns, Crown, Handlebar, Twin Peaks. No payments, accounts, ads, commercial game assets or copied audio.

Touch/mouse: drag to shave. Desktop arrows move the clipper; Space toggles its power. Escape pauses. Restart resets the current haircut. Cancelling a touch or switching away turns the clipper off; finished cuts remain. Reload starts the current unfinished customer again. Storage is optional; blocked storage works for the session. Sound and optional vibration start only after interaction.

Open index.html directly, or upload it to static hosting. Its Three.js and game code are bundled inline for offline use. Editable source is included separately. Three.js r147 MIT license: THREE-LICENSE.txt. All models, procedural curls, scenery, effects and synthesized sounds are original code art. Inspired by the tactile barber interactions in Shave & Stuff (Steam app2195400); this is a small original touch game, not its commercial VR version or assets.

Portrait-first, responsive landscape, device pixel ratio capped at1.5, instanced hair/effects, merged static meshes, bounded130 particles and14 sound voices. WebGL is required; Retry refreshes after context loss. Physical mobile performance varies and must be checked on the intended device.
