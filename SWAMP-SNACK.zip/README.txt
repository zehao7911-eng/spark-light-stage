SHREK: SWAMP SNACK
Original unofficial fan-made HTML5 toy game. No affiliation with DreamWorks.

Drag Shrek's head around the logs and rocks. Eat onions, then let go to snap back and bank them. Bank 3 onions to unlock the golden onion. Collect all 7 to clear the swamp. A knight bonk drops the last unbanked onion; earned onions are always safe. Returning head knocks knights away. No lives, timers or paid systems.

Stars: clear / no bonks / at most 4 stretches. Best stars per swamp saved locally. 6 stars unlock Donkey, 15 unlock a crown. Six layout variants repeat with a changing patrol, up to swamp 999.

Desktop: drag mouse, or arrow keys to extend and Space to retract. Escape pauses. Restart replays the current swamp. Sound is synthesized after interaction. Storage is optional. Pause, interruption and cancelled touch discard unbanked food without making a throw.

Open index.html directly, or upload it to static hosting. The bundled index contains all code and Three.js; no server or external network needed. Source files are included separately for editing. Three.js r147 (MIT): see THREE-LICENSE.txt. All character meshes, scenery, effects and audio are procedurally made for this game. No commercial game assets are bundled.

Phone-oriented portrait layout, landscape support, capped 1.5 device pixel ratio, instanced neck/effects, merged static meshes. Physical device performance varies. WebGL required. Retry reloads if the GPU context is interrupted.
