SQUIDWARD: STACK ATTACK

Open index.html in a WebGL-capable browser, or upload it to static hosting.
The packaged index.html includes every dependency and makes no network requests.

Drag sideways anywhere on the game to guide Squidward's tray. Catch the five
burger layers in order. Once complete, flick upward to throw the burger into
SpongeBob's mouth (the arrow button also serves). Feed three burgers per shift.
The layers physically lag behind the tray: abrupt movements can spill them.
Missed layers return; there are no lives or forced timers. Optional pickles
briefly slow the falling food. Three stars: finish, catch all three pickles,
and finish without misses or spills. Only your best stars per shift count.
Six total stars unlock a chef hat; twelve unlock a wider golden tray.

Eight drop patterns, with increasing falling speed capped at shift eight.
Further shifts reuse these patterns, up to 999; not infinitely unique levels.
Progress, best times, sound preference and the current shift save locally.
Reloading an active shift pauses it. Blocked storage still permits play.
Keyboard: arrows / A,D move, Space serves, Escape pauses. Touch cancel, app
backgrounding and pause release input. Pause freezes game, scene and audio.

Loose gameplay reference: the flexible-limb comedy of Octodad: Dadliest Catch
https://store.steampowered.com/app/224480/Octodad_Dadliest_Catch/
This is an original small catch/stack/serve game, not an Octodad port.
Squidward and SpongeBob belong to Nickelodeon / Paramount. This unofficial
fan game is not affiliated with or endorsed by them. Character references:
https://www.nick.com/info-page/c2e5s0/squidward-j-q-tentacles
https://www.nick.com/info-page/xe31fl/spongebob-squarepants
All character geometry, food, restaurant, layouts and synthesized sounds are
original code. No commercial assets were extracted. No AI images generated.
Three.js r147 is bundled under MIT; see THREE-LICENSE.txt.

Portrait first; landscape supported. 46px buttons, safe-area layout, 1.5 DPR
cap, batched static geometry, instanced food and bounded particles / audio.
WebGL context loss offers Retry. Tested with emulated mobile viewports and
native browser touch events; physical handset performance is not certified.

Source files: engine.js (rules / physics), scene.js (procedural 3D), app.js
(input / UI / save / audio), style.css. The published single HTML is bundled
from the source; keep the source files when editing, then bundle again.
