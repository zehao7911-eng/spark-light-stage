LILY HOP
A little path home.

PLAY
Open index.html in a modern browser, or upload the contents of this ZIP to an HTML5 game platform. Keep all files together in the same folder. No build step, external library, or internet connection is required after downloading.

Tap an island to rotate its bridge. Your frog follows the connected path. Join the entrance to the little house to finish the pond.

REWARDS
Each homecoming earns a star. Solve without hints for another star, and use few turns for the third. Every six stars reveals a garden decoration. There are twelve collectibles and continuing generated puzzles after the collection is complete.

CONTROLS
Tap or click islands. HINT makes one useful turn. RESET restores the current puzzle. The flower button opens your garden collection. The music note toggles sound; sound starts only after an interaction. Progress is saved in this browser when browser storage is available.

MOBILE
Designed for touch, portrait and landscape layouts. All artwork uses Canvas 2D. There are no 3D assets or large downloads.

ONLINE
https://zehao7911-eng.github.io/spark-light-stage/lily-hop.html
