/* NIGHT FREQUENCY — original game model. No third-party engine. */
(function(root){
'use strict';
const names=['Harbor Afterglow','Rooftop Waltz','Velvet Transit','Satellite Tea','Glass Arcade','Midnight Orchard','Paper Moon FM','Rain on Mercury','The Last Broadcast'];
const desc=['A piano above the harbor.','A waltz between the water tanks.','The last train is still running.','A tiny voice from very far away.','An arcade with no closing time.','Something is growing in the static.','A letter without an address.','Rain, a million miles from home.','Nine lights across the sleeping city.'];
const colors=['#e6ad65','#e8827d','#9fc5bf','#a39bc8','#e9bb69','#90b99b','#e7a5c0','#8eb7d9','#ead8a7'];
const melodies=[[0,4,7,12,7,4,2,7],[0,3,7,10,7,3,5,2],[0,7,10,14,12,7,5,3],[0,5,9,12,14,9,5,2],[0,4,9,7,12,9,7,4],[0,3,5,10,7,5,3,0],[0,7,11,14,12,11,7,4],[0,2,7,9,14,9,7,2],[0,4,7,11,14,12,7,4]];
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
function station(i){const n=i%9;return {id:i,name:names[n],description:desc[n],color:colors[n],notes:melodies[n],frequency:18+((i*29+13)%65),gain:35+((i*17+9)%42),phase:20+((i*23+11)%60),filter:i<6?0:1+i%2,seconds:4+Math.min(3,Math.floor(i/3)),base:48+n*2};}
function fresh(){return {version:1,completed:[],parts:0,upgrades:[0,0,0],selected:0,mode:'tune',values:[12,50,50],filter:0,record:0,stability:0,mistakes:0,assist:false,earned:0};}
function restore(raw){const s=fresh();try{const p=JSON.parse(raw);if(p.version!==1)return s; s.completed=Array.from(new Set((p.completed||[]).filter(n=>Number.isInteger(n)&&n>=0&&n<9)));s.parts=clamp(Math.floor(+p.parts||0),0,99999);s.upgrades=s.upgrades.map((_,i)=>clamp(Math.floor(+p.upgrades?.[i]||0),0,3));const max=Math.min(8,s.completed.length);s.selected=clamp(Math.floor(+p.selected||0),0,max);s.values=(p.values||s.values).map((x,i)=>clamp(Number.isFinite(x)?x:s.values[i],0,100)).slice(0,3);if(s.values.length!==3)s.values=[12,50,50];s.filter=clamp(Math.floor(+p.filter||0),0,2);}catch(_){}return s;}
function quality(s){const t=station(s.selected),slack=5+s.upgrades[0]*2;const f=clamp(1-Math.max(0,Math.abs(s.values[0]-t.frequency)-slack)/12,0,1);const g=s.selected<2?1:clamp(1-Math.max(0,Math.abs(s.values[1]-t.gain)-5)/26,0,1);const p=s.selected<4?1:clamp(1-Math.max(0,Math.abs(s.values[2]-t.phase)-5)/28,0,1);const k=s.selected<6||s.filter===t.filter?1:.32;return clamp(f*(.65+.35*g)*(.65+.35*p)*k,0,1);}
function start(s,i){if(!Number.isInteger(i)||i<0||i>Math.min(8,s.completed.length))return false;s.selected=i;s.mode='tune';s.values=[12,50,50];s.filter=0;s.record=0;s.stability=0;s.mistakes=0;s.assist=false;s.earned=0;return true;}
function turn(s,i,v){if(s.mode==='done'||i<0||i>2||!Number.isFinite(v))return false;if((i===1&&s.selected<2)||(i===2&&s.selected<4))return false;s.values[i]=clamp(v,0,100);return true;}
function canRecord(s){return s.mode==='tune'&&quality(s)>=.88&&s.stability>=.7;}
function record(s){if(!canRecord(s))return false;s.mode='record';return true;}
function tick(s,dt){dt=clamp(dt,0,.1);if(s.mode==='done')return null;const q=quality(s);if(q>=.88)s.stability=clamp(s.stability+dt,0,1);else s.stability=Math.max(0,s.stability-dt*2);if(s.mode==='record'){if(q<.80){s.record=Math.max(0,s.record-dt*.2);s.mode='tune';s.mistakes++;return 'lost';}s.record+=dt/(station(s.selected).seconds*(1-.12*s.upgrades[1]));if(s.record>=1){s.record=1;s.mode='done';const first=!s.completed.includes(s.selected);s.earned=first?20+s.selected*5:4;if(first)s.completed.push(s.selected);s.parts+=s.earned;return 'complete';}}return null;}
function cost(s,i){return [20,25,30][i]*(s.upgrades[i]+1);}
function buy(s,i){if(i<0||i>2||s.upgrades[i]>=3||s.parts<cost(s,i))return false;s.parts-=cost(s,i);s.upgrades[i]++;return true;}
function assist(s){if(s.mode==='done')return;s.assist=true;const t=station(s.selected);s.values=[t.frequency,t.gain,t.phase];s.filter=t.filter;}
const baseRestore=restore;function resumeSave(raw){const s=baseRestore(raw);try{const p=JSON.parse(raw);if(p.version===1){s.record=clamp(+p.record||0,0,.99);s.mistakes=clamp(Math.floor(+p.mistakes||0),0,999);s.assist=!!p.assist;if(p.mode==='done'&&s.completed.includes(s.selected)){s.mode='done';s.record=1;}}}catch(_){}return s;}
const api={names,colors,station,fresh,restore:resumeSave,quality,start,turn,canRecord,record,tick,cost,buy,assist};if(typeof module!=='undefined')module.exports=api;root.NightModel=api;
})(typeof window==='undefined'?globalThis:window);
