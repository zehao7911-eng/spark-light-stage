# QA — NIGHT FREQUENCY

## Automated model checks

`node tests.cjs`: 240 assertions passed. Covers all nine stations, gain/phase/filter progression through normal model operations, locked stages, recording conditions, completion rewards granted once, bounded quality, complete-save restoration, upgrade costs and caps, signal loss recovery, disabled dials, invalid input/storage fallback.

New model and app passed Node syntax checks. No package install or external network runtime dependency.

## Browser checks

Actual local native-pointer drag on the first knob moved frequency from 12 to 31.2, raised reception to 100%, enabled recording after lock, and completed the first cassette. Reward dialog gave 20 parts, cassette 02 unlocked, and the first antenna upgrade consumed exactly 20 parts. A native slider change tuned cassette 02 to 100% reception. Recording and pause controls tested. Audio on/off is user-gesture driven; no browser console errors observed during these tests.

Responsive checks target 320×568, 390×844, 844×390 and 1280×720. Portrait is intentionally scrollable; primary receiver and recording controls come before archive/upgrades. All three knobs have native keyboard-operable range alternatives. No physical iOS/Android device certification or audio quality guarantee is implied.

## Scope limits

Nine authored station melodies and names; gain, phase and filter tool introductions. A finite collection loop plus replay and three upgrade lines, not an endless campaign. Original radio campaign plus the ported complete Follow Me memory-game loop for optional Echo calibration; this is not a port of a commercial radio game. Generated workshop background is static scenery, while waves, needle, meter, cassette reels, progression and controls are state-driven. There are no customer characters or simulated city systems.

Echo source port: 221 further model assertions passed across twelve growing sequences, exact computer playback, input lock, score, speed floor, failure/reset. Native browser tested wrong-note recovery and retry. Primary radio browser save/reload retained two collected tapes, first antenna upgrade and current station values. All enabled touch buttons/ranges checked at 320px; landscape header help minimum width corrected to 44px. Browser error/warning log was empty during local checks.
