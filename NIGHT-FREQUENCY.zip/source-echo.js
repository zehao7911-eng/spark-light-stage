/* Port of Follow Me! by Nambiar / Game Dolphin (MIT).
   Upstream Game.js: initBoxes, compPlay, resetFrames, resetGame.
   Adaptation: Phaser timer/sprites replaced with deterministic clock/events;
   all four-choice sequence growth, score, turn lock, reset and speed floor retained. */
(function(root){'use strict';class Echo{
constructor(random=Math.random){this.random=random;this.resetGame();}
pick(){return Math.floor(this.random()*4);}
resetGame(){this.score=0;this.playOrder=[this.pick()];this.compDelay=.9;this.counter=0;this.gameState='idle';this.clock=0;this.cursor=0;this.lit=-1;this.litUntil=0;}
compPlay(){this.gameState='comp';this.clock=0;this.cursor=0;this.counter=0;this.lit=-1;}
tick(dt){this.clock+=Math.max(0,Math.min(dt,.1));if(this.lit>=0&&this.clock>=this.litUntil)this.lit=-1;if(this.gameState==='comp'){if(this.cursor<this.playOrder.length&&this.clock>=this.compDelay*(this.cursor+1)){this.lit=this.playOrder[this.cursor++];this.litUntil=this.clock+.4;return {type:'tone',note:this.lit};}if(this.cursor===this.playOrder.length&&this.clock>=this.compDelay*(this.cursor+1)){this.counter=0;this.gameState='player';return {type:'turn'};}}return null;}
chooseShape(n){if(this.gameState!=='player'||this.lit>=0||!Number.isInteger(n)||n<0||n>3)return null;this.lit=n;this.litUntil=this.clock+.4;if(this.playOrder[this.counter]!==n){this.gameState='lost';return {type:'lost',score:this.score};}this.counter++;if(this.counter>=this.playOrder.length){this.score++;this.playOrder.push(this.pick());this.compDelay=Math.max(.5,this.compDelay-.05);this.gameState='between';return {type:'round',score:this.score};}return {type:'tone',note:n};}
}if(typeof module!=='undefined')module.exports=Echo;root.EchoCalibration=Echo;})(typeof window==='undefined'?globalThis:window);
