mergeInto(LibraryManager.library, {
 SnackState: function(ptr) {if(window.ssState)window.ssState(UTF8ToString(ptr));},
 SnackEvent: function(ptr) {if(window.ssEvent)window.ssEvent(UTF8ToString(ptr));},
 SnackPhoto: function(ptr) {if(window.ssPhoto)window.ssPhoto(UTF8ToString(ptr));}
});
