Shader "Snack/Matte" {
 Properties {_Color("Color",Color)=(1,1,1,1)}
 SubShader { Tags {"RenderType"="Opaque"} LOD 100
 Pass { Tags {"LightMode"="ForwardBase"}
 CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #pragma multi_compile_fwdbase nolightmap nodirlightmap nodynlightmap novertexlight
 #include "UnityCG.cginc"
 #include "Lighting.cginc"
 #include "AutoLight.cginc"
 fixed4 _Color;
 struct v2f {float4 pos:SV_POSITION;float3 normal:TEXCOORD0;float3 world:TEXCOORD1;SHADOW_COORDS(2)};
 v2f vert(appdata_base v){v2f o;o.pos=UnityObjectToClipPos(v.vertex);o.normal=UnityObjectToWorldNormal(v.normal);o.world=mul(unity_ObjectToWorld,v.vertex).xyz;TRANSFER_SHADOW(o);return o;}
 fixed4 frag(v2f i):SV_Target{float3 n=normalize(i.normal);float lit=saturate(dot(n,_WorldSpaceLightPos0.xyz)*.75+.25);float sh=SHADOW_ATTENUATION(i);float ao=lerp(.96,1,saturate(i.world.y*.5));float3 c=_Color.rgb*(.57+.43*lit)*lerp(.72,1,sh)*ao;float rim=pow(1-saturate(dot(n,normalize(_WorldSpaceCameraPos-i.world))),3)*.04;float grain=frac(sin(dot(floor(i.world*38),float3(12.9898,78.233,37.719)))*43758.5453);c*=.975+grain*.05;c+=rim*_Color.rgb;return fixed4(c,1);}
 ENDCG
 }
 UsePass "Legacy Shaders/VertexLit/SHADOWCASTER"
 } FallBack "Diffuse"
}
