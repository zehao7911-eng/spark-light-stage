Shader "Snack/Water" {
 Properties {_Color("Color",Color)=(.22,.66,.66,1)}
 SubShader {Tags {"RenderType"="Opaque"} Pass {
 CGPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #include "UnityCG.cginc"
 float4 _Color;
 struct v2f{float4 pos:SV_POSITION;float3 w:TEXCOORD0;};
 v2f vert(appdata_base v){v2f o;o.pos=UnityObjectToClipPos(v.vertex);o.w=mul(unity_ObjectToWorld,v.vertex).xyz;return o;}
 fixed4 frag(v2f i):SV_Target{float a=sin(i.w.x*2.9+i.w.z*1.7+_Time.y*.8);float b=sin(i.w.z*4.1-i.w.x*.8-_Time.y*.6);float glint=pow(saturate(a*b),12);float3 c=_Color.rgb+sin(i.w.z*.6+i.w.x*.8)*.025+glint*.18;return float4(c,1);}
 ENDCG
 }}
}
