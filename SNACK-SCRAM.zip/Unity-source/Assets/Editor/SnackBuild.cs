using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;
using UnityEditor.Build.Reporting;
using UnityEditor.Build;
using System.IO;
public static class SnackBuild {
 public static void Build(){
  SnackCore.Verify();SnackRoutes.Verify();
  var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);new GameObject("SnackGame").AddComponent<SnackGame>();
  Directory.CreateDirectory("Assets/Scenes");EditorSceneManager.SaveScene(scene,"Assets/Scenes/Harbour.unity");EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene("Assets/Scenes/Harbour.unity",true)};
  PlayerSettings.companyName="Little Trouble Studio";PlayerSettings.productName="Snack & Scram";PlayerSettings.colorSpace=ColorSpace.Gamma;PlayerSettings.runInBackground=false;PlayerSettings.defaultWebScreenWidth=1280;PlayerSettings.defaultWebScreenHeight=800;
  PlayerSettings.WebGL.template="PROJECT:Snack";PlayerSettings.WebGL.compressionFormat=WebGLCompressionFormat.Gzip;PlayerSettings.WebGL.decompressionFallback=true;PlayerSettings.WebGL.exceptionSupport=WebGLExceptionSupport.None;PlayerSettings.WebGL.dataCaching=true;PlayerSettings.WebGL.initialMemorySize=64;PlayerSettings.WebGL.maximumMemorySize=512;
  PlayerSettings.SetManagedStrippingLevel(NamedBuildTarget.WebGL,ManagedStrippingLevel.High);
  PlayerSettings.stripEngineCode=true;PlayerSettings.SplashScreen.show=false;
  string dest=Path.GetFullPath(Path.Combine(Application.dataPath,"../../snack-scram-web"));Directory.CreateDirectory(dest);
  var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions{scenes=new[]{"Assets/Scenes/Harbour.unity"},locationPathName=dest,target=BuildTarget.WebGL,options=BuildOptions.None});
  Debug.Log("SNACK BUILD "+report.summary.result+" bytes "+report.summary.totalSize+" errors "+report.summary.totalErrors);
  if(report.summary.result!=BuildResult.Succeeded)throw new System.Exception("Web build failed");
 }
}
