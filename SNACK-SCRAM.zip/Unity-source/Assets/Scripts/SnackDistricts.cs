using UnityEngine;
using System.Collections.Generic;
using static SnackArt;
public sealed partial class SnackGame {
 void BuildBakeryAlley(Transform p){
  var left=Group("left bakery lane facade",p).transform;left.localPosition=new Vector3(-6.4f,0,.8f);left.localRotation=Quaternion.Euler(0,-90,0);House(left,Vector3.zero,5.5f,"e4c69b","a85f42");
  var right=Group("right pink lane facade",p).transform;right.localPosition=new Vector3(6.4f,0,2.2f);right.localRotation=Quaternion.Euler(0,90,0);House(right,Vector3.zero,4.8f,"d5987e","b9724a");
  var oven=Group("street bakery oven",p).transform;oven.localPosition=new Vector3(-1.7f,0,4.45f);Ball(oven,new Vector3(0,.7f,0),new Vector3(1.6f,1.35f,1.25f),"c78b60","brick oven dome");Ball(oven,new Vector3(0,.48f,-.69f),new Vector3(.85f,.75f,.08f),"423e36","arched oven mouth");Ball(oven,new Vector3(0,.30f,-.74f),new Vector3(.6f,.18f,.07f),"e4a85d","warm embers");Box(oven,new Vector3(0,.15f,-.7f),new Vector3(1.4f,.22f,.5f),"dec093","oven sill");Cyl(oven,new Vector3(0,1.6f,.2f),.22f,1.3f,"b47957","flue");for(int i=0;i<3;i++)Ball(oven,new Vector3((i-1)*.3f,.34f,-.7f),new Vector3(.27f,.18f,.45f),"e0b16d","fresh bread");
  for(int i=0;i<12;i++){float z=-4.7f+i*.8f;Box(p,new Vector3(-4.2f,.08f,z),new Vector3(.20f,.05f,.55f),"b98f68","gutter stone");}
 }
 void AddSea(Transform p,string color){var q=Box(p,new Vector3(0,core.stage==2?-5.6f:-.85f,0),new Vector3(180,.15f,180),color,"open sea");var mat=new Material(Resources.Load<Shader>("SnackWater"));mat.color=Hex(color);q.GetComponent<MeshRenderer>().sharedMaterial=mat;}
 void BuildDistrict(){
  var p=Group(core.stage==1?"cross-canal fish market":"sunset rooftop restaurant").transform;worldRoot=p;boat=null;
  if(core.stage==1){
   sun.color=Hex("fff0cf");sun.intensity=1.08f;AddSea(p,"347f8a");
   // Two real walkable decks separated by a canal. Only two bridges cross it.
   for(int side=-1;side<=1;side+=2){
    Box(p,new Vector3(side*2.95f,-.35f,.4f),new Vector3(4.3f,.7f,12.4f),"8c7051","wharf foundation");
    for(int row=0;row<33;row++)for(int col=0;col<5;col++)Box(p,new Vector3(side*2.95f+(col-2)*.84f,.025f,-5.4f+row*.36f),new Vector3(.81f,.075f,.335f),(row+col)%3==0?"bd9c6c":(row+col)%3==1?"c8ab7b":"aa8a62","weathered quay plank");
    for(int i=0;i<9;i++){Cyl(p,new Vector3(side*4.98f,-.35f,-5+i*1.35f),.15f,1.8f,"795e42","mooring post");if(i<8)Rod(p,new Vector3(side*4.98f,.45f,-5+i*1.35f),new Vector3(side*4.98f,.45f,-5+(i+1)*1.35f),.035f,"b3a47c");}
   }
   foreach(float z in new[]{-1.5f,2.8f}){BridgeArch(p,z);
    for(int i=0;i<8;i++)Box(p,new Vector3(-.9f+i*.26f,.03f,z),new Vector3(.245f,.10f,1.3f),i%2==0?"d1b583":"b89b70","bridge planks");
    for(int side=-1;side<=1;side+=2){for(int i=0;i<4;i++)Rod(p,new Vector3(-.95f+i*.63f,.05f,z+side*.65f),new Vector3(-.95f+i*.63f,.60f,z+side*.65f),.035f,"8d7653");Rod(p,new Vector3(-1.05f,.60f,z+side*.65f),new Vector3(1.05f,.60f,z+side*.65f),.04f,"b5a578");}
   }
   House(p,new Vector3(-2.8f,0,6.9f),3.5f,"b5c4ad","b66b4b");House(p,new Vector3(2.8f,0,7.5f),3.7f,"d9b18b","b76642");
   FishStall(p,new Vector3(-4,0,1.2f),-90);FishStall(p,new Vector3(4,0,1.2f),90);
   var crane=Group("harbour cargo derrick",p).transform;crane.localPosition=new Vector3(4.5f,0,4.7f);Rod(crane,Vector3.zero,new Vector3(0,3.6f,0),.1f,"8c6b47");Rod(crane,new Vector3(0,3.3f,0),new Vector3(-2,3.3f,0),.09f,"98784f");Rod(crane,new Vector3(-2,3.3f,0),new Vector3(-2,1.6f,0),.018f,"b9b599");Box(crane,new Vector3(-2,1.3f,0),new Vector3(.7f,.6f,.7f),"aa8256","suspended cargo");
   for(int i=0;i<4;i++){float z=-4.5f+i*3;Cyl(p,new Vector3(.75f,-.25f,z),.18f,.45f,"e5d9a5","canal buoy");}
   // Boat is small enough to pass under the bridge rail; motion stays in canal.
   boat=Group("canal fishing skiff").transform;boat.position=new Vector3(0,-.56f,.65f);Ball(boat,Vector3.zero,new Vector3(.9f,.43f,1.5f),"517d79","hull");Ball(boat,new Vector3(0,.12f,0),new Vector3(.7f,.12f,1.2f),"e2c899","boat interior");Box(boat,new Vector3(0,.22f,0),new Vector3(.8f,.08f,.18f),"b3976d","rowing seat");Combine(boat);
   for(int i=0;i<5;i++){float x=5.8f+i*.3f;Ball(p,new Vector3(x,-.5f,-3),new Vector3(.2f,.2f,.25f),"b99765","buoy line");}
  }else{
   sun.color=Hex("ffd3a0");sun.intensity=1.12f;AddSea(p,"9b8589");
   Box(p,new Vector3(0,-2.4f,.5f),new Vector3(10.4f,4.8f,12.6f),"c18e7b","roof terrace masonry");
   for(int row=0;row<2;row++)for(int col=0;col<7;col++){float x=-4.2f+col*1.4f,y=-1.3f-row*1.8f;Box(p,new Vector3(x,y,-5.83f),new Vector3(.65f,.95f,.06f),"688d88","lower storey window");Box(p,new Vector3(x,y-.52f,-5.95f),new Vector3(.85f,.08f,.3f),"e0bca0","stone window sill");for(int side=-1;side<=1;side+=2)Box(p,new Vector3(x+side*.43f,y,-5.9f),new Vector3(.15f,1.0f,.08f),"a87164","painted lower shutter");}for(int i=0;i<3;i++)Box(p,new Vector3(0,-.15f-i*1.8f,-5.87f),new Vector3(10.5f,.1f,.2f),"ead0b1","storey cornice");
   for(int x=0;x<17;x++)for(int z=0;z<21;z++){bool alt=(x+z)%2==0;Box(p,new Vector3(-4.8f+x*.6f,.015f,-5.5f+z*.6f),new Vector3(.58f,.05f,.58f),alt?"ccaa91":"b99883","muted chequered stone");if(x%3==0&&z%3==0)Box(p,new Vector3(-4.8f+x*.6f,.043f,-5.5f+z*.6f),new Vector3(.12f,.008f,.12f),"eee0b6","tile inlay");}
   for(int side=-1;side<=1;side+=2){Box(p,new Vector3(side*5,.1f,.4f),new Vector3(.30f,.22f,12.4f),"ead1b5","balustrade base");Box(p,new Vector3(side*5,.85f,.4f),new Vector3(.38f,.14f,12.4f),"ffe1b9","balustrade cap");for(int i=0;i<24;i++){float z=-5.4f+i*.51f;Taper(p,new Vector3(side*5,.2f,z),.10f,.07f,.60f,"ddbea0");}}
   for(int i=0;i<15;i++){Taper(p,new Vector3(-4.6f+i*.66f,.16f,6.5f),.12f,.08f,.65f,"d7b699");}Box(p,new Vector3(0,.85f,6.5f),new Vector3(10.3f,.16f,.4f),"f7d8b0","back parapet");
   Box(p,new Vector3(-4.7f,-4.85f,9.3f),new Vector3(4.9f,1.7f,2.4f),"b49785","neighbouring stone foundation");Box(p,new Vector3(1.4f,-4.4f,10.5f),new Vector3(4.4f,2.6f,2.4f),"b4a28f","lower town foundation");Box(p,new Vector3(6.2f,-4.85f,8.4f),new Vector3(4.2f,1.7f,2.4f),"b89e87","seaside foundation");
   for(int row=0;row<2;row++)for(int col=0;col<7;col++){float z=-4.7f+col*1.6f,y=-1.3f-row*1.8f;Box(p,new Vector3(5.23f,y,z),new Vector3(.06f,.95f,.65f),"688d88","side facade window");Box(p,new Vector3(5.34f,y-.52f,z),new Vector3(.3f,.08f,.85f),"e0bca0","side window sill");for(int side=-1;side<=1;side+=2)Box(p,new Vector3(5.28f,y,z+side*.43f),new Vector3(.08f,1.0f,.15f),"a87164","side painted shutter");}
   House(p,new Vector3(-4.7f,-4,9.3f),4.7f,"dba18b","ac6a59");House(p,new Vector3(1.4f,-3.1f,10.5f),4.2f,"c3b8ac","9f7567");House(p,new Vector3(6.2f,-4,8.4f),4,"e0baa0","bb7c60");
   // Fountain, ivy trellis and string-lit dining pavilion form the skyline.
   obstacles.Add(new Vector4(0,5,1.2f,0));Cyl(p,new Vector3(0,.20f,5.0f),1.05f,.4f,"b69987","fountain basin");Cyl(p,new Vector3(0,.43f,5),.88f,.025f,"739d98","fountain water");Cyl(p,new Vector3(0,.78f,5),.15f,1.0f,"d1b69a","fountain pedestal");Cyl(p,new Vector3(0,1.22f,5),.56f,.10f,"e1c7a5","upper fountain bowl");for(int i=0;i<8;i++){float a=i*Mathf.PI/4;Rod(p,new Vector3(Mathf.Sin(a)*.5f,1.22f,5+Mathf.Cos(a)*.5f),new Vector3(Mathf.Sin(a)*.75f,.48f,5+Mathf.Cos(a)*.75f),.015f,"b7d8c1");}
   for(int side=-1;side<=1;side+=2){Rod(p,new Vector3(side*4,0,4.0f),new Vector3(side*4,3.1f,4),.075f,"906e59");for(int i=0;i<12;i++)Leaf(p,new Vector3(side*4,1+i*.17f,4),.45f,"648362",i*47);}
   Rod(p,new Vector3(-4,3.1f,4),new Vector3(4,3.1f,4),.015f,"8f7a67");for(int i=0;i<15;i++){float x=-3.7f+i*.53f,y=3.1f-Mathf.Sin(i*Mathf.PI/14)*.45f;Rod(p,new Vector3(x,y,4),new Vector3(x,y-.14f,4),.012f,"907b62");Ball(p,new Vector3(x,y-.20f,4),Vector3.one*.14f,"ffe6a1","festoon bulb");}
   for(int side=-1;side<=1;side+=2){Pot(p,new Vector3(side*4.2f,0,-3.7f),1.1f);Pot(p,new Vector3(side*4.2f,0,4.5f),1.2f);}
   SmallTable(p,new Vector3(3.6f,0,-2.6f),.55f);SmallTable(p,new Vector3(-3.5f,0,3.65f),.55f);
  }
  foreach(var spot in mealSpots)ServingTable(p,spot);
  if(core.stage==1){Lamp(p,new Vector3(4.5f,0,-3.8f));Lamp(p,new Vector3(-4.5f,0,3.8f));}
  Combine(p);if(boat)boat.SetParent(p,true);
  refuge=Bush(null,bushPos,.93f).transform;refuge.SetParent(p,true);for(int i=0;i<4;i++)Flower(refuge,new Vector3((i-1.5f)*.3f,.8f,.12f),.42f,"f5dcaf");
  var ground=Group("district collision floor",p);var c=ground.AddComponent<BoxCollider>();c.center=new Vector3(0,-.18f,.5f);c.size=new Vector3(10.4f,.35f,13);
 }

 void BridgeArch(Transform p,float z){
  foreach(int side in new[]{-1,1}){var mesh=new Mesh{name="SnackTransient"};var v=new List<Vector3>();var t=new List<int>();for(int i=0;i<12;i++){float x0=-1.0f+i/6f,x1=x0+1/6f;float y0=-.9f+Mathf.Sqrt(Mathf.Max(0,1-x0*x0))*.66f,y1=-.9f+Mathf.Sqrt(Mathf.Max(0,1-x1*x1))*.66f;int n=v.Count;v.Add(new Vector3(x0,-.055f,z+side*.62f));v.Add(new Vector3(x1,-.055f,z+side*.62f));v.Add(new Vector3(x0,y0,z+side*.62f));v.Add(new Vector3(x1,y1,z+side*.62f));if(side<0)t.AddRange(new[]{n,n+1,n+2,n+1,n+3,n+2});else t.AddRange(new[]{n,n+2,n+1,n+1,n+2,n+3});}mesh.SetVertices(v);mesh.SetTriangles(t,0);mesh.RecalculateNormals();var g=Group("stone arch below footbridge",p);g.AddComponent<MeshFilter>().sharedMesh=mesh;g.AddComponent<MeshRenderer>().sharedMaterial=Mat("d2b990");}
 }
 void FishStall(Transform p,Vector3 pos,float yaw){var g=Group("green striped fishmonger",p).transform;g.localPosition=pos;g.localEulerAngles=new Vector3(0,yaw,0);Box(g,new Vector3(0,.65f,0),new Vector3(2.7f,.22f,.85f),"7b927d","fish counter");Box(g,new Vector3(0,.8f,0),new Vector3(2.6f,.06f,.8f),"c8d1b2","bed of ice");for(int i=0;i<6;i++){float x=(i-2.5f)*.38f;Ball(g,new Vector3(x,.92f,0),new Vector3(.25f,.16f,.52f),i%2==0?"729e9e":"9cb6a6","fresh fish");var tail=Box(g,new Vector3(x,.93f,.29f),new Vector3(.25f,.04f,.20f),"7e9f98","fish tail");tail.transform.localEulerAngles=new Vector3(0,45,0);Ball(g,new Vector3(x+.1f,.97f,-.15f),Vector3.one*.04f,"394f50","fish eye");}for(int side=-1;side<=1;side+=2)Rod(g,new Vector3(side*1.2f,0,.2f),new Vector3(side*1.2f,2.3f,.2f),.04f,"836d4a");for(int i=0;i<10;i++){var aw=Box(g,new Vector3((i-4.5f)*.29f,2.25f,-.15f),new Vector3(.29f,.08f,1.3f),i%2==0?"537f70":"f2d9a5","striped fish canopy");aw.transform.localEulerAngles=new Vector3(-10,0,0);}}
}
