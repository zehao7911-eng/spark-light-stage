using UnityEngine;
using System;
using static SnackArt;
public sealed class SnackInteractionState {
 public bool used,pending;public float effect,age;public int bonus;readonly bool[] picked=new bool[6];
 public void Reset(){used=false;pending=false;effect=age=0;bonus=0;Array.Clear(picked,0,6);}
 public bool Activate(int stage){if(used)return false;used=true;pending=false;age=0;effect=stage==0?3.8f:stage==1?8f:6.5f;return true;}
 public void Tick(float dt,bool paused){if(paused)return;if(used)age+=dt;effect=Mathf.Max(0,effect-dt);}
 public bool Pick(int index){if(index<0||index>=6||picked[index]||!used)return false;picked[index]=true;bonus++;return true;}
 public static void Verify(){var s=new SnackInteractionState();s.Reset();if(!s.Activate(1)||s.Activate(1))throw new Exception("interaction once");s.Tick(2,true);if(s.effect!=8f)throw new Exception("interaction pause");for(int i=0;i<6;i++){if(!s.Pick(i)||s.Pick(i))throw new Exception("bonus duplicate");}s.Tick(9,false);if(s.effect!=0||s.bonus!=6)throw new Exception("effect lifetime");s.Reset();if(s.used||s.bonus!=0||!s.Activate(2))throw new Exception("interaction retry");}
}
public static class SnackRoutes {
 public static Vector3 Goal(int stage,Vector3 from,Vector3 target){if(stage!=1||((from.x*target.x>=0)&&Mathf.Abs(from.x)>.84f))return target;float a=-1.5f,b=2.8f;float z=Mathf.Abs(from.z-a)+Mathf.Abs(target.z-a)<=Mathf.Abs(from.z-b)+Mathf.Abs(target.z-b)?a:b;float side=target.x<0?-1:1;if(Mathf.Abs(from.x)>.85f&&Mathf.Abs(from.z-z)>.18f)return new Vector3(Mathf.Sign(from.x)*1.03f,from.y,z);return new Vector3(side*1.04f,from.y,z);}
 public static Vector3 Target(int stage,Vector3 from,Vector3 target){if(stage==1&&Water(target))target.x=from.x<0?-1.02f:1.02f;return target;}
 public static bool Water(Vector3 p){return Mathf.Abs(p.x)<.80f&&Mathf.Abs(p.z+1.5f)>.57f&&Mathf.Abs(p.z-2.8f)>.57f;}
 public static Vector3 Constrain(int stage,Vector3 from,Vector3 next){if(stage!=1||!Water(next))return next;var slide=new Vector3(from.x,next.y,next.z);if(!Water(slide))return slide;slide=new Vector3(next.x,next.y,from.z);return Water(slide)?from:slide;}
 public static void Verify(){Vector3[] starts={new Vector3(2.25f,0,-1.2f),new Vector3(-3,0,3.3f),new Vector3(-2.1f,0,2.1f),new Vector3(3,0,4)};Vector3[] ends={new Vector3(-1.1f,0,1.4f),new Vector3(2,0,-1),new Vector3(3,0,-3),new Vector3(-3,0,4)};for(int i=0;i<starts.Length;i++){var p=starts[i];for(int j=0;j<1800&&Vector3.Distance(p,ends[i])>.12f;j++){var d=Goal(1,p,ends[i])-p;d.y=0;var n=Constrain(1,p,p+Vector3.ClampMagnitude(d,.065f));if(Water(n))throw new Exception("canal water");p=n;}if(Vector3.Distance(p,ends[i])>.13f)throw new Exception("bridge route "+i);}if(Water(Target(1,new Vector3(2,0,0),Vector3.zero)))throw new Exception("water tap snap");SnackInteractionState.Verify();Debug.Log("DISTRICT QA PASS: four bidirectional bridge routes, no water walking, one-shot interaction, pause, unique bonuses and retry");}
}
public sealed partial class SnackGame {
 readonly SnackInteractionState interaction=new SnackInteractionState();Vector3 interactionPos;Transform toy,toyHandle;Transform[] flourCloud=new Transform[10],bonusFruit=new Transform[6];bool[] fruitTaken=new bool[6];Transform[] musicRings=new Transform[3];
 bool GuardsStopped=>interaction.effect>0&&core.stage==0;
 bool GuardsSafe=>interaction.effect>0;
 Vector3 RouteGoal(Vector3 from,Vector3 target)=>SnackRoutes.Goal(core.stage,from,target);
 Vector3 ConstrainDistrict(Vector3 from,Vector3 next)=>SnackRoutes.Constrain(core.stage,from,next);
 Vector3 GuardGoal(Vector3 chase){if(interaction.effect>0&&core.stage>0)return core.stage==1?new Vector3(Mathf.Lerp(1.3f,-3,Mathf.Clamp01(interaction.age/1.3f)),0,-1.5f):interactionPos;return chase;}
 void BuildInteraction(Transform p){
  interactionPos=core.stage==0?new Vector3(2.1f,0,.45f):core.stage==1?new Vector3(1.5f,0,-1.5f):new Vector3(-2.45f,0,.4f);
  toy=Group(core.stage==0?"puffable flour sack":core.stage==1?"rollable fish barrel":"dance party gramophone",p).transform;toy.position=interactionPos;
  if(core.stage==0){Ball(toy,new Vector3(0,.35f,0),new Vector3(.7f,.8f,.65f),"e9d3a5","flour sack");Cyl(toy,new Vector3(0,.78f,0),.22f,.14f,"d1b78d","tied sack mouth");Box(toy,new Vector3(0,.4f,-.32f),new Vector3(.28f,.29f,.035f),"ab7952","wheat label");for(int i=0;i<3;i++)Rod(toy,new Vector3((i-1)*.06f,.27f,-.35f),new Vector3((i-1)*.06f,.52f,-.35f),.01f,"f0dfbb");}
  if(core.stage==1){var b=Group("barrel shell",toy).transform;b.localEulerAngles=new Vector3(0,0,90);Ball(b,new Vector3(0,.4f,0),new Vector3(.8f,1,.8f),"a87d51","bulging barrel");for(int i=0;i<3;i++)Cyl(b,new Vector3(0,.05f+i*.35f,0),.41f,.065f,"526d66","iron hoop");for(int i=0;i<10;i++){float a=i*Mathf.PI*.2f;Rod(b,new Vector3(Mathf.Cos(a)*.39f,.05f,Mathf.Sin(a)*.39f),new Vector3(Mathf.Cos(a)*.39f,.75f,Mathf.Sin(a)*.39f),.013f,"d0a16a");}b.localPosition=new Vector3(0,0,-.4f);}
  if(core.stage==2){Box(toy,new Vector3(0,.42f,0),new Vector3(.8f,.8f,.7f),"9e7252","gramophone cabinet");Cyl(toy,new Vector3(0,.85f,0),.32f,.05f,"424947","record player");toyHandle=Group("spinning vinyl",toy).transform;toyHandle.localPosition=new Vector3(0,.9f,0);Cyl(toyHandle,Vector3.zero,.27f,.035f,"344744","vinyl");Cyl(toyHandle,Vector3.up*.022f,.08f,.012f,"d4925c","record label");Rod(toy,new Vector3(.25f,.9f,.2f),new Vector3(.25f,1.35f,.2f),.04f,"c09a5e");var horn=Taper(toy,new Vector3(.25f,1.32f,.2f),.06f,.34f,.6f,"d6ad62");horn.transform.localRotation=Quaternion.Euler(-65,0,-25);var lip=Cyl(toy,horn.transform.localPosition+horn.transform.localRotation*(Vector3.up*.605f),.29f,.012f,"786343","open horn throat");lip.transform.localRotation=horn.transform.localRotation;}
  // All interactive geometry remains separate from the static district batches.
  if(core.stage!=2)Combine(toy);else{foreach(var child in new[]{toyHandle})Combine(child);}
  for(int i=0;i<3;i++){musicRings[i]=Ring(p,interactionPos+Vector3.up*.07f,.5f,.025f,"f9d58c");musicRings[i].gameObject.SetActive(false);}
  for(int i=0;i<10;i++){flourCloud[i]=Ball(p,new Vector3(0,-10,0),Vector3.one,"fff0d2","flour puff").transform;flourCloud[i].GetComponent<MeshRenderer>().sharedMaterial=Mist();flourCloud[i].gameObject.SetActive(false);}
  for(int i=0;i<6;i++){bonusFruit[i]=Ball(p,new Vector3(0,-10,0),Vector3.one*.22f,"edab42","rolling orange bonus").transform;Leaf(bonusFruit[i],new Vector3(0,.12f,0),.14f,"6c8c4e",i*30);bonusFruit[i].gameObject.SetActive(false);}
 }
 static Material mistMaterial;Material Mist(){if(!mistMaterial){mistMaterial=new Material(Resources.Load<Shader>("SnackMist"));mistMaterial.color=Hex("fff0d2");}return mistMaterial;}
 void ResetInteraction(){interaction.Reset();for(int i=0;i<6;i++){fruitTaken[i]=false;if(bonusFruit[i])bonusFruit[i].gameObject.SetActive(false);}foreach(var c in flourCloud)if(c)c.gameObject.SetActive(false);if(toy){toy.position=interactionPos+(core.stage==1?Vector3.up*.43f:Vector3.zero);toy.localRotation=Quaternion.identity;toy.localScale=Vector3.one;}}
 void BeginInteraction(){if(core.paused||core.phase>=2||interaction.used)return;interaction.pending=true;autoMove=true;axis=Vector2.zero;Vector3 d=player-interactionPos;d.y=0;autoTarget=interactionPos+(d.sqrMagnitude<.01f?Vector3.forward:d.normalized)*.9f;core.started=true;Tell(new[]{"Flour power!","Roll the barrel!","Start the music!"}[core.stage],"ready");}
 void UpdateInteraction(float dt){interaction.Tick(dt,false);if(core.phase>=2)return;if(interaction.pending&&Vector3.Distance(player,interactionPos)<1.15f){interaction.Activate(core.stage);autoMove=false;axis=Vector2.zero;Burst(interactionPos+Vector3.up*.8f,18);Tell(new[]{"Achoo! Run!","Fish parade!","Dance break!"}[core.stage],new[]{"poof","roll","music"}[core.stage]);}
  if(core.stage==1&&interaction.used){for(int i=0;i<6;i++)if(!fruitTaken[i]&&interaction.age>i*.11f&&Vector3.Distance(player,FruitPos(i))<.73f&&interaction.Pick(i)){fruitTaken[i]=true;core.score+=8;Burst(FruitPos(i)+Vector3.up*.3f,5);Tell("+8","bonus");}}
 }
 Vector3 FruitPos(int i)=>new Vector3(.85f-i*.61f,.18f,-1.5f+(i%2==0?.13f:-.13f));
 void AnimateDistrict(float dt){
  if(toy&&interaction.used){if(core.stage==0){toy.localScale=new Vector3(1.17f,.70f,1.17f);for(int i=0;i<10;i++){var c=flourCloud[i];bool alive=interaction.age<3.8f;c.gameObject.SetActive(alive);if(alive){float t=interaction.age,a=i*2.4f;c.position=interactionPos+new Vector3(Mathf.Cos(a)*(.2f+t*.3f),.3f+t*.2f+i*.035f,Mathf.Sin(a)*(.2f+t*.3f));c.localScale=Vector3.one*(.45f+t*.25f)*Mathf.Clamp01((3.8f-t)*2);}}}else if(core.stage==1){float t=Mathf.Clamp01(interaction.age/1.3f);toy.position=new Vector3(Mathf.Lerp(1.3f,-3,t),.43f,-1.5f);toy.localEulerAngles=new Vector3(0,0,-t*540);for(int i=0;i<6;i++){bonusFruit[i].gameObject.SetActive(!fruitTaken[i]&&interaction.age>i*.11f);bonusFruit[i].position=FruitPos(i)+Vector3.up*Mathf.Abs(Mathf.Sin(Mathf.Min(1,interaction.age-i*.11f)*7))*.13f;}}else if(interaction.effect>0){toyHandle.Rotate(0,dt*400,0);toy.localRotation=Quaternion.Euler(0,0,Mathf.Sin(clock*9)*3);}}
  for(int i=0;i<3;i++){var r=musicRings[i];r.gameObject.SetActive(core.stage==2&&interaction.effect>0);if(r.gameObject.activeSelf){float wave=Mathf.Repeat(interaction.age*.7f+i*.33f,1);r.localScale=Vector3.one*(.8f+wave*4);}}if(core.stage==0&&interaction.effect>0){dog.head.localRotation=Quaternion.Euler(15+Mathf.Sin(clock*15)*10,Mathf.Sin(clock*11)*14,0);}
  if(core.stage==2&&interaction.effect>0){dog.body.localRotation=Quaternion.Euler(0,0,Mathf.Sin(clock*10)*12);dog.leftArm.localRotation=Quaternion.Euler(-65,0,25);dog.rightArm.localRotation=Quaternion.Euler(-65,0,-25);}else dog.body.localRotation=Quaternion.identity;
 }
}
