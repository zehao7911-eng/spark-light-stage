using UnityEngine;
using static SnackArt;
public sealed class SnackCharacter {
 public Transform root,body,head,leftLeg,rightLeg,leftArm,rightArm,mouth,cheekL,cheekR,eyes,alert,chefHat;
 Transform[] tail;bool dog;Vector3 headBase;float seed;
 public SnackCharacter(string name,Vector3 pos,bool isDog=false){
  dog=isDog;seed=isDog?2:0;root=Group(name).transform;root.position=pos;
  body=Group("breathing body",root).transform;body.localPosition=new Vector3(0,.5f,0);
  Ball(body,Vector3.zero,new Vector3(.72f,.8f,.68f),dog?"4e8582":"8f9190","round belly");Ball(body,new Vector3(0,.0f,.25f),new Vector3(.5f,.59f,.23f),dog?"e4be87":"eee5d0","soft bib");
  if(dog){for(int i=0;i<3;i++)Ball(body,new Vector3(.03f,.18f-i*.15f,.36f),Vector3.one*.055f,"d9ae62","uniform button");Box(body,new Vector3(0,-.18f,.29f),new Vector3(.7f,.08f,.08f),"51565b","belt");}
  Combine(body);
  head=Group("expressive head",root).transform;headBase=new Vector3(0,.91f,.18f);head.localPosition=headBase;
  Ball(head,Vector3.zero,new Vector3(dog?.71f:.65f,.56f,.65f),dog?"bd9567":"d7d4c5","face");
  for(int side=-1;side<=1;side+=2){var ear=Ball(head,new Vector3(side*.29f,dog?.10f:.23f,.01f),new Vector3(.24f,dog?.36f:.31f,.12f),dog?"806650":"777b7d","ear");ear.transform.localEulerAngles=new Vector3(0,0,side*(dog?15:28));if(!dog)Ball(head,new Vector3(side*.29f,.25f,.065f),new Vector3(.15f,.21f,.045f),"d59b9a","pink ear");}
  var snout=Taper(head,new Vector3(0,-.13f,.2f),dog?.22f:.2f,dog?.17f:.10f,dog?.25f:.34f,dog?"e6d1a5":"ede2c6");snout.transform.localRotation=Quaternion.Euler(90,0,0);
  Ball(head,new Vector3(0,-.08f,dog?.49f:.55f),new Vector3(dog?.24f:.17f,.14f,.12f),"444f54","shiny nose");Ball(head,new Vector3(-.025f,-.04f,dog?.54f:.60f),Vector3.one*.035f,"929d9c","nose glint");
  if(dog){Cyl(head,new Vector3(0,.27f,0),.34f,.16f,"3f7477","patrol cap");var brim=Ball(head,new Vector3(0,.22f,.28f),new Vector3(.72f,.08f,.36f),"355c64","cap brim");Ball(head,new Vector3(0,.3f,.3f),new Vector3(.1f,.12f,.035f),"e7bd68","cap badge");}
  Combine(head);
  eyes=Group("blinking eyes",head).transform;
  for(int side=-1;side<=1;side+=2){Ball(eyes,new Vector3(side*.205f,.065f,.29f),new Vector3(.16f,.20f,.12f),"f6efd8","eye white");Ball(eyes,new Vector3(side*.205f,.055f,.35f),new Vector3(.088f,.125f,.06f),"374852","bright pupil");Ball(eyes,new Vector3(side*.19f,.087f,.38f),Vector3.one*.036f,"ffffff","eye catchlight");var brow=Box(eyes,new Vector3(side*.21f,.20f,.32f),new Vector3(.17f,.03f,.03f),"656766","brow");brow.transform.localEulerAngles=new Vector3(0,0,side*-13);}
  Combine(eyes);
  mouth=Ball(head,new Vector3(0,-.19f,.43f),new Vector3(.17f,.055f,.07f),"57494b","hungry mouth").transform;
  cheekL=Ball(head,new Vector3(-.235f,-.09f,.25f),new Vector3(.17f,.16f,.22f),"d4c4af","cheek").transform;
  cheekR=Ball(head,new Vector3(.235f,-.09f,.25f),new Vector3(.17f,.16f,.22f),"d4c4af","cheek").transform;
  leftLeg=Limb(-1,false);rightLeg=Limb(1,false);leftArm=Limb(-1,true);rightArm=Limb(1,true);
  if(!dog){tail=new Transform[9];var p=root;for(int i=0;i<tail.Length;i++){tail[i]=Group("jointed pink tail",p).transform;tail[i].localPosition=i==0?new Vector3(0,.28f,-.31f):new Vector3(0,0,-.18f);var q=Ball(tail[i],new Vector3(0,0,-.09f),new Vector3(.14f-i*.012f,.14f-i*.012f,.24f),i%3==0?"c99995":"d8ada4","tail segment");p=tail[i];}}
  chefHat=Group("earned little chef hat",head).transform;chefHat.localPosition=new Vector3(0,.32f,0);Cyl(chefHat,Vector3.zero,.22f,.13f,"f3e6c4","toque band");for(int i=0;i<3;i++)Ball(chefHat,new Vector3((i-1)*.14f,.13f,0),new Vector3(.27f,.28f,.28f),"fff0d1","toque puff");Combine(chefHat);chefHat.gameObject.SetActive(false);
  alert=Group("surprise",root).transform;alert.localPosition=new Vector3(0,1.65f,0);Box(alert,new Vector3(0,.13f,0),new Vector3(.105f,.36f,.075f),"e5a15f","exclamation");Ball(alert,new Vector3(0,-.14f,0),Vector3.one*.11f,"e5a15f","exclamation dot");alert.gameObject.SetActive(false);
 }
 Transform Limb(int side,bool arm){var q=Group(arm?"little arm":"little boot",root).transform;q.localPosition=new Vector3(side*(arm?.36f:.22f),arm?.58f:.22f,arm?.15f:.03f);Ball(q,Vector3.zero,new Vector3(arm?.17f:.22f,arm?.32f:.3f,arm?.2f:.25f),dog?"477d7a":"818787");Ball(q,new Vector3(0,-.13f,.1f),new Vector3(.22f,.13f,.30f),dog?"846950":"606c70","soft paw");for(int i=0;i<3;i++)Ball(q,new Vector3((i-1)*.055f,-.13f,.23f),Vector3.one*.065f,dog?"d2ad81":"d6bab0","toe");Combine(q);return q;}
 public void Animate(float t,float speed,float eat,float belly,bool asleep,bool hidden,bool excited,Camera cam){
  float step=Mathf.Sin(t*12+seed)*Mathf.Clamp01(speed*2);body.localScale=new Vector3(1+belly*.13f,1+Mathf.Sin(t*3)*.016f,1+belly*.10f);body.localPosition=new Vector3(0,.5f+Mathf.Abs(step)*.035f,0);
  leftLeg.localRotation=Quaternion.Euler(step*32,0,0);rightLeg.localRotation=Quaternion.Euler(-step*32,0,0);leftArm.localRotation=Quaternion.Euler(-step*24-eat*45,0,-eat*20);rightArm.localRotation=Quaternion.Euler(step*24-eat*45,0,eat*20);
  head.localPosition=headBase+Vector3.up*(Mathf.Abs(step)*.04f+Mathf.Sin(t*3)*.009f);head.localRotation=Quaternion.Euler(asleep?18:Mathf.Sin(t*8)*eat*8,Mathf.Sin(t*.5f)*4,Mathf.Sin(t*12)*eat*5);
  float blink=asleep?.12f:(Mathf.Sin(t*1.4f+seed)> .985f?.12f:1f);eyes.localScale=new Vector3(1,blink,1);mouth.localScale=new Vector3(.17f+eat*.10f,.055f+eat*.18f,.07f);cheekL.localScale=new Vector3(.17f+eat*.08f,.16f+eat*.06f,.22f);cheekR.localScale=cheekL.localScale;
  if(tail!=null)for(int i=0;i<tail.Length;i++)tail[i].localRotation=Quaternion.Euler(Mathf.Sin(t*3+i*.5f)*4,Mathf.Sin(t*3-i*.45f)*(7+speed*8),0);
  alert.gameObject.SetActive(excited);if(excited){alert.rotation=cam.transform.rotation;alert.localScale=Vector3.one*(1+Mathf.Sin(t*8)*.08f);}
  root.localScale=Vector3.one*(hidden?.87f:1);
 }
}
