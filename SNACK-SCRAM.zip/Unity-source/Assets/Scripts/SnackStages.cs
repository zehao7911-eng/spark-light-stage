using UnityEngine;
using System.Collections.Generic;
using static SnackArt;
public sealed partial class SnackGame {
 Transform worldRoot,hideRing,alarmRing;SnackCharacter extraDog;Vector3 extraGuard;int builtStage=-1,mealIndex;float dashTime,dashCooldown,barkClock,dustClock;
 Vector3[] mealSpots;readonly string[] stageNames={"Bakery Alley","Harbour Hustle","Sunset Soiree"};
 struct FlyingBite {public Transform tr;public Vector3 from;public float age;}
 List<FlyingBite> flying=new List<FlyingBite>();
 void PrepareStage(){
  foreach(var f in flying)if(f.tr)Destroy(f.tr.gameObject);flying.Clear();mealIndex=0;dashTime=0;dashCooldown=0;barkClock=0;dustClock=0;
  if(builtStage!=core.stage){
   if(worldRoot){DisposeMeshes(worldRoot);Destroy(worldRoot.gameObject);}if(extraDog!=null){DisposeMeshes(extraDog.root);Destroy(extraDog.root.gameObject);extraDog=null;}
   obstacles.Clear();furniture.Clear();chairHome.Clear();chairRot.Clear();
   mealSpots=core.stage==0?new[]{new Vector3(0,0,-.6f)}:core.stage==1?new[]{new Vector3(2.25f,0,-2.4f),new Vector3(-2.1f,0,2.15f)}:new[]{new Vector3(-1.5f,0,-2.2f),new Vector3(1.6f,0,.2f),new Vector3(-1.2f,0,2.55f)};
   cakePos=mealSpots[0];bushPos=core.stage==0?new Vector3(-2.45f,0,1.45f):core.stage==1?new Vector3(-3.5f,0,3.8f):new Vector3(2.85f,0,3.35f);
   guardHome=core.stage==0?new Vector3(2.5f,0,2.8f):core.stage==1?new Vector3(2.2f,0,2.6f):new Vector3(3.25f,0,2.3f);
   BuildWorld();BuildInteraction(worldRoot);hideRing=Ring(worldRoot,bushPos+Vector3.up*.085f,.87f,.055f,"f8e1a0");alarmRing=Ring(worldRoot,guardHome+Vector3.up*.08f,.6f,.045f,"dc7254");
   if(core.stage==2)extraDog=new SnackCharacter("Inspector Biscuit",new Vector3(-3.2f,0,2.7f),true);
   builtStage=core.stage;
  }
  cakePos=mealSpots[0];extraGuard=new Vector3(-3.2f,0,2.7f);if(extraDog!=null)extraDog.root.position=extraGuard;
 }
 void DisposeMeshes(Transform root){var seen=new HashSet<Mesh>();foreach(var mf in root.GetComponentsInChildren<MeshFilter>()){var m=mf.sharedMesh;if(m&&(m.name=="SnackBatch"||m.name=="SnackTransient")&&seen.Add(m))Destroy(m);}}
 void ServingTable(Transform p,Vector3 pos){
  Cyl(p,pos+Vector3.up*.45f,.91f,.12f,"e4bf85","meal table");Cyl(p,pos+Vector3.up*.25f,.12f,.45f,"427d76","table pedestal");Cyl(p,pos+Vector3.up*.04f,.47f,.08f,"427d76","table foot");Cyl(p,pos+Vector3.up*.54f,.8f,.045f,"fff0cf","ceramic plate");Cyl(p,pos+Vector3.up*.565f,.73f,.018f,"d3ae6b","gold plate rim");obstacles.Add(new Vector4(pos.x,pos.z,1.17f,0));
 }
 Transform Ring(Transform p,Vector3 pos,float radius,float thickness,string color){
  var g=Group("painted feedback ring",p);g.transform.position=pos;var mesh=new Mesh{name="SnackTransient"};var verts=new List<Vector3>();var tris=new List<int>();for(int i=0;i<=48;i++){float a=i*Mathf.PI*2/48;verts.Add(new Vector3(Mathf.Cos(a)*radius,0,Mathf.Sin(a)*radius));verts.Add(new Vector3(Mathf.Cos(a)*(radius+thickness),0,Mathf.Sin(a)*(radius+thickness)));if(i<48){int k=i*2;tris.AddRange(new[]{k,k+2,k+1,k+1,k+2,k+3});}}mesh.SetVertices(verts);mesh.SetTriangles(tris,0);mesh.RecalculateNormals();g.AddComponent<MeshFilter>().sharedMesh=mesh;g.AddComponent<MeshRenderer>().sharedMaterial=Mat(color);return g.transform;
 }
 void UpdateRings(float dt){
  hideRing.gameObject.SetActive(core.phase==1);hideRing.localScale=Vector3.one*(1+Mathf.Sin(clock*5)*.055f);hideRing.Rotate(Vector3.up*dt*35);
  alarmRing.gameObject.SetActive(core.guardPhase>0&&core.phase<2&&!GuardsSafe);alarmRing.position=guard+Vector3.up*.08f;alarmRing.localScale=Vector3.one*(1+Mathf.Sin(clock*9)*.15f);
 }
 void FlyBite(Transform piece){piece.SetParent(null,true);flying.Add(new FlyingBite{tr=piece,from=piece.position,age=0});}
 void AnimateBites(float dt){for(int i=flying.Count-1;i>=0;i--){var f=flying[i];if(!f.tr){flying.RemoveAt(i);continue;}f.age+=dt;float t=Mathf.Clamp01(f.age/.26f);f.tr.position=Vector3.Lerp(f.from,player+hero.root.forward*.4f+Vector3.up*.93f,t)+Vector3.up*Mathf.Sin(t*Mathf.PI)*.5f;f.tr.localScale=Vector3.one*(1-t*.92f);f.tr.Rotate(0,dt*180,dt*90);if(t>=1){DisposeMeshes(f.tr);Destroy(f.tr.gameObject);flying.RemoveAt(i);}else flying[i]=f;}}
 void Dust(Vector3 pos,int count){for(int j=0;j<count;j++){int i=fxNext++%fx.Length;var f=fx[i];f.pos=pos+new Vector3(Rand(-.25f,.25f),.09f,Rand(-.25f,.25f));f.vel=new Vector3(Rand(-.3f,.3f),Rand(.3f,.7f),Rand(-.3f,.3f));f.spin=Vector3.zero;f.life=f.max=.38f;f.scale=Rand(.12f,.24f);f.tr.localScale=Vector3.one*f.scale;f.tr.gameObject.SetActive(true);fx[i]=f;}}
 void UpdateSecondGuard(float dt){if(extraDog==null)return;float speed=0;if(core.guardPhase==2){Vector3 target=GuardGoal(hidden?lastSeen:player);var d=RouteGoal(extraGuard,target)-extraGuard;d.y=0;if(d.magnitude>.7f&&!GuardsStopped){speed=2.03f;var n=extraGuard+d.normalized*speed*dt;foreach(var ob in obstacles){var q=new Vector3(n.x-ob.x,0,n.z-ob.y);if(q.magnitude<ob.z+.1f&&q.magnitude>.001f){q=q.normalized*(ob.z+.1f);n.x=ob.x+q.x;n.z=ob.y+q.z;}}extraGuard=ConstrainDistrict(extraGuard,n);}if(d.sqrMagnitude>.01f)extraDog.root.rotation=Quaternion.Slerp(extraDog.root.rotation,Quaternion.LookRotation(d),dt*7);}extraDog.root.position=extraGuard;extraDog.Animate(clock+.7f,speed,0,0,core.guardPhase==0,false,core.guardPhase>0&&!GuardsSafe,cam);if(core.stage==2&&interaction.effect>0){extraDog.body.localRotation=Quaternion.Euler(0,0,Mathf.Sin(clock*10)*12);extraDog.leftArm.localRotation=Quaternion.Euler(-65,0,25);extraDog.rightArm.localRotation=Quaternion.Euler(-65,0,-25);}else extraDog.body.localRotation=Quaternion.identity;}
 void StageDecor(Transform p){
  // Layered backstreet silhouettes, balconies, vines, baked-in signs and produce.
  House(p,new Vector3(-6.0f,-.25f,9.8f),3.5f,"dfa274","a65338");House(p,new Vector3(1.0f,.1f,10.4f),3.5f,"e8c18c","b76542");House(p,new Vector3(5.4f,-.2f,9.5f),3.0f,"d6976c","b05a3d");
  for(int side=-1;side<=1;side+=2){var x=side== -1?-2.65f:2.2f;Box(p,new Vector3(x,1.3f,5.12f),new Vector3(1.8f,.12f,.7f),"cba379","balcony stone");for(int i=0;i<7;i++)Rod(p,new Vector3(x-.8f+i*.27f,1.35f,4.8f),new Vector3(x-.8f+i*.27f,1.85f,4.8f),.017f,"37685f");Rod(p,new Vector3(x-.85f,1.85f,4.8f),new Vector3(x+.85f,1.85f,4.8f),.024f,"37685f");for(int i=0;i<14;i++)Leaf(p,new Vector3(x+1.0f,2.9f-i*.11f,5.18f),.32f,i%2==0?"477845":"789446",i*53);}
  // Small stones and grass along the walls, kept away from the playable lane.
  for(int i=0;i<28;i++){float z=-5.0f+i*.4f;for(int side=-1;side<=1;side+=2){Box(p,new Vector3(side*4.75f,.06f,z),new Vector3(.27f,.08f,.32f),i%2==0?"d3b583":"f0d2a1","worn edge cobble");if(i%3==0)Leaf(p,new Vector3(side*4.83f,.13f,z),.23f,"71915b",i*61);}}
  if(core.stage==1){
   // Scarlet market booths and olive barrels make a new spatial silhouette.
   for(int side=-1;side<=1;side+=2){var g=Group("scarlet market stall",p).transform;g.localPosition=new Vector3(side*3.55f,0,-.6f);for(int k=0;k<2;k++)Rod(g,new Vector3((k-.5f)*1.6f,0,.2f),new Vector3((k-.5f)*1.6f,2,.2f),.04f,"8a6947");for(int k=0;k<6;k++){var aw=Box(g,new Vector3((k-2.5f)*.32f,2,-.15f),new Vector3(.32f,.08f,1.3f),k%2==0?"c65942":"ffe1a4","market canopy");aw.transform.localEulerAngles=new Vector3(-8,0,0);}Box(g,new Vector3(0,.65f,0),new Vector3(1.8f,.12f,.8f),"a77d51");for(int k=0;k<15;k++)Ball(g,new Vector3((k%5-2)*.27f,.82f,(k/5-1)*.23f),Vector3.one*.25f,k%2==0?"dc7c38":"8b9d43","fresh market produce");}
  }
  if(core.stage==2){
   // Rooftop pergola and grape garden, leaving all three meal routes open.
   for(int side=-1;side<=1;side+=2){Rod(p,new Vector3(side*4,0,6.5f),new Vector3(side*4,3.3f,6.5f),.07f,"a8794b");Rod(p,new Vector3(side*4,0,4.3f),new Vector3(side*4,3.3f,4.3f),.07f,"a8794b");}for(int i=0;i<8;i++){Rod(p,new Vector3(-4,3.3f,4.3f+i*.3f),new Vector3(4,3.3f,4.3f+i*.3f),.04f,"ad8a56");for(int j=0;j<6;j++)Leaf(p,new Vector3((j-2.5f)*1.2f,3.34f,4.3f+i*.3f),.58f,"698749",i*23+j*31);}for(int i=0;i<8;i++)Ball(p,new Vector3(3.8f,2.9f-i*.05f,2.5f),Vector3.one*.17f,"8e7392","grape bunch");
  }
 }
}
