using System;
[Serializable] public class SnackProfile {public int wins,best,round;public bool sound=true;}
public sealed class SnackCore {
 public int bites,total,phase,score,guardPhase; // 0 eat, 1 hide, 2 won, 3 caught
 public float elapsed,firstBite=-1,wakeAt=-1,biteClock,hideClock;
 public bool started,alert,paused;
 public void Reset(int round){bites=0;total=round%3==1?8:6;phase=0;score=0;guardPhase=0;elapsed=0;firstBite=-1;wakeAt=-1;biteClock=0;hideClock=0;started=false;alert=false;paused=false;}
 public bool Feed(float dt,bool near){if(paused||phase>=2)return false;if(!near||bites>=total){biteClock=0;return false;}biteClock+=dt;if(biteClock<.22f)return false;biteClock=0;bites++;score+=10+bites*2;if(firstBite<0)firstBite=elapsed;if(bites==2){alert=true;wakeAt=elapsed;}if(bites==total)phase=1;return true;}
 public void Tick(float dt,bool moving,bool hidden){if(paused||phase>=2)return;if(moving)started=true;if(started)elapsed+=dt;if(alert){guardPhase=elapsed-wakeAt<.9f?1:2;}if(phase==1&&hidden){hideClock+=dt;if(hideClock>=1.15f)phase=2;}else hideClock=0;}
 public bool Catch(){if(paused||phase>=2||elapsed<5.5f)return false;phase=3;return true;}
 public static void Verify(){
  for(int r=0;r<6;r++){var c=new SnackCore();c.Reset(r);for(int i=0;i<300&&c.phase<1;i++){c.Tick(.02f,true,false);c.Feed(.02f,true);}if(c.bites!=c.total||c.phase!=1||c.firstBite>.3f||!c.alert)throw new Exception("meal");int score=c.score;c.Feed(1,true);if(c.score!=score)throw new Exception("duplicate bite");for(int i=0;i<60;i++)c.Tick(.02f,false,true);if(c.phase!=2||c.Catch())throw new Exception("ending");}
  var p=new SnackCore();p.Reset(0);p.paused=true;p.Tick(4,true,true);p.Feed(4,true);if(p.bites!=0||p.elapsed!=0)throw new Exception("pause");p.paused=false;if(p.Catch())throw new Exception("opening grace");p.Tick(6,true,false);if(!p.Catch()||p.phase!=3)throw new Exception("catch");
  UnityEngine.Debug.Log("SNACK CORE QA PASS: six meals, first bite, full/duplicate guards, hide win, pause and opening grace");
 }
}
