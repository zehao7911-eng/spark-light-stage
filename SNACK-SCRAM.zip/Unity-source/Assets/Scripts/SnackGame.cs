using UnityEngine;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using static SnackArt;
public sealed partial class SnackGame:MonoBehaviour {
 [DllImport("__Internal")]static extern void SnackState(string s);
 [DllImport("__Internal")]static extern void SnackEvent(string s);
 [DllImport("__Internal")]static extern void SnackPhoto(string s);
 [NonSerialized]public SnackCore core=new SnackCore();SnackProfile profile=new SnackProfile();
 Camera cam;Light sun;SnackCharacter hero,dog;Transform refuge,foodRoot,boat;List<GameObject> pieces=new List<GameObject>();
 Rigidbody heroRb;Vector3 player,guard,lastSeen,autoTarget;Vector2 axis;bool autoMove,hidden,awarded,photoPending;
 float clock,eatPulse,sendClock,shake,walkSpeed,guardSpeed;int screenW,screenH,eventID;string message="Cake first. Questions later.";
 Vector3 cakePos=new Vector3(0,0,-.6f),bushPos=new Vector3(-2.45f,0,1.45f);Vector3 guardHome=new Vector3(2.5f,0,2.8f);
 readonly List<Vector4> obstacles=new List<Vector4>(); readonly List<Rigidbody> furniture=new List<Rigidbody>();List<Vector3> chairHome=new List<Vector3>();List<Quaternion> chairRot=new List<Quaternion>();
 struct Fx {public Transform tr;public Vector3 pos,vel,spin;public float life,max,scale;}
 Fx[] fx=new Fx[48];int fxNext;
 [Serializable]public class View {public bool ready=true,paused,hidden,sound;public int phase,bites,total,wins,best,round,score,dog,fx,eventID,stage,meal,meals;public float dash,hideFill,danger;public string stageName,foodName;public float elapsed,firstBite,wakeAt,px,pz,fps;public string notice;public Vector2 food,bush;}
 void Awake(){
  Application.targetFrameRate=40;QualitySettings.vSyncCount=0;QualitySettings.antiAliasing=2;QualitySettings.shadows=ShadowQuality.All;QualitySettings.shadowResolution=ShadowResolution.Medium;QualitySettings.shadowDistance=32;QualitySettings.shadowCascades=0;
  RenderSettings.ambientMode=UnityEngine.Rendering.AmbientMode.Flat;RenderSettings.ambientLight=Hex("bdc5b3");RenderSettings.fog=false;
  cam=Camera.main;if(!cam){var cg=new GameObject("Main Camera");cam=cg.AddComponent<Camera>();cg.tag="MainCamera";cg.AddComponent<AudioListener>();}cam.orthographic=true;cam.nearClipPlane=.1f;cam.farClipPlane=100;cam.clearFlags=CameraClearFlags.SolidColor;cam.backgroundColor=Hex("99c9c4");cam.transform.position=new Vector3(6.5f,13,-16);cam.transform.LookAt(new Vector3(0,0,2.3f));
  var sg=new GameObject("Warm Mediterranean sun");sun=sg.AddComponent<Light>();sun.type=LightType.Directional;sun.color=Hex("ffe3b5");sun.intensity=1.1f;sun.shadows=LightShadows.Soft;sun.shadowStrength=.65f;sg.transform.rotation=Quaternion.Euler(48,-34,0);
  try{string saved=PlayerPrefs.GetString("snack-scram.v1","");if(saved!=""){var p=JsonUtility.FromJson<SnackProfile>(saved);if(p!=null){p.wins=Mathf.Clamp(p.wins,0,99999);p.round=Mathf.Clamp(p.round,0,99999);p.best=Mathf.Clamp(p.best,0,999999);profile=p;}}}catch{}
  hero=new SnackCharacter("Pip the hungry possum",Vector3.zero);dog=new SnackCharacter("Captain Crumb",guardHome,true);
  heroRb=hero.root.gameObject.AddComponent<Rigidbody>();heroRb.isKinematic=true;heroRb.interpolation=RigidbodyInterpolation.Interpolate;heroRb.collisionDetectionMode=CollisionDetectionMode.ContinuousSpeculative;var col=hero.root.gameObject.AddComponent<CapsuleCollider>();col.center=new Vector3(0,.5f,0);col.radius=.3f;col.height=1;
  for(int i=0;i<fx.Length;i++){var q=Ball(null,new Vector3(0,-30,0),Vector3.one*.09f,i%3==0?"fff0d0":i%3==1?"d9905b":"e8c88f","cream and crumb");q.SetActive(false);fx[i]=new Fx{tr=q.transform};}
  ResetRound();Resize();Emit();
 }
 void BuildWorld(){
  var world=Group("painted harbour courtyard").transform;worldRoot=world;
  var water=Box(world,new Vector3(0,-.75f,0),new Vector3(180,.15f,180),"77b9b2","animated sea");var wm=new Material(Resources.Load<Shader>("SnackWater"));wm.color=Hex("438f92");water.GetComponent<MeshRenderer>().sharedMaterial=wm;
  Box(world,new Vector3(0,-.55f,.5f),new Vector3(10.5f,.9f,13),"b9aa88","limestone island edge");Box(world,new Vector3(0,-.10f,.5f),new Vector3(10.2f,.20f,12.7f),"eed5ad","grout");
  string[] tiles={"ce9269","dba57a","e7b88b","d99b70","e0ac7c"};for(int x=0;x<16;x++)for(int z=0;z<20;z++){var q=Box(world,new Vector3(-4.8f+x*.64f,.025f,-5.55f+z*.64f),new Vector3(.615f,.05f,.615f),tiles[(x*7+z*3)%tiles.Length],"hand laid terracotta");q.transform.localEulerAngles=new Vector3(0,Rand(-.7f,.7f),0);}
  for(int side=-1;side<=1;side+=2){for(int z=0;z<13;z++){Box(world,new Vector3(side*5.05f,.38f,-5.4f+z),new Vector3(.23f,.7f,.95f),"f2dcaf","plaster parapet");Box(world,new Vector3(side*5.05f,.77f,-5.4f+z),new Vector3(.34f,.10f,1),"f9e9c7","limestone coping");}for(int j=0;j<8;j++){Box(world,new Vector3(side*5.1f,-.65f,j*1.5f-4.5f),new Vector3(.5f,.5f,.9f),j%2==0?"a49e85":"c0b292","old stone foundation");}}
  for(int i=0;i<5;i++){Box(world,new Vector3(-1.2f+i*.58f,.25f,-5.82f),new Vector3(.54f,.5f,.25f),"e9d4a7","front wall");Box(world,new Vector3(-1.2f+i*.58f,.52f,-5.82f),new Vector3(.59f,.08f,.38f),"f7e4bb");}
  House(world,new Vector3(-2.65f,0,6.5f),4.0f,"eed5a4","b36549");House(world,new Vector3(2.2f,0,7.0f),3.2f,"e3b98e","c97d55");
  for(int i=0;i<7;i++){Box(world,new Vector3(5.65f,-.12f-i*.15f,2.3f-i*.5f),new Vector3(1.3f,.18f,.56f),"e0b28c","steps down to the quay");}
  for(int i=0;i<8;i++){Box(world,new Vector3(-6.0f,.0f,-3.6f+i*.55f),new Vector3(2.4f,.13f,.5f),i%2==0?"a48462":"ba9972","quayside wood");if(i%2==0)Cyl(world,new Vector3(-7.0f,-.35f,-3.6f+i*.55f),.1f,1.5f,"8c765a","pier pile");}
  Tree(world,new Vector3(-3.85f,0,3.5f));Tree(world,new Vector3(3.9f,0,4.1f));Pot(world,new Vector3(-3.9f,0,-3.0f),1.1f);Pot(world,new Vector3(4,0,-3.8f),.8f);Pot(world,new Vector3(3.55f,0,5.2f),.8f);Lamp(world,new Vector3(-4.0f,0,-.1f));Lamp(world,new Vector3(4.0f,0,-.1f));
  // The empty center lane makes the first meal and escape leg immediately readable.
  for(int i=0;i<3;i++){Flower(world,new Vector3(-3.4f+i*.33f,0,.8f),.45f,"dcaaaf");Flower(world,new Vector3(-3.3f+i*.31f,0,2.35f),.5f,"f4d6aa");}
  refuge=Bush(null,bushPos,1.02f).transform;
  for(int i=0;i<4;i++)Flower(refuge,new Vector3((i-1.5f)*.3f,.8f,.12f),.42f,"f5dcaf");
  // Hand-carved central cake stand.
  foreach(var spot in mealSpots)ServingTable(world,spot);
  SmallTable(world,new Vector3(2.5f,0,-2.25f),.68f);SmallTable(world,new Vector3(-2.7f,0,-3.65f),.65f);
  Chair(new Vector3(3.1f,.02f,-1.35f),-25);Chair(new Vector3(1.5f,.02f,-2.9f),155);Chair(new Vector3(-1.7f,.02f,-3.9f),95);
  // Fruit cart, woven basket, crate slats, individually modelled fruit.
  var cart=Group("market fruit cart",world).transform;cart.localPosition=new Vector3(3.4f,0,1.1f);Box(cart,new Vector3(0,.5f,0),new Vector3(1.2f,.1f,.7f),"b58e64");for(int j=0;j<4;j++)Box(cart,new Vector3(0,.66f,-.31f+j*.20f),new Vector3(1.15f,.08f,.035f),"d4b083","crate slat");for(int side=-1;side<=1;side+=2){Rod(cart,new Vector3(side*.5f,.5f,-.3f),new Vector3(side*.5f,.1f,-.3f),.04f,"987652");var wh=Cyl(cart,new Vector3(side*.63f,.23f,0),.21f,.075f,"667975","cart wheel");wh.transform.localRotation=Quaternion.Euler(0,0,90);}for(int i=0;i<12;i++)Ball(cart,new Vector3(Rand(-.45f,.45f),.73f,Rand(-.2f,.2f)),Vector3.one*.21f,i%3==0?"a4af67":"e7ac5b","market fruit");
  // Bunting and flower boxes link the scene into one warm palette.
  Rod(world,new Vector3(-4.6f,2.8f,4.9f),new Vector3(4.6f,2.8f,4.9f),.014f,"a59477");for(int i=0;i<13;i++){var flag=Box(world,new Vector3(-4.1f+i*.68f,2.6f-Mathf.Sin(i*Mathf.PI/12)*.25f,4.9f),new Vector3(.24f,.35f,.025f),i%3==0?"6b958b":i%3==1?"e7b977":"d79378","little bunting");flag.transform.localEulerAngles=new Vector3(0,0,(i%2==0?-1:1)*10);}
  for(int i=0;i<12;i++){float z=-4.8f+i;Ball(world,new Vector3(-5.75f,-.66f,z),new Vector3(.22f,.012f,.62f),"c7dfcc","shore foam");}
  StageDecor(world);Combine(world);refuge.SetParent(world,true);foreach(var rb in furniture)rb.transform.SetParent(world,true);
  boat=Group("little moored rowboat").transform;boat.position=new Vector3(-7.65f,-.52f,-1.1f);Ball(boat,Vector3.zero,new Vector3(1.25f,.42f,2.4f),"bd9871","wooden hull");Ball(boat,new Vector3(0,.16f,0),new Vector3(1.12f,.12f,2.25f),"648f87","painted gunwale");Ball(boat,new Vector3(0,.20f,0),new Vector3(.92f,.035f,1.90f),"d4b58b","inside the boat");for(int i=0;i<2;i++)Box(boat,new Vector3(0,.27f,(i-.5f)*1.1f),new Vector3(.96f,.07f,.2f),"b7956a","rowing seat");Rod(boat,new Vector3(-.3f,.31f,-.9f),new Vector3(.5f,.31f,.9f),.025f,"ddc49a");Ball(boat,new Vector3(.6f,.30f,1.05f),new Vector3(.25f,.06f,.48f),"e3caa2","oar blade");Combine(boat);boat.SetParent(world,true);
  var ground=new GameObject("courtyard collision floor");ground.transform.SetParent(world);var bc=ground.AddComponent<BoxCollider>();bc.center=new Vector3(0,-.18f,.5f);bc.size=new Vector3(10.4f,.35f,13);
 }
 void SmallTable(Transform p,Vector3 pos,float r){Cyl(p,pos+Vector3.up*.57f,r,.10f,"d5bd85","cafe table");Rod(p,pos+Vector3.up*.54f,pos,.06f,"657b73");for(int i=0;i<3;i++){float a=i*2.1f;Rod(p,pos+Vector3.up*.15f,pos+new Vector3(Mathf.Cos(a)*.4f,0,Mathf.Sin(a)*.4f),.035f,"657b73");}var cup=Cyl(p,pos+new Vector3(.15f,.69f,0),.09f,.15f,"f5e5bf","espresso cup");Cyl(p,pos+new Vector3(.15f,.77f,0),.075f,.01f,"76604b","coffee");obstacles.Add(new Vector4(pos.x,pos.z,r+.28f,0));}
 void Chair(Vector3 p,float yaw){var g=Group("tippable cafe chair");g.transform.position=p;g.transform.rotation=Quaternion.Euler(0,yaw,0);Box(g.transform,new Vector3(0,.35f,0),new Vector3(.5f,.09f,.5f),"698d83","chair seat");for(int side=-1;side<=1;side+=2){Rod(g.transform,new Vector3(side*.2f,.35f,-.2f),new Vector3(side*.23f,0,-.23f),.028f,"506f69");Rod(g.transform,new Vector3(side*.2f,.9f,.2f),new Vector3(side*.23f,0,.23f),.028f,"506f69");}for(int j=0;j<3;j++)Box(g.transform,new Vector3(0,.65f+j*.10f,.21f),new Vector3(.43f,.055f,.055f),"72988a","chair back slat");Combine(g.transform);var c=g.AddComponent<BoxCollider>();c.center=new Vector3(0,.40f,0);c.size=new Vector3(.55f,.8f,.55f);var rb=g.AddComponent<Rigidbody>();rb.mass=1.2f;rb.linearDamping=.7f;rb.angularDamping=.65f;rb.interpolation=RigidbodyInterpolation.Interpolate;furniture.Add(rb);chairHome.Add(p);chairRot.Add(g.transform.rotation);}
 void BuildFood(){if(foodRoot){DisposeMeshes(foodRoot);Destroy(foodRoot.gameObject);}foodRoot=Group("a very tempting meal",worldRoot).transform;foodRoot.position=cakePos+new Vector3(0,.58f,0);pieces.Clear();int kind=(core.stage+mealIndex)%3;
  for(int i=0;i<core.mealSize;i++){var g=Group("bite "+(i+1),foodRoot).transform;float a=i*360f/core.mealSize+2,b=(i+1)*360f/core.mealSize-2;float middle=(a+b)*.5f*Mathf.Deg2Rad;
   if(kind==0){Sector(g,a,b,.64f,.0f,.18f,"b87956");Sector(g,a,b,.64f,.18f,.04f,"cf8077");Sector(g,a,b,.64f,.22f,.16f,"edd5a4");Sector(g,a,b,.66f,.38f,.06f,"f8e6c0");for(int j=0;j<3;j++){float r=.30f+j*.13f;Ball(g,new Vector3(Mathf.Sin(middle)*r,.48f,Mathf.Cos(middle)*r),new Vector3(.16f,.13f,.16f),"fff0d0","piped cream");}Strawberry(g,new Vector3(Mathf.Sin(middle)*.46f,.57f,Mathf.Cos(middle)*.46f));}
   else if(kind==1){Sector(g,a,b,.73f,0,.09f,"d6a369");Sector(g,a,b,.68f,.09f,.03f,"ba6a4f");Sector(g,a,b,.67f,.12f,.045f,"f4c974");for(int j=0;j<3;j++){float theta=Mathf.Lerp(a,b,(j+.5f)/3)*Mathf.Deg2Rad;Ball(g,new Vector3(Mathf.Sin(theta)*.70f,.10f,Mathf.Cos(theta)*.70f),new Vector3(.2f,.16f,.2f),"e2b478","puffy crust");}Cyl(g,new Vector3(Mathf.Sin(middle)*.42f,.18f,Mathf.Cos(middle)*.42f),.095f,.025f,"b65d46","pepperoni");Leaf(g,new Vector3(Mathf.Sin(middle)*.23f,.19f,Mathf.Cos(middle)*.23f),.18f,"698b57",i*37);}
   else{Sector(g,a,b,.69f,0,.45f,"e9ba65");Sector(g,a,b,.70f,.45f,.04f,"f6d586");for(int j=0;j<3;j++){float r=.23f+j*.16f;Ball(g,new Vector3(Mathf.Sin(middle)*r,.49f,Mathf.Cos(middle)*r),new Vector3(.12f,.017f,.11f),"c5944a","cheese holes");}}
   Combine(g);pieces.Add(g.gameObject);
  }
 }
 void Strawberry(Transform p,Vector3 a){var g=Group("strawberry",p).transform;g.localPosition=a;var f=Ball(g,Vector3.zero,new Vector3(.19f,.23f,.18f),"c86d62","ripe berry");for(int k=0;k<5;k++){float t=k*2.4f;Ball(g,new Vector3(Mathf.Cos(t)*.084f,Mathf.Sin(t)*.07f,Mathf.Sin(t)*.075f),Vector3.one*.019f,"f8d799","berry seed");Leaf(g,new Vector3(0,.10f,0),.15f,"7b965b",k*72);}}
 void Sector(Transform p,float start,float end,float radius,float y,float height,string color){var mesh=new Mesh{name="SnackTransient"};var v=new List<Vector3>();var t=new List<int>();Action<Vector3,Vector3,Vector3> tri=(a,b,c)=>{int n=v.Count;v.Add(a);v.Add(b);v.Add(c);t.Add(n);t.Add(n+1);t.Add(n+2);};int N=8;Vector3 cb=new Vector3(0,y,0),ct=cb+Vector3.up*height;for(int i=0;i<N;i++){float a=Mathf.Lerp(start,end,i/(float)N)*Mathf.Deg2Rad,b=Mathf.Lerp(start,end,(i+1f)/N)*Mathf.Deg2Rad;Vector3 u=new Vector3(Mathf.Sin(a)*radius,y,Mathf.Cos(a)*radius),w=new Vector3(Mathf.Sin(b)*radius,y,Mathf.Cos(b)*radius);tri(ct,u+Vector3.up*height,w+Vector3.up*height);tri(cb,w,u);tri(u,w,w+Vector3.up*height);tri(u,w+Vector3.up*height,u+Vector3.up*height);}Vector3 s=new Vector3(Mathf.Sin(start*Mathf.Deg2Rad)*radius,y,Mathf.Cos(start*Mathf.Deg2Rad)*radius),e=new Vector3(Mathf.Sin(end*Mathf.Deg2Rad)*radius,y,Mathf.Cos(end*Mathf.Deg2Rad)*radius);tri(cb,s,ct);tri(s,s+Vector3.up*height,ct);tri(cb,ct,e);tri(e,ct,e+Vector3.up*height);mesh.SetVertices(v);mesh.SetTriangles(t,0);mesh.RecalculateNormals();var go=Group("hand cut food layer",p);go.AddComponent<MeshFilter>().sharedMesh=mesh;go.AddComponent<MeshRenderer>().sharedMaterial=Mat(color);}
 void ResetRound(){core.Reset(profile.round);PrepareStage();awarded=false;axis=Vector2.zero;autoMove=false;player=mealSpots[0]+new Vector3(0,.025f,2.4f);guard=guardHome;lastSeen=player;hero.root.position=player;hero.root.rotation=Quaternion.Euler(0,180,0);dog.root.position=guard;dog.root.rotation=Quaternion.Euler(0,205,0);hidden=false;eatPulse=0;shake=0;for(int i=0;i<fx.Length;i++){fx[i].life=0;fx[i].tr.gameObject.SetActive(false);}for(int i=0;i<furniture.Count;i++){furniture[i].position=chairHome[i];furniture[i].rotation=chairRot[i];furniture[i].linearVelocity=Vector3.zero;furniture[i].angularVelocity=Vector3.zero;}hero.chefHat.gameObject.SetActive(profile.wins>=3);BuildFood();Tell(stageNames[core.stage],"ready");}
 void Resize(){screenW=Screen.width;screenH=Screen.height;cam.aspect=(float)screenW/Mathf.Max(1,screenH);cam.orthographicSize=Mathf.Max(5.7f,4.05f/cam.aspect);}
 public void Command(string command){var p=command.Split(':');switch(p[0]){
  case "axis":if(p.Length>=3&&!core.paused&&core.phase<2){axis=Vector2.ClampMagnitude(new Vector2(Parse(p[1]),Parse(p[2])),1);if(axis.sqrMagnitude>.01f)autoMove=false;}break;
  case "food":if(!core.paused&&core.phase<2){autoTarget=cakePos+(player-cakePos).normalized*1.23f;autoMove=true;core.started=true;}break;
  case "bush":if(!core.paused&&core.phase<2){autoTarget=bushPos;autoMove=true;core.started=true;}break;
  case "ground":if(p.Length>=3&&!core.paused&&core.phase<2){Ray r=cam.ViewportPointToRay(new Vector3(Parse(p[1]),1-Parse(p[2]),0));var plane=new Plane(Vector3.up,Vector3.zero);if(plane.Raycast(r,out float d)){autoTarget=r.GetPoint(d);autoTarget.x=Mathf.Clamp(autoTarget.x,-3.7f,3.7f);autoTarget.z=Mathf.Clamp(autoTarget.z,-4.7f,4.8f);autoMove=true;core.started=true;}}break;
  case "dash":if(!core.paused&&core.phase<2&&dashCooldown<=0){dashTime=.85f;dashCooldown=4.0f;Tell("Zoom!","dash");Burst(player+Vector3.up*.2f,10);}break;
  case "cancel":axis=Vector2.zero;autoMove=false;break;
  case "pause":SetPause(p.Length>1&&p[1]=="1");break;
  case "sound":profile.sound=!profile.sound;Save();break;
  case "again":if(core.phase>=2){SetPause(false);ResetRound();}break;
  case "fresh":SetPause(false);profile=new SnackProfile();Save();ResetRound();break;
  case "photo":if(!photoPending)StartCoroutine(Photo());break;
 }Emit();}
 static float Parse(string s){float.TryParse(s,System.Globalization.NumberStyles.Float,System.Globalization.CultureInfo.InvariantCulture,out float v);return float.IsNaN(v)||float.IsInfinity(v)?0:v;}
 void Update(){if(Screen.width!=screenW||Screen.height!=screenH)Resize();float dt=Mathf.Min(Time.deltaTime,.05f);if(core.paused)return;clock+=dt;dashTime=Mathf.Max(0,dashTime-dt);dashCooldown=Mathf.Max(0,dashCooldown-dt);barkClock+=dt;dustClock+=dt;
 #if !UNITY_WEBGL || UNITY_EDITOR
  float kx=(Input.GetKey(KeyCode.D)?1:0)-(Input.GetKey(KeyCode.A)?1:0),ky=(Input.GetKey(KeyCode.W)?1:0)-(Input.GetKey(KeyCode.S)?1:0);if(kx!=0||ky!=0){axis=new Vector2(kx,ky).normalized;autoMove=false;}else axis=Vector2.zero;
 #endif
  if(core.phase<2){Vector3 forward=cam.transform.forward;forward.y=0;forward.Normalize();Vector3 right=cam.transform.right;right.y=0;right.Normalize();Vector3 desired=right*axis.x+forward*axis.y;if(autoMove){var d=autoTarget-player;d.y=0;if(d.magnitude<.10f){autoMove=false;desired=Vector3.zero;}else desired=d.normalized;}
   walkSpeed=desired.magnitude;Vector3 next=player+desired*dt*(dashTime>0?5.6f:3.25f);next.x=Mathf.Clamp(next.x,-3.8f,3.8f);next.z=Mathf.Clamp(next.z,-4.8f,5.0f);foreach(var ob in obstacles){Vector3 d=new Vector3(next.x-ob.x,0,next.z-ob.y);if(d.magnitude<ob.z&&d.magnitude>.001f){d=d.normalized*ob.z;next.x=ob.x+d.x;next.z=ob.y+d.z;}}player=next;hero.root.position=player;
   if(desired.sqrMagnitude>.01f)hero.root.rotation=Quaternion.Slerp(hero.root.rotation,Quaternion.LookRotation(desired),dt*13);
   hidden=Vector3.Distance(player,bushPos)<.8f;
   core.Tick(dt,walkSpeed>.02f,hidden);
   if(core.Feed(dt,Vector3.Distance(player,cakePos)<1.34f)){
    int bite=(core.bites-1)%core.mealSize;FlyBite(pieces[bite].transform);eatPulse=1;shake=.07f;hero.root.rotation=Quaternion.LookRotation(cakePos-player);Burst(hero.root.position+hero.root.forward*.5f+Vector3.up*.9f,12);Tell(core.bites==core.total?"Flowers. Quick!":"Nom × "+core.bites,"bite");
    if(core.bites==2){Tell("Snack thief!","wake");shake=.14f;}
    if(core.bites%core.mealSize==0&&core.bites<core.total){mealIndex++;cakePos=mealSpots[mealIndex];BuildFood();Burst(player+Vector3.up,18);Tell("Next course!","course");}
   }
   guardSpeed=0;if(core.guardPhase>0){if(!hidden)lastSeen=player;Vector3 d=lastSeen-guard;d.y=0;if(core.guardPhase==2&&d.magnitude>.6f){guardSpeed=2.12f+core.stage*.17f+Mathf.Min(3,profile.round/3)*.05f;Vector3 nextDog=guard+d.normalized*dt*guardSpeed;foreach(var ob in obstacles){var q=new Vector3(nextDog.x-ob.x,0,nextDog.z-ob.y);if(q.magnitude<ob.z+.1f&&q.magnitude>.001f){q=q.normalized*(ob.z+.1f);nextDog.x=ob.x+q.x;nextDog.z=ob.y+q.z;}}guard=nextDog;}if(d.sqrMagnitude>.01f)dog.root.rotation=Quaternion.Slerp(dog.root.rotation,Quaternion.LookRotation(d),dt*7);}
   dog.root.position=guard;
   UpdateSecondGuard(dt);
   if(core.guardPhase==2&&!hidden&&barkClock>1.6f){barkClock=0;Tell("Run!","bark");}
   if(walkSpeed>.1f&&dustClock>(dashTime>0?.045f:.13f)){dustClock=0;Dust(player,2);if(core.guardPhase==2)Dust(guard,1);}

   if(core.guardPhase==2&&!hidden&&(Vector3.Distance(player,guard)<.66f||(extraDog!=null&&Vector3.Distance(player,extraGuard)<.66f))&&core.Catch()){autoMove=false;axis=Vector2.zero;Tell("Busted. Still worth it.","caught");}
   if(core.phase==2&&!awarded){awarded=true;profile.wins++;profile.round++;profile.best=Mathf.Max(profile.best,core.score);autoMove=false;axis=Vector2.zero;Save();Burst(player+Vector3.up,22);Tell(core.stage==2?"Three courses. One great escape!":"A very clean getaway.","win");}
  }else{walkSpeed=0;guardSpeed=0;}
  eatPulse=Mathf.MoveTowards(eatPulse,0,dt*3.4f);hero.Animate(clock,walkSpeed,eatPulse,core.bites/(float)core.total,false,hidden,false,cam);dog.Animate(clock,guardSpeed,0,0,core.guardPhase==0,false,core.guardPhase>0,cam);
  if(boat){boat.position=new Vector3(-7.65f,-.52f+Mathf.Sin(clock)*.018f,-1.1f);boat.localEulerAngles=new Vector3(0,8,Mathf.Sin(clock*.8f)*1.1f);}
  refuge.localScale=new Vector3(1+Mathf.Sin(clock*10)*.015f*(hidden?4:1),1,1+Mathf.Cos(clock*8)*.01f*(hidden?4:1));
  AnimateBites(dt);UpdateRings(dt);AnimateFx(dt);shake=Mathf.MoveTowards(shake,0,dt*.35f);cam.transform.position=new Vector3(6.5f+Mathf.Sin(clock*43)*shake,13+Mathf.Cos(clock*39)*shake,-16);cam.transform.LookAt(new Vector3(0,0,2.3f));
  sendClock+=dt;if(sendClock>.1f){sendClock=0;Emit();}
 }
 void FixedUpdate(){if(heroRb&&!core.paused)heroRb.MovePosition(player);}
 void Burst(Vector3 origin,int count){for(int j=0;j<count;j++){int i=fxNext++%fx.Length;var f=fx[i];f.pos=origin+UnityEngine.Random.insideUnitSphere*.2f;f.vel=new Vector3(Rand(-2.2f,2.2f),Rand(1.5f,3.1f),Rand(-2f,2f));f.spin=new Vector3(Rand(-100,100),Rand(-100,100),Rand(-100,100));f.life=f.max=Rand(.7f,1.3f);f.scale=Rand(.07f,.14f);f.tr.localScale=Vector3.one*f.scale;f.tr.gameObject.SetActive(true);fx[i]=f;}}
 void AnimateFx(float dt){for(int i=0;i<fx.Length;i++){var f=fx[i];if(f.life<=0)continue;f.life-=dt;f.vel.y-=dt*7;f.pos+=f.vel*dt;if(f.pos.y<.09f){f.pos.y=.09f;f.vel.y=Mathf.Abs(f.vel.y)*.28f;f.vel.x*=.8f;f.vel.z*=.8f;}f.tr.position=f.pos;f.tr.Rotate(f.spin*dt);f.tr.localScale=Vector3.one*f.scale*Mathf.Clamp01(f.life*4);if(f.life<=0)f.tr.gameObject.SetActive(false);fx[i]=f;}}
 void SetPause(bool p){core.paused=p;axis=Vector2.zero;autoMove=false;Time.timeScale=p?0:1;Emit();}
 void OnApplicationFocus(bool focus){if(!focus)SetPause(true);}
 void OnApplicationPause(bool paused){if(paused)SetPause(true);}
 void Save(){try{PlayerPrefs.SetString("snack-scram.v1",JsonUtility.ToJson(profile));PlayerPrefs.Save();}catch{}}
 void Tell(string s,string sound){message=s;eventID++;
 #if UNITY_WEBGL && !UNITY_EDITOR
  SnackEvent(sound);
 #endif
 }
 void Emit(){if(!cam)return;Vector3 a=cam.WorldToViewportPoint(cakePos+Vector3.up*1.2f),b=cam.WorldToViewportPoint(bushPos+Vector3.up*1.1f);var view=new View{stage=core.stage,meal=mealIndex+1,meals=core.meals,stageName=stageNames[core.stage],foodName=new[]{"cake","pizza","cheese"}[(core.stage+mealIndex)%3],dash=dashCooldown,hideFill=core.hideClock/1.15f,danger=core.guardPhase==2&&!hidden?Mathf.Clamp01(1-Vector3.Distance(player,guard)/4):0,paused=core.paused,hidden=hidden,sound=profile.sound,phase=core.phase,bites=core.bites,total=core.total,wins=profile.wins,best=profile.best,round=profile.round,score=core.score,dog=core.guardPhase,elapsed=core.elapsed,firstBite=core.firstBite,wakeAt=core.wakeAt,px=player.x,pz=player.z,notice=message,eventID=eventID,fps=1/Mathf.Max(.001f,Time.unscaledDeltaTime),food=new Vector2(a.x,1-a.y),bush=new Vector2(b.x,1-b.y)};int n=0;foreach(var f in fx)if(f.life>0)n++;view.fx=n;
 #if UNITY_WEBGL && !UNITY_EDITOR
  SnackState(JsonUtility.ToJson(view));
 #endif
 }
 System.Collections.IEnumerator Photo(){photoPending=true;yield return new WaitForEndOfFrame();var tex=ScreenCapture.CaptureScreenshotAsTexture();var data=Convert.ToBase64String(tex.EncodeToPNG());Destroy(tex);
 #if UNITY_WEBGL && !UNITY_EDITOR
  SnackPhoto(data);
 #endif
  photoPending=false;}
}
