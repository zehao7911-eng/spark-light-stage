BUGS BUNNY: BUNNY BOING
An unofficial fan-made HTML5 game. Original procedural 3D artwork and code.

PLAY
Touch anywhere on the scene to start bouncing. Keep your finger down and drag
left or right to steer. Land on the next ledge and reach the golden flag.
Collect three carrots. Flags at ledges 4 and 8 save your height after a fall.
There are no lives or countdown. Letting go stops horizontal steering.
Desktop: arrows or A/D, Space to start, Escape to pause.

REWARDS
One star for finishing, one for all carrots, one for no falls.
Only the best result on each trip counts. Six stars unlock aviator goggles;
twelve unlock golden gloves. Eight designed routes are remixed on later trips.
Progress saves locally when browser storage is available. Resume starts paused.

INSTALL
Open index.html directly or serve this folder on any static HTML5 host.
The index includes all rendering code; no CDN or external requests are required.
WebGL and a modern browser are required. Mobile portrait layout is recommended.
Touch, rotation, small-screen layout and recovery were tested in browser mobile
emulation. This is not a claim of testing on every physical handset.

CREDITS
Loose gameplay inspiration: Pogostuck: Rage With Your Friends (Steam app 688130).
Bugs Bunny and Looney Tunes belong to Warner Bros. This is an unofficial fan
work, not a commercial game port or an endorsement. No official model files,
textures or audio were extracted. Original sound synthesis runs after input.
Three.js r147: MIT; see THREE-LICENSE.txt.
