extends Node2D
const DIRS=[Vector2i(1,0),Vector2i(0,1),Vector2i(-1,1),Vector2i(-1,0),Vector2i(0,-1),Vector2i(1,-1)]
const NAMES=['Meadow','Forest','Fields','Village','Lake']
const LIMIT=6
var tiles=[]
var cells={}
var queue=[]
var chosen=0
var turn=0
var selected=Vector2i(999,999)
var score=0
var supply=30
var relaxed=false
var ended=false
var perfects=0
var contracts=0
var goals=[3,3,3,3]
var lifetime_perfect=0
var lifetime_contract=0
var best_score=0
var season=0
var muted=false
var paused=true
var seed_value=71237
var undo=[]
var event=0
var notice='Choose an open hex. Turn the tile. Make a little match.'
var callback
var ticker=0.0
var elapsed=0.0
var world: SubViewport
var landscape
var css_size=Vector2(1100,760)
var map_rect=Rect2()
var fx=[]
var drag_start=Vector2.ZERO
var last_pointer=Vector2.ZERO
var is_dragging=false
var pointer_down=false
var css_bottom=230.0
var css_top=109.0

func _ready():
	world=SubViewport.new(); world.size=Vector2i(1100,460); world.render_target_update_mode=SubViewport.UPDATE_ALWAYS
	world.own_world_3d=true; add_child(world)
	landscape=Node3D.new(); landscape.set_script(preload('landscape.gd')); landscape.game=self; world.add_child(landscape)
	if not restore(): fresh(false)
	landscape.rebuild()
	if OS.has_feature('web'):
		callback=JavaScriptBridge.create_callback(web_action)
		JavaScriptBridge.get_interface('window').mAction=callback
	if '--qa' in OS.get_cmdline_user_args(): verify()

func key(p): return str(p.x)+','+str(p.y)
func pos(t): return Vector2i(int(t.q),int(t.r))
func inside(p): return maxi(absi(p.x),maxi(absi(p.y),absi(p.x+p.y)))<=LIMIT
func get_tile(p): return cells.get(key(p))
func sync_index():
	cells={}
	for t in tiles: cells[key(pos(t))]=t

func random_int(n):
	seed_value=(seed_value*1664525+1013904223)%4294967296
	return int(seed_value%n)

func next_tile():
	var k=1+random_int(4); var length=2+random_int(5); var edges=[]
	for i in range(6): edges.append(k if i<length else 0)
	return {'edges':edges,'kind':k}

func active_edges():
	var result=[]
	if queue.is_empty(): return result
	for i in range(6): result.append(int(queue[chosen].edges[posmod(i-turn,6)]))
	return result

func frontier():
	var result=[]; var seen={}
	for t in tiles:
		for d in DIRS:
			var p=pos(t)+d
			if inside(p) and not get_tile(p) and not seen.has(key(p)):
				seen[key(p)]=true; result.append(p)
	result.sort_custom(func(a,b):return a.y<b.y or (a.y==b.y and a.x<b.x))
	return result

func evaluate(p,edges):
	var match_count=0; var neighbours=0
	for i in range(6):
		var other=get_tile(p+DIRS[i])
		if other:
			neighbours+=1
			if int(edges[i])==int(other.edges[(i+3)%6]): match_count+=1
	var perfect=neighbours>=2 and match_count==neighbours
	return {'matches':match_count,'neighbours':neighbours,'perfect':perfect,'points':4+match_count*10+(30 if perfect else 0)}

func regions():
	var maxima=[0,0,0,0]
	for kind in range(1,5):
		var visited={}
		for start in tiles:
			var p=pos(start)
			var contains_kind=false
			for edge in start.edges:
				if int(edge)==kind: contains_kind=true
			if visited.has(key(p)) or not contains_kind: continue
			var work=[p]; visited[key(p)]=true; var count=0
			while not work.is_empty():
				var current=work.pop_back(); var t=get_tile(current); count+=1
				for i in range(6):
					var q=current+DIRS[i]; var n=get_tile(q)
					if n and not visited.has(key(q)) and int(t.edges[i])==kind and int(n.edges[(i+3)%6])==kind:
						visited[key(q)]=true; work.append(q)
			maxima[kind-1]=maxi(maxima[kind-1],count)
	return maxima

func fresh(keep=true):
	if keep and not relaxed: best_score=maxi(best_score,score)
	tiles=[]; cells={}; queue=[]; score=0; supply=30; perfects=0; contracts=0; relaxed=false; ended=false; undo=[]
	chosen=0; turn=0; selected=Vector2i(999,999); goals=[3,3,3,3]
	seed_value=int(Time.get_unix_time_from_system())%4294967296
	for entry in [[0,0,0],[1,0,3],[0,1,2],[-1,1,1],[-1,0,1],[0,-1,4],[1,-1,2]]:
		var edges=[]
		for j in range(6): edges.append(entry[2])
		tiles.append({'q':entry[0],'r':entry[1],'edges':edges,'kind':entry[2]})
	sync_index()
	queue=[{'edges':[1,1,1,1,1,1],'kind':1},{'edges':[2,2,2,0,0,0],'kind':2},{'edges':[3,3,3,3,0,0],'kind':3}]
	tell('A new little world. Take your time.')
	if landscape: landscape.target=Vector2.ZERO; landscape.magnify=1; landscape.rebuild()
	save_game()

func checkpoint():
	return {'tiles':tiles.duplicate(true),'queue':queue.duplicate(true),'score':score,'supply':supply,'perfects':perfects,'contracts':contracts,'goals':goals.duplicate(),'seed':seed_value,'lp':lifetime_perfect,'lc':lifetime_contract,'season':season,'relaxed':relaxed,'ended':ended}

func apply_checkpoint(s):
	tiles=s.tiles.duplicate(true); sync_index(); queue=s.queue.duplicate(true); score=int(s.score); supply=int(s.supply)
	perfects=int(s.perfects); contracts=int(s.contracts); goals=s.goals.duplicate(); seed_value=int(s.seed)
	lifetime_perfect=int(s.lp); lifetime_contract=int(s.lc); season=int(s.season); relaxed=bool(s.relaxed); ended=bool(s.ended)
	chosen=0; turn=0; selected=Vector2i(999,999)

func place(p):
	if ended or (supply<=0 and not relaxed) or not p in frontier(): return false
	undo.append(checkpoint())
	if undo.size()>20: undo.pop_front()
	var edges=active_edges(); var result=evaluate(p,edges)
	tiles.append({'q':p.x,'r':p.y,'edges':edges,'kind':int(queue[chosen].kind)}); cells[key(p)]=tiles.back()
	score+=result.points; supply=maxi(0,supply-1)
	if result.perfect: perfects+=1; lifetime_perfect+=1; supply+=1
	queue.remove_at(chosen); queue.append(next_tile()); chosen=0; turn=0
	var maxima=regions(); var completed=0
	for i in range(4):
		if maxima[i]>=int(goals[i]):
			completed+=1; contracts+=1; lifetime_contract+=1; goals[i]=maxi(int(goals[i])+2,maxima[i]+2); supply+=8; score+=80
	var label='+'+str(result.points)+' · '+str(result.matches)+' matching edges'
	if result.perfect: label='A perfect fit! +'+str(result.points)+' · +1 tile'
	if completed>0: label='A growing landscape! +'+str(completed*8)+' tiles · +'+str(completed*80+result.points)
	tell(label)
	selected=Vector2i(999,999)
	if frontier().is_empty() or (supply<=0 and not relaxed):
		ended=true
		if not relaxed: best_score=maxi(best_score,score)
	if landscape:
		landscape.rebuild()
		var point=project_css(p)
		for i in range(28 if result.perfect or completed>0 else 12):
			fx.append({'p':point,'v':Vector2(randf_range(-65,65),randf_range(-100,-25)),'life':randf_range(.5,1.2),'c':Color('#f0cc82') if result.perfect else Color('#8ba98b')})
		while fx.size()>140: fx.pop_front()
	save_game()
	return true

func tell(message): notice=message; event+=1
func choose(p):
	if ended: return false
	if p in frontier(): selected=p; landscape.show_preview(); tell('Turn it until the edges feel right.'); return true
	return false

func action(command):
	var b=command.split(':'); var n=int(b[1]) if b.size()>1 else 0
	match b[0]:
		'begin': paused=false
		'cancel': pointer_down=false; is_dragging=false
		'view':
			if b.size()>=3: css_size=Vector2(maxi(240,n),maxi(240,int(b[2])))
			if b.size()>=5: css_bottom=maxf(80,float(b[3])); css_top=maxf(50,float(b[4]))
		'choose':
			if b.size()>=3: choose(Vector2i(n,int(b[2])))
		'pick':
			if b.size()>=3: choose(mouse_hex(Vector2(float(b[1]),float(b[2]))*(get_viewport_rect().size.x/css_size.x)))
		'pan':
			if b.size()>=5:
				var factor=get_viewport_rect().size.x/css_size.x
				var before=mouse_point(Vector2(float(b[1]),float(b[2]))*factor); var after=mouse_point(Vector2(float(b[3]),float(b[4]))*factor)
				landscape.target=(landscape.target-Vector2(after.x-before.x,after.z-before.z)).clamp(Vector2(-12,-12),Vector2(12,12))
		'queue':
			if n>=0 and n<queue.size(): chosen=n; turn=0; landscape.show_preview()
		'rotate': turn=posmod(turn+(n if n else 1),6); landscape.show_preview()
		'place': place(selected)
		'undo':
			if not undo.is_empty(): apply_checkpoint(undo.pop_back()); landscape.rebuild(); tell('A little room to reconsider.'); save_game()
		'zoom': landscape.magnify=clampf(landscape.magnify*(1.2 if n>0 else 1/1.2),.5,1.8)
		'home': landscape.target=Vector2.ZERO; landscape.magnify=1
		'season':
			if n>=0 and n<3 and (n==0 or (n==1 and lifetime_contract>=5) or (n==2 and lifetime_perfect>=10)): season=n; landscape.rebuild(); save_game()
		'sound': muted=not muted; save_game()
		'pause': paused=n==1; pointer_down=false; is_dragging=false
		'new': fresh(true)
		'relax': relaxed=true; ended=frontier().is_empty(); tell('No rush. No tile limit. Just your little world.'); save_game()
		'photo': photo()

func web_action(args):
	if args.size(): action(str(args[0]))

func _process(dt):
	var native=get_viewport_rect().size
	if not OS.has_feature('web'): css_size=native
	var factor=native.x/css_size.x
	var bottom=230 if css_size.x<600 else (110 if css_size.y<500 else 183)
	var top=109 if css_size.x<600 else 99
	if OS.has_feature('web'): bottom=css_bottom; top=css_top
	map_rect=Rect2(Vector2(0,top*factor),Vector2(native.x,maxf(100,(css_size.y-top-bottom)*factor)))
	var target_size=Vector2i(int(minf(1280,map_rect.size.x)),int(minf(850,map_rect.size.y)))
	if world.size!=target_size: world.size=target_size
	landscape.update_camera()
	if not paused:
		elapsed+=dt; landscape.animate(dt,elapsed)
		for f in fx: f.p+=f.v*dt; f.v.y+=90*dt; f.life-=dt
		fx=fx.filter(func(f):return f.life>0)
	ticker+=dt
	if ticker>.2:
		ticker=0
		if OS.has_feature('web'): JavaScriptBridge.eval('window.mState && window.mState('+JSON.stringify(snapshot())+');')
	queue_redraw()

func _draw():
	draw_rect(get_viewport_rect(),Color('#e7e6d9'))
	if world: draw_texture_rect(world.get_texture(),map_rect,false)
	var factor=get_viewport_rect().size.x/css_size.x
	for f in fx: draw_circle(f.p*factor,2.5*factor,f.c)

func project_css(p):
	if not landscape or not landscape.camera: return Vector2.ZERO
	var pixel=landscape.camera.unproject_position(landscape.world_pos(p)+Vector3(0,.24,0))
	var factor=get_viewport_rect().size.x/css_size.x
	return (map_rect.position+pixel/Vector2(world.size)*map_rect.size)/factor

func mouse_point(pixel):
	var local=(pixel-map_rect.position)/map_rect.size*Vector2(world.size)
	var origin=landscape.camera.project_ray_origin(local); var direction=landscape.camera.project_ray_normal(local)
	if absf(direction.y)<.001: return Vector3.ZERO
	return origin+direction*((.22-origin.y)/direction.y)

func mouse_hex(pixel): return landscape.axial_round(mouse_point(pixel))

func _unhandled_input(e):
	if paused: return
	if e is InputEventMouseButton:
		if e.button_index==MOUSE_BUTTON_WHEEL_UP and e.pressed: action('zoom:1')
		if e.button_index==MOUSE_BUTTON_WHEEL_DOWN and e.pressed: action('zoom:-1')
		if e.button_index==MOUSE_BUTTON_LEFT:
			if e.pressed and map_rect.has_point(e.position): pointer_down=true; drag_start=e.position; last_pointer=e.position; is_dragging=false
			elif not e.pressed and pointer_down:
				if not is_dragging and map_rect.has_point(e.position): choose(mouse_hex(e.position))
				pointer_down=false; is_dragging=false
	if e is InputEventMouseMotion and pointer_down:
		if e.position.distance_to(drag_start)>8: is_dragging=true
		if is_dragging:
			var before=mouse_point(last_pointer); var after=mouse_point(e.position)
			landscape.target-=Vector2(after.x-before.x,after.z-before.z)
			landscape.target=landscape.target.clamp(Vector2(-12,-12),Vector2(12,12))
		last_pointer=e.position

func snapshot():
	var points=[]; var max_visible=0
	for p in frontier():
		var screen=project_css(p); var valid=screen.x>=22 and screen.x<=css_size.x-22 and screen.y>=map_rect.position.y/(get_viewport_rect().size.x/css_size.x)+22 and screen.y<css_size.y-css_bottom-22
		if valid: points.append({'q':p.x,'r':p.y,'x':screen.x,'y':screen.y}); max_visible+=1
	var preview=evaluate(selected,active_edges()) if selected.x!=999 else {}
	var factor=get_viewport_rect().size.x/css_size.x
	return {'map':{'x':map_rect.position.x/factor,'y':map_rect.position.y/factor,'w':map_rect.size.x/factor,'h':map_rect.size.y/factor},'score':score,'supply':supply,'relaxed':relaxed,'ended':ended,'count':tiles.size(),'max':127,'perfects':perfects,'contracts':contracts,'regions':regions(),'goals':goals,'lp':lifetime_perfect,'lc':lifetime_contract,'best':best_score,'season':season,'muted':muted,'paused':paused,'chosen':chosen,'turn':turn,'queue':queue,'active':active_edges(),'selected':[selected.x,selected.y],'preview':preview,'frontier':points,'undo':undo.size(),'event':event,'notice':notice}

func save_game():
	var data=checkpoint(); data.best=best_score; data.muted=muted; data.undo=undo
	var text=JSON.stringify(data); var file=FileAccess.open('user://moss-meadow.json',FileAccess.WRITE)
	if file: file.store_string(text)
	if OS.has_feature('web'): JavaScriptBridge.eval('try{localStorage.setItem("moss-meadow.v1",'+JSON.stringify(text)+')}catch(e){}')

func restore():
	var text=''
	if OS.has_feature('web'): text=str(JavaScriptBridge.eval('(function(){try{return localStorage.getItem("moss-meadow.v1")||""}catch(e){return ""}})()'))
	elif FileAccess.file_exists('user://moss-meadow.json'): text=FileAccess.get_file_as_string('user://moss-meadow.json')
	if text.is_empty(): return false
	var s=JSON.parse_string(text)
	if not valid_save(s): return false
	apply_checkpoint(s); best_score=maxi(0,int(s.get('best',0))); muted=bool(s.get('muted',false)); undo=[]
	var history=s.get('undo',[])
	if not history is Array: history=[]
	for step in history:
		if valid_save(step): undo.append(step)
		if undo.size()>=20: break
	return true

func valid_save(s):
	if not s is Dictionary: return false
	for field in ['tiles','queue','goals','score','supply','perfects','contracts','seed','lp','lc','season','relaxed','ended']:
		if not s.has(field): return false
	if not s.tiles is Array or s.tiles.is_empty() or s.tiles.size()>127 or not s.queue is Array or s.queue.size()!=3 or not s.goals is Array or s.goals.size()!=4: return false
	for field in ['score','supply','perfects','contracts','seed','lp','lc','season']:
		if not (s[field] is int or s[field] is float) or not is_finite(float(s[field])): return false
	for goal in s.goals:
		if not (goal is int or goal is float) or int(goal)<1 or int(goal)>1000: return false
	var seen={}
	for t in s.tiles:
		if not t is Dictionary or not t.has('q') or not t.has('r') or not t.has('kind') or not t.get('edges') is Array or t.edges.size()!=6: return false
		for field in ['q','r','kind']:
			if not (t[field] is int or t[field] is float) or not is_finite(float(t[field])): return false
		if int(t.kind)<0 or int(t.kind)>4: return false
		var p=Vector2i(int(t.q),int(t.r))
		if not inside(p) or seen.has(key(p)): return false
		seen[key(p)]=true
		for e in t.edges:
			if not (e is int or e is float) or int(e)<0 or int(e)>4: return false
	for t in s.queue:
		if not t is Dictionary or not t.has('kind') or not t.get('edges') is Array or t.edges.size()!=6: return false
		if not (t.kind is int or t.kind is float) or int(t.kind)<0 or int(t.kind)>4: return false
		for e in t.edges:
			if not (e is int or e is float) or int(e)<0 or int(e)>4: return false
	return int(s.score)>=0 and int(s.supply)>=0 and int(s.season)>=0 and int(s.season)<3

func photo():
	await RenderingServer.frame_post_draw
	var data=Marshalls.raw_to_base64(world.get_texture().get_image().save_png_to_buffer())
	if OS.has_feature('web'): JavaScriptBridge.eval('window.mPhoto('+JSON.stringify(data)+')')

func verify():
	fresh(false); assert(tiles.size()==7 and frontier().size()==12)
	var before=checkpoint(); var at=Vector2i(-2,1)
	assert(place(at)); assert(tiles.size()==8 and contracts>=1 and supply>=37)
	action('undo'); assert(tiles.size()==7 and supply==30 and score==0 and lifetime_contract==int(before.lc))
	var locked=score; assert(not place(Vector2i.ZERO) and score==locked)
	for i in range(6): action('rotate:1')
	assert(active_edges()==queue[chosen].edges)
	print('MOSS QA PASS: frontier, connections, contracts, undo, duplicate placement, turn')
	get_tree().quit()
