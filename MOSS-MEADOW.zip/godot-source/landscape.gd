extends Node3D
var game
var camera: Camera3D
var target=Vector2.ZERO
var magnify=1.0
var surface: SurfaceTool
var ground: MeshInstance3D
var preview: MeshInstance3D
var markers: MeshInstance3D
var mills=[]
var boats=[]
var material: StandardMaterial3D
var sun: DirectionalLight3D
var palette=[]

func _ready():
	material=StandardMaterial3D.new(); material.vertex_color_use_as_albedo=true; material.roughness=1; material.cull_mode=BaseMaterial3D.CULL_DISABLED
	material.specular_mode=BaseMaterial3D.SPECULAR_DISABLED
	ground=MeshInstance3D.new(); ground.material_override=material; add_child(ground)
	preview=MeshInstance3D.new(); var ghost=material.duplicate(); ghost.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA; ghost.albedo_color=Color(1,1,1,.82); preview.material_override=ghost; add_child(preview)
	markers=MeshInstance3D.new(); markers.material_override=material; add_child(markers)
	var env=WorldEnvironment.new(); var settings=Environment.new()
	settings.background_mode=Environment.BG_COLOR; settings.background_color=Color('#e7e6d9')
	settings.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR; settings.ambient_light_color=Color('#fff3df'); settings.ambient_light_energy=.65
	env.environment=settings; add_child(env)
	sun=DirectionalLight3D.new(); sun.rotation_degrees=Vector3(-55,-35,0); sun.light_color=Color('#fff2da'); sun.light_energy=1.0; sun.shadow_enabled=false; add_child(sun)
	camera=Camera3D.new(); camera.projection=Camera3D.PROJECTION_ORTHOGONAL; camera.size=9; camera.near=.1; camera.far=100; add_child(camera); camera.make_current()
	update_camera()

func world_pos(p): return Vector3(sqrt(3.0)*(p.x+p.y*.5),0,1.5*p.y)

func axial_round(v):
	var r=v.z/1.5; var q=v.x/sqrt(3.0)-r*.5
	var cube=Vector3(q,-q-r,r); var rounded=Vector3(round(cube.x),round(cube.y),round(cube.z)); var diff=(rounded-cube).abs()
	if diff.x>diff.y and diff.x>diff.z: rounded.x=-rounded.y-rounded.z
	elif diff.y>diff.z: rounded.y=-rounded.x-rounded.z
	else: rounded.z=-rounded.x-rounded.y
	return Vector2i(int(rounded.x),int(rounded.z))

func update_camera():
	if not camera: return
	var aim=Vector3(target.x,0,target.y)
	camera.position=aim+Vector3(7,11,9); camera.look_at(aim,Vector3.UP)
	camera.size=(10.8 if game.css_size.x<600 else 8.8)/magnify
	sun.shadow_enabled=game.css_size.x>=900
	sun.directional_shadow_max_distance=30

func start_mesh():
	surface=SurfaceTool.new(); surface.begin(Mesh.PRIMITIVE_TRIANGLES)

func triangle(a,b,c,color,normal=Vector3.ZERO):
	var n=(b-a).cross(c-a).normalized() if normal==Vector3.ZERO else normal
	surface.set_color(color); surface.set_normal(n)
	surface.add_vertex(a); surface.add_vertex(b); surface.add_vertex(c)

func quad(a,b,c,d,color):
	triangle(a,b,c,color); triangle(a,c,d,color)

func box(center,size,color,angle=0.0):
	var points=[]; var basis=Basis(Vector3.UP,angle)
	for p in [Vector3(-1,-1,-1),Vector3(1,-1,-1),Vector3(1,1,-1),Vector3(-1,1,-1),Vector3(-1,-1,1),Vector3(1,-1,1),Vector3(1,1,1),Vector3(-1,1,1)]: points.append(center+basis*(p*size*.5))
	for face in [[0,3,2,1],[4,5,6,7],[0,4,7,3],[1,2,6,5],[3,7,6,2],[0,1,5,4]]: quad(points[face[0]],points[face[1]],points[face[2]],points[face[3]],color)

func cone(center,radius,height,color,sides=6):
	for i in range(sides):
		var a=TAU*i/sides; var b=TAU*(i+1)/sides
		triangle(center+Vector3(cos(a)*radius,0,sin(a)*radius),center+Vector3(0,height,0),center+Vector3(cos(b)*radius,0,sin(b)*radius),color)

func hexagon(center,radius,height,color):
	for i in range(6):
		var a=deg_to_rad(i*60-30); var b=deg_to_rad(i*60+30)
		var p=center+Vector3(cos(a)*radius,height,sin(a)*radius); var q=center+Vector3(cos(b)*radius,height,sin(b)*radius)
		triangle(center+Vector3(0,height,0),q,p,color,Vector3.UP)
		quad(p,q,Vector3(q.x,center.y,q.z),Vector3(p.x,center.y,p.z),color.darkened(.16))

func house(p,variant):
	var walls=Color(['#ead6b0','#e1bf9c','#d4d1b3'][variant%3]); var roof=Color(['#b97f70','#b78f72','#a58178'][variant%3])
	box(p+Vector3(0,.12,0),Vector3(.32,.24,.28),walls)
	var a=p+Vector3(-.19,.24,-.17); var b=p+Vector3(.19,.24,-.17); var c=p+Vector3(0,.40,-.17)
	triangle(a,c,b,roof); triangle(a+Vector3(0,0,.34),b+Vector3(0,0,.34),c+Vector3(0,0,.34),roof)
	quad(a,a+Vector3(0,0,.34),c+Vector3(0,0,.34),c,roof); quad(c,c+Vector3(0,0,.34),b+Vector3(0,0,.34),b,roof)
	for x in [-.085,.085]: box(p+Vector3(x,.14,.145),Vector3(.052,.067,.015),Color('#64898b'))
	box(p+Vector3(.01,.055,.15),Vector3(.06,.11,.014),Color('#a08c74'))
	box(p+Vector3(.09,.36,-.03),Vector3(.055,.13,.055),Color('#b4a28d'))
	box(p+Vector3(.03,.255,.03),Vector3(.33,.01,.02),roof.lightened(.1))

func tree(p,height,kind):
	# Small baked ground shadows replace real-time shadows on phones.
	hexagon(p+Vector3(.07,.003,.05),.16,0.003,Color('#7e9976'))
	box(p+Vector3(0,.13,0),Vector3(.055,.26,.055),Color('#9d8767'))
	if game.season==1:
		cone(p+Vector3(0,.13,0),height*.35,height*.73,Color(['#b9a56b','#be926b','#a7a16d'][kind%3]),7)
		cone(p+Vector3(0,.31,0),height*.25,height*.55,Color('#c6ab77'),7)
	else:
		var c=Color(['#517d63','#608a69','#709271'][kind%3]) if game.season==0 else Color(['#6b8d87','#789992','#64857d'][kind%3])
		cone(p+Vector3(0,.12,0),height*.36,height*.75,c,6)
		cone(p+Vector3(0,.32,0),height*.26,height*.6,c.lightened(.07),6)
		if game.season==2: cone(p+Vector3(0,.49,0),height*.18,height*.32,Color('#e4e6dc'),6)

func tile(t,props=true):
	var center=world_pos(Vector2i(int(t.q),int(t.r)))
	hexagon(center,.985,.17,Color('#879b7b') if game.season!=2 else Color('#93a6a1'))
	for i in range(6):
		var kind=int(t.edges[i]); var color=palette[kind]
		var a=deg_to_rad(i*60-30); var b=deg_to_rad(i*60+30)
		var p=center+Vector3(cos(a)*.95,.205,sin(a)*.95); var q=center+Vector3(cos(b)*.95,.205,sin(b)*.95)
		triangle(center+Vector3(0,.205,0),q,p,color,Vector3.UP)
		if not props: continue
		var angle=deg_to_rad(i*60); var direction=Vector3(cos(angle),0,sin(angle)); var side=Vector3(-sin(angle),0,cos(angle))
		var base=center+direction*.52+Vector3(0,.21,0)
		var variation=absi(int(t.q)*37+int(t.r)*19+i*7)
		match kind:
			0:
				for j in range(3):
					var pos=base+side*(j-1)*.10
					box(pos+Vector3(0,.02,0),Vector3(.026,.045,.026),Color(['#e9d4aa','#cc9c92','#a8bc88'][variation%3]))
			1:
				tree(base+side*.12,.48+variation%3*.07,variation)
				tree(base-side*.14+direction*.14,.42+variation%4*.05,variation+1)
			2:
				for j in range(4):
					box(base+side*(j-1.5)*.072+Vector3(0,.025,0),Vector3(.04,.055,.38),Color('#d6bd76').lightened((j%2)*.08),angle+PI/2)
			3: house(base,variation)
			4:
				for j in range(2): box(base+side*(j-.5)*.11+Vector3(0,.006,0),Vector3(.13,.008,.015),Color('#add0cc'),angle)
	if props and int(t.kind)==2 and (absi(int(t.q)*19+int(t.r)*7)%5==0 or (int(t.q)==0 and int(t.r)==1)):
		box(center+Vector3(0,.40,0),Vector3(.20,.43,.20),Color('#dfcfab'))
		cone(center+Vector3(0,.62,0),.20,.18,Color('#a8836e'),4)
		if mills.size()<12:
			var rotor=Node3D.new(); add_child(rotor); rotor.position=center+Vector3(0,.62,.17)
			var arms=MeshInstance3D.new(); start_mesh_rotor(arms); rotor.add_child(arms); mills.append(rotor)
	if props and int(t.kind)==4 and (absi(int(t.q)*11+int(t.r)*17)%4==0 or (int(t.q)==0 and int(t.r)==-1)) and boats.size()<8:
		var boat=Node3D.new(); add_child(boat); var mesh=MeshInstance3D.new(); var old=surface; start_mesh()
		box(Vector3.ZERO,Vector3(.28,.05,.13),Color('#b48e72')); box(Vector3(.01,.13,0),Vector3(.015,.26,.015),Color('#a89b7e'))
		triangle(Vector3(.02,.24,0),Vector3(.02,.05,0),Vector3(.17,.07,0),Color('#e9dcc0'))
		mesh.mesh=surface.commit(); mesh.material_override=material; boat.add_child(mesh); boat.position=center+Vector3(0,.23,0); boats.append(boat); surface=old

func start_mesh_rotor(mesh):
	var old=surface; start_mesh()
	box(Vector3.ZERO,Vector3(.47,.035,.025),Color('#e8d9b6')); box(Vector3.ZERO,Vector3(.035,.47,.025),Color('#e8d9b6'))
	mesh.mesh=surface.commit(); mesh.material_override=material; surface=old

func rebuild():
	if not ground: return
	for n in mills+boats: n.queue_free()
	mills=[]; boats=[]
	palette=[Color('#a8bc8b'),Color('#83a374'),Color('#d1b676'),Color('#c3b894'),Color('#78aaa9')]
	if game.season==1: palette=[Color('#b9b78d'),Color('#b4a278'),Color('#d9ba7d'),Color('#cdb99c'),Color('#86abaa')]
	if game.season==2: palette=[Color('#d6ded1'),Color('#a8c0b0'),Color('#c9c8a6'),Color('#d0ccba'),Color('#95bbbd')]
	start_mesh()
	for t in game.tiles: tile(t)
	ground.mesh=surface.commit()
	start_mesh()
	for p in game.frontier():
		var center=world_pos(p)
		for i in range(6):
			var a=deg_to_rad(i*60-30); var b=deg_to_rad(i*60+30)
			var p1=center+Vector3(cos(a)*.88,.006,sin(a)*.88); var p2=center+Vector3(cos(b)*.88,.006,sin(b)*.88)
			var p3=center+Vector3(cos(b)*.91,.006,sin(b)*.91); var p4=center+Vector3(cos(a)*.91,.006,sin(a)*.91)
			quad(p1,p2,p3,p4,Color('#c6cbb9'))
	markers.mesh=surface.commit()
	show_preview()

func show_preview():
	if not preview or palette.is_empty(): return
	preview.visible=game.selected.x!=999 and not game.ended
	if not preview.visible: return
	var t={'q':game.selected.x,'r':game.selected.y,'edges':game.active_edges(),'kind':game.queue[game.chosen].kind}
	start_mesh(); tile(t,false)
	var center=world_pos(game.selected)
	for i in range(6):
		var other=game.get_tile(game.selected+game.DIRS[i])
		var color=Color('#f0d7a2')
		if other: color=Color('#598d73') if int(t.edges[i])==int(other.edges[(i+3)%6]) else Color('#bd8c7b')
		var a=deg_to_rad(i*60-30); var b=deg_to_rad(i*60+30)
		quad(center+Vector3(cos(a)*.93,.23,sin(a)*.93),center+Vector3(cos(b)*.93,.23,sin(b)*.93),center+Vector3(cos(b),.23,sin(b)),center+Vector3(cos(a),.23,sin(a)),color)
	preview.mesh=surface.commit()

func animate(dt,time):
	for rotor in mills: rotor.rotation.z+=dt*.65
	for i in range(boats.size()): boats[i].position.y=.24+sin(time*1.2+i)*.02; boats[i].rotation.y=sin(time*.25+i)*.14
