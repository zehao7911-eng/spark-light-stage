LITTLE METRO WORLD
3D HTML5 game featuring the supplied Blender train model.

Upload all files in this archive to the same directory on a static web host.
The main page is index.html. Keep the .glb, .js and .css files alongside it.

Controls:
Tap BRAKE when the next station glows. Tap GO to leave after boarding.
Drag to orbit, pinch or scroll to zoom. Switch cameras and time of day with the round buttons.
Sound is optional and begins only after you tap the sound button.
