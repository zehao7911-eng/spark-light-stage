extends SceneTree
var checks=0
var failures=0
func check(v,msg):
	checks+=1
	if not v:failures+=1;push_error(msg)
func _initialize():call_deferred('test')
func test():
	var G=load('res://garden.gd');var g=G.new()
	check(not g.wake(-1),'Invalid flower rejected');check(not g.wake(6),'Invalid flower rejected')
	for i in range(6):check(g.wake(i),'Every flower responds')
	check(g.wakes==6,'Wake count');check(g.awaken(),'Parade begins')
	for i in range(100):g.update(.1)
	check(g.bloom[0]>.99,'Flower opens smoothly');check(g.parade==0,'Burst expires')
	var before=g.elapsed;g.paused=true;g.update(1);check(g.elapsed==before,'Pause freezes clock');check(not g.awaken(),'Paused interactions do not run')
	for i in range(4):g.next_season()
	check(g.season==0,'Four seasons wrap')
	var save=g.snapshot();var h=G.new();check(h.restore(JSON.parse_string(JSON.stringify(save))),'JSON save restores');check(abs(h.elapsed-g.elapsed)<.000001 and abs(h.bloom[0]-g.bloom[0])<.000001 and h.paused==g.paused,'State round trip')
	for key in ['bloom','target','elapsed','season','parade']:
		var bad=save.duplicate(true);bad[key]=[1] if key in ['bloom','target'] else -1;check(not h.restore(bad),'Bad save rejected: '+key)
	var game=load('res://main.tscn').instantiate();root.add_child(game);game.g.paused=false
	for dims in [Vector2i(320,480),Vector2i(390,844),Vector2i(844,390),Vector2i(640,360),Vector2i(1280,720)]:
		root.size=dims;await process_frame;game.layout()
		var rs=[]
		for b in game.buttons:
			var r=Rect2(b.position,b.size);check(Rect2(Vector2.ZERO,game.view).encloses(r),'UI stays on screen');check(b.size.x>=44 and b.size.y>=44,'44px touch target')
			for other in rs:check(not r.intersects(other),'Controls do not overlap')
			rs.append(r)
		game.menu=true;game.layout();check(game.ui.get_child(game.ui.get_child_count()-1).get_rect().end.y<=game.view.y,'Menu fits short screens');game.menu=false
	game.layout();check(game.world.flowers.size()==6,'Six animated flowers');check(game.world.flies.size()==7,'Seven butterflies')
	game.menu=true;var t=game.g.elapsed;await create_timer(.12).timeout;check(game.g.elapsed==t,'Menu freezes the world');game.menu=false
	game.lifecycle(['away']);await create_timer(.1).timeout;check(game.g.elapsed==t,'Background freezes world');game.lifecycle(['back']);check(not game.hidden_,'Foreground resumes')
	game.cinema=true;game.layout();check(game.buttons.size()==1,'Cinema has one exit control')
	var layout=load('res://garden_layout.gd')
	check(game.world.tree_crowns.size()==2,'Two independently bounded garden trees')
	for i in range(2):
		check(not layout.crown_rect(layout.TREE_SPECS[i]).intersects(layout.ROOF.grow(layout.ROOF_CLEARANCE)),'Planned canopy leaves roof clearance')
		var bounds=game.world.tree_crowns[i].mesh.get_aabb();var rect=Rect2(Vector2(bounds.position.x,bounds.position.z),Vector2(bounds.size.x,bounds.size.z)).grow(layout.WIND_MARGIN)
		check(not rect.intersects(layout.ROOF.grow(layout.ROOF_CLEARANCE)),'Actual generated crown including wind stays outside roof')
	check(game.world.landscape.grove_count==48,'Expanded forest uses 48 instanced trees')
	check(game.world.landscape.clouds.multimesh.instance_count==16,'Clouds fill the upper landscape')
	# Sample the entire camera loop at two aspect ratios, not just its keyframes.
	game.world.director=true;game.world.director_origin=0.0
	for dims in [Vector2(1280,720),Vector2(390,844)]:
		game.world.viewport_size=dims;game.vp.size=Vector2i(dims)
		for j in range(131):
			game.g.elapsed=j*.5;game.world.camera_initialized=false;game.world.update_camera();var cam=game.world.camera;var target=game.world.aim
			check(cam.position.is_finite() and target.is_finite(),'Finite camera spline')
			check(cam.position.y>=3.5 and cam.position.distance_to(target)>5.0,'Camera remains outside the miniature')
			check(Vector2(cam.position.x,cam.position.z).length()+1.5<game.world.landscape.min_forest_radius,'Outer forest stays beyond the swept camera corridor')
			var center=cam.unproject_position(target);check(center.distance_to(dims*.5)<2.0,'Camera subject stays centered')
	var a=game.world.director_sample(0);var b=game.world.director_sample(.999999)
	check(a[0].distance_to(b[0])<.001 and a[1].distance_to(b[1])<.001,'Seamless closed camera path')
	game.cinema=false;game.command(2);check(game.cinema,'Film action enters clean cinema');game.layout();check(game.buttons.size()==1,'Film has a clear return control')
	game.sound.stop();await create_timer(.15).timeout;game.free();await process_frame;await process_frame;print('MOSSBACK QA: '+str(checks)+' checks, '+str(failures)+' failures');quit(1 if failures else 0)
