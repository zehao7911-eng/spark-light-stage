extends RefCounted
# Small stories on the lake. Shared meshes, no physics or screen-space effects.
const B=preload('res://mesh.gd')
var ducks=[]
var duck_heads=[]
var wakes:MultiMeshInstance3D
var motes:MultiMeshInstance3D
var swimmers:MultiMeshInstance3D
var reeds:MultiMeshInstance3D
var chimes=[]
var ripple_mat:ShaderMaterial
var insect_mat:ShaderMaterial
var fish_mat:ShaderMaterial
var rush_mat:ShaderMaterial
var lotuses:MultiMeshInstance3D
var floating_petals:MultiMeshInstance3D
var elapsed=0.0
var touch_rings=[]
var water_taps=0
var feed_point=Vector3.ZERO
var feed_until=-1.0
func duck_path(t):
	# This sheltered crescent stays outside the turtle and the island banks.
	return Vector3(sin(t*.065)*4.8,.09,7.55+cos(t*.065)*.85)
func build(w):
	var feather=B.new()
	feather.ellipsoid(Vector3(0,.17,0),Vector3(.32,.24,.49),Color('#f2e8c9'),16,9)
	feather.ellipsoid(Vector3(-.23,.22,-.06),Vector3(.105,.13,.29),Color('#d3c7a4'),12,7)
	feather.ellipsoid(Vector3(.23,.22,-.06),Vector3(.105,.13,.29),Color('#d3c7a4'),12,7)
	feather.ellipsoid(Vector3(0,.24,-.41),Vector3(.12,.12,.22),Color('#eee2bd'),10,6)
	var body_mesh=feather.mesh(w.paper)
	var face=B.new();face.ellipsoid(Vector3(0,.46,.25),Vector3(.205,.22,.23),Color('#f5edcf'),16,9)
	face.ellipsoid(Vector3(0,.405,.47),Vector3(.13,.045,.145),Color('#dda15f'),12,6)
	for side in [-1,1]:
		face.ellipsoid(Vector3(side*.175,.50,.34),Vector3(.025,.032,.025),Color('#354f48'),8,5)
		face.ellipsoid(Vector3(side*.177,.512,.359),Vector3(.008,.009,.007),Color('#fff9e5'),5,3)
	var face_mesh=face.mesh(w.paper)
	for i in range(5):
		var root=Node3D.new();w.add_child(root);var body=MeshInstance3D.new();body.mesh=body_mesh;root.add_child(body)
		var head=MeshInstance3D.new();head.mesh=face_mesh;root.add_child(head);duck_heads.append(head)
		root.scale=Vector3.ONE*(1.0 if i==0 else .43+.025*i);ducks.append(root)
	# Low alpha single-batch surface rings for ducks, fish and waterfall spray.
	ripple_mat=w.material('res://ripple.gdshader');var ring=B.new()
	for i in range(40):
		var a=i*TAU/40;var c=(i+1)*TAU/40
		ring.quad(Vector3(cos(a),0,sin(a)),Vector3(cos(c),0,sin(c)),Vector3(cos(c)*.95,0,sin(c)*.95),Vector3(cos(a)*.95,0,sin(a)*.95),Color.WHITE)
	wakes=instances(w,ring.mesh(ripple_mat),46,true)
	# Slender silver-orange fish silhouettes just below the surface.
	fish_mat=w.material('res://lakefish.gdshader');var fish=B.new()
	fish.ellipsoid(Vector3.ZERO,Vector3(.10,.025,.30),Color('#d4b085'),10,5)
	fish.triangle(Vector3(0,0,-.24),Vector3(-.13,0,-.43),Vector3(.13,0,-.43),Color('#e4c7a3'))
	fish.ellipsoid(Vector3(0,.01,.16),Vector3(.07,.02,.06),Color('#eae0b9'),8,4)
	swimmers=instances(w,fish.mesh(fish_mat),12,false)
	# Four dragonflies with delicate crossing wings, hovering above the lilies.
	insect_mat=w.material('res://paper.gdshader');var insect=B.new()
	insect.tube(Vector3(0,0,-.20),Vector3(0,0,.14),.017,Color('#4b9694'),6)
	insect.ellipsoid(Vector3(0,0,.16),Vector3(.035,.028,.035),Color('#d3b97c'),8,5)
	for side in [-1,1]:
		for z in [-.07,.04]:insect.ellipsoid(Vector3(side*.135,.015,z),Vector3(.16,.006,.045),Color('#d4e5d8'),10,4)
	motes=instances(w,insect.mesh(insect_mat),4,false)
	# Reeds at the waterline sway at their tips, separate from the fixed banks.
	var rush=B.new()
	for j in range(5):
		var a=j*2.4;var tip=Vector3(sin(a)*.19,.65+j*.08,cos(a)*.16);rush.tube(Vector3.ZERO,tip,.012,Color('#638f7c'),4)
		if j%2==0:rush.ellipsoid(tip,Vector3(.035,.12,.035),Color('#9c8467'),8,5)
	rush_mat=w.material('res://paper.gdshader');rush_mat.set_shader_parameter('bend_start',0.0);rush_mat.set_shader_parameter('breeze',.055)
	reeds=instances(w,rush.mesh(rush_mat),22,false)
	for i in range(22):
		var a=i*2.4;var p=Vector3(cos(a)*(6.4+i%3*.45),.015,sin(a)*(5.0+i%3*.30));reeds.multimesh.set_instance_transform(i,Transform3D(Basis(Vector3.UP,a),p))
	# Rounded, cupped petals sit above a notched lily pad, never on top of a bank.
	var lily=B.new()
	for i in range(28):
		var a=.20+i*(TAU-.40)/28;var c=.20+(i+1)*(TAU-.40)/28
		lily.triangle(Vector3.ZERO,Vector3(cos(a)*.52,.005,sin(a)*.42),Vector3(cos(c)*.52,.005,sin(c)*.42),Color('#699b7d'))
	for layer in range(2):
		for i in range(9):
			var a=i*TAU/9+layer*.3;var r=.12-layer*.025;var p=Vector3(cos(a)*r,.10+layer*.065,sin(a)*r)
			lily.ellipsoid(p,Vector3(.13-layer*.025,.055,.12-layer*.025),Color('#edc9ba').lightened(layer*.06),10,5)
	lily.ellipsoid(Vector3(0,.23,0),Vector3(.07,.04,.07),Color('#e7bd6f'),10,5)
	lotuses=instances(w,lily.mesh(w.paper),8,false)
	var petal=B.new();petal.ellipsoid(Vector3.ZERO,Vector3(.065,.008,.11),Color('#e4b8a4'),9,4)
	floating_petals=instances(w,petal.mesh(w.paper),18,false)
	build_cottage_details(w)
func instances(w,mesh,count_,custom):
	var n=MultiMeshInstance3D.new();n.multimesh=MultiMesh.new();n.multimesh.transform_format=MultiMesh.TRANSFORM_3D;n.multimesh.use_custom_data=custom;n.multimesh.mesh=mesh;n.multimesh.instance_count=count_;w.add_child(n);return n
func build_cottage_details(w):
	var home=w.point(-.65,-.75,.03);var trim=B.new()
	# Recessed door panels, brass hinges, a porch mat and finer gable trim.
	for y in [.19,.51]:trim.box(home+Vector3(0,y,.596),Vector3(.27,.23,.012),Color('#597e77'))
	for y in [.22,.65]:trim.box(home+Vector3(-.16,y,.61),Vector3(.055,.025,.016),Color('#c4a469'))
	trim.box(home+Vector3(0,.035,.86),Vector3(.40,.025,.20),Color('#9b9175'))
	for side in [-1,1]:trim.tube(home+Vector3(0,1.91,.59),home+Vector3(side*.64,1.10,.59),.025,Color('#d8bd96'),6)
	# A wind chime hangs from the right eave, safely in front of the wall.
	var anchor=home+Vector3(.57,1.03,.73)
	trim.tube(anchor,anchor+Vector3(0,-.13,0),.007,Color('#8c947b'))
	trim.ellipsoid(anchor+Vector3(0,-.14,0),Vector3(.12,.025,.09),Color('#bd9a64'),12,6)
	w.add_mesh(trim,w.beast,w.paper)
	for i in range(4):
		var root=Node3D.new();root.position=anchor+Vector3(sin(i*TAU/4)*.08,-.16,cos(i*TAU/4)*.06);w.beast.add_child(root)
		var b=B.new();b.tube(Vector3.ZERO,Vector3(0,-.19-i*.023,0),.013,Color('#d7bd83'),6);w.add_mesh(b,root,w.paper);chimes.append(root)
func splash(p,t):
	if not p.is_finite() or absf(p.x)>6 or p.z<4.7 or p.z>10.0:return false
	if touch_rings.size()>=4:touch_rings.pop_front()
	touch_rings.append([Vector3(p.x,.024,p.z),t]);water_taps+=1;feed_point=p;feed_until=t+4.5;return true
func update(w):
	var t=w.g.elapsed;elapsed=t
	ripple_mat.set_shader_parameter('night',w.night_weight);fish_mat.set_shader_parameter('night',w.night_weight);insect_mat.set_shader_parameter('night',w.night_weight)
	rush_mat.set_shader_parameter('clock',t);rush_mat.set_shader_parameter('night',w.night_weight);rush_mat.set_shader_parameter('foliage_tint',w.foliage_tint);rush_mat.set_shader_parameter('foliage_mix',w.foliage_mix)
	for i in range(8):
		var a=i*2.4;var p=Vector3(cos(a)*(6.1+i%2*.4),.04+sin(t*.8+i)*.012,sin(a)*5.2)
		lotuses.multimesh.set_instance_transform(i,Transform3D(Basis.from_euler(Vector3(sin(t*.7+i)*.018,a+sin(t*.15+i)*.08,cos(t*.6+i)*.018)),p))
	for i in range(18):
		var a=i*2.4+t*.013;var r=5.6+i%4*.65;var p=Vector3(cos(a)*r,.035+sin(t*.7+i)*.005,sin(a)*r*.78)
		floating_petals.multimesh.set_instance_transform(i,Transform3D(Basis.from_euler(Vector3(sin(t*.5+i)*.06,a+t*.025,0)),p))
	for i in range(5):
		var lag=t-i*1.7;var p=duck_path(lag);var ahead=duck_path(lag+.1)-p
		if i>0:p.x+=sin(i*2.4)*.22;p.z+=cos(i*2.4)*.15
		p.y+=sin(t*1.4+i)*.018;ducks[i].position=p;ducks[i].rotation=Vector3(0,atan2(ahead.x,ahead.z),sin(t*2+i)*.025)
		# An occasional little dip, then an unhurried recovery.
		duck_heads[i].rotation.x=pow(maxf(0,sin(t*.23+i*1.9)),18)*.65
		for j in range(3):
			var k=i*3+j;var q=fposmod(t*.45+j/3.0,1.0);var r=.25+q*(.70 if i==0 else .35)
			wakes.multimesh.set_instance_transform(k,Transform3D(Basis.IDENTITY.scaled(Vector3(r,1,r*.65)),p+Vector3(-ahead.x*4,.022-p.y,-ahead.z*4)))
			wakes.multimesh.set_instance_custom_data(k,Color(1-q,0,0,0))
	for i in range(12):
		var a=t*.09+i*2.4;var p=Vector3(sin(a)*(5.2+i%2*.4),.035,cos(a)*1.2+5.9)
		var heading=atan2(cos(a)*(5.2+i%2*.4),-sin(a)*1.2)
		if t<feed_until:
			var phase_=clampf((4.5-feed_until+t)/4.5,0,1);var weight=pow(sin(phase_*PI),.65)*.82;var angle_=t*.8+i*TAU/12;var target=Vector3(feed_point.x+cos(angle_)*(.35+i%3*.12),.035,feed_point.z+sin(angle_)*.4);var delta_=target-p;p=p.lerp(target,weight);heading=lerp_angle(heading,atan2(delta_.x,delta_.z),weight)
		swimmers.multimesh.set_instance_transform(i,Transform3D(Basis(Vector3.UP,heading).scaled(Vector3.ONE*(.6+i%3*.15)),p))
	for i in range(4):
		var a=t*.24+i*2.4;var p=Vector3(cos(a)*(5.5+i*.3),.7+sin(t*1.4+i)*.12,sin(a)*4.5)
		motes.multimesh.set_instance_transform(i,Transform3D(Basis.from_euler(Vector3(0,-a,sin(t*38+i)*.14)),p))
	for i in range(19):
		var q=fposmod(t*.28+i*.17,1.0);var p=Vector3(sin(i*2.4)*6.7,.021,cos(i*2.4)*5.6);var r=.05+q*.65
		wakes.multimesh.set_instance_transform(15+i,Transform3D(Basis.IDENTITY.scaled(Vector3(r,1,r)),p));wakes.multimesh.set_instance_custom_data(15+i,Color((1-q)*.5,0,0,0))
	for i in range(12):
		var slot=int(i/3);var delay_=i%3*.20;var active_=slot<touch_rings.size();var age=t-touch_rings[slot][1]-delay_ if active_ else -1.0
		var fade=0.0;var r=.001;var p=Vector3.ZERO
		if active_ and age>=0 and age<3.0:r=.10+age*.65;fade=pow(1-age/3.0,1.7)*.95;p=touch_rings[slot][0]
		wakes.multimesh.set_instance_transform(34+i,Transform3D(Basis.IDENTITY.scaled(Vector3(r,1,r)),p));wakes.multimesh.set_instance_custom_data(34+i,Color(fade,0,0,0))
	for i in range(chimes.size()):chimes[i].rotation=Vector3(sin(t*1.7+i)*.10,0,sin(t*1.1+i)*.12)
