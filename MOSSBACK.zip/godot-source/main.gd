extends Node2D
const Garden=preload('res://garden.gd')
const World=preload('res://world.gd')
const Action=preload('res://action.gd')
const FONT=preload('res://fonts/Bitter.ttf')
const SAVE='mossback-garden.v1'
var g=Garden.new()
var vp:SubViewport
var world
var image:TextureRect
var ui:Control
var raw=Vector2.ZERO
var density=1.0
var view=Vector2.ZERO
var safe=Vector2.ZERO
var buttons=[]
var cinema=false
var menu=false
var hidden_=false
var callback
var drag=false
var moved=0.0
var start=Vector2.ZERO
var last=Vector2.ZERO
var save_time=0.0
var snapshot_time=0.0
var cue:Label
var toast='Drag to explore. Film to watch.'
var toast_time=9.0
var sound:AudioStreamPlayer
var taking_photo=false
var redraw_frames=3
var last_photo={}
var cinema_idle=0.0
func _ready():
	Engine.max_fps=45;load_game();vp=SubViewport.new();vp.own_world_3d=true;vp.msaa_3d=Viewport.MSAA_2X;vp.render_target_update_mode=SubViewport.UPDATE_ALWAYS;add_child(vp)
	world=World.new();world.g=g;vp.add_child(world);image=TextureRect.new();image.expand_mode=TextureRect.EXPAND_IGNORE_SIZE;image.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR;image.stretch_mode=TextureRect.STRETCH_SCALE;image.texture=vp.get_texture();image.mouse_filter=Control.MOUSE_FILTER_IGNORE;add_child(image)
	ui=Control.new();ui.mouse_filter=Control.MOUSE_FILTER_IGNORE;add_child(ui)
	sound=AudioStreamPlayer.new();if ResourceLoader.exists('res://audio/chime.wav'):sound.stream=load('res://audio/chime.wav')
	add_child(sound);layout();world.director_origin=g.elapsed;world.director=g.orbit and not g.calm;world.update_world()
	if OS.has_feature('web'):
		callback=JavaScriptBridge.create_callback(lifecycle);JavaScriptBridge.get_interface('window').mossLifecycle=callback;JavaScriptBridge.eval('window.mossReady && window.mossReady()')
	web_snapshot()
func label_(s,p,sz,font_size=16):
	var l=Label.new();l.text=s;l.position=p;l.size=sz;var fv=FontVariation.new();fv.base_font=FONT;fv.variation_embolden=.55;l.add_theme_font_override('font',fv);l.add_theme_font_size_override('font_size',font_size);l.add_theme_color_override('font_color',Color('#ede9d5') if g.night else Color('#4b6257'));l.mouse_filter=Control.MOUSE_FILTER_IGNORE;ui.add_child(l);return l
func action(kind,caption,p,sz,fn):
	var b=Action.new();b.kind=kind;b.caption=caption;b.position=p;b.size=sz;b.tooltip_text=caption if caption!='' else kind;b.pressed.connect(fn,CONNECT_DEFERRED);ui.add_child(b);buttons.append(b);return b
func layout():
	cinema_idle=0.0;ui.modulate.a=1.0;redraw_frames=3
	raw=get_viewport_rect().size;density=1.0
	if OS.has_feature('web'):density=maxf(1,float(JavaScriptBridge.eval('window.devicePixelRatio || 1')))
	var insets=[0,0,0,0]
	if OS.has_feature('web'):
		var ins=JSON.parse_string(str(JavaScriptBridge.eval('JSON.stringify(["--sal","--sat","--sar","--sab"].map(k=>parseFloat(getComputedStyle(document.documentElement).getPropertyValue(k))||0))')))
		if ins is Array:insets=ins
	safe=Vector2(insets[0],insets[1]);ui.position=safe*density;ui.scale=Vector2.ONE*density;view=raw/density-Vector2(insets[0]+insets[2],insets[1]+insets[3]);image.size=raw
	if not taking_photo:vp.size=Vector2i((raw*minf(1.0,(900.0 if raw.y>raw.x else 1280.0)/maxf(raw.x,raw.y))).round())
	world.viewport_size=Vector2(vp.size)
	for c in ui.get_children():c.free()
	buttons=[]
	if cinema:
		action('back','',Vector2(16,16),Vector2(46,46),func():cinema=false;layout());return
	label_('MOSSBACK',Vector2(20,22),Vector2(210,35),20 if view.x<430 else 25)
	if view.x>430:label_('A world that takes its time.',Vector2(26,59),Vector2(300,25),13)
	var season=Button.new();season.text=Garden.SEASONS[g.season]+'  ›';season.position=Vector2(view.x-166,25);season.size=Vector2(95,44);season.flat=true;season.add_theme_color_override('font_color',Color('#ede9d5') if g.night else Color('#4b6257'));season.pressed.connect(func():g.next_season();chime();save_game();layout(),CONNECT_DEFERRED);ui.add_child(season);buttons.append(season)
	action('menu','',Vector2(view.x-60,25),Vector2(44,44),func():menu=not menu;drag=false;layout())
	var width_=minf(370,view.x-32);var x=(view.x-width_)/2;var y=view.y-99
	var names=['Bloom','Rain','Film','Photo'];var kinds=['bloom','rain','film','photo']
	for i in range(4):
		var id=i;var b=action(kinds[i],names[i],Vector2(x+i*width_/4,y),Vector2(width_/4-7,72),func():command(id))
		b.active_=(g.rain and i==1);b.queue_redraw()
	cue=label_(toast,Vector2(10,y-33),Vector2(view.x-20,25),12);cue.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	if menu:
		var panel=Panel.new();panel.position=Vector2(view.x-218,82);panel.size=Vector2(200,minf(328,view.y-100));var sb=StyleBoxFlat.new();sb.bg_color=Color('#f6f1e8');sb.set_corner_radius_all(18);sb.shadow_color=Color(0.2,.3,.2,.1);sb.shadow_size=12;panel.add_theme_stylebox_override('panel',sb);ui.add_child(panel);var scroll=ScrollContainer.new();scroll.position=Vector2(5,5);scroll.size=panel.size-Vector2(10,10);panel.add_child(scroll);var list=Control.new();list.custom_minimum_size=Vector2(180,320);scroll.add_child(list)
		var labels=['Night','Sound','Calm','Pause','Cinema','Close'];var values=[g.night,not g.muted,g.calm,g.paused,false,false]
		for i in range(6):
			var id=i;var b=Button.new();b.position=Vector2(10,7+i*52);b.size=Vector2(180,46);b.text=labels[i]+(('  On' if values[i] else '  Off') if i<4 else '');b.flat=true;b.add_theme_color_override('font_color',Color('#4b6257'));list.add_child(b);b.pressed.connect(func():setting(id),CONNECT_DEFERRED)
func chime():
	if not g.muted and sound.stream:sound.pitch_scale=1+g.season*.06;sound.volume_db=-17;sound.play()
func command(i):
	match i:
		0:g.awaken();toast='A little world, wide awake.';toast_time=4;chime()
		1:g.rain=not g.rain;toast='A passing shower.' if g.rain else 'Clear skies.';toast_time=3;chime()
		2:cinema=true;menu=false;world.begin_director();g.awaken();chime()
		3:photo()
	save_game();layout();web_snapshot()
func setting(i):
	match i:
		0:g.night=not g.night
		1:g.muted=not g.muted;if g.muted:sound.stop()
		2:g.calm=not g.calm
		3:g.paused=not g.paused
		4:cinema=true;menu=false;world.begin_director();g.awaken();chime()
		5:menu=false
	drag=false;save_game();layout()
	if i==0:redraw_frames=100
func _process(dt):
	if get_viewport_rect().size!=raw:layout()
	cinema_idle+=dt;ui.modulate.a=1.0 if not cinema or cinema_idle<2.5 else 0.0
	world.camera_dt=minf(dt,.05);world.director=cinema or (g.orbit and world.focus==0 and not g.calm)
	var active_=not hidden_ and not menu and not g.paused
	if active_:
		g.update(dt);world.update_world();vp.render_target_update_mode=SubViewport.UPDATE_ALWAYS
	else:
		if redraw_frames>0 or taking_photo:world.update_world();vp.render_target_update_mode=SubViewport.UPDATE_ONCE;redraw_frames-=1
		else:vp.render_target_update_mode=SubViewport.UPDATE_DISABLED
	toast_time=maxf(0,toast_time-dt)
	if is_instance_valid(cue):cue.visible=toast_time>0
	save_time+=dt;snapshot_time+=dt
	if save_time>4:save_time=0;save_game()
	if snapshot_time>.5:snapshot_time=0;web_snapshot()
func _unhandled_input(e):
	if e is InputEventMouseMotion or (e is InputEventMouseButton and e.pressed):cinema_idle=0.0
	if e is InputEventKey and e.pressed and not e.echo:
		if e.keycode==KEY_ESCAPE:cinema=not cinema;menu=false;layout()
		if e.keycode==KEY_SPACE:command(0)
		if e.keycode==KEY_V:g.orbit=true;world.focus=(world.focus+1)%3;world.director_origin=g.elapsed
	if menu or hidden_ or g.paused:return
	if e is InputEventMouseButton and e.button_index==MOUSE_BUTTON_LEFT:
		if e.pressed:drag=true;moved=0;start=e.position;last=start
		elif drag:
			drag=false
			if moved<14:
				var p=e.position/raw*Vector2(vp.size);var best=-1;var distance_=110.0
				for i in range(6):
					var d=world.flower_screen(i).distance_to(p)
					if d<distance_:best=i;distance_=d
				if best>=0:g.wake(best);world.touch_index=best;world.touch_until=g.elapsed+2.5;chime();save_game();toast='';web_snapshot()
				else:
					if not world.lake_tap(p):world.pet_until=g.elapsed+1.3
					chime();web_snapshot()
	if e is InputEventMouseMotion and drag:
		var d=(e.position-last)/density;last=e.position;moved+=d.length();world.yaw-=d.x*.006;world.pitch=clampf(world.pitch+d.y*.004,.2,.85);g.orbit=false
func lifecycle(args):
	var s=str(args[0]) if args.size()>0 else 'save';save_game();drag=false
	if s=='away':hidden_=true;sound.stop()
	if s=='back':hidden_=false;snapshot_time=0
func save_game():
	var s=JSON.stringify(g.snapshot())
	if OS.has_feature('web'):JavaScriptBridge.eval('localStorage.setItem('+JSON.stringify(SAVE)+','+JSON.stringify(s)+')')
	else:
		var f=FileAccess.open('user://garden.json',FileAccess.WRITE);if f:f.store_string(s)
func load_game():
	var s=''
	if OS.has_feature('web'):s=str(JavaScriptBridge.eval('localStorage.getItem('+JSON.stringify(SAVE)+') || ""'))
	elif FileAccess.file_exists('user://garden.json'):s=FileAccess.get_file_as_string('user://garden.json')
	if s!='':
		var d=JSON.parse_string(s);if d is Dictionary:g.restore(d)
func web_snapshot():
	if not OS.has_feature('web'):return
	var s=g.snapshot();s['view']=[view.x,view.y];s['render']=[vp.size.x,vp.size.y];s['cinema']=cinema;s['menu']=menu;s['focus']=world.focus;s['director']=world.director;s['shot_phase']=world.director_phase;s['revision']='waterlight-5';s['stats']=world.stats;s['diagnostics']={'cpu_ms':Performance.get_monitor(Performance.TIME_PROCESS)*1000,'delta':get_process_delta_time(),'draw_calls':Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME),'primitives':Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME),'adapter':RenderingServer.get_video_adapter_name(),'focus':JavaScriptBridge.eval('document.hasFocus()'),'hidden':hidden_};s['water_taps']=world.living.water_taps;s['last_photo']=last_photo;s['flowers']=[]
	for i in range(6):
		var p=world.flower_screen(i)/Vector2(vp.size)*(raw/density);s.flowers.append([p.x,p.y])
	s['buttons']=[]
	for b in buttons:s.buttons.append([b.tooltip_text,b.position.x+safe.x,b.position.y+safe.y,b.size.x,b.size.y])
	JavaScriptBridge.eval('window.mossSnapshot && window.mossSnapshot('+JSON.stringify(s)+')')
func photo():
	if taking_photo:return
	taking_photo=true;g.photos+=1;save_game();var old=vp.size;vp.size=Vector2i((raw*minf(2,1600.0/maxf(raw.x,raw.y))).round());world.viewport_size=Vector2(vp.size);world.update_world();vp.render_target_update_mode=SubViewport.UPDATE_ALWAYS
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var png=vp.get_texture().get_image().save_png_to_buffer();last_photo={'width':vp.size.x,'height':vp.size.y,'bytes':png.size(),'signature':png.slice(0,8).hex_encode()}
	if OS.has_feature('web'):JavaScriptBridge.eval('(()=>{const s=atob('+JSON.stringify(Marshalls.raw_to_base64(png))+');const b=Uint8Array.from(s,c=>c.charCodeAt(0));const u=URL.createObjectURL(new Blob([b],{type:"image/png"}));const a=document.createElement("a");a.href=u;a.download="MOSSBACK-garden.png";a.click();setTimeout(()=>URL.revokeObjectURL(u),1000)})()')
	else:FileAccess.open('user://MOSSBACK-garden.png',FileAccess.WRITE).store_buffer(png)
	vp.size=old;world.viewport_size=Vector2(old);taking_photo=false;toast='A small moment, kept.';toast_time=4
