extends Button
var kind='bloom'
var caption='Bloom'
var active_=false
var ink=Color('#53685e')
func _ready():
	flat=true;mouse_default_cursor_shape=Control.CURSOR_POINTING_HAND;focus_mode=Control.FOCUS_ALL
func _draw():
	var bg=StyleBoxFlat.new();bg.bg_color=Color('#e8e7d8') if active_ else Color('#f6f1e4');bg.border_color=Color('#c2c9b4');bg.set_border_width_all(1);bg.set_corner_radius_all(18);draw_style_box(bg,Rect2(Vector2.ZERO,size))
	if is_hovered() or has_focus():draw_style_box(bg,Rect2(Vector2(2,2),size-Vector2(4,4)))
	var p=Vector2(size.x*.5,24);var col=ink
	match kind:
		'bloom':
			for i in range(6):draw_circle(p+Vector2.from_angle(i*TAU/6)*7,5,Color('#d09d94'))
			draw_circle(p,4,Color('#b8985e'))
		'rain':
			draw_circle(p+Vector2(-5,-3),6,col);draw_circle(p+Vector2(4,-6),8,col);draw_line(p+Vector2(-9,1),p+Vector2(10,1),col,4,true)
			for i in range(3):draw_line(p+Vector2(-6+i*6,7),p+Vector2(-8+i*6,12),col,1.5,true)
		'view':
			draw_arc(p,11,.3,TAU-.5,32,col,1.5,true);draw_line(p+Vector2(11,2),p+Vector2(14,-4),col,1.5,true);draw_line(p+Vector2(11,2),p+Vector2(5,-1),col,1.5,true);draw_circle(p,3,col)
		'photo':
			draw_rect(Rect2(p-Vector2(12,8),Vector2(24,17)),col,false,1.5);draw_circle(p,5,col,false,1.5,true);draw_line(p+Vector2(-5,-11),p+Vector2(5,-11),col,2,true)
		'menu':
			for i in range(3):draw_circle(p+Vector2((i-1)*7,0),1.8,col)
		'back':
			draw_line(p+Vector2(5,-8),p+Vector2(-4,0),col,1.8,true);draw_line(p+Vector2(-4,0),p+Vector2(5,8),col,1.8,true)
		'film':
			draw_rect(Rect2(p-Vector2(12,9),Vector2(24,18)),col,false,1.4);draw_colored_polygon(PackedVector2Array([p+Vector2(-3,-5),p+Vector2(5,0),p+Vector2(-3,5)]),col)
	if caption!='':draw_string(ThemeDB.fallback_font,Vector2((size.x-ThemeDB.fallback_font.get_string_size(caption,HORIZONTAL_ALIGNMENT_LEFT,-1,12).x)/2,size.y-12),caption,HORIZONTAL_ALIGNMENT_LEFT,-1,12,col)
