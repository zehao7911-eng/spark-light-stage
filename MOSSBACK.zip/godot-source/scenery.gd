extends RefCounted
const B=preload('res://mesh.gd')
func build(w):
	var rng=RandomNumberGenerator.new();rng.seed=87123
	var base=B.new();base.box(Vector3(0,-.2,0),Vector3(250,.25,250),Color.WHITE);w.ground_mat=w.material('res://ground.gdshader');w.add_mesh(base,w,w.ground_mat)
	var pool=B.new();pool.quad(Vector3(-190,.005,-190),Vector3(190,.005,-190),Vector3(190,.005,190),Vector3(-190,.005,190),Color.WHITE);w.lagoon_mat=w.material('res://lagoon.gdshader');w.add_mesh(pool,w,w.lagoon_mat)
	var shadow=MeshInstance3D.new();var plane=PlaneMesh.new();plane.size=Vector2(9.0,7.0);shadow.mesh=plane;shadow.position=Vector3(0,.02,0);shadow.material_override=w.material('res://shadow.gdshader');w.add_child(shadow)
	var bank=B.new();var reeds=B.new();var lilies=B.new()
	for i in range(38):
		var a=i*TAU/38;var p=Vector3(cos(a)*8.65,-.025,sin(a)*6.65)
		bank.ellipsoid(p,Vector3(.2+rng.randf()*.27,.10,.17+rng.randf()*.19),Color('#d6d7bc'),9,5)
		if i%3==0:
			for j in range(7):
				var q=p+Vector3(rng.randf_range(-.3,.3),0,rng.randf_range(-.3,.3));var tip=q+Vector3(rng.randf_range(-.2,.2),rng.randf_range(.2,.6),.06);reeds.tube(q,tip,.016,Color('#789c86'),4)
	for i in range(17):
		var a=i*2.4;var p=Vector3(cos(a)*(5.5+rng.randf()*1.5),.025,sin(a)*(4.1+rng.randf()*.6));var r=.16+rng.randf()*.25
		lilies.ellipsoid(p,Vector3(r,.018,r*.8),Color('#7ca88d'),12,4)
		if i%3==0:
			for j in range(7):
				var ang=j*TAU/7;lilies.ellipsoid(p+Vector3(cos(ang)*.085,.075,sin(ang)*.085),Vector3(.075,.035,.065),Color('#f4d4bf'),7,4)
			lilies.ellipsoid(p+Vector3(0,.1,0),Vector3(.045,.03,.045),Color('#e7bf72'),7,4)
	w.add_mesh(bank,w,w.paper);w.add_mesh(reeds,w,w.leaf);w.add_mesh(lilies,w,w.paper)
	# Small plants in distinct beds leave the walking trail and water readable.
	var meadow=B.new();var buds=B.new();var moss=B.new();var stems=B.new()
	for i in range(190):
		var x=rng.randf_range(-3.45,3.45);var z=rng.randf_range(-2.5,2.5)
		if pow(x/3.5,2)+pow(z/2.7,2)>.96:continue
		if abs(x-(-.55+sin((z+1.8)/.165*.3)*.7))<.31:continue
		if Vector2(x-1.55,z-.65).length()<1.08:continue
		if x> -1.5 and x<.2 and z> -1.5 and z<.0:continue
		var p=w.point(x,z,.06);var col=[Color('#8cab80'),Color('#aac58b'),Color('#b5c294')][i%3]
		moss.ellipsoid(p,Vector3(.16,.055,.13),col,8,4)
		for j in range(3):
			var a=j*TAU/3+i;var tip=p+Vector3(cos(a)*.095,.12+rng.randf()*.17,sin(a)*.095);stems.tube(p,tip,.008,Color('#739774'),3);meadow.ellipsoid(tip,Vector3(.055,.025,.105),col,7,4)
		if i%3==0:
			var top=p+Vector3(0,.26+rng.randf()*.15,0);stems.tube(p,top,.009,Color('#779679'),4)
			var c=[Color('#eac1b5'),Color('#f2e0ad'),Color('#cfb9d0')][int(i/3)%3]
			for k in range(5):buds.ellipsoid(top+Vector3(cos(k*TAU/5)*.039,0,sin(k*TAU/5)*.039),Vector3(.04,.025,.04),c,6,4)
			buds.ellipsoid(top+Vector3(0,.018,0),Vector3(.018,.018,.018),Color('#cda875'),5,3)
	w.add_mesh(moss,w.beast,w.leaf);w.add_mesh(stems,w.beast,w.paper);w.add_mesh(meadow,w.beast,w.leaf);w.add_mesh(buds,w.beast,w.paper)
	# A real gabled tiled roof, a round attic window, flower boxes and woodwork.
	var home=w.point(-.65,-.75,.03);var house=B.new();var roof=B.new();var ink=Color('#6b7769')
	house.triangle(home+Vector3(-.65,1.08,.557),home+Vector3(.65,1.08,.557),home+Vector3(0,1.91,.557),Color('#f0dfb9'))
	house.triangle(home+Vector3(-.65,1.08,-.557),home+Vector3(0,1.91,-.557),home+Vector3(.65,1.08,-.557),Color('#f0dfb9'))
	for side in [-1,1]:
		for row in range(8):
			for col in range(9):
				var x0=side*(.02+row*.112);var x1=side*(.02+(row+1)*.112);var z0=-.8+col*.18;var z1=z0+.19;var y0=1.99-abs(x0)*.95;var y1=1.99-abs(x1)*.95
				var c=Color('#bc7f70').lightened(rng.randf_range(-.04,.11));roof.quad(home+Vector3(x0,y0,z0),home+Vector3(x1,y1,z0),home+Vector3(x1,y1,z1),home+Vector3(x0,y0,z1),c)
		for j in range(9):roof.tube(home+Vector3(side*.91,1.1,-.81+j*.18),home+Vector3(side*.91,1.1,-.65+j*.18),.027,Color('#9b6e63'),5)
	for i in range(11):roof.ellipsoid(home+Vector3(0,2.0,-.78+i*.15),Vector3(.07,.04,.09),Color('#d99b7c'),8,4)
	house.ellipsoid(home+Vector3(0,1.45,.574),Vector3(.19,.19,.019),ink,20,8);house.ellipsoid(home+Vector3(0,1.45,.598),Vector3(.145,.145,.008),Color('#d6c79b'),20,8)
	for d in [-1,1]:house.tube(home+Vector3(d*.13,1.45,.61),home+Vector3(-d*.13,1.45,.61),.012,ink,4)
	house.tube(home+Vector3(0,1.31,.61),home+Vector3(0,1.59,.61),.013,ink,4)
	for x in [-.64,.64]:house.box(home+Vector3(x,.53,.57),Vector3(.065,1.05,.065),Color('#a39373'))
	for j in range(8):house.tube(home+Vector3(-.6,.12+j*.11,.573),home+Vector3(.6,.12+j*.11,.573),.006,Color('#d7ccab'),3)
	for j in range(3):house.box(home+Vector3(0,.03-j*.04,.66+j*.1),Vector3(.55,.07,.15),Color('#c6bea3'))
	for x in [-.44,.44]:
		for j in range(5):
			var p=home+Vector3(x+(j-2)*.065,.49,.69);house.ellipsoid(p,Vector3(.05,.04,.055),Color('#9eaf7f'),7,4);house.ellipsoid(p+Vector3(0,.07,0),Vector3(.04,.04,.04),Color('#e9af9b'),7,4)
	# A tiny bench, mushrooms, and porcelain watering can beside the front path.
	var bench=w.point(-1.5,1.55,.12)
	for x in [-.25,.25]:house.tube(bench+Vector3(x,0,0),bench+Vector3(x,.25,0),.025,ink,5)
	for j in range(3):house.box(bench+Vector3(0,.25,j*.08),Vector3(.68,.05,.06),Color('#c8ac88'))
	house.box(bench+Vector3(0,.49,-.03),Vector3(.68,.18,.04),Color('#c8ac88'))
	for i in range(6):
		var p=w.point(-2.9+i*.13,1.35+sin(i)*.11,.04);var h=.13+i%3*.045;house.tube(p,p+Vector3(0,h,0),.02,Color('#e4d8b6'),6);house.ellipsoid(p+Vector3(0,h,0),Vector3(.1,.055,.1),Color('#cfa08d'),9,5)
	w.add_mesh(house,w.beast,w.paper);w.add_mesh(roof,w.beast,w.paper)
	# Steam and firefly instancing stay inexpensive on mobile.
	var s=B.new();s.ellipsoid(Vector3.ZERO,Vector3(.12,.10,.12),Color('#eee4cd'),10,6)
	w.smoke=MultiMeshInstance3D.new();w.smoke.multimesh=MultiMesh.new();w.smoke.multimesh.transform_format=MultiMesh.TRANSFORM_3D;w.smoke.multimesh.mesh=s.mesh(w.material('res://smoke.gdshader'));w.smoke.multimesh.use_custom_data=true;w.smoke.multimesh.instance_count=6;w.beast.add_child(w.smoke)
	var sparks=B.new();sparks.ellipsoid(Vector3.ZERO,Vector3(.022,.022,.022),Color('#ffda87'),7,5);w.fireflies=MultiMeshInstance3D.new();w.fireflies.multimesh=MultiMesh.new();w.fireflies.multimesh.transform_format=MultiMesh.TRANSFORM_3D;w.fireflies.multimesh.mesh=sparks.mesh(w.glow);w.fireflies.multimesh.instance_count=48;w.beast.add_child(w.fireflies)

	w.firefly_halos=MultiMeshInstance3D.new();w.firefly_halos.multimesh=MultiMesh.new();w.firefly_halos.multimesh.transform_format=MultiMesh.TRANSFORM_3D;var quad=QuadMesh.new();quad.size=Vector2(.28,.28);quad.material=w.material('res://aura.gdshader');w.firefly_halos.multimesh.mesh=quad;w.firefly_halos.multimesh.instance_count=48;w.beast.add_child(w.firefly_halos)
