extends RefCounted
const B=preload('res://mesh.gd')
var earth:ShaderMaterial
var leaves:ShaderMaterial
var clouds_material:ShaderMaterial
var cascade:ShaderMaterial
var clouds:MultiMeshInstance3D
var wheel:Node3D
var boats=[]
var sail_material:ShaderMaterial
var birds=[]
var bird_bodies:MultiMeshInstance3D
var bird_wings:MultiMeshInstance3D
var solid_bounds=[]
var grove_count=0
var min_forest_radius=INF
func build(w):
	var rng=RandomNumberGenerator.new();rng.seed=716024
	earth=w.material('res://distance.gdshader')
	leaves=w.material('res://distance.gdshader');leaves.set_shader_parameter('breeze',.12)
	var land=B.new();var rocks=B.new();var plants=B.new();var flowers=B.new()
	# Low islands close to the camera create parallax without blocking the tortoise.
	var islands=[[-16,-5,6.0,1.7,7.0],[18,-9,7.0,2.0,6.0],[-15,16,5.0,1.7,5.0],[-9,13,3.4,1.25,3.0],[9,12,3.1,1.35,3.0],[19,15,7.0,1.9,5.0],[0,-24,7.0,1.4,5.0],[12,-24,4.5,1.5,4.0],[-30,-20,8.0,2.2,6.0],[29,-26,10.0,2.3,9.0],[-32,26,9.0,2.0,7.0],[35,18,8.0,1.9,10.0]]
	for spec in islands:
		var center=Vector3(spec[0],-.55,spec[1]);var radii=Vector3(spec[2],spec[3],spec[4]);land.ellipsoid(center,radii,Color('#91af92'),20,8)
		for j in range(18):
			var a=j*TAU/18;var p=center+Vector3(cos(a)*radii.x*.95,.75,sin(a)*radii.z*.95);rocks.ellipsoid(p,Vector3(.4+rng.randf()*.4,.24,.35+rng.randf()*.4),Color('#b4c1aa'),9,5)
		for j in range(30):
			var a=rng.randf()*TAU;var r=rng.randf_range(.3,.87);var p=Vector3(center.x+cos(a)*radii.x*r,center.y+radii.y*sqrt(1-r*r),center.z+sin(a)*radii.z*r)
			for k in range(3):plants.tube(p,p+Vector3(sin(k*2.4)*.19,rng.randf_range(.28,.8),cos(k*2.4)*.19),.025,Color('#739f82'),4)
			if j%7==0:plants.ellipsoid(p+Vector3(0,.3,0),Vector3(.5,.35,.43),Color('#a5bc96'),10,6)
			if j%5==0:flowers.ellipsoid(p+Vector3(0,.5,0),Vector3(.14,.1,.14),Color('#e4c4ab'),8,5)
	# Forests live beyond the complete swept camera corridor, on their own islands.
	var roots=[]
	for i in range(16):
		var a=i*TAU/16+.19;var radius=43+rng.randf()*25;var center=Vector3(cos(a)*radius,-.7,sin(a)*radius);land.ellipsoid(center,Vector3(9.5,2.2,8.5),Color('#83a892'),16,7)
		for j in range(3):
			var p=center+Vector3(rng.randf_range(-3.5,3.5),1.9,rng.randf_range(-3.3,3.3));roots.append([p,rng.randf_range(.95,1.55),rng.randf()*TAU])
	grove_count=roots.size()
	for v in roots:min_forest_radius=minf(min_forest_radius,Vector2(v[0].x,v[0].z).length()-2.4*v[1])
	var wood=B.new();var crown=B.new();wood.tube(Vector3.ZERO,Vector3(.15,3.7,0),.22,Color('#8d8774'),9)
	for j in range(6):
		var a=j*2.4;var p=Vector3(cos(a)*1.15,3.8+sin(j*1.7)*.5,sin(a)*1.0);wood.tube(Vector3(.1,2.4,0),p,.10,Color('#8d8774'),6);crown.ellipsoid(p,Vector3(1.12,.8,1.0),Color('#91b395').lightened(.06*sin(j)),9,5)
	for mesh in [wood.mesh(earth),crown.mesh(leaves)]:
		var node=MultiMeshInstance3D.new();node.multimesh=MultiMesh.new();node.multimesh.transform_format=MultiMesh.TRANSFORM_3D;node.multimesh.mesh=mesh;node.multimesh.instance_count=roots.size();w.add_child(node)
		for i in range(roots.size()):
			var v=roots[i];node.multimesh.set_instance_transform(i,Transform3D(Basis(Vector3.UP,v[2]).scaled(Vector3.ONE*v[1]),v[0]))
	# Two continuous ridgelines replace isolated dome shapes, with a soft valley silhouette.
	for layer in range(2):
		var radius=86.0+layer*32;var width_=23.0+layer*6
		for i in range(128):
			for j in range(11):
				var ps=[]
				for q in [Vector2(i,j),Vector2(i+1,j),Vector2(i+1,j+1),Vector2(i,j+1)]:
					var ang=q.x*TAU/128;var cross_=q.y/11;var r=radius+(cross_-.5)*width_*2;var h=13.0+layer*5+sin(ang*3.0+layer)*5+sin(ang*7.0+layer)*2.5+sin(ang*11.0)*1.1
					ps.append(Vector3(cos(ang)*r,pow(maxf(0,sin(cross_*PI)),1.35)*h-.2,sin(ang)*r))
				land.quad(ps[0],ps[1],ps[2],ps[3],Color('#9ab7a7').lightened(layer*.08+j*.002))
	w.add_mesh(land,w,earth);w.add_mesh(rocks,w,earth);w.add_mesh(plants,w,leaves);w.add_mesh(flowers,w,earth)
	build_bridge(w);build_landmarks(w);build_clouds(w)
	w.stats['grove_trees']=grove_count
func build_bridge(w):
	var b=B.new();var origin=Vector3(3,.3,-23)
	for i in range(22):
		var x=-7+i*14.0/22;var nx=-7+(i+1)*14.0/22;var y=1.2+cos(x/7*PI*.5)*1.8;var ny=1.2+cos(nx/7*PI*.5)*1.8
		for z in [-1.1,1.1]:
			b.quad(origin+Vector3(x,y,z),origin+Vector3(nx,ny,z),origin+Vector3(nx,ny-.6,z),origin+Vector3(x,y-.6,z),Color('#d0c7a9').darkened(.04*(i%2)))
			b.tube(origin+Vector3(x,y+.6,z),origin+Vector3(nx,ny+.6,z),.07,Color('#c0b89e'),6)
			b.tube(origin+Vector3(x,y,z),origin+Vector3(x,y+.65,z),.055,Color('#d7cbb0'),5)
		b.quad(origin+Vector3(x,y,-1.1),origin+Vector3(nx,ny,-1.1),origin+Vector3(nx,ny,1.1),origin+Vector3(x,y,1.1),Color('#d9cfb0'))
	for x in [-6.5,6.5]:b.box(origin+Vector3(x,.7,0),Vector3(.9,1.8,2.4),Color('#b8baa4'))
	w.add_mesh(b,w,earth)
func build_landmarks(w):
	var b=B.new();var p=Vector3(-29,1.5,-20)
	b.box(p+Vector3(0,1.7,0),Vector3(1.7,3.4,1.6),Color('#e1d1af'));b.roof(p+Vector3(0,3.4,0),Vector3(2.2,1.4,2.1),Color('#b88e79'))
	for y in [.6,2.1]:b.box(p+Vector3(0,y,.815),Vector3(.42,.55,.025),Color('#e9c78b'))
	wheel=Node3D.new();wheel.position=p+Vector3(0,3,.96);w.add_child(wheel);var rotor=B.new()
	for j in range(4):
		var a=j*PI*.5;var dir=Vector3(cos(a),sin(a),0);var side=Vector3(-sin(a),cos(a),0);rotor.tube(dir*.15,dir*2.0,.04,Color('#9a927a'),5);rotor.quad(dir*.65-side*.17,dir*1.95-side*.17,dir*1.95+side*.28,dir*.65+side*.28,Color('#e3d9bd'))
	w.add_mesh(rotor,wheel,earth)
	# Two rock-fed cascades face the open center of the wetland.
	cascade=w.material('res://cascade.gdshader')
	for v in [Vector3(-24,0,-32),Vector3(27,0,-34)]:
		b.ellipsoid(v+Vector3(0,2.2,0),Vector3(4.2,4.5,3.0),Color('#a1b5a2'),16,10)
		b.box(v+Vector3(0,5.9,2.4),Vector3(1.8,.24,1.65),Color('#a7baa8'));b.ellipsoid(v+Vector3(0,.035,3.3),Vector3(1.15,.045,.7),Color('#dce8d3'),18,5)
		var flow=B.new();flow.quad(v+Vector3(-.55,.03,3.25),v+Vector3(.55,.03,3.25),v+Vector3(.55,6.0,3.25),v+Vector3(-.55,6.0,3.25),Color.WHITE);w.add_mesh(flow,w,cascade)
	w.add_mesh(b,w,earth)
	sail_material=w.material('res://sail.gdshader')
	for i in range(2):
		var root=Node3D.new();root.position=Vector3(-10 if i==0 else 12,.06,-12 if i==0 else 8);w.add_child(root);var boat=B.new();boat.ellipsoid(Vector3.ZERO,Vector3(.6,.18,1.3),Color('#ba9479'),18,7);boat.tube(Vector3(0,.1,0),Vector3(0,2.2,0),.035,Color('#a28b71'),7);var sail=B.new();sail.triangle(Vector3(.035,2.05,0),Vector3(.035,.65,0),Vector3(.035,.65,.95),Color('#eae0bc'));sail.triangle(Vector3(.035,1.85,0),Vector3(.035,.65,-.65),Vector3(.035,.65,0),Color('#d7b999'));w.add_mesh(sail,root,sail_material);w.add_mesh(boat,root,earth);boats.append([root,root.position,i])
	var bird_mesh=B.new();bird_mesh.ellipsoid(Vector3.ZERO,Vector3(.08,.09,.24),Color('#e8e5d1'),10,6);bird_mesh.ellipsoid(Vector3(0,.10,.19),Vector3(.065,.07,.07),Color('#ece9d7'),8,5);bird_mesh.tube(Vector3(0,.10,.22),Vector3(0,.10,.33),.022,Color('#c5a47b'),5)
	var wing=B.new();wing.quad(Vector3(0,0,.08),Vector3(.25,.02,.12),Vector3(.55,.03,-.16),Vector3(.12,0,-.13),Color('#e0e0cc'));wing.triangle(Vector3(.25,.02,.12),Vector3(.65,.02,-.11),Vector3(.55,.03,-.16),Color('#d0d7c4'))
	for data in [[bird_mesh,8],[wing,16]]:
		var n=MultiMeshInstance3D.new();n.multimesh=MultiMesh.new();n.multimesh.transform_format=MultiMesh.TRANSFORM_3D;n.multimesh.mesh=data[0].mesh(earth);n.multimesh.instance_count=data[1];w.add_child(n)
		if data[1]==8:bird_bodies=n
		else:bird_wings=n
	for i in range(8):birds.append(Vector3.ZERO)
func build_clouds(w):
	var b=B.new()
	for data in [[0,0,0,3.7,.5,1.5],[-2,.2,.2,2.0,.7,1.3],[2.2,.15,0,2.1,.65,1.5]]:b.ellipsoid(Vector3(data[0],data[1],data[2]),Vector3(data[3],data[4],data[5]),Color.WHITE,10,6)
	clouds_material=w.material('res://cloud.gdshader');clouds=MultiMeshInstance3D.new();clouds.multimesh=MultiMesh.new();clouds.multimesh.transform_format=MultiMesh.TRANSFORM_3D;clouds.multimesh.mesh=b.mesh(clouds_material);clouds.multimesh.instance_count=16;w.add_child(clouds)
func update(w):
	var t=w.g.elapsed
	for m in [earth,leaves]:m.set_shader_parameter('night',w.night_weight);m.set_shader_parameter('clock',t)
	leaves.set_shader_parameter('foliage_tint',w.foliage_tint);leaves.set_shader_parameter('foliage_mix',w.foliage_mix*.75)
	sail_material.set_shader_parameter('clock',t);sail_material.set_shader_parameter('night',w.night_weight)
	clouds_material.set_shader_parameter('night',w.night_weight);cascade.set_shader_parameter('clock',t);cascade.set_shader_parameter('night',w.night_weight)
	for i in range(16):
		var a=i*TAU/16+t*.0018;var p=Vector3(cos(a)*(54+i%3*9),14+i%4*3.0,sin(a)*(54+i%3*9));clouds.multimesh.set_instance_transform(i,Transform3D(Basis(Vector3.UP,a+.6),p))
	wheel.rotation.z=t*.13
	for boat in boats:boat[0].position=boat[1]+Vector3(sin(t*.08+boat[2])*.6,sin(t*.7+boat[2])*.025,cos(t*.07+boat[2])*.8);boat[0].rotation=Vector3(sin(t*.4)*.025,sin(t*.06+boat[2])*.2,cos(t*.5)*.03)
	for i in range(birds.size()):
		var a=t*.025+i*.055;var p=Vector3(cos(a)*28,9.0+sin(t*.1+i)*.5+abs(i-3)*.25,sin(a)*23-5);birds[i]=p
		var basis=Basis(Vector3.UP,-a);bird_bodies.multimesh.set_instance_transform(i,Transform3D(basis,p))
		for side in [-1,1]:
			var flap=sin(t*3.3-i*.8)*.42;var wing_basis=basis*Basis(Vector3.FORWARD,side*flap).scaled(Vector3(side,1,1));bird_wings.multimesh.set_instance_transform(i*2+(0 if side<0 else 1),Transform3D(wing_basis,p))
