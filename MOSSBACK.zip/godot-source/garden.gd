extends RefCounted
const SEASONS=['Spring','Summer','Autumn','Winter']
const FLOWERS=[Vector3(-1.5,0,1.0),Vector3(1.65,0,-.35),Vector3(.5,0,1.9),Vector3(-2.7,0,.1),Vector3(.7,0,-2.1),Vector3(2.6,0,.9)]
var elapsed=0.0
var season=0
var rain=false
var night=false
var muted=false
var calm=false
var paused=false
var orbit=true
var bloom=[.55,.3,.75,.35,.6,.25]
var target=[.55,.3,.75,.35,.6,.25]
var wakes=0
var showers=0
var photos=0
var parade=0.0
var auto_at=5.0
var events=[]
func wake(i):
	if i<0 or i>=6 or paused:return false
	target[i]=1.0;bloom[i]=maxf(.12,bloom[i]);wakes+=1;events.append(['bloom',i]);return true
func awaken():
	if paused:return false
	for i in range(6):target[i]=1.0
	parade=8;showers+=1;events.append(['parade',showers]);return true
func next_season():
	season=(season+1)%4;events.append(['season',season])
func update(dt):
	if paused:return
	dt=clampf(dt,0,.1);elapsed+=dt;parade=maxf(0,parade-dt)
	for i in range(6):bloom[i]=lerpf(bloom[i],target[i],1-exp(-dt*1.5))
	if elapsed>=auto_at:
		auto_at=elapsed+4.5;var i=int(elapsed/4.5)%6
		target[i]=.3 if target[i]>.8 else .95
		if parade>0:target.fill(1.0)
func snapshot():return {'v':1,'elapsed':elapsed,'season':season,'rain':rain,'night':night,'muted':muted,'calm':calm,'paused':paused,'orbit':orbit,'bloom':bloom.duplicate(),'target':target.duplicate(),'wakes':wakes,'showers':showers,'photos':photos,'parade':parade,'auto_at':auto_at}
func restore(d):
	if not d is Dictionary or d.get('v')!=1:return false
	for key in ['bloom','target']:
		if not d.get(key) is Array or d[key].size()!=6:return false
		for x in d[key]:
			if not (x is float or x is int) or not is_finite(x) or x<0 or x>1:return false
	for key in ['elapsed','season','wakes','showers','photos','parade','auto_at']:
		if not (d.get(key) is float or d.get(key) is int) or not is_finite(d[key]) or d[key]<0 or d[key]>1e10:return false
	if d.season>3 or d.season!=floor(d.season) or d.parade>8:return false
	for key in ['elapsed','parade','auto_at']:set(key,float(d[key]))
	for key in ['season','wakes','showers','photos']:set(key,int(d[key]))
	for key in ['rain','night','muted','calm','paused','orbit']:set(key,d.get(key)==true)
	bloom=d.bloom.duplicate();target=d.target.duplicate();events.clear();return true
