extends Node3D
const Builder=preload('res://mesh.gd')
var g
var camera:Camera3D
var sun:DirectionalLight3D
var environment:WorldEnvironment
var beast:Node3D
var head:Node3D
var eyes=[]
var legs=[]
var flowers=[]
var petals=[]
var flies=[]
var fish=[]
var weather:MultiMeshInstance3D
var pollen:MultiMeshInstance3D
var paper:ShaderMaterial
var leaf:ShaderMaterial
var water:ShaderMaterial
var windows:StandardMaterial3D
var yaw=.61
var pitch=.5
var focus=0
var viewport_size=Vector2(900,600)
var aim=Vector3(0,2.7,0)
var glints=[]
var pet_until=0.0
var season_old=-1
var stats={}
var glow:ShaderMaterial
var ripples=[]
func material(path):
	var m=ShaderMaterial.new();m.shader=load(path);return m
func add_mesh(b,parent,mat):
	var node=MeshInstance3D.new();node.mesh=b.mesh(mat);parent.add_child(node);return node
func height(x,z):return 1.8+sqrt(maxf(.03,1-pow(x/4.05,2)-pow(z/3.2,2)))*2.05
func point(x,z,extra=0.0):return Vector3(x,height(x,z)+extra,z)
func _ready():
	paper=material('res://paper.gdshader');leaf=material('res://paper.gdshader');water=material('res://water.gdshader');glow=material('res://glow.gdshader')
	environment=WorldEnvironment.new();var e=Environment.new();e.background_mode=Environment.BG_COLOR;e.background_color=Color('#e8e7da');e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;e.ambient_light_color=Color('#dbe4dc');e.ambient_light_energy=.7;e.tonemap_mode=Environment.TONE_MAPPER_LINEAR;environment.environment=e;add_child(environment)
	sun=DirectionalLight3D.new();sun.rotation_degrees=Vector3(-48,-28,0);sun.light_color=Color('#fff0d1');sun.light_energy=1.1;sun.shadow_enabled=false;sun.directional_shadow_max_distance=45;sun.shadow_bias=.08;add_child(sun)
	camera=Camera3D.new();camera.projection=Camera3D.PROJECTION_ORTHOGONAL;camera.current=true;camera.near=.1;camera.far=150;add_child(camera)
	var shade=MeshInstance3D.new();var plane=PlaneMesh.new();plane.size=Vector2(10.5,8.5);shade.mesh=plane;shade.position=Vector3(0,-.06,.2);var sm=ShaderMaterial.new();sm.shader=load('res://shadow.gdshader');shade.material_override=sm;add_child(shade)
	var ground=Builder.new();ground.box(Vector3(0,-.2,0),Vector3(300,.25,300),Color('#f3eedc'));add_mesh(ground,self,paper)
	var grass=Builder.new()
	for i in range(70):
		var x=sin(i*27.1)*18;var z=cos(i*17.3)*16
		if Vector2(x,z).length()<5:continue
		for j in range(3):grass.tube(Vector3(x+j*.06,-.05,z),Vector3(x+(j-1)*.15,.05+fmod(i*.13,.17),z+.06),.013,Color('#a8ba9c'),3)
	add_mesh(grass,self,paper)
	beast=Node3D.new();add_child(beast)
	var body=Builder.new();body.ellipsoid(Vector3(0,1.45,0),Vector3(3.55,.87,2.75),Color('#a5b6a0'),28,14)
	# An organically panelled shell, with seams following the dome rather than a sphere.
	for j in range(12):
		for i in range(64):
			var ps=[]
			for q in [Vector2(i,j),Vector2(i+1,j),Vector2(i+1,j+1),Vector2(i,j+1)]:
				var a=q.x*TAU/64;var r=q.y/12;ps.append(Vector3(cos(a)*4.05*r,height(cos(a)*4.05*r,sin(a)*3.2*r),sin(a)*3.2*r))
			body.quad(ps[0],ps[1],ps[2],ps[3],Color('#96ad82').lightened(.08*sin(i*.61+j*.7)))
	for j in [5,8,11,12]:
		var r=j/12.0
		for i in range(80):
			var a=i*TAU/80;var b=(i+1)*TAU/80;body.tube(point(cos(a)*4.05*r,sin(a)*3.2*r,.018),point(cos(b)*4.05*r,sin(b)*3.2*r,.018),.021,Color('#718d75'),4)
	for i in range(16):
		var a=i*TAU/16
		for j in range(5,12):
			var r=j/12.0;var s=(j+1)/12.0;body.tube(point(cos(a)*4.05*r,sin(a)*3.2*r,.025),point(cos(a)*4.05*s,sin(a)*3.2*s,.025),.019,Color('#78947b'),4)
	body.ellipsoid(Vector3(0,1.55,-3),Vector3(.35,.24,.9),Color('#94aa96'));add_mesh(body,beast,paper)
	for x in [-1,1]:
		for z in [-1,1]:
			var leg=Node3D.new();beast.add_child(leg);leg.position=Vector3(x*2.8,1.2,z*1.7);legs.append(leg)
			var b=Builder.new();b.ellipsoid(Vector3(x*.12,-.35,0),Vector3(.65,.8,.65),Color('#a5b49a'));b.ellipsoid(Vector3(x*.22,-.83,.12),Vector3(.68,.28,.75),Color('#a5b49a'))
			for k in range(3):b.ellipsoid(Vector3(x*.22+(k-1)*.29,-.86,.72),Vector3(.12,.11,.16),Color('#eee5c9'),8,5)
			add_mesh(b,leg,paper)
	head=Node3D.new();head.position=Vector3(0,1.75,3.38);beast.add_child(head)
	var face=Builder.new();face.ellipsoid(Vector3(0,0,.1),Vector3(.69,.49,1.15),Color('#b6c3a1'));face.ellipsoid(Vector3(0,.12,.95),Vector3(.94,.61,.84),Color('#bdcaaa'),24,14)
	for x in [-1,1]:
		face.ellipsoid(Vector3(x*.57,.1,1.58),Vector3(.16,.08,.03),Color('#d8a998'),10,6);face.ellipsoid(Vector3(x*.28,.27,1.7),Vector3(.045,.025,.035),Color('#687f70'),8,5)
	for i in range(12):
		var x=(i/11.0-.5)*.95;var nx=((i+1)/11.0-.5)*.95
		face.tube(Vector3(x,-.02+x*x*.2,1.68-abs(x)*.16),Vector3(nx,-.02+nx*nx*.2,1.68-abs(nx)*.16),.018,Color('#607466'),5)
	add_mesh(face,head,paper)
	for x in [-1,1]:
		var eye=Node3D.new();eye.position=Vector3(x*.67,.4,1.27);head.add_child(eye);eyes.append(eye)
		var b=Builder.new();b.ellipsoid(Vector3.ZERO,Vector3(.18,.2,.16),Color('#f7f2db'));b.ellipsoid(Vector3(x*.035,.005,.13),Vector3(.083,.115,.057),Color('#364b46'));b.ellipsoid(Vector3(x*.035-.025,.055,.17),Vector3(.025,.035,.012),Color('#fff8e7'),7,4);add_mesh(b,eye,paper)
	build_garden();build_particles();stats={'flowers':flowers.size(),'butterflies':flies.size(),'shell_panels':768,'fps':0}
func build_garden():
	var b=Builder.new();var foliage=Builder.new();var ink=Color('#64756c');var cream=Color('#f6e9cb')
	# A winding stepping-stone trail leads from the house to the forehead.
	for i in range(25):
		var z=-1.8+i*.165;var x=-.55+sin(i*.3)*.7;b.ellipsoid(point(x,z,.06),Vector3(.23,.055,.15),Color('#d6d4b7'),9,4)
	var home=point(-.65,-.75,.03)
	b.box(home+Vector3(0,.53,0),Vector3(1.3,1.1,1.1),cream);b.roof(home+Vector3(0,1.08,0),Vector3(1.75,.85,1.55),Color('#bd8275'))
	# Individual roof seams, ivory eaves, and little terracotta chimney.
	for i in range(9):
		var x=-.85+i*.21;b.tube(home+Vector3(x,1.1,.77),home+Vector3(x*.05,1.9,0),.018,Color('#915d60'),4)
	for z in [-.57,.57]:b.tube(home+Vector3(-.72,1.02,z),home+Vector3(.72,1.02,z),.035,ink,5)
	b.box(home+Vector3(.42,1.7,-.3),Vector3(.22,.7,.22),Color('#d1b998'));b.box(home+Vector3(.42,2.07,-.3),Vector3(.33,.09,.33),ink)
	b.box(home+Vector3(0,.37,.567),Vector3(.39,.74,.04),Color('#708e88'));b.ellipsoid(home+Vector3(.11,.37,.6),Vector3(.026,.026,.026),Color('#e7c983'),8,4)
	for x in [-.44,.44]:
		b.box(home+Vector3(x,.65,.57),Vector3(.28,.33,.035),Color('#f5cd81'))
		for u in [-.16,0,.16]:b.tube(home+Vector3(x+u,.47,.6),home+Vector3(x+u,.82,.6),.017,ink,4)
		b.tube(home+Vector3(x-.16,.64,.6),home+Vector3(x+.16,.64,.6),.018,ink,4)
		b.box(home+Vector3(x,.42,.65),Vector3(.39,.1,.19),Color('#b5836b'))
	for i in range(38):
		var x=-3+fmod(i*1.37,5.9);var z=-2.2+fmod(i*1.83,4.4)
		if abs(x)<1 and z<.4:continue
		var p=point(x,z,.05)
		for k in range(5):
			var end=p+Vector3(sin(k*2.3)*.22,.2+fmod(k*.13,.25),cos(k*2.3)*.22);b.tube(p,end,.014,Color('#738d73'),4);foliage.ellipsoid(end,Vector3(.11,.04,.19),Color('#8faa85'),7,4)
	# Tiny fence follows a contour of the shell.
	for i in range(12):
		var a=2.55+i*.08;var p=point(cos(a)*3.4,sin(a)*2.65,.04);b.tube(p,p+Vector3(0,.36,0),.035,Color('#d2c5a4'),5)
		if i>0:
			var q=point(cos(a-.08)*3.4,sin(a-.08)*2.65,.04)
			for h in [.14,.29]:b.tube(p+Vector3(0,h,0),q+Vector3(0,h,0),.025,Color('#c3b99b'),5)
	for data in [[-2.0,-.7,2.3],[1.7,-1.25,1.6]]:
		var p=point(data[0],data[1]);var s=data[2]
		b.tube(p,p+Vector3(.15,s*.55,0),.115,Color('#8b8173'),9)
		for j in range(7):
			var a=j*2.4;var end=p+Vector3(cos(a)*s*.44,s*(.68+.13*sin(j*1.8)),sin(a)*s*.31);b.tube(p+Vector3(.1,s*.4,0),end,.047,Color('#8c8174'),7)
			foliage.ellipsoid(end,Vector3(s*.36,s*.22,s*.33),Color('#a1b99b').lightened(.06*sin(j*2)),14,8)
			for k in range(3):foliage.ellipsoid(end+Vector3(sin(k*2+j)*s*.29,s*.11,cos(k*2+j)*s*.24),Vector3(.17,.11,.15),Color('#e8c5b7'),8,5)
	# Delicate trailing ivy over the rim, with alternating leaves.
	for j in range(19):
		var a=j*TAU/19;var p=point(cos(a)*3.65,sin(a)*2.9,.04)
		for k in range(7):
			var q=p+Vector3(sin(k*.7+j)*.06,-k*.10,cos(a)*k*.015);var r=q+Vector3(sin(k*.7+j+1)*.03,-.11,.015);b.tube(q,r,.012,Color('#6f8768'),4)
			foliage.ellipsoid(q+Vector3((1 if k%2==0 else -1)*.08,-.025,0),Vector3(.1,.035,.065),Color('#8ea47e'),7,4)
	add_mesh(b,beast,paper);add_mesh(foliage,beast,leaf)
	var warm=Builder.new()
	for x in [-.44,.44]:
		for dx in [-1,1]:
			for dy in [-1,1]:warm.box(home+Vector3(x+dx*.072,.65+dy*.081,.611),Vector3(.115,.13,.012),Color('#f4d392'))
	for i in range(4):
		var p=point(-2.1+i*.9,-1.4,.85+sin(i)*.4);var post=Builder.new();post.tube(p,p+Vector3(0,.4,0),.013,Color('#6a7a6c'),4);warm.ellipsoid(p,Vector3(.1,.14,.1),Color('#e6c998'),12,7);add_mesh(post,beast,paper)
	add_mesh(warm,beast,glow)
	# Pond, polished river stones, an arched cedar footbridge, and circling koi.
	var pond=point(1.55,.65,.09);var pool=Builder.new();pool.ellipsoid(pond,Vector3(.85,.065,.61),Color.WHITE,36,5);add_mesh(pool,beast,water)
	var stones=Builder.new()
	for i in range(25):
		var a=i*TAU/25;stones.ellipsoid(pond+Vector3(cos(a)*.86,0,sin(a)*.62),Vector3(.14,.1,.1),Color('#c5c7ad'),7,4)
	for i in range(11):
		var x=(i-5)*.115;stones.box(pond+Vector3(x,.19+cos(x*2)*.15,0),Vector3(.105,.06,.36),Color('#c99e7e'))
	add_mesh(stones,beast,paper)
	for i in range(3):
		var ring=Builder.new()
		for j in range(48):
			var a=j*TAU/48;var z=(j+1)*TAU/48;ring.quad(Vector3(cos(a)*.5,0,sin(a)*.5),Vector3(cos(z)*.5,0,sin(z)*.5),Vector3(cos(z)*.49,0,sin(z)*.49),Vector3(cos(a)*.49,0,sin(a)*.49),Color('#d9e8d9'))
		var r=add_mesh(ring,beast,paper);r.position=pond+Vector3(.1,.075,0);ripples.append(r)
	for i in range(3):
		var n=Node3D.new();beast.add_child(n);var koi=Builder.new();koi.ellipsoid(Vector3.ZERO,Vector3(.045,.025,.14),Color('#e7a17a') if i%2==0 else Color('#f4e8cc'),8,4);koi.triangle(Vector3(0,0,-.12),Vector3(-.065,0,-.22),Vector3(.065,0,-.22),Color('#e8c6a4'));add_mesh(koi,n,paper);fish.append([n,pond,i])
	for i in range(g.FLOWERS.size()):build_flower(i)
	for i in range(7):
		var fly=Node3D.new();beast.add_child(fly);var body=Builder.new();body.ellipsoid(Vector3.ZERO,Vector3(.018,.018,.1),Color('#596e69'),6,4);add_mesh(body,fly,paper);var wings=[]
		for side in [-1,1]:
			var wing=Node3D.new();fly.add_child(wing);var mb=Builder.new();mb.ellipsoid(Vector3(side*.09,0,.03),Vector3(.12,.012,.12),Color('#efd2a1') if i%2==0 else Color('#d5b9d4'),9,5);mb.ellipsoid(Vector3(side*.065,0,-.09),Vector3(.08,.012,.08),Color('#cd9589'),9,5);add_mesh(mb,wing,paper);wings.append(wing)
		flies.append([fly,wings])
func build_flower(i):
	var anchor=g.FLOWERS[i];var p=point(anchor.x,anchor.z);var h=.65+.2*(i%3);var stem=Builder.new();stem.tube(p,p+Vector3(.06,h*.5,0),.023,Color('#6f946e'));stem.tube(p+Vector3(.06,h*.5,0),p+Vector3(0,h,0),.02,Color('#6f946e'));stem.ellipsoid(p+Vector3(.17,h*.35,0),Vector3(.22,.045,.09),Color('#91aa78'),10,5);add_mesh(stem,beast,paper)
	var root=Node3D.new();root.position=p+Vector3(0,h,0);root.rotation_degrees=Vector3(9+i*3,0,-8+i*3);beast.add_child(root);flowers.append(root)
	var m=material('res://petal.gdshader');var b=Builder.new();var color_=[Color('#e6a5a0'),Color('#cfb5d8'),Color('#ecd296')][i%3];var size_=.63 if i<3 else .42
	for layer in range(2):
		for j in range(8):
			var a=j*TAU/8+layer*.38
			for u in range(7):
				for v in range(6):
					var ps=[]
					for q in [Vector2(u,v),Vector2(u+1,v),Vector2(u+1,v+1),Vector2(u,v+1)]:
						var t=q.x/7;var w=(q.y/6-.5)*2;var r=.075+t*size_*(1-layer*.2);var width=sin(t*PI)*size_*.38;var y=.1-sin(t*PI)*.12+t*t*.19+layer*.07+w*w*.055;ps.append(Vector3(cos(a)*r-sin(a)*w*width,y,sin(a)*r+cos(a)*w*width))
					b.quad(ps[0],ps[1],ps[2],ps[3],color_.lightened(u*.025+layer*.04))
	add_mesh(b,root,m);petals.append(m)
	var core=Builder.new();core.ellipsoid(Vector3(0,.15,0),Vector3(.13,.07,.13),Color('#d8b26d'),12,6)
	for j in range(16):
		var a=j*2.4;var r=.1*sqrt(j/16.0);core.ellipsoid(Vector3(cos(a)*r,.21,sin(a)*r),Vector3(.015,.02,.015),Color('#f7e4ad'),5,3)
	add_mesh(core,root,paper)
func build_particles():
	var b=Builder.new();b.ellipsoid(Vector3.ZERO,Vector3(.045,.012,.025),Color('#f3d1b0'),5,3)
	pollen=MultiMeshInstance3D.new();pollen.multimesh=MultiMesh.new();pollen.multimesh.transform_format=MultiMesh.TRANSFORM_3D;pollen.multimesh.mesh=b.mesh(paper);pollen.multimesh.instance_count=75;beast.add_child(pollen)
	b=Builder.new();b.tube(Vector3.ZERO,Vector3(0,.18,0),.009,Color('#a9c5ca'),3);weather=MultiMeshInstance3D.new();weather.multimesh=MultiMesh.new();weather.multimesh.transform_format=MultiMesh.TRANSFORM_3D;weather.multimesh.mesh=b.mesh(paper);weather.multimesh.instance_count=150;beast.add_child(weather)
func update_world():
	g.events.clear();var t=g.elapsed;stats.fps=Engine.get_frames_per_second();var pace=.28 if g.calm else 1.0
	beast.position.y=sin(t*1.2)*.045*pace;beast.rotation.z=sin(t*.6)*.008*pace
	head.rotation.x=sin(t*.8)*.035*pace;head.rotation.z=sin(t*5)*.09 if pet_until>t else 0.0
	for i in range(legs.size()):legs[i].rotation.x=sin(t*1.4+i%3*PI)*.12*pace
	var blink=abs(sin(t*.67))<.045 or pet_until>t
	for e in eyes:e.scale.y=.12 if blink else 1.0
	for i in range(petals.size()):
		petals[i].set_shader_parameter('opening',g.bloom[i]);petals[i].set_shader_parameter('winter',1.0 if g.season==3 else 0.0);petals[i].set_shader_parameter('night',1.0 if g.night else 0.0);flowers[i].rotation.z=sin(t*.65+i)*.035
	for f in fish:
		var a=t*.3+f[2]*TAU/3;f[0].position=f[1]+Vector3(cos(a)*.55,.08,sin(a)*.35);f[0].rotation.y=-a
	for i in range(flies.size()):
		var f=flies[i];var a=t*(.24+i*.017)+i*1.9;f[0].position=Vector3(cos(a)*3.1,4.5+sin(t*.5+i)*.5,sin(a)*2.6);f[0].rotation.y=-a
		for j in range(2):f[1][j].rotation.z=sin(t*14+i)*.65*(1 if j==0 else -1)
	for i in range(75):
		var a=i*2.4+t*.12;var y=2.5+fmod(i*.31+t*(.1 if g.parade<=0 else .5),4.5);var radius=3.2 if g.parade>0 else 4.5;var p=Vector3(sin(a)*radius,y,cos(a*1.17)*radius*.7);pollen.multimesh.set_instance_transform(i,Transform3D(Basis(Vector3.UP,a),p))
	weather.visible=g.rain
	if g.rain:
		for i in range(150):weather.multimesh.set_instance_transform(i,Transform3D(Basis.IDENTITY,Vector3(sin(i*35.1)*5,1+fposmod(i*.37-t*5,8),cos(i*23.4)*4)))
	water.set_shader_parameter('clock',t)
	for i in range(ripples.size()):
		var q=fposmod(t*(.8 if g.rain else .25)+i*.33,1.0);ripples[i].scale=Vector3(q,1,q*.65);ripples[i].visible=q>.08
	paper.set_shader_parameter('night',1.0 if g.night else 0.0);leaf.set_shader_parameter('night',1.0 if g.night else 0.0);glow.set_shader_parameter('night',1.0 if g.night else 0.0)
	leaf.set_shader_parameter('season',float(g.season));paper.set_shader_parameter('warmth',.12 if g.season==2 else 0.0)
	var e=environment.environment;e.background_color=Color('#b9cbd2') if g.night else [Color('#e9e8db'),Color('#e7e5cc'),Color('#eee0cf'),Color('#e4e8e6')][g.season];e.ambient_light_energy=.45 if g.night else .8;sun.light_energy=.35 if g.night else 1.05;sun.light_color=Color('#b2c9e7') if g.night else Color('#fff0d7')
	var portrait=viewport_size.y>viewport_size.x;var target=Vector3(0,3.2,.4);camera.keep_aspect=Camera3D.KEEP_WIDTH if portrait else Camera3D.KEEP_HEIGHT;var size_=9.8 if portrait else 11.0
	if focus==1:target=Vector3(0,4.1,-.2);size_=7.6 if portrait else 6.2
	if focus==2:target=Vector3(0,2.2,3.8);size_=4.5 if portrait else 4.8
	aim=aim.lerp(target,.08);camera.size=lerpf(camera.size,size_,.08)
	var angle=yaw+(sin(t*.065)*.13 if g.orbit else 0.0);camera.position=aim+Vector3(sin(angle)*cos(pitch),sin(pitch),cos(angle)*cos(pitch))*22;camera.look_at(aim)
func flower_screen(i):return camera.unproject_position(flowers[i].global_position)
