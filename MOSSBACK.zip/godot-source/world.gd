extends Node3D
const Layout=preload('res://garden_layout.gd')
const Builder=preload('res://mesh.gd')
var g
var camera:Camera3D
var sun:DirectionalLight3D
var environment:WorldEnvironment
var beast:Node3D
var head:Node3D
var eyes=[]
var legs=[]
var flowers=[]
var petals=[]
var flies=[]
var fish=[]
var weather:MultiMeshInstance3D
var pollen:MultiMeshInstance3D
var paper:ShaderMaterial
var leaf:ShaderMaterial
var water:ShaderMaterial
var tree_crowns=[]
var landscape
var windows:StandardMaterial3D
var yaw=.61
var pitch=.34
var focus=0
var viewport_size=Vector2(900,600)
var aim=Vector3(0,2.7,0)
var glints=[]
var pet_until=0.0
var season_old=-1
var stats={}
var glow:ShaderMaterial
var ripples=[]
var ground_mat:ShaderMaterial
var lagoon_mat:ShaderMaterial
var smoke:MultiMeshInstance3D
var fireflies:MultiMeshInstance3D
var firefly_halos:MultiMeshInstance3D
var post:ColorRect
var wash:ShaderMaterial
var director=false
var director_origin=0.0
var director_phase=0.0
var camera_initialized=false
var camera_dt=.022222
var cinematic_warmth=0.0
var night_weight=0.0
var winter_weight=0.0
var foliage_tint=Color('#95b599')
var foliage_mix=0.0
var touch_index=-1
var touch_until=0.0
const SHOTS=[
 [Vector3(11,7.4,19),Vector3(0,3.5,.4),38.0],
 [Vector3(4.1,4.0,9.6),Vector3(0,2.1,3.9),34.0],
 [Vector3(6.6,8.0,8.9),Vector3(1.1,4.1,.5),32.0],
 [Vector3(-5.4,8.2,8.4),Vector3(-.65,4.7,-.5),33.0],
 [Vector3(-15,13,22),Vector3(0,3.2,.2),36.0]]
func material(path):
	var m=ShaderMaterial.new();m.shader=load(path);return m
func add_mesh(b,parent,mat):
	var node=MeshInstance3D.new();node.mesh=b.mesh(mat);parent.add_child(node);return node
func height(x,z):return 1.8+sqrt(maxf(.03,1-pow(x/4.05,2)-pow(z/3.2,2)))*2.05
func point(x,z,extra=0.0):return Vector3(x,height(x,z)+extra,z)
func _ready():
	night_weight=1.0 if g.night else 0.0;winter_weight=1.0 if g.season==3 else 0.0;foliage_tint=[Color('#95b599'),Color('#64a888'),Color('#e3aa79'),Color('#e1ebdf')][g.season];foliage_mix=[0.0,.18,.6,.7][g.season]
	paper=material('res://paper.gdshader');leaf=material('res://paper.gdshader');water=material('res://water.gdshader');glow=material('res://glow.gdshader')
	environment=WorldEnvironment.new();var e=Environment.new();e.background_mode=Environment.BG_COLOR;e.background_color=Color('#e8e7da');e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;e.ambient_light_color=Color('#dbe4dc');e.ambient_light_energy=.7;e.tonemap_mode=Environment.TONE_MAPPER_LINEAR;environment.environment=e;add_child(environment)
	sun=DirectionalLight3D.new();sun.rotation_degrees=Vector3(-48,-28,0);sun.light_color=Color('#fff0d1');sun.light_energy=1.1;sun.shadow_enabled=false;sun.directional_shadow_max_distance=45;sun.shadow_bias=.08;add_child(sun)
	camera=Camera3D.new();camera.projection=Camera3D.PROJECTION_PERSPECTIVE;camera.current=true;camera.near=.1;camera.far=150;add_child(camera)
	beast=Node3D.new();add_child(beast)
	var body=Builder.new();body.ellipsoid(Vector3(0,1.45,0),Vector3(3.55,.87,2.75),Color('#a5b6a0'),28,14)
	# An organically panelled shell, with seams following the dome rather than a sphere.
	for j in range(12):
		for i in range(64):
			var ps=[]
			for q in [Vector2(i,j),Vector2(i+1,j),Vector2(i+1,j+1),Vector2(i,j+1)]:
				var a=q.x*TAU/64;var r=q.y/12;ps.append(Vector3(cos(a)*4.05*r,height(cos(a)*4.05*r,sin(a)*3.2*r),sin(a)*3.2*r))
			body.quad(ps[0],ps[1],ps[2],ps[3],Color('#96ad82').lightened(.08*sin(i*.61+j*.7)))
	for j in [5,8,11,12]:
		var r=j/12.0
		for i in range(80):
			var a=i*TAU/80;var b=(i+1)*TAU/80;body.tube(point(cos(a)*4.05*r,sin(a)*3.2*r,.018),point(cos(b)*4.05*r,sin(b)*3.2*r,.018),.021,Color('#718d75'),4)
	for i in range(16):
		var a=i*TAU/16
		for j in range(5,12):
			var r=j/12.0;var s=(j+1)/12.0;body.tube(point(cos(a)*4.05*r,sin(a)*3.2*r,.025),point(cos(a)*4.05*s,sin(a)*3.2*s,.025),.019,Color('#78947b'),4)
	body.ellipsoid(Vector3(0,1.55,-3),Vector3(.35,.24,.9),Color('#94aa96'));add_mesh(body,beast,paper)
	for x in [-1,1]:
		for z in [-1,1]:
			var leg=Node3D.new();beast.add_child(leg);leg.position=Vector3(x*2.8,1.12,z*1.7);legs.append(leg)
			var b=Builder.new();b.ellipsoid(Vector3(x*.12,-.35,0),Vector3(.65,.8,.65),Color('#a5b49a'));b.ellipsoid(Vector3(x*.22,-.83,.12),Vector3(.68,.28,.75),Color('#a5b49a'))
			for k in range(3):b.ellipsoid(Vector3(x*.22+(k-1)*.29,-.86,.72),Vector3(.12,.11,.16),Color('#eee5c9'),8,5)
			add_mesh(b,leg,paper)
	head=Node3D.new();head.position=Vector3(0,1.75,3.38);beast.add_child(head)
	var face=Builder.new();face.ellipsoid(Vector3(0,0,.1),Vector3(.69,.49,1.15),Color('#b6c3a1'));face.ellipsoid(Vector3(0,.12,.95),Vector3(.94,.61,.84),Color('#bdcaaa'),24,14)
	for x in [-1,1]:
		face.ellipsoid(Vector3(x*.57,.1,1.58),Vector3(.16,.08,.03),Color('#d8a998'),10,6);face.ellipsoid(Vector3(x*.28,.27,1.7),Vector3(.045,.025,.035),Color('#687f70'),8,5)
	for i in range(12):
		var x=(i/11.0-.5)*.95;var nx=((i+1)/11.0-.5)*.95
		face.tube(Vector3(x,-.06+x*x*.4,1.80-abs(x)*.20),Vector3(nx,-.06+nx*nx*.4,1.80-abs(nx)*.20),.018,Color('#607466'),5)
	add_mesh(face,head,paper)
	for x in [-1,1]:
		var eye=Node3D.new();eye.position=Vector3(x*.67,.4,1.27);head.add_child(eye);eyes.append(eye)
		var b=Builder.new();b.ellipsoid(Vector3.ZERO,Vector3(.18,.2,.16),Color('#f7f2db'));b.ellipsoid(Vector3(x*.035,.005,.13),Vector3(.083,.115,.057),Color('#364b46'));b.ellipsoid(Vector3(x*.035-.025,.055,.17),Vector3(.025,.035,.012),Color('#fff8e7'),7,4);add_mesh(b,eye,paper)
	build_garden();preload('res://scenery.gd').new().build(self);landscape=preload('res://landscape.gd').new();landscape.build(self);build_particles();build_post();stats={'flowers':flowers.size(),'butterflies':flies.size(),'shell_panels':768,'fps':0,'grove_trees':landscape.grove_count,'world_span':220}
func build_garden():
	var b=Builder.new();var foliage=Builder.new();var ink=Color('#64756c');var cream=Color('#f6e9cb')
	# A winding stepping-stone trail leads from the house to the forehead.
	for i in range(25):
		var z=-1.8+i*.165;var x=-.55+sin(i*.3)*.7;b.ellipsoid(point(x,z,.06),Vector3(.23,.055,.15),Color('#d6d4b7'),9,4)
	var home=point(-.65,-.75,.03)
	b.box(home+Vector3(0,.53,0),Vector3(1.3,1.1,1.1),cream)
	# Individual roof seams, ivory eaves, and little terracotta chimney.
	for z in [-.57,.57]:b.tube(home+Vector3(-.72,1.02,z),home+Vector3(.72,1.02,z),.035,ink,5)
	b.box(home+Vector3(.42,1.7,-.3),Vector3(.22,.7,.22),Color('#d1b998'));b.box(home+Vector3(.42,2.07,-.3),Vector3(.33,.09,.33),ink)
	b.box(home+Vector3(0,.37,.567),Vector3(.39,.74,.04),Color('#708e88'));b.ellipsoid(home+Vector3(.11,.37,.6),Vector3(.026,.026,.026),Color('#e7c983'),8,4)
	for x in [-.44,.44]:
		b.box(home+Vector3(x,.65,.57),Vector3(.28,.33,.035),Color('#f5cd81'))
		for u in [-.16,0,.16]:b.tube(home+Vector3(x+u,.47,.6),home+Vector3(x+u,.82,.6),.017,ink,4)
		b.tube(home+Vector3(x-.16,.64,.6),home+Vector3(x+.16,.64,.6),.018,ink,4)
		b.box(home+Vector3(x,.42,.65),Vector3(.39,.1,.19),Color('#b5836b'))
	for i in range(38):
		var x=-3+fmod(i*1.37,5.9);var z=-2.2+fmod(i*1.83,4.4)
		if abs(x)<1 and z<.4:continue
		var p=point(x,z,.05)
		for k in range(5):
			var end=p+Vector3(sin(k*2.3)*.22,.2+fmod(k*.13,.25),cos(k*2.3)*.22);b.tube(p,end,.014,Color('#738d73'),4);foliage.ellipsoid(end,Vector3(.11,.04,.19),Color('#8faa85'),7,4)
	# Tiny fence follows a contour of the shell.
	for i in range(12):
		var a=2.55+i*.08;var p=point(cos(a)*3.4,sin(a)*2.65,.04);b.tube(p,p+Vector3(0,.36,0),.035,Color('#d2c5a4'),5)
		if i>0:
			var q=point(cos(a-.08)*3.4,sin(a-.08)*2.65,.04)
			for h in [.14,.29]:b.tube(p+Vector3(0,h,0),q+Vector3(0,h,0),.025,Color('#c3b99b'),5)
	for spec in Layout.TREE_SPECS:Layout.make_tree(self,spec)
	Layout.foundation(self)
	# Delicate trailing ivy over the rim, with alternating leaves.
	for j in range(19):
		var a=j*TAU/19;var p=point(cos(a)*3.65,sin(a)*2.9,.04)
		for k in range(7):
			var q=p+Vector3(sin(k*.7+j)*.06,-k*.10,cos(a)*k*.015);var r=q+Vector3(sin(k*.7+j+1)*.03,-.11,.015);b.tube(q,r,.012,Color('#6f8768'),4)
			foliage.ellipsoid(q+Vector3((1 if k%2==0 else -1)*.08,-.025,0),Vector3(.1,.035,.065),Color('#8ea47e'),7,4)
	add_mesh(b,beast,paper);add_mesh(foliage,beast,leaf)
	var warm=Builder.new()
	for x in [-.44,.44]:
		for dx in [-1,1]:
			for dy in [-1,1]:warm.box(home+Vector3(x+dx*.072,.65+dy*.081,.611),Vector3(.115,.13,.012),Color('#f4d392'))
	for i in range(4):
		var p=point(-2.1+i*.9,-1.4,.85+sin(i)*.4);var post=Builder.new();post.tube(p,p+Vector3(0,.4,0),.013,Color('#6a7a6c'),4);warm.ellipsoid(p,Vector3(.1,.14,.1),Color('#e6c998'),12,7);add_mesh(post,beast,paper)
	add_mesh(warm,beast,glow)
	# Pond, polished river stones, an arched cedar footbridge, and circling koi.
	var pond=point(1.55,.65,.09);var pool=Builder.new();pool.ellipsoid(pond,Vector3(.85,.065,.61),Color.WHITE,36,5);add_mesh(pool,beast,water)
	var stones=Builder.new()
	for i in range(25):
		var a=i*TAU/25;stones.ellipsoid(pond+Vector3(cos(a)*.86,0,sin(a)*.62),Vector3(.14,.1,.1),Color('#c5c7ad'),7,4)
	for i in range(11):
		var x=(i-5)*.115;stones.box(pond+Vector3(x,.19+cos(x*2)*.15,0),Vector3(.105,.06,.36),Color('#c99e7e'))
	add_mesh(stones,beast,paper)
	for i in range(3):
		var ring=Builder.new()
		for j in range(48):
			var a=j*TAU/48;var z=(j+1)*TAU/48;ring.quad(Vector3(cos(a)*.5,0,sin(a)*.5),Vector3(cos(z)*.5,0,sin(z)*.5),Vector3(cos(z)*.49,0,sin(z)*.49),Vector3(cos(a)*.49,0,sin(a)*.49),Color('#d9e8d9'))
		var r=add_mesh(ring,beast,paper);r.position=pond+Vector3(.1,.075,0);ripples.append(r)
	for i in range(3):
		var n=Node3D.new();beast.add_child(n);var koi=Builder.new();koi.ellipsoid(Vector3.ZERO,Vector3(.045,.025,.14),Color('#e7a17a') if i%2==0 else Color('#f4e8cc'),8,4);koi.triangle(Vector3(0,0,-.12),Vector3(-.065,0,-.22),Vector3(.065,0,-.22),Color('#e8c6a4'));add_mesh(koi,n,paper);fish.append([n,pond,i])
	for i in range(g.FLOWERS.size()):build_flower(i)
	for i in range(7):
		var fly=Node3D.new();beast.add_child(fly);var body=Builder.new();body.ellipsoid(Vector3.ZERO,Vector3(.018,.018,.1),Color('#596e69'),6,4);add_mesh(body,fly,paper);var wings=[]
		for side in [-1,1]:
			var wing=Node3D.new();fly.add_child(wing);var mb=Builder.new();mb.ellipsoid(Vector3(side*.09,0,.03),Vector3(.12,.012,.12),Color('#efd2a1') if i%2==0 else Color('#d5b9d4'),9,5);mb.ellipsoid(Vector3(side*.065,0,-.09),Vector3(.08,.012,.08),Color('#cd9589'),9,5);
			for k in range(5):
				var a=k*PI/4;mb.ellipsoid(Vector3(side*(.08+sin(a)*.065),.014,.03+cos(a)*.075),Vector3(.018,.004,.018),Color('#fff1ce'),6,4)
			mb.tube(Vector3.ZERO,Vector3(side*.17,.013,.1),.004,Color('#a98477'),3);add_mesh(mb,wing,paper);wings.append(wing)
		flies.append([fly,wings])
func build_flower(i):
	var anchor=g.FLOWERS[i];var p=point(anchor.x,anchor.z);var h=.65+.2*(i%3);var stem=Builder.new();stem.tube(p,p+Vector3(.06,h*.5,0),.023,Color('#6f946e'));stem.tube(p+Vector3(.06,h*.5,0),p+Vector3(0,h,0),.02,Color('#6f946e'));stem.ellipsoid(p+Vector3(.17,h*.35,0),Vector3(.22,.045,.09),Color('#91aa78'),10,5);add_mesh(stem,beast,paper)
	var root=Node3D.new();root.position=p+Vector3(0,h,0);root.rotation_degrees=Vector3(9+i*3,0,-8+i*3);beast.add_child(root);flowers.append(root)
	var m=material('res://petal.gdshader');var b=Builder.new();var color_=[Color('#e8aaa4'),Color('#c6acd6'),Color('#efd39b')][i%3];var size_=.63 if i<3 else .42
	for layer in range(3):
		for j in range(8):
			var a=j*TAU/8+layer*.38
			for u in range(7):
				for v in range(6):
					var ps=[]
					for q in [Vector2(u,v),Vector2(u+1,v),Vector2(u+1,v+1),Vector2(u,v+1)]:
						var t=q.x/7;var w=(q.y/6-.5)*2;var r=.055+sin(t*PI*.5)*size_*(1-layer*.18);var width=pow(maxf(0,sin(t*PI)),.7)*size_*.46;var y=.06-sin(t*PI)*.095+t*t*.065+layer*.07+w*w*.045;ps.append(Vector3(cos(a)*r-sin(a)*w*width,y,sin(a)*r+cos(a)*w*width))
					b.quad(ps[0],ps[1],ps[2],ps[3],color_.darkened((1-u/7.0)*.13).lightened(layer*.035))
	add_mesh(b,root,m);petals.append(m)
	var core=Builder.new();core.ellipsoid(Vector3(0,.15,0),Vector3(.13,.07,.13),Color('#d8b26d'),12,6)
	for j in range(16):
		var a=j*2.4;var r=.1*sqrt(j/16.0);core.ellipsoid(Vector3(cos(a)*r,.21,sin(a)*r),Vector3(.015,.02,.015),Color('#f7e4ad'),5,3)
	add_mesh(core,root,paper)
func build_particles():
	var b=Builder.new();b.ellipsoid(Vector3.ZERO,Vector3(.045,.012,.025),Color('#f3d1b0'),5,3)
	pollen=MultiMeshInstance3D.new();pollen.multimesh=MultiMesh.new();pollen.multimesh.transform_format=MultiMesh.TRANSFORM_3D;pollen.multimesh.mesh=b.mesh(paper);pollen.multimesh.instance_count=75;beast.add_child(pollen)
	b=Builder.new();b.tube(Vector3.ZERO,Vector3(0,.18,0),.009,Color('#a9c5ca'),3);weather=MultiMeshInstance3D.new();weather.multimesh=MultiMesh.new();weather.multimesh.transform_format=MultiMesh.TRANSFORM_3D;weather.multimesh.mesh=b.mesh(paper);weather.multimesh.instance_count=150;beast.add_child(weather)
func build_post():
	var canvas=CanvasLayer.new();canvas.layer=2;add_child(canvas);post=ColorRect.new();post.mouse_filter=Control.MOUSE_FILTER_IGNORE;wash=material('res://wash.gdshader');post.material=wash;canvas.add_child(post)
func begin_director():
	director=true;director_origin=g.elapsed
func update_world():
	g.events.clear();var t=g.elapsed;var fade=1.0-exp(-camera_dt*2.0)
	night_weight=lerpf(night_weight,1.0 if g.night else 0.0,fade);winter_weight=lerpf(winter_weight,1.0 if g.season==3 else 0.0,fade);foliage_tint=foliage_tint.lerp([Color('#95b599'),Color('#64a888'),Color('#e3aa79'),Color('#e1ebdf')][g.season],fade);foliage_mix=lerpf(foliage_mix,[0.0,.18,.6,.7][g.season],fade)
	leaf.set_shader_parameter('foliage_tint',foliage_tint);leaf.set_shader_parameter('foliage_mix',foliage_mix)
	stats.fps=Engine.get_frames_per_second();var pace=.28 if g.calm else 1.0
	beast.position.y=sin(t*1.7)*.025*pace;beast.rotation.z=sin(t*.6)*.008*pace
	head.rotation.x=sin(t*.8)*.035*pace;head.rotation.z=sin(t*5)*.09 if pet_until>t else 0.0
	for i in range(legs.size()):
		var step_=sin(t*.85+(PI if i in [1,2] else 0.0));legs[i].rotation.x=step_*.16*pace;legs[i].position.y=1.12+maxf(0,step_)*.07*pace
	var blink=abs(sin(t*.67))<.045 or pet_until>t
	for e in eyes:e.scale.y=.12 if blink else 1.0
	for i in range(petals.size()):
		petals[i].set_shader_parameter('opening',g.bloom[i]);petals[i].set_shader_parameter('winter',winter_weight);petals[i].set_shader_parameter('night',night_weight);flowers[i].rotation.z=sin(t*.65+i)*.035
	for f in fish:
		var a=t*.3+f[2]*TAU/3;f[0].position=f[1]+Vector3(cos(a)*.55,.08,sin(a)*.35);f[0].rotation.y=-a
	for i in range(flies.size()):
		var f=flies[i];var a=t*(.24+i*.017)+i*1.9;var radius=2.1 if g.parade>0 else 3.1;f[0].position=Vector3(cos(a)*radius,4.5+sin(t*.5+i)*.5+(sin(t*.8+i)*.35 if g.parade>0 else 0.0),sin(a)*radius*.84);f[0].rotation.y=-a
		for j in range(2):f[1][j].rotation.z=sin(t*14+i)*.65*(1 if j==0 else -1)
	for i in range(75):
		var a=i*2.4+t*.12;var y=2.5+fmod(i*.31+t*(.1 if g.parade<=0 else .5),4.5);var radius=3.2 if g.parade>0 else 4.5;var p=Vector3(sin(a)*radius,y,cos(a*1.17)*radius*.7);var rotation_=Basis.from_euler(Vector3(sin(t*1.5+i)*.8,a,cos(t*1.2+i)*.6));if touch_index>=0 and t<touch_until and i<30:
				var center=flowers[touch_index].position;p=center+Vector3(sin(a)*.55,cos(a*.7)*.3+.3,cos(a)*.55)
		pollen.multimesh.set_instance_transform(i,Transform3D(rotation_.scaled(Vector3.ONE*(1.5 if g.parade>0 else .65)),p))
	weather.visible=g.rain
	if g.rain:
		for i in range(150):weather.multimesh.set_instance_transform(i,Transform3D(Basis.IDENTITY,Vector3(sin(i*35.1)*5,1+fposmod(i*.37-t*5,8),cos(i*23.4)*4)))
	leaf.set_shader_parameter('clock',t);leaf.set_shader_parameter('breeze',.065 if not g.calm else .02);paper.set_shader_parameter('clock',t)
	var chimney=point(-.23,-1.05,2.13)
	for i in range(6):
		var q=fposmod(t*.18+i/6.0,1.0);var p=chimney+Vector3(sin(t*.6+i)*.09+q*.38,q*1.15,0);smoke.multimesh.set_instance_transform(i,Transform3D(Basis.IDENTITY.scaled(Vector3.ONE*(.7+q*1.8)),p));smoke.multimesh.set_instance_custom_data(i,Color(q,0,0,0))
	fireflies.visible=night_weight>.4;firefly_halos.visible=night_weight>.4
	for i in range(48):
		var a=i*2.4+t*.12;var r=1.0+fmod(i*.19,2.5);var p=Vector3(sin(a)*r,3.5+sin(t*.5+i)*.6,cos(a)*r*.75);var size_=.5+pow(maxf(0,sin(t*.8+i)),5)*1.4;fireflies.multimesh.set_instance_transform(i,Transform3D(Basis.IDENTITY.scaled(Vector3.ONE*size_),p));firefly_halos.multimesh.set_instance_transform(i,Transform3D(camera.basis.scaled(Vector3.ONE*(.65+size_*.3)),p))
	ground_mat.set_shader_parameter('night',night_weight);lagoon_mat.set_shader_parameter('clock',t);lagoon_mat.set_shader_parameter('night',night_weight);lagoon_mat.set_shader_parameter('warmth',cinematic_warmth)
	water.set_shader_parameter('clock',t)
	for i in range(ripples.size()):
		var q=fposmod(t*(.8 if g.rain else .25)+i*.33,1.0);ripples[i].scale=Vector3(q,1,q*.65);ripples[i].visible=q>.08
	paper.set_shader_parameter('night',night_weight);leaf.set_shader_parameter('night',night_weight);glow.set_shader_parameter('night',night_weight)
	leaf.set_shader_parameter('season',float(g.season));paper.set_shader_parameter('warmth',.12 if g.season==2 else 0.0)
	var e=environment.environment;e.background_color=Color('#d8e6df').lerp(Color('#172b3e'),night_weight);e.ambient_light_energy=.45 if g.night else .8;sun.light_energy=lerpf(1.05,.35,night_weight);sun.light_color=Color('#b2c9e7') if g.night else Color('#fff0d7')
	update_camera()
	landscape.update(self);post.size=viewport_size;wash.set_shader_parameter('warmth',cinematic_warmth);wash.set_shader_parameter('night',night_weight)
func update_camera():
	var t=g.elapsed;var portrait=viewport_size.y>viewport_size.x
	camera.keep_aspect=Camera3D.KEEP_WIDTH if portrait else Camera3D.KEEP_HEIGHT
	if director:
		camera.projection=Camera3D.PROJECTION_PERSPECTIVE
		director_phase=fposmod((t-director_origin)/65.0,1.0)
		var sample=director_sample(director_phase);var new_pos=sample[0];var new_aim=sample[1]
		if portrait:
			sample[2]*=1.0-.19*pow(maxf(0,sin(director_phase*PI)),2);new_aim.y-=1.0
		if not camera_initialized:camera.position=new_pos;aim=new_aim;camera.fov=sample[2]
		else:camera.position=camera.position.lerp(new_pos,1-exp(-camera_dt*3));aim=aim.lerp(new_aim,1-exp(-camera_dt*3.5));camera.fov=lerpf(camera.fov,sample[2],1-exp(-camera_dt*3.5))
		camera.look_at(aim);cinematic_warmth=.35+.3*sin(director_phase*TAU-1.2)
	else:
		camera.projection=Camera3D.PROJECTION_PERSPECTIVE
		var target=Vector3(0,3.2,.4);var size_=10.2 if portrait else 11.8
		if focus==1:target=Vector3(0,4.25,-.2);size_=7.6 if portrait else 6.2
		if focus==2:target=Vector3(0,2.2,3.8);size_=4.5 if portrait else 4.8
		aim=aim.lerp(target,.08);camera.fov=lerpf(camera.fov,rad_to_deg(2.0*atan(size_/44.0)),.08)
		var angle=yaw+(sin(t*.045)*.27 if g.orbit else 0.0);var p=aim+Vector3(sin(angle)*cos(pitch),sin(pitch),cos(angle)*cos(pitch))*22
		camera.position=camera.position.lerp(p,.1) if camera_initialized else p;camera.look_at(aim);cinematic_warmth=.18+.12*sin(t*.025)
	camera_initialized=true
func director_sample(phase):
	var q=fposmod(phase,1.0)*SHOTS.size();var i=int(q);var u=q-i;var n=SHOTS.size();var a=SHOTS[posmod(i-1,n)];var b=SHOTS[i];var c=SHOTS[(i+1)%n];var d=SHOTS[(i+2)%n]
	var p=b[0].cubic_interpolate(c[0],a[0],d[0],u);var at=b[1].cubic_interpolate(c[1],a[1],d[1],u);p.y=maxf(p.y,3.5)
	return [p,at,lerpf(b[2],c[2],u)]
func flower_screen(i):return camera.unproject_position(flowers[i].global_position)
