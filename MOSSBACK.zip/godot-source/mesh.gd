extends RefCounted
var vertices=PackedVector3Array()
var normals=PackedVector3Array()
var colors=PackedColorArray()
var uv=PackedVector2Array()
func triangle(a,b,c,col,normal=Vector3.ZERO):
	var n=(b-a).cross(c-a).normalized() if normal==Vector3.ZERO else normal
	vertices.append_array(PackedVector3Array([a,b,c]));normals.append_array(PackedVector3Array([n,n,n]));colors.append_array(PackedColorArray([Color(col),Color(col),Color(col)]));uv.append_array(PackedVector2Array([Vector2(a.x,a.z),Vector2(b.x,b.z),Vector2(c.x,c.z)]))
func quad(a,b,c,d,col):triangle(a,b,c,col);triangle(a,c,d,col)
func box(p,size_,col):
	var v=[]
	for y in [-1,1]:
		for z in [-1,1]:
			for x in [-1,1]:v.append(p+Vector3(x*size_.x,y*size_.y,z*size_.z)*.5)
	for f in [[0,1,3,2],[4,6,7,5],[0,4,5,1],[2,3,7,6],[0,2,6,4],[1,5,7,3]]:quad(v[f[0]],v[f[1]],v[f[2]],v[f[3]],col)
func tube(a,b,r,col,sides=7):
	var axis=(b-a).normalized();var side=axis.cross(Vector3.UP)
	if side.length()<.01:side=axis.cross(Vector3.RIGHT)
	side=side.normalized();var other=side.cross(axis).normalized()
	for i in range(sides):
		var d=side*cos(i*TAU/sides)+other*sin(i*TAU/sides);var e=side*cos((i+1)*TAU/sides)+other*sin((i+1)*TAU/sides)
		quad(a+d*r,b+d*r,b+e*r,a+e*r,col);triangle(a,a+e*r,a+d*r,col);triangle(b,b+d*r,b+e*r,col)
func ellipsoid(p,size_,col,segments=14,rings=8):
	for j in range(rings):
		for i in range(segments):
			var pts=[];var ns=[]
			for q in [Vector2(i,j),Vector2(i+1,j),Vector2(i+1,j+1),Vector2(i,j+1)]:
				var a=q.x*TAU/segments;var b=q.y*PI/rings;var n=Vector3(sin(b)*cos(a),cos(b),sin(b)*sin(a));pts.append(p+n*size_);ns.append(n)
			for k in [0,1,2,0,2,3]:
				vertices.append(pts[k]);normals.append(ns[k]);var c=Color(col).lightened(maxf(0,ns[k].y)*.11).darkened(maxf(0,-ns[k].y)*.08);colors.append(c);uv.append(Vector2(pts[k].x,pts[k].z))
func roof(p,size_,col):
	var a=p+Vector3(-size_.x/2,0,-size_.z/2);var b=p+Vector3(size_.x/2,0,-size_.z/2);var c=p+Vector3(size_.x/2,0,size_.z/2);var d=p+Vector3(-size_.x/2,0,size_.z/2);var top=p+Vector3(0,size_.y,0)
	for e in [[a,b],[b,c],[c,d],[d,a]]:triangle(e[0],top,e[1],col)
func mesh(material):
	var a=[];a.resize(Mesh.ARRAY_MAX);a[Mesh.ARRAY_VERTEX]=vertices;a[Mesh.ARRAY_NORMAL]=normals;a[Mesh.ARRAY_COLOR]=colors;a[Mesh.ARRAY_TEX_UV]=uv
	var m=ArrayMesh.new();m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,a);m.surface_set_material(0,material);return m
