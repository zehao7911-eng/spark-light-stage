extends RefCounted
# Roof envelope includes the eaves; canopy envelopes include shader wind.
const ROOF=Rect2(Vector2(-1.60,-1.58),Vector2(1.90,1.68))
const TREE_SPECS=[
 {'base':Vector2(-2.65,-1.40),'height':2.6},
 {'base':Vector2(2.60,-1.40),'height':2.25}]
const CANOPY_RADIUS=.78
const WIND_MARGIN=.07
const ROOF_CLEARANCE=.15
static func crown_rect(spec):return Rect2(spec.base-Vector2.ONE*(CANOPY_RADIUS+WIND_MARGIN),Vector2.ONE*(CANOPY_RADIUS+WIND_MARGIN)*2)
static func make_tree(w,spec):
	var B=load('res://mesh.gd');var wood=B.new();var leaves=B.new();var p=w.point(spec.base.x,spec.base.y);var h=spec.height
	wood.tube(p,p+Vector3(-.06,h*.32,.015),.105,Color('#8d8272'),9);wood.tube(p+Vector3(-.06,h*.32,.015),p+Vector3(.04,h*.66,0),.075,Color('#968876'),8)
	for j in range(9):
		var a=j*2.4;var end=p+Vector3(cos(a)*.35,h*(.71+.06*sin(j*1.8)),sin(a)*.31)
		wood.tube(p+Vector3(.01,h*.48,0),end,.035,Color('#968876'),6)
		leaves.ellipsoid(end,Vector3(.37,.25,.34),Color('#9cbb99').lightened(.05*sin(j)),12,8)
		for k in range(5):
			var a2=k*2.4+j;var q=end+Vector3(sin(a2)*.17,sin(k*1.2)*.13,cos(a2)*.15)
			leaves.ellipsoid(q,Vector3(.20,.17,.19),Color('#b0c69c').lightened(.05*sin(k+j)),10,6)
		for k in range(2):leaves.ellipsoid(end+Vector3(sin(k*2+j)*.23,.20,cos(k*2+j)*.22),Vector3(.09,.065,.09),Color('#e8c5b7'),8,5)
	w.add_mesh(wood,w.beast,w.paper);var crown=w.add_mesh(leaves,w.beast,w.leaf);w.tree_crowns.append(crown)
static func foundation(w):
	var B=load('res://mesh.gd');var b=B.new();var home=w.point(-.65,-.75,.03);var corners=[]
	for v in [Vector2(-.78,-.67),Vector2(.78,-.67),Vector2(.78,.67),Vector2(-.78,.67)]:corners.append(home+Vector3(v.x,0,v.y))
	for i in range(4):
		var a=corners[i];var c=corners[(i+1)%4];var lowa=Vector3(a.x,w.height(a.x,a.z)-.025,a.z);var lowc=Vector3(c.x,w.height(c.x,c.z)-.025,c.z)
		b.quad(lowa,lowc,c,a,Color('#c4baa0'))
		for j in range(8):
			var q=a.lerp(c,j/8.0);var r=a.lerp(c,(j+1)/8.0);b.tube(q+Vector3(0,-.07,0),r+Vector3(0,-.07,0),.008,Color('#a59d85'),4)
	b.quad(corners[0],corners[1],corners[2],corners[3],Color('#d8d0b1'));w.add_mesh(b,w.beast,w.paper)
