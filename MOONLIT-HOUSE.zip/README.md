# MUNCHY'S MIDNIGHT KITCHEN

A touch-first, endless HTML5 luck game about a candy-eating monster and its midnight supper club.

Choose a recipe with a visible chance and payout multiplier, choose how many jellybeans to risk, then feed the fortune. Wins grow your purse and yum streak; misses spend the chosen stake. Every fifth round opens a kitchen-charm choice, while recipe odds and payouts evolve as the night goes on. New nights create a fresh seed, pantry, specials, and kitchen colors.

Open `moonlit-house.html` in a modern browser. It is a standalone file with no build step or external assets. Sound is synthesized locally by the browser after you turn it on. Your best purse is stored only in this browser.

**Jellybeans are score-only play points. They have no cash value. The game has no purchases or cash-out.**

## Controls

- Tap a recipe to select its risk and payout.
- Choose 10, 25, 50, or all available jellybeans.
- Tap **Feed the Fortune** to reveal the result.
- Choose a kitchen charm after each fifth round.
- Tap **Sound** to enable generated audio.
