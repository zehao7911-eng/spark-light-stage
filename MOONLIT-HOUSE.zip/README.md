# MOONLIT HOUSE

A mobile-first, single-player endless game of chance set around an illustrated moonlit roulette table.

## Play

Open `moonlit-house.html` in a modern browser. Choose one of three gates, then spin. Each new run receives a different seed, reshuffling its omens, house names, and relic offers. Survive floor after floor; every fifth floor opens a special relic event. The wheel result uses the odds shown on the selected gate.

The game runs as a single HTML file. It uses no build step and keeps score in local browser storage only. Sound is synthesized by the browser and starts only after you enable it.

**Virtual play credits have no cash value. There are no purchases, cash-outs, or real-money wagers.**

## Controls

- Tap or click a gate to select it.
- Tap **Spin the Wheel** (or press Space on desktop) to play.
- Tap **Sound** to toggle generated audio.
- Tap **New Run** to create a fresh seeded run.

Designed for touch screens and portrait phones, with desktop layout support.
