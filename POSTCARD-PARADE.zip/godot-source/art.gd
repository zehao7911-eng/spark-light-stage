extends Node2D
var game
var picture = 0

func r(x,y,w,h,c): draw_rect(Rect2(floor(x),floor(y),w,h),Color('#'+c))
func l(x,y,xx,yy,c,w=1): draw_line(Vector2(x,y),Vector2(xx,yy),Color('#'+c),w)

func bush(x,y,width=24,color='6e9775'):
	r(x+4,y-11,width-8,19,color); r(x,y-6,width,12,color)
	for i in range(6): r(x+3+(i*7)%(width-5),y-7+(i*3)%11,3,2,'91ac7c')

func pot(x,y,c='ce9877'):
	r(x-6,y,12,12,c); r(x-8,y-2,16,3,'e1b390'); r(x-3,y+3,2,6,'e7b99a')
	l(x,y-2,x-1,y-20,'68836d',2)
	for i in range(3): r(x-9+(i%2)*10,y-8-i*5,8,3,'759877')

func window(x,y,w=20,h=26,night=false):
	r(x-2,y-2,w+4,h+5,'a38873'); r(x,y,w,h,'f2dfad' if night else '689aab')
	r(x+2,y+2,w-4,2,'f8ebc8' if night else 'b2d1ce'); r(x+w/2-1,y,2,h,'d7c7a3')
	r(x,y+h/2, w,2,'d7c7a3'); r(x-4,y+h+1,w+8,3,'e6cba2')

func roof(x,y,w,h,c='b86f66'):
	for yy in range(h):
		var inset=int(float(h-yy)/h*12)
		r(x+inset,y+yy,w-inset*2,1,c)
	for yy in range(3,h,5):
		var inset=int(float(h-yy)/h*12)
		r(x+inset,y+yy,w-inset*2,1,'9d625e')
		for xx in range(int(x+inset+3),int(x+w-inset-2),8): r(xx+(yy%2)*3,y+yy-2,1,2,'dc9c7d')
	r(x-3,y+h,w+6,3,'714e50'); r(x+9,y-2,w-18,3,'d4a180')

func flowers(x,y,w=30):
	r(x,y,w,7,'9f7865'); r(x-2,y,w+4,2,'c69b7b')
	for i in range(7):
		var xx=x+2+i*(w-4)/7
		r(xx,y-5,2,6,'729271'); r(xx-1,y-6,4,3,['ebbe8d','dfa0a2','e9d5a6'][i%3]); r(xx,y-7,2,5,['ebbe8d','dfa0a2','e9d5a6'][i%3])

func bicycle(x,y):
	for xx in [x,x+23]:
		draw_arc(Vector2(xx,y),8,0,TAU,18,Color('#617778'),1)
		l(xx-5,y,xx+5,y,'a3b2a0')
	l(x,y,x+9,y-12,'bd8370',2); l(x+9,y-12,x+17,y,'bd8370',2); l(x+17,y,x,y,'bd8370',2)
	l(x+17,y,x+23,y-14,'bd8370',2); l(x+20,y-14,x+28,y-14,'526e72',2); r(x+5,y-15,9,2,'526e72')

func cat(x,y,c='d3b08c'):
	r(x,y,16,9,c); r(x+10,y-7,10,9,c); r(x+10,y-10,3,5,c); r(x+17,y-10,3,5,c)
	r(x+12,y-4,2,1,'605759'); r(x+17,y-4,2,1,'605759'); r(x+1,y+7,4,3,c); r(x+12,y+7,4,3,c)
	l(x,y+3,x-7,y-3,c,3)

func house(x,y,w,h,color='dbcaa6',night=false):
	r(x+4,y+4,w,h,'849084'); r(x,y,w,h,color); r(x+3,y+3,3,h-6,'eadabd')
	for yy in range(int(y+9),int(y+h-3),9):
		for xx in range(int(x+7+(yy%2)*4),int(x+w-5),19): r(xx,yy,7,1,'c8b89d')
	r(x,y+h-4,w,4,'b2997e')
	for xx in [x+13,x+w-34]: window(xx,y+17,20,28,night)

func _draw():
	var id=picture
	var night=id in [3,5,8,11]
	var sky=['b7d5cc','c6d9b5','a9ccdb','8198b5','e8d6bf','a1a9c5','cfdbbf','d9d8ae','8b98bc','bbcbb4','d4d3bb','8d99ba'][id]
	r(0,0,240,240,sky)
	# Small hand-placed texture, never randomized at runtime: adjacent pieces share lines.
	for i in range(40):
		var x=(i*73+id*17)%240; var y=(i*29+13)%105
		r(x,y,1,1,'dce4c7' if not night else 'c5c5d4')
	if night:
		r(191,21,16,16,'e9dfb6'); r(188,24,22,10,'e9dfb6'); r(196,19,9,20,'e9dfb6')
		for i in range(11): r(15+(i*37)%210,15+(i*17)%71,2,2,'e7dcb8')
	else:
		for i in range(4):
			var x=18+i*64-id*3
			r(x,21+i%2*12,35,7,'e6e8d0'); r(x+6,17+i%2*12,18,14,'e6e8d0')
	# Layered hills keep each postcard a miniature world.
	for x in range(240):
		var y=94+sin(x*.035+id)*8+sin(x*.08)*4
		r(x,y,1,80,'96b7a0' if not night else '657f95')
	r(0,174,240,66,'c8b895' if not night else '81919d')
	for i in range(70): r((i*43)%240,180+(i*13)%59,4,1,'dacead' if not night else '9ca8ad')
	match id:
		0: coffee()
		1: greenhouse()
		2: lighthouse()
		3: bookshop()
		4: bakery()
		5: train()
		6: rooftop()
		7: honey()
		8: pier()
		9: mushroom()
		10: provence()
		11: observatory()
	# Foreground detail anchors all four corners for visual puzzle reading.
	bush(0,225,35); bush(209,222,35)
	for i in range(12):
		var x=5+i*21; var y=222+(i%3)*5
		r(x,y,2,8,'719173'); r(x-2,y-2,6,3,['e5bb87','d69496','ece0b4'][i%3])
	r(0,237,240,3,'8b997d')

func coffee():
	house(47,69,143,115); roof(39,41,159,29)
	window(62,83,24,29); window(145,83,24,29); flowers(59,115,30); flowers(143,115,30)
	r(102,116,29,68,'8e9a8a'); r(106,120,21,47,'b5c2a7'); r(123,149,2,2,'e8cf9b')
	r(46,124,51,10,'a77a65'); r(140,124,51,10,'a77a65')
	for i in range(6): r(46+i*8,125,4,8,'eee1bb'); r(141+i*8,125,4,8,'eee1bb')
	r(57,137,33,29,'4e7a83'); r(144,137,33,29,'4e7a83')
	r(94,89,43,15,'7f9c8b'); r(99,93,4,5,'eee1bd'); r(106,93,24,2,'eee1bd'); r(106,97,19,2,'eee1bd')
	r(35,177,57,5,'a7846b'); r(41,182,3,18,'a7846b'); r(83,182,3,18,'a7846b')
	r(51,169,8,7,'f0dfb6'); r(59,171,3,3,'f0dfb6'); pot(182,177); bicycle(149,205); cat(43,205)

func greenhouse():
	r(34,86,172,95,'5a8986'); r(38,89,164,88,'95beb0')
	for y in range(49): r(35+int(y/3),85-y,170-int(y*2/3),1,'8bafa4')
	for i in range(7): l(38+i*27,85,38+i*27,181,'e7d6ad',3)
	for i in range(5): l(38,85+i*23,204,85+i*23,'e7d6ad',3)
	l(35,85,120,37,'e7d6ad',3); l(120,37,206,85,'e7d6ad',3); l(120,38,120,181,'e7d6ad',3)
	for i in range(7): pot(48+i*23,157-i%2*24,['bf9073','d5b18a','a5ad85'][i%3])
	r(107,129,27,55,'d9d3ab'); r(111,133,19,47,'7eab98'); r(112,133,2,45,'afd0b2')
	for i in range(4): flowers(44+i*41,186,31)
	r(153,205,31,8,'b99a76'); r(160,199,16,6,'d1b590'); cat(72,210,'e1caab')

func lighthouse():
	r(0,123,240,97,'80aeba')
	for i in range(45): r((i*47)%240,129+i%11*7,13+i%7,1,'b5cdd0')
	r(0,193,137,47,'bba984'); bush(0,174,68)
	for y in range(115):
		var inset=int((115-y)*.08)
		r(87+inset,62+y,50-inset*2,1,'ecdbb2' if int(y/20)%2==0 else 'bd8171')
	r(83,58,58,6,'6b6c6d'); r(91,37,42,22,'79a7b4'); r(94,39,3,18,'e5d4a9'); r(111,39,3,18,'e5d4a9'); r(129,39,3,18,'e5d4a9')
	roof(84,22,56,15,'8f7670'); r(101,144,20,33,'627d80'); window(103,87,15,19)
	house(20,145,58,36); roof(12,127,73,18); r(43,155,14,26,'82988b'); flowers(22,183,27)
	r(152,176,44,9,'9b7d69'); r(158,185,3,19,'9b7d69'); l(130,179,185,187,'c5b49a'); bicycle(25,211)

func bookshop():
	house(40,66,161,121,'b6bbaf',true); roof(32,37,177,29,'7b7d88')
	window(56,80,26,31,true); window(153,80,26,31,true); flowers(53,114,32); flowers(150,114,32)
	r(91,85,52,18,'667c81'); r(98,90,37,2,'e6d9b4'); r(103,95,27,2,'e6d9b4')
	r(52,137,55,40,'5b737c'); r(134,137,55,40,'5b737c')
	for i in range(16):
		var x=55+i%8*6; var y=142+int(i/8)*17
		r(x,y,4,12,['c9957f','9daa93','d7bf8b','a9a5bb'][i%4]); r(x+82,y,4,12,['9daa93','c9957f','a9a5bb','d7bf8b'][i%4])
	r(112,130,17,57,'7d8b85'); r(115,136,11,37,'e7d3a3')
	r(25,172,4,35,'6e7779'); r(18,162,17,13,'ecd29a'); roof(17,157,20,5,'6e7779')
	cat(171,201,'e3ccab'); pot(49,188); r(79,203,22,6,'8d9c90'); r(83,198,19,5,'c49b80')

func bakery():
	house(45,72,147,111,'e1b99c'); roof(36,45,165,27,'ad7970'); window(60,88,25,24); window(151,88,25,24)
	r(89,89,53,19,'f1dbac'); r(99,94,32,3,'bd8371'); r(106,100,18,2,'bd8371')
	r(43,123,151,12,'b77e74')
	for i in range(15): r(43+i*10,124,5,10,'eddbb7')
	r(54,139,50,31,'6e9295'); r(132,139,50,31,'6e9295'); r(111,133,15,51,'91a393')
	for i in range(10):
		var x=58+i%5*9; var y=146+int(i/5)*12
		r(x,y,7,5,'d4aa73'); r(x+79,y,7,5,'e4bd85'); r(x+2,y-1,3,2,'e9c98f')
	r(24,191,45,5,'a78269'); r(29,196,3,13,'a78269'); r(61,196,3,13,'a78269')
	r(38,183,13,7,'e7d2a9'); r(40,180,9,3,'bc8d6d'); pot(190,186); bicycle(145,208); flowers(73,190,27)

func train():
	r(0,182,240,58,'92958e'); r(0,210,240,6,'6e6e70'); r(0,229,240,3,'6e6e70')
	for i in range(18): r(i*15,214,5,15,'b59a80')
	r(20,118,203,65,'ac8173'); r(18,112,207,9,'e1c9a4'); r(22,166,199,12,'7b797e')
	for i in range(6): window(32+i*31,129,22,26,true)
	for i in range(4):
		draw_circle(Vector2(47+i*49,186),10,Color('#56676e')); draw_circle(Vector2(47+i*49,186),5,Color('#9ba7a0'))
	r(7,84,225,6,'d4c6a8'); r(20,89,4,20,'9c8f7f'); r(215,89,4,20,'9c8f7f')
	roof(0,64,240,20,'707d88'); r(111,87,26,12,'627d87'); r(117,91,14,2,'ecdcb4')
	r(176,196,20,10,'b49279'); r(179,192,13,4,'c9ab85'); cat(200,200,'d8c4a4')

func rooftop():
	house(54,91,136,110,'d7bc9d'); roof(42,69,160,22,'a97c73')
	for x in [66,113,160]: window(x,111,21,29); flowers(x-2,142,26)
	r(50,64,146,5,'a28e74'); r(56,36,3,29,'819184'); r(104,36,3,29,'819184'); r(151,36,3,29,'819184'); r(191,36,3,29,'819184')
	l(57,37,194,37,'a6a889',2)
	for x in [65,85,112,134,161,183]: pot(x,54,['bd9677','c4ad85','a6ab8b'][int(x)%3])
	r(103,165,29,36,'7f9b90'); r(109,171,16,26,'adc1a6'); bush(31,195,33); bush(177,193,35); cat(133,207)

func honey():
	house(52,75,138,111,'d9ce9f'); roof(39,41,164,35,'b99768'); window(65,94,28,31); window(150,94,25,31)
	r(104,92,37,18,'9ca88b'); r(112,96,21,2,'eddfb4'); r(118,101,9,2,'eddfb4')
	r(111,143,22,44,'a39176'); r(115,149,14,35,'c7b08b')
	for i in range(3):
		var x=25+i*72
		r(x,180,33,21,'bb9968'); r(x-3,177,39,5,'e0bd7f'); r(x+3,186,27,2,'ddbd83'); r(x+3,193,27,2,'ddbd83'); r(x+13,198,8,3,'6e6d5e')
	for i in range(7):
		var x=28+i*29; var y=146+i%2*18
		r(x,y,6,4,'e5c684'); r(x+2,y,2,4,'7c7563'); r(x-1,y-3,3,3,'e4dfc0'); r(x+4,y-3,3,3,'e4dfc0')
	flowers(79,210,79)

func pier():
	r(0,115,240,125,'637e9d')
	for i in range(60): r((i*47)%240,122+i%16*7,11+i%7,1,'9aacb8')
	r(34,167,177,17,'af967d')
	for x in range(36,211,9): r(x,168,1,14,'796f69')
	for x in [48,106,190]: r(x,182,6,34,'8b7e72'); r(x-2,162,10,5,'d0b18a')
	house(71,93,96,72,'b6b8aa',true); roof(62,72,114,21,'7a7b86'); window(85,107,23,28,true); window(132,107,20,28,true)
	r(113,126,14,39,'a68c75'); r(117,130,6,25,'e7c995')
	r(24,201,58,8,'ba9a7e'); r(31,209,44,4,'8b7d73'); l(51,196,51,174,'d3ba96'); cat(174,168,'d9c9ad')

func mushroom():
	for x in [17,39,202,226]:
		r(x,33,8,143,'8c8d72'); bush(x-18,47,47,'73917a'); bush(x-11,75,35,'7d9b7d')
	house(72,115,99,74,'ded0a7'); window(86,135,24,25); window(136,135,20,25)
	r(118,148,16,42,'919b81')
	for y in range(60):
		var inset=int(pow((60-y)/60.0,1.6)*60)
		r(46+inset,58+y,151-inset*2,1,'c88d7e')
	r(42,116,158,7,'9b756b')
	for p in [Vector2(92,83),Vector2(139,75),Vector2(157,96),Vector2(72,104),Vector2(118,105)]:
		r(p.x,p.y,11,6,'e8ccaa'); r(p.x+2,p.y-2,7,10,'e8ccaa')
	for i in range(6):
		var x=22+i*37; var y=202+i%2*8
		r(x+4,y,4,10,'d2c8a3'); r(x,y-5,13,6,'bd8b7a'); r(x+3,y-7,7,3,'bd8b7a')
	cat(150,199,'d5b697')

func provence():
	house(53,72,136,118,'d8c7a2'); roof(43,45,156,27,'ba8873')
	for x in [65,152]: window(x,87,24,32); r(x-5,86,4,34,'8c9f90'); r(x+25,86,4,34,'8c9f90'); flowers(x-2,121,29)
	r(109,140,26,50,'92a596'); r(113,144,18,41,'acbca3')
	for i in range(12):
		var x=15+i*19; var y=187+i%3*10
		l(x,y+13,x+3,y-5,'7f967d',2); r(x,y-8,6,9,'a7a1be'); r(x+1,y-11,3,6,'b4aac7')
	l(79,53,165,26,'8f9b80',2)
	for x in [94,112,135,155]: r(x,34+int((155-x)/5),7,11,['e1c2a0','b5bba3','caabba'][int(x)%3])
	bicycle(54,211); cat(164,205); pot(37,166)

func observatory():
	house(57,109,128,80,'abb5ad',true); window(73,129,25,29,true); window(147,129,23,29,true)
	for y in range(66):
		var inset=int(pow((66-y)/66.0,1.7)*58)
		r(53+inset,44+y,136-inset*2,1,'7f929f')
	for x in [76,104,136,165]: l(x,104,121+(x-121)*.3,52,'a9b4b6',1)
	r(48,106,147,6,'c6bea4'); r(109,153,23,37,'7d9390'); r(115,160,10,24,'dbc99e')
	l(138,52,175,28,'a6b5b6',8); l(168,27,178,33,'e4d6af',3); r(134,51,7,18,'b5baa9')
	r(21,190,43,5,'aa9179'); r(26,194,3,18,'aa9179'); r(56,194,3,18,'aa9179'); r(35,183,13,7,'d7ba8a')
	cat(164,201,'b8c3ba'); pot(188,185)
