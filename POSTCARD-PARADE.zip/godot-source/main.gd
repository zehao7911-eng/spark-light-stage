extends Node2D
const TITLES=['A Corner for Coffee','The Glass Garden','Letters by the Sea','The Midnight Bookshop','A Slice of Sunday','The Last Little Train','A Roof Full of Flowers','The Honey House','Moonlight at the Pier','The Mushroom Cottage','An Afternoon in Provence','A Window for the Stars']
var puzzle = 0
var grid = 3
var pieces = []
var best = []
var moves = 0
var hints = 0
var selected = -1
var won = false
var mode = 'puzzle'
var wall = 0
var light = false
var muted = false
var preview = false
var paused = true
var event = 0
var notice = 'Choose two picture pieces to swap them.'
var fx = []
var time = 0.0
var ticker = 0.0
var callback
var art: SubViewport
var painting
var cached: ImageTexture
var generating = false
var board = Rect2()
var drag_start = Vector2.ZERO
var drag_index = -1
var pointer = Vector2.ZERO
var drag_active = false
var album = []

func _ready():
	for i in range(12): best.append(0)
	album.resize(12)
	art=SubViewport.new(); art.size=Vector2i(240,240); art.render_target_update_mode=SubViewport.UPDATE_ALWAYS
	add_child(art)
	painting=Node2D.new(); painting.set_script(preload('art.gd')); painting.game=self; art.add_child(painting)
	if not restore(): new_puzzle(0)
	if OS.has_feature('web'):
		callback=JavaScriptBridge.create_callback(web_action)
		JavaScriptBridge.get_interface('window').pAction=callback
	refresh_art()
	if '--qa' in OS.get_cmdline_user_args(): verify()

func size_for(id): return 3 if id<3 else (4 if id<8 else 5)
func unlocked():
	var count=1
	for i in range(11):
		if best[i]>0: count=i+2
		else: break
	return count
func stars():
	var total=0
	for b in best: total+=int(b)
	return total
func settled():
	var result=0
	for i in range(pieces.size()):
		if int(pieces[i])==i: result+=1
	return result
func rating(): return 1+(1 if hints==0 else 0)+(1 if moves<=grid*grid else 0)

func new_puzzle(id):
	puzzle=clampi(id,0,11); grid=size_for(puzzle); pieces=[]
	for i in range(grid*grid): pieces.append(i)
	pieces.shuffle()
	# A fully scrambled start, so every visible settled piece was earned.
	for i in range(pieces.size()):
		if int(pieces[i])==i:
			var j=(i+1)%pieces.size(); var value=pieces[i]; pieces[i]=pieces[j]; pieces[j]=value
	if settled()==pieces.size(): pieces.reverse()
	moves=0; hints=0; selected=-1; won=false; preview=false; mode='puzzle'; fx=[]
	tell('A fresh letter. One little piece at a time.')
	if art: refresh_art()
	save_game()

func refresh_art():
	if album[puzzle] is ImageTexture:
		cached=album[puzzle]
		return
	if generating: return
	generating=true
	art.render_target_update_mode=SubViewport.UPDATE_ALWAYS
	for id in range(12):
		painting.picture=id
		painting.queue_redraw()
		await RenderingServer.frame_post_draw
		await RenderingServer.frame_post_draw
		album[id]=ImageTexture.create_from_image(art.get_texture().get_image())
		if OS.has_feature('web'):
			var png=Marshalls.raw_to_base64(album[id].get_image().save_png_to_buffer())
			JavaScriptBridge.eval('window.pArt && window.pArt('+str(id)+','+JSON.stringify(png)+');')
	cached=album[puzzle]
	art.render_target_update_mode=SubViewport.UPDATE_DISABLED
	generating=false

func tell(text): notice=text; event+=1

func swap(a,b):
	if won or a<0 or b<0 or a>=pieces.size() or b>=pieces.size() or a==b: return
	if int(pieces[a])==a or int(pieces[b])==b: tell('That piece has found its home.'); return
	var value=pieces[a]; pieces[a]=pieces[b]; pieces[b]=value
	moves+=1; selected=-1
	var found=0
	for index in [a,b]:
		if int(pieces[index])==index:
			found+=1; burst(center(index),12,'e6c486')
	if found>0: tell('A perfect fit.' if found==1 else 'Two little things, just right.')
	else: tell('Try another neighbour.')
	check_win(); save_game()

func check_win():
	if settled()!=pieces.size(): return
	won=true; selected=-1; preview=false
	var score=rating()
	best[puzzle]=maxi(int(best[puzzle]),score)
	for i in range(60): burst(Vector2(board.position.x+randf()*board.size.x,board.position.y+randf()*board.size.y),1,['e6c486','94b4a0','df9c93'][i%3])
	tell('One lovely picture. Yours to keep.')

func nudge():
	if won: return
	var target=-1
	for i in range(pieces.size()):
		if int(pieces[i])!=i: target=i; break
	if target<0: return
	var source=pieces.find(target)
	hints+=1
	swap(source,target)

func burst(p,n,c):
	for i in range(n):
		if fx.size()<140: fx.append({'x':p.x,'y':p.y,'vx':randf_range(-80,80),'vy':randf_range(-120,30),'life':randf_range(.45,1.4),'c':c})

func center(index):
	var cell=board.size.x/grid
	return board.position+Vector2(index%grid+.5,int(index/grid)+.5)*cell

func hit(p):
	if not board.has_point(p): return -1
	var c=(p-board.position)/(board.size.x/grid)
	return clampi(int(c.y),0,grid-1)*grid+clampi(int(c.x),0,grid-1)

func tap(index):
	if paused or won or mode!='puzzle' or index<0 or index>=pieces.size(): return
	if int(pieces[index])==index: tell('A happy little piece. Already home.'); return
	if selected<0: selected=index
	elif selected==index: selected=-1
	else: swap(selected,index)

func _unhandled_input(e):
	if paused or won or mode!='puzzle' or preview: return
	if e is InputEventMouseButton and e.button_index==MOUSE_BUTTON_LEFT:
		if e.pressed:
			drag_start=e.position; pointer=e.position; drag_index=hit(e.position); drag_active=false
		else:
			var destination=hit(e.position)
			if drag_active: swap(drag_index,destination)
			elif destination>=0:
				if int(pieces[destination])==destination: tell('A happy little piece. Already home.')
				elif selected<0: selected=destination
				elif selected==destination: selected=-1
				else: swap(selected,destination)
			drag_index=-1; drag_active=false
	if e is InputEventMouseMotion:
		pointer=e.position
		if drag_index>=0 and int(pieces[drag_index])!=drag_index and e.position.distance_to(drag_start)>8: drag_active=true

func web_action(args):
	if args.size(): action(str(args[0]))

func action(cmd):
	var b=cmd.split(':'); var id=int(b[1]) if b.size()>1 else 0
	match b[0]:
		'tap': tap(id)
		'swap':
			if b.size()>=3: swap(id,int(b[2])); drag_index=-1; drag_active=false
		'drag':
			if b.size()>=4 and id>=0 and id<pieces.size() and int(pieces[id])!=id:
				drag_index=id; drag_active=true; pointer=Vector2(float(b[2]),float(b[3]))
		'begin': paused=false
		'pause': paused=id==1; drag_index=-1; drag_active=false; preview=false
		'nudge': nudge()
		'peek': preview=id==1
		'cancel': drag_index=-1; drag_active=false; preview=false
		'next':
			if won and puzzle<11: new_puzzle(puzzle+1)
		'replay': new_puzzle(puzzle)
		'open':
			if id>=0 and id<unlocked(): new_puzzle(id)
		'mode': mode='gallery' if mode=='puzzle' else 'puzzle'; selected=-1; tell('A wall of lovely afternoons.' if mode=='gallery' else 'One picture piece at a time.')
		'wall':
			if id>=0 and id<4 and stars()>=[0,6,15,24][id]: wall=id; save_game()
		'light': light=not light; save_game()
		'sound': muted=not muted; save_game()
		'photo': photo()

func _process(dt):
	var s=get_viewport_rect().size
	var available=maxf(120,s.y-(260 if s.x<600 else (205 if s.y<500 else 270)))
	var width=minf(s.x-40,available)
	board=Rect2(Vector2((s.x-width)/2,(88 if s.x<600 else 104)+(available-width)/2),Vector2(width,width))
	if s.y<500 and s.x>600:
		width=minf(s.y-106,s.x*.48)
		board=Rect2(Vector2((s.x*.52-width)/2,82),Vector2(width,width))
	if not paused:
		time+=dt
		for f in fx: f.x+=f.vx*dt; f.y+=f.vy*dt; f.vy+=dt*120; f.life-=dt
		fx=fx.filter(func(f):return f.life>0)
	ticker+=dt
	if ticker>.15:
		ticker=0
		if OS.has_feature('web'): JavaScriptBridge.eval('window.pState && window.pState('+JSON.stringify(snapshot())+');')
	queue_redraw()

func _draw():
	var size=get_viewport_rect().size
	var walls=['#ede3d0','#d5ded6','#dfd3da','#c6d6de']
	draw_rect(get_viewport_rect(),Color(walls[wall]))
	for x in range(0,int(size.x),52): draw_line(Vector2(x,60),Vector2(x,size.y),Color(0.7,0.65,0.53,.12),1)
	var floor_y=size.y-(185 if size.x<600 else 175)
	draw_rect(Rect2(0,floor_y,size.x,6),Color('#b29b7b'))
	draw_rect(Rect2(0,floor_y+6,size.x,size.y-floor_y),Color('#c4ad8d'))
	if mode=='gallery':
		draw_gallery()
		if light: draw_rect(Rect2(0,68,size.x,size.y-68),Color(.91,.69,.42,.08))
		return
	if not cached: return
	draw_rect(Rect2(board.position+Vector2(8,12),board.size),Color(0.21,.28,.25,.15))
	draw_rect(Rect2(board.position-Vector2(10,10),board.size+Vector2(20,20)),Color('#896e55'))
	draw_rect(Rect2(board.position-Vector2(6,6),board.size+Vector2(12,12)),Color('#ead7ae'))
	draw_rect(board,Color('#b8af98'))
	if preview or won:
		draw_texture_rect(cached,board,false)
	else:
		var cell=board.size.x/grid
		for i in range(pieces.size()):
			var p=board.position+Vector2(i%grid,int(i/grid))*cell
			var dest=Rect2(p+Vector2(1,1),Vector2(cell-2,cell-2))
			var id=int(pieces[i]); var source=Rect2(Vector2(id%grid,int(id/grid))*240/grid,Vector2(240.0/grid,240.0/grid))
			draw_texture_rect_region(cached,dest,source)
			if id==i:
				draw_rect(dest,Color('#e6dcbd'),false,1)
				draw_circle(p+Vector2(cell-8,8),3,Color('#eef0d4'))
			if i==selected: draw_rect(dest.grow(-2),Color('#fff9da'),false,3)
		if drag_active and drag_index>=0:
			var id=int(pieces[drag_index]); var source=Rect2(Vector2(id%grid,int(id/grid))*240/grid,Vector2(240.0/grid,240.0/grid))
			draw_texture_rect_region(cached,Rect2(pointer-Vector2(cell,cell)/2,Vector2(cell,cell)),source,Color(1,1,1,.9))
			draw_rect(Rect2(pointer-Vector2(cell,cell)/2,Vector2(cell,cell)),Color('#fff6d5'),false,3)
	for f in fx: draw_rect(Rect2(f.x,f.y,4,4),Color('#'+f.c))
	if light: draw_rect(Rect2(board.position,board.size),Color(.91,.69,.42,.10))

func gallery_layout():
	var size=get_viewport_rect().size
	var columns=3 if size.x<600 else 4
	var gap=16.0
	var rows=ceil(12.0/columns)
	var cell=minf((size.x-48-gap*(columns-1))/columns,(size.y-280-gap*(rows-1))/rows)
	var start=Vector2((size.x-columns*cell-(columns-1)*gap)/2,100)
	if size.x<600:
		cell=minf(cell,(size.y-372-gap*(rows-1))/rows)
		start=Vector2((size.x-columns*cell-(columns-1)*gap)/2,122)
	if size.y<500 and size.x>600:
		cell=minf((size.x*.52-48-gap*3)/4,(size.y-130-gap*2)/3)
		start=Vector2((size.x*.52-columns*cell-gap*3)/2,82)
	return {'columns':columns,'cell':cell,'x':start.x,'y':start.y}

func draw_gallery():
	var size=get_viewport_rect().size
	var layout=gallery_layout()
	var columns=int(layout.columns); var cell=layout.cell; var gap=16.0
	var start=Vector2(layout.x,layout.y)
	for i in range(12):
		var pos=start+Vector2(i%columns,int(i/columns))*(cell+gap)
		draw_rect(Rect2(pos+Vector2(3,5),Vector2(cell,cell)),Color(0,.1,.1,.12))
		draw_rect(Rect2(pos-Vector2(4,4),Vector2(cell+8,cell+8)),Color('#8b7058'))
		draw_rect(Rect2(pos,Vector2(cell,cell)),Color('#e6d7b7'))
		if int(best[i])>0:
			if i==puzzle and cached: draw_texture_rect(cached,Rect2(pos,Vector2(cell,cell)),false)
			elif i<album.size() and album[i] is ImageTexture: draw_texture_rect(album[i],Rect2(pos,Vector2(cell,cell)),false)
			else:
				draw_string(ThemeDB.fallback_font,pos+Vector2(10,cell*.55),str(i+1),HORIZONTAL_ALIGNMENT_LEFT,-1,18,Color('#987653'))
		else: draw_string(ThemeDB.fallback_font,pos+Vector2(cell/2-4,cell/2+5),'·',HORIZONTAL_ALIGNMENT_LEFT,-1,20,Color('#b5aa90'))
	if stars()>=6:
		var p=Vector2(25,size.y-205)
		draw_rect(Rect2(p.x,p.y,20,23),Color('#a17c62')); draw_line(p+Vector2(10,0),p+Vector2(8,-35),Color('#65856f'),4)
		for i in range(4): draw_rect(Rect2(p.x-2+(i%2)*12,p.y-i*9-5,14,5),Color('#7d9c7b'))
	if stars()>=15:
		var p=Vector2(size.x-68,size.y-205)
		draw_rect(Rect2(p.x,p.y,40,20),Color('#d5aa82')); draw_rect(Rect2(p.x+7,p.y-9,18,12),Color('#d5aa82'))
		draw_rect(Rect2(p.x+7,p.y-14,5,7),Color('#d5aa82')); draw_rect(Rect2(p.x+20,p.y-14,5,7),Color('#d5aa82'))
		draw_rect(Rect2(p.x+12,p.y-4,3,2),Color('#775d53'))

func snapshot():
	return {'rating':rating() if won else 0,'gallery':gallery_layout(),'ready':not generating and cached!=null,'puzzle':puzzle,'title':TITLES[puzzle],'grid':grid,'pieces':pieces,'settled':settled(),'moves':moves,'hints':hints,'selected':selected,'won':won,'best':best,'stars':stars(),'unlocked':unlocked(),'mode':mode,'wall':wall,'light':light,'muted':muted,'event':event,'notice':notice,'board':{'x':board.position.x,'y':board.position.y,'size':board.size.x},'paused':paused}

func save_game():
	var data=JSON.stringify({'puzzle':puzzle,'pieces':pieces,'moves':moves,'hints':hints,'best':best,'won':won,'wall':wall,'light':light,'muted':muted})
	var file=FileAccess.open('user://postcard-parade.json',FileAccess.WRITE)
	if file: file.store_string(data)
	if OS.has_feature('web'): JavaScriptBridge.eval('try{localStorage.setItem("postcard-parade.v1",'+JSON.stringify(data)+')}catch(e){}')

func restore():
	var data=''
	if OS.has_feature('web'): data=str(JavaScriptBridge.eval('(function(){try{return localStorage.getItem("postcard-parade.v1")||""}catch(e){return ""}})()'))
	elif FileAccess.file_exists('user://postcard-parade.json'): data=FileAccess.get_file_as_string('user://postcard-parade.json')
	if data.is_empty(): return false
	var s=JSON.parse_string(data)
	if not s is Dictionary: return false
	if s.get('best') is Array and s.best.size()==12:
		for i in range(12): best[i]=clampi(int(s.best[i]),0,3)
	puzzle=clampi(int(s.get('puzzle',0)),0,unlocked()-1); grid=size_for(puzzle)
	if not s.get('pieces') is Array or s.pieces.size()!=grid*grid: return false
	var seen=[]
	for id in s.pieces:
		if not (id is int or id is float) or int(id)<0 or int(id)>=grid*grid or int(id) in seen: return false
		seen.append(int(id))
	pieces=seen; moves=maxi(0,int(s.get('moves',0))); hints=maxi(0,int(s.get('hints',0)))
	won=settled()==pieces.size(); wall=clampi(int(s.get('wall',0)),0,3); light=bool(s.get('light',false)); muted=bool(s.get('muted',false))
	return true

func photo():
	if not cached: return
	var data=Marshalls.raw_to_base64(cached.get_image().save_png_to_buffer())
	if OS.has_feature('web'): JavaScriptBridge.eval('window.pPhoto('+JSON.stringify(data)+')')

func verify():
	for id in range(12):
		new_puzzle(id)
		assert(settled()<pieces.size())
		while not won:
			var target=-1
			for i in range(pieces.size()):
				if int(pieces[i])!=i: target=i; break
			swap(pieces.find(target),target)
		assert(best[id]==3)
	assert(stars()==36 and unlocked()==12)
	new_puzzle(11); nudge(); assert(hints==1)
	while not won: nudge()
	assert(best[11]==3)
	print('POSTCARD QA PASS: 12 solvable pictures, settled locks, 36 stars, sequential unlocks, nudge/replay')
	get_tree().quit()
