PIKACHU: STATIC PANIC
Original unofficial fan mini-game. Not affiliated with Nintendo, Game Freak or The Pokemon Company.

Open index.html in a current browser. All assets and scripts are included; no network is required after download. For web hosting, upload this folder intact, or use the standalone static-panic.html file.

DRAG TO MOVE. Nearby enemies get zapped automatically. Hold to build charge; lift to unleash a shockwave once the meter is at least one third full. Cancelled touches, pauses and interruptions never discharge.
Defeat the entire wave, including the giant Electrode. Pick Chain, Turbo or Boom between rounds. Each upgrade has five levels. Waves grow from 16 to a maximum of 38 foes, with at most 18 living enemies. The numbered rounds continue to 999 and reuse the arena with increasing, capped difficulty.
Collect sparks to recharge. Every 12 collected sparks restores one heart. Four hearts; no purchases, ads, betting or accounts. Best wave and highest stars per wave save locally. Retry retains current upgrades. Closing during a wave restores its saved snapshot paused. Storage may be unavailable; session play still works.

Keyboard: arrows/WASD move, hold Space to charge and release to discharge. Escape pauses. Mouse uses the same drag/release controls as touch. Music-note button toggles original synthesized sound.

Original procedural geometric fan characters, diorama, effects, code and synthesized sounds. No commercial model, voice, music, texture or game code was extracted. Three.js r147 included under MIT; see THREE-LICENSE.txt.
Touch and portrait/landscape browser sizes tested by automation; physical handset performance varies. WebGL required; a context failure offers retry. Rendering DPR is capped at 1.5, live enemies at 18, particles at 100, dropped sparks at 50, lightning segments at 70 and audio voices at 12.
