extends Node2D
const Sim=preload('res://sim.gd')
const Painter=preload('res://painter.gd')
const Tile=preload('res://tile.gd')
const Art=preload('res://art.gd')
const FONT=preload('res://fonts/pixel.ttf')
const SAVE='soulstride.v1'
var g=Sim.new()
var hud:Node2D
var ui:Control
var vp:SubViewport
var painter
var image:TextureRect
var view=Vector2.ZERO
var scene_rect=Rect2()
var raw_size=Vector2.ZERO
var ui_scale=1.0
var safe=Vector2.ZERO
var buttons=[]
var popup=''
var overlay:Control
var accumulator=0.0
var sync=0.0
var saving=0.0
var toast=''
var toast_time=0.0
var transition=0.0
var hidden_=false
var away_at=0.0
var callback
var sounds={}
var players=[]
var coin_audio=0.0
var fixture=false
var jump_pointer=false

func _ready():
	Engine.max_fps=60
	load_game()
	if '--art-qa' in OS.get_cmdline_user_args():
		fixture=true;g.started=true;g.gold=580;g.souls=27;g.all_gold=1350;g.all_souls=58;g.upgrades=[3,2,1,2,1,1];g.skills=[1,1,1,0];g.kills=40;g.coins=160;g.distance=1320;g.lifetime_distance=1320;g.spawn_to=1260;g.y=170;g.vy=-120;g.elapsed=25
	for name_ in ['coin','jump','slash','boost','buy','portal','chest','hit','soul']:
		if ResourceLoader.exists('res://audio/'+name_+'.wav'):sounds[name_]=load('res://audio/'+name_+'.wav')
	for i in range(10):var a=AudioStreamPlayer.new();add_child(a);players.append(a)
	vp=SubViewport.new();vp.disable_3d=true;vp.render_target_update_mode=SubViewport.UPDATE_ALWAYS;add_child(vp);painter=Painter.new();painter.g=g;vp.add_child(painter)
	image=TextureRect.new();image.expand_mode=TextureRect.EXPAND_IGNORE_SIZE;image.texture=vp.get_texture();image.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST;image.mouse_filter=Control.MOUSE_FILTER_IGNORE;add_child(image)
	hud=Node2D.new();hud.draw.connect(draw_hud);add_child(hud)
	ui=Control.new();ui.mouse_filter=Control.MOUSE_FILTER_IGNORE;add_child(ui)
	layout()
	if not g.started:open_popup('welcome')
	if OS.has_feature('web'):
		callback=JavaScriptBridge.create_callback(lifecycle);JavaScriptBridge.get_interface('window').strideLifecycle=callback;JavaScriptBridge.eval('window.strideReady && window.strideReady()')
	web_snapshot()
func text(s,p,sz=16,col=Color('#f3efdc')):draw_string(FONT,p,str(s),HORIZONTAL_ALIGNMENT_LEFT,-1,sz,col)
func centered(s,p,sz=16,col=Color('#f3efdc')):
	var ww=FONT.get_string_size(str(s),HORIZONTAL_ALIGNMENT_LEFT,-1,sz).x;text(s,p-Vector2(ww/2,0),sz,col)
func label_(parent,s,p,size_,sz=16):
	var l=Label.new();l.position=p;l.size=size_;l.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;l.clip_text=true;l.mouse_filter=Control.MOUSE_FILTER_IGNORE;l.add_theme_font_override('font',FONT);l.add_theme_font_size_override('font_size',sz+3);l.add_theme_color_override('font_color',Color('#e6e6d6'));l.text=s;parent.add_child(l);return l
func tile(parent,id,ic,r,title_='',sub='',action='',n=0,small_=false):
	var b=Tile.new();b.position=r.position;b.size=r.size;b.custom_minimum_size=r.size;b.icon_=ic;b.title_=title_;b.sub=sub;b.small=small_;b.tooltip_text=title_+'\n'+sub;b.set_meta('id',id);b.set_meta('action',action);b.set_meta('n',n);parent.add_child(b)
	if action=='jump':
		b.button_down.connect(func():jump_pointer=true;g.jump())
		b.button_up.connect(func():jump_pointer=false;g.release_jump())
	else:b.pressed.connect(func():command(action,n),CONNECT_DEFERRED)
	buttons.append(b);return b
func layout():
	raw_size=get_viewport_rect().size;ui_scale=maxf(1,DisplayServer.screen_get_scale()) if OS.has_feature('web') else 1.0
	var insets=[0,0,0,0]
	if OS.has_feature('web'):
		var d=JSON.parse_string(str(JavaScriptBridge.eval('JSON.stringify(["--sal","--sat","--sar","--sab"].map(k=>parseFloat(getComputedStyle(document.documentElement).getPropertyValue(k))||0))')))
		if d is Array:insets=d
	safe=Vector2(insets[0],insets[1]);position=safe*ui_scale;scale=Vector2.ONE*ui_scale;view=raw_size/ui_scale-Vector2(insets[0]+insets[2],insets[1]+insets[3])
	for child in ui.get_children():child.free()
	buttons=[];jump_pointer=false;g.hold=false
	var wide=view.x>view.y and view.x>=600
	if wide:scene_rect=Rect2(12,66,view.x-24,view.y-160)
	else:scene_rect=Rect2(10,78,view.x-20,maxf(120,minf(view.y*.55,view.y-300)))
	if wide:vp.size=Vector2i(clampi(int(scene_rect.size.x/scene_rect.size.y*270),480,1400),270)
	else:vp.size=Vector2i(320,maxi(160,int(320*scene_rect.size.y/scene_rect.size.x)))
	painter.w=vp.size.x;painter.h=vp.size.y;image.position=scene_rect.position;image.size=scene_rect.size
	tile(ui,'upgrades',4,Rect2(view.x-156,8,44,44),'Equipment','','upgrades',0,true)
	tile(ui,'skills',5,Rect2(view.x-104,8,44,44),'Soul skills','','skills',0,true)
	tile(ui,'settings',10,Rect2(view.x-52,8,44,44),'Menu','','settings',0,true)
	if wide:
		var ids=[0,1,2,3,4,5] if view.x>=800 else [0,1,3]
		for j in range(ids.size()):tile(ui,'quick-'+str(ids[j]),ids[j],Rect2(12+j*54,view.y-78,48,60),Sim.NAMES[ids[j]],'','buy',ids[j],true)
		var bw=90.0;var jw=maxf(140,minf(280,view.x*.28));tile(ui,'boost',6,Rect2(view.x-jw-bw-24,view.y-78,bw,60),'Rush','','boost',0,true);tile(ui,'jump',13,Rect2(view.x-jw-12,view.y-78,jw,60),'JUMP','hold for height','jump')
	else:
		var yy=scene_rect.end.y+10;var ww=(view.x-28)/2
		for j in range(4):var i=[0,1,2,3][j];tile(ui,'quick-'+str(i),i,Rect2(10+(j%2)*(ww+8),yy+int(j/2)*58,ww,52),Sim.NAMES[i],'','buy',i)
		if view.y-88-(yy+110)>70:
			for i in range(4):tile(ui,'milestone-'+str(i),[0,1,8,6][i],Rect2(10+i*(view.x-12)/4,yy+128,(view.x-28)/4-4,48),'Milestones','','quests',i,true)
		tile(ui,'quests',11,Rect2(10,view.y-88,52,64),'Milestones','','quests',0,true)
		tile(ui,'boost',6,Rect2(70,view.y-88,72,64),'Rush','','boost',0,true)
		tile(ui,'jump',13,Rect2(150,view.y-88,view.x-160,64),'JUMP','','jump')
	if popup!='':build_popup()
	refresh();web_snapshot()
func refresh():
	for b in buttons:
		if not is_instance_valid(b):continue
		var action=b.get_meta('action');var n=int(b.get_meta('n'))
		if action=='buy':b.disabled=g.paused or g.gold<g.cost(n) or g.upgrades[n]>=20;b.sub=g.fmt(g.cost(n));b.tooltip_text=Sim.NAMES[n]+'  Level '+str(g.upgrades[n])+' / 20\n'+g.fmt(g.cost(n))+' gold'
		elif action=='learn':b.disabled=g.paused or g.souls<g.skill_cost(n) or g.skills[n]>=[1,1,5,3][n];b.sub=g.fmt(g.skill_cost(n))+' souls  •  '+str(g.skills[n])+'/'+str([1,1,5,3][n])
		elif action=='boost':b.disabled=g.boost_cd>0;b.sub=str(int(ceil(g.boost_cd)))+'s' if g.boost_cd>0 else 'READY';b.meter=1-g.boost_cd/8
		elif action=='claim':b.disabled=n in g.claimed or g.quest_progress(n)<g.quest_goal(n);b.sub='DONE' if n in g.claimed else str(g.quest_progress(n))+' / '+str(g.quest_goal(n));b.meter=minf(1,float(g.quest_progress(n))/g.quest_goal(n))
		elif action=='ascend-confirm':b.disabled=g.ascend_gain()<1;b.sub='+'+str(g.ascend_gain())+' echo crystals'
		elif action=='quests' and str(b.get_meta('id')).begins_with('milestone-'):b.meter=minf(1,float(g.quest_progress(n))/g.quest_goal(n));b.sub='✓' if n in g.claimed else str(mini(g.quest_progress(n),g.quest_goal(n)))+'/'+str(g.quest_goal(n))
		b.queue_redraw()
func open_popup(name_):
	popup=name_;g.hold=false;jump_pointer=false;build_popup();web_snapshot()
func build_popup():
	if is_instance_valid(overlay):overlay.free()
	buttons=buttons.filter(func(b):return is_instance_valid(b))
	overlay=Control.new();overlay.size=view;overlay.mouse_filter=Control.MOUSE_FILTER_STOP;ui.add_child(overlay)
	var veil=ColorRect.new();veil.color=Color(.025,.04,.07,.85);veil.size=view;overlay.add_child(veil)
	var w=minf(540,view.x-24);var h=minf(610,view.y-30);var origin=(view-Vector2(w,h))/2
	var frame=Panel.new();frame.position=origin;frame.size=Vector2(w,h);var st=StyleBoxFlat.new();st.bg_color=Color('#19283c');st.border_color=Color('#bba779');st.set_border_width_all(2);frame.add_theme_stylebox_override('panel',st);overlay.add_child(frame)
	var titles={'welcome':'A road worth running.','upgrades':'Equipment','skills':'Soul skills','settings':'Travel kit','quests':'Milestones','ascend':'A brighter beginning','help':'Run. Jump. Grow.','reset':'Begin again?','stats':'Journey journal'}
	label_(frame,titles.get(popup,'Soulstride'),Vector2(16,16),Vector2(w-82,54),24)
	if popup!='welcome':tile(frame,'close',12,Rect2(w-60,10,44,44),'Close','','close',0,true)
	var sc=ScrollContainer.new();sc.position=Vector2(14,78);sc.size=Vector2(w-28,h-94);sc.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED;frame.add_child(sc)
	var body=Control.new();var ww=w-42;body.custom_minimum_size=Vector2(ww,100);sc.add_child(body);var y_=0.0
	if popup=='welcome':
		label_(body,'Tap to jump. Hold to soar.\nYour sword handles nearby enemies.',Vector2(4,0),Vector2(ww-8,100),20);y_=112
		for i in range(4):tile(body,'intro-'+str(i),[0,1,2,8][i],Rect2(i*ww/4,y_,ww/4-6,58),'','','none',0,true)
		y_+=80;label_(body,'Collect gold. Grow stronger. Discover the next horizon.',Vector2(4,y_),Vector2(ww-8,70),16);y_+=85
		tile(body,'start',13,Rect2(0,y_,ww,60),'LET’S RUN','','start');y_+=72
	elif popup=='upgrades':
		label_(body,g.fmt(g.gold)+' gold',Vector2(4,0),Vector2(ww-8,30),18);y_=40
		var details=['More gold per coin','Stronger blade & arrows','Faster running & shorter rush cooldown','Pull nearby coins toward you','More passive & away income','Boost passive & away income']
		for i in range(6):
			tile(body,'buy-'+str(i),i,Rect2(0,y_,ww,60),Sim.NAMES[i]+'  '+str(g.upgrades[i])+'/20','','buy',i);y_+=64;label_(body,details[i],Vector2(8,y_),Vector2(ww-16,24),12);y_+=30
	elif popup=='skills':
		label_(body,g.fmt(g.souls)+' souls',Vector2(4,0),Vector2(ww-8,30),18);y_=40
		for i in range(4):tile(body,'skill-'+str(i),[2,7,5,6][i],Rect2(0,y_,ww,64),['Air step · double jump','Spirit bow · auto aim','Soul keeper · more souls','Long rush · extra duration'][i],'','learn',i);y_+=74
		tile(body,'ascend',8,Rect2(0,y_,ww,58),'Ascension','Keep soul skills; gain permanent power','ascend');y_+=70
	elif popup=='settings':
		for d in [['pause',9,'Resume' if g.paused else 'Pause'],['mute',15,'Sound on' if g.muted else 'Sound off'],['calm',14,'Full effects' if g.calm else 'Calm effects'],['quests',11,'Milestones'],['stats',4,'Journey journal'],['help',13,'Quick guide'],['export',4,'Export save'],['reset',8,'Fresh journey']]:tile(body,'setting-'+d[0],d[1],Rect2(0,y_,ww,54),d[2],'',d[0]);y_+=62
	elif popup=='quests':
		for i in range(4):tile(body,'claim-'+str(i),[0,1,8,6][i],Rect2(0,y_,ww,70),['Collect 40 coins','Defeat 10 enemies','Cross 3 portals','Rush 4 times'][i],'','claim',i);y_+=80
	elif popup=='ascend':
		label_(body,'Turn this run’s souls into echo crystals. Each crystal permanently improves gold and souls by 25%. Equipment and road progress restart. Soul skills and claimed milestones remain.',Vector2(4,0),Vector2(ww-8,190),17);y_=200
		label_(body,'Run souls  '+g.fmt(g.run_souls)+' / 60\nEcho crystals  '+str(g.gems),Vector2(4,y_),Vector2(ww-8,70),18);y_+=82
		tile(body,'ascend-confirm',8,Rect2(0,y_,ww,64),'ASCEND','','ascend-confirm');y_+=80
	elif popup=='help':
		label_(body,'Tap the road or hold JUMP to jump higher. Space works too.\n\nYour sword attacks nearby enemies automatically. Jump for the higher coin trails. Rush (B) moves faster and powers your blade for a short burst.\n\nGold buys equipment. Souls unlock a double jump and an automatically aimed bow.\n\nCoin streaks increase rewards. Bumping an enemy breaks your streak and briefly slows you; there are no lives to lose.\n\nPortals lead to six visual realms. Milestones grant gold and souls once.\n\nMenus pause the road. Away income is based on your Satchel and Fortune upgrades, capped at four hours. Progress saves in this browser. Export a backup before clearing site data.',Vector2(4,0),Vector2(ww-8,700),16);y_=710
	elif popup=='stats':
		label_(body,'Gold collected  '+g.fmt(g.all_gold)+'\nSouls collected  '+g.fmt(g.all_souls)+'\nDistance  '+str(int(g.lifetime_distance/10))+' m\nEnemies defeated  '+str(g.kills)+'\nCoins collected  '+str(g.coins)+'\nBest streak  '+str(g.best_combo)+'\nJumps  '+str(g.jumps)+'\nRushes  '+str(g.boosts)+'\nAscensions  '+str(g.ascensions)+'\nAway income  '+('%.2f'%g.idle_rate())+' /s',Vector2(4,0),Vector2(ww-8,430),18);y_=440
	elif popup=='reset':
		label_(body,'This replaces this browser’s journey. Export a save before starting over if you want to keep it.',Vector2(4,0),Vector2(ww-8,115),17);y_=130;tile(body,'reset-confirm',8,Rect2(0,y_,ww,60),'RESET JOURNEY','','reset-confirm');y_+=72
	body.custom_minimum_size.y=y_;refresh()
func command(action,n=0):
	match action:
		'start':g.started=true;popup='';layout()
		'close':popup='';layout()
		'upgrades','skills','settings','quests','help','ascend','stats','reset':open_popup(action)
		'buy':
			if g.buy(n):notify(Sim.NAMES[n]+' upgraded');sound('buy');if popup=='upgrades':build_popup()
		'learn':
			if g.learn(n):notify(['Double jump unlocked','Spirit bow unlocked','Soul rewards increased','Rush extended'][n]);sound('buy');build_popup()
		'boost':g.boost()
		'claim':
			if g.claim(n):notify('Milestone claimed');sound('chest');build_popup()
		'ascend-confirm':
			if g.ascend():popup='';notify('A brighter beginning');transition=1;sound('portal');layout()
		'pause':g.paused=not g.paused;build_popup();if g.paused:for p in players:p.stop()
		'mute':g.muted=not g.muted;build_popup();if g.muted:for p in players:p.stop()
		'calm':g.calm=not g.calm;build_popup()
		'export':export_save()
		'reset-confirm':g=Sim.new();painter.g=g;painter.fx.clear();painter.pops.clear();popup='welcome';layout()
	refresh();save_game();web_snapshot()
func notify(s):toast=s;toast_time=3.0
func sound(name_):
	if g.muted or hidden_ or not sounds.has(name_):return
	for p in players:
		if not p.playing:p.stream=sounds[name_];p.pitch_scale=1+minf(.3,g.combo*.005) if name_=='coin' else 1;p.play();return
func _input(e):
	if e is InputEventKey and not e.echo:
		if e.keycode==KEY_SPACE and popup=='':
			if e.pressed:g.jump()
			else:g.release_jump()
			get_viewport().set_input_as_handled()
		elif e.keycode==KEY_B and e.pressed and popup=='':g.boost()
		elif e.keycode==KEY_ESCAPE and e.pressed:
			if popup!='':command('close')
			else:open_popup('settings')
	if e is InputEventMouseButton and e.button_index==MOUSE_BUTTON_LEFT and popup=='':
		var pos=e.position/ui_scale-safe
		if e.pressed and scene_rect.has_point(pos):g.jump();jump_pointer=true;get_viewport().set_input_as_handled()
		elif not e.pressed and jump_pointer:g.release_jump();jump_pointer=false
func _process(dt):
	if raw_size!=get_viewport_rect().size:layout()
	if hidden_:return
	if popup=='' and not g.paused:
		accumulator+=minf(.1,dt)
		while accumulator>=1.0/120:g.update(1.0/120,painter.w);accumulator-=1.0/120
		painter.visual_time=g.elapsed;coin_audio=maxf(0,coin_audio-dt);transition=maxf(0,transition-dt);toast_time=maxf(0,toast_time-dt)
		for f in painter.fx:f.x+=f.vx*dt;f.y+=f.vy*dt;f.vy+=260*dt;f.life-=dt
		painter.fx=painter.fx.filter(func(f):return f.life>0)
		for f in painter.pops:f.y-=26*dt;f.life-=dt
		painter.pops=painter.pops.filter(func(f):return f.life>0)
	for e in g.events:
		match e[0]:
			'coin':
				if coin_audio<=0:sound('coin');coin_audio=.045
				effect(e[2],e[3],'#f3d17a',4)
			'kill':sound('soul');effect(e[2],e[3],'#a4c5dc',9);pop(e[2],e[3]-18,'+SOUL')
			'jump':sound('jump')
			'slash':sound('slash')
			'bow':sound('slash')
			'land':effect(g.distance,g.y,'#cbb48a',5)
			'boost':sound('boost');notify('RUSH')
			'portal':transition=1;sound('portal');notify(Sim.REALMS[int(g.realm)]+'  +'+g.fmt(e[2]))
			'chest':sound('chest');effect(e[2],e[3],'#f8cf77',14);pop(e[2],e[3]-20,'+'+g.fmt(e[1]))
			'hit':sound('hit')
	g.events.clear();painter.queue_redraw();queue_redraw();hud.queue_redraw();sync+=dt;saving+=dt
	if sync>.15:sync=0;refresh();web_snapshot()
	if saving>4:saving=0;save_game()
func effect(x,y,col,n):
	if g.calm:return
	for i in range(n):
		if painter.fx.size()<120:painter.fx.append({'x':x,'y':y,'vx':randf_range(-60,60),'vy':randf_range(-100,-30),'life':randf_range(.25,.6),'size':randi_range(1,3),'col':Color(col)})
func pop(x,y,s):
	if painter.pops.size()<15:painter.pops.append({'x':x,'y':y,'text':s,'life':.8})
func _draw():
	draw_rect(Rect2(Vector2.ZERO,view),Color('#101c2e'));draw_rect(Rect2(0,0,view.x,60),Color('#19273b'));draw_line(Vector2(0,60),Vector2(view.x,60),Color('#728795'),1)
	text('SOULSTRIDE',Vector2(14,27),22);text(Sim.REALMS[int(g.realm)%6],Vector2(14,47),13,Color('#99b8ba'))
	draw_rect(scene_rect.grow(3),Color('#8f9b91'),false,2)
func hud_text(s,p,sz=16,col=Color("#f3efdc")):
	hud.draw_string(FONT,p,str(s),HORIZONTAL_ALIGNMENT_LEFT,-1,sz,col)
func hud_centered(s,p,sz=16):
	hud_text(s,p-Vector2(FONT.get_string_size(str(s),HORIZONTAL_ALIGNMENT_LEFT,-1,sz).x/2,0),sz)
func draw_hud():
	# Readable wallet floats over sky without introducing a large text dashboard.
	Art.icon(hud,0,scene_rect.position+Vector2(10,5),.75);hud_text(g.fmt(g.gold),scene_rect.position+Vector2(39,26),19,Color('#283b50'))
	Art.icon(hud,5,scene_rect.position+Vector2(10,33),.75);hud_text(g.fmt(g.souls),scene_rect.position+Vector2(39,53),17,Color('#283b50'))
	if int(g.realm)%6 in [2,5]:
		hud_text(g.fmt(g.gold),scene_rect.position+Vector2(39,26),19,Color('#ffdf91'));hud_text(g.fmt(g.souls),scene_rect.position+Vector2(39,53),17,Color('#e3c6f2'))
	if g.combo>=10:hud_text('×'+('%.2f'%(1+minf(1.5,floor(g.combo/10.0)*.25))),scene_rect.position+Vector2(12,80),14,Color('#efdfaa'))
	var progress=fmod(g.distance,4200)/4200;var bar=Rect2(scene_rect.end.x-110,scene_rect.position.y+12,96,3);hud.draw_rect(bar,Color(0,0,0,.25));hud.draw_rect(Rect2(bar.position,Vector2(bar.size.x*progress,3)),Color('#e9d7a6'));hud_text(str(int(g.lifetime_distance/10))+' m',Vector2(scene_rect.end.x-80,scene_rect.position.y+31),12,Color('#e7eddb'))
	if transition>0:hud.draw_rect(scene_rect,Color(.85,.88,.72,transition*.35))
	if toast_time>0 and popup=='':
		var yy=scene_rect.end.y-18;var ww=FONT.get_string_size(toast,HORIZONTAL_ALIGNMENT_LEFT,-1,14).x+24;hud.draw_rect(Rect2(view.x/2-ww/2,yy-21,ww,30),Color(.08,.14,.23,.9));hud_centered(toast,Vector2(view.x/2,yy),14)
	if g.paused:hud_centered('PAUSED',scene_rect.get_center(),24)
func save_game():
	if fixture:return
	var data=JSON.stringify(g.snapshot())
	if OS.has_feature('web'):JavaScriptBridge.eval('try{localStorage.setItem("'+SAVE+'",'+JSON.stringify(data)+')}catch(e){}')
	else:var file=FileAccess.open('user://soulstride.json',FileAccess.WRITE);if file:file.store_string(data)
func load_game():
	var raw=''
	if OS.has_feature('web'):raw=str(JavaScriptBridge.eval('(function(){try{return localStorage.getItem("'+SAVE+'")||""}catch(e){return ""}})()'))
	elif FileAccess.file_exists('user://soulstride.json'):raw=FileAccess.get_file_as_string('user://soulstride.json')
	if raw=='':return
	var d=JSON.parse_string(raw)
	if g.restore(d) and g.started:
		var reward=g.away(Time.get_unix_time_from_system()-float(d.get('stamp',Time.get_unix_time_from_system())))
		if reward>=1:notify('Welcome back  +'+g.fmt(reward));save_game()
func lifecycle(args):
	if args.is_empty():return
	var s=str(args[0])
	if s=='away':hidden_=true;away_at=Time.get_unix_time_from_system();g.hold=false;jump_pointer=false;save_game();for p in players:p.stop()
	elif s=='back':
		if hidden_ and away_at>0:g.away(Time.get_unix_time_from_system()-away_at)
		hidden_=false;away_at=0;accumulator=0;save_game()
	else:save_game()
func export_save():
	var data=JSON.stringify(g.snapshot())
	if OS.has_feature('web'):JavaScriptBridge.eval('(()=>{let a=document.createElement("a");a.href=URL.createObjectURL(new Blob(['+JSON.stringify(data)+'],{type:"application/json"}));a.download="soulstride-save.json";a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000)})()')
	notify('Save exported')
func web_snapshot():
	if not OS.has_feature('web'):return
	var d={'gold':g.gold,'souls':g.souls,'distance':g.distance,'y':g.y,'vy':g.vy,'coins':g.coins,'kills':g.kills,'jumps':g.jumps,'boosts':g.boosts,'combo':g.combo,'portals':g.portals,'realm':g.realm,'upgrades':g.upgrades,'skills':g.skills,'boost_time':g.boost_time,'boost_cd':g.boost_cd,'started':g.started,'paused':g.paused,'popup':popup,'view':[view.x,view.y],'world':[painter.w,painter.h],'scene':[scene_rect.position.x+safe.x,scene_rect.position.y+safe.y,scene_rect.size.x,scene_rect.size.y],'buttons':[]}
	for b in buttons:
		if not is_instance_valid(b) or not b.is_visible_in_tree():continue
		var p=b.global_position/ui_scale;var visible=true;var a=b.get_parent()
		while a!=null:
			if a is ScrollContainer and not Rect2(a.global_position/ui_scale,a.size).encloses(Rect2(p,b.size)):visible=false
			a=a.get_parent()
		if visible:d.buttons.append({'id':b.get_meta('id'),'x':p.x,'y':p.y,'w':b.size.x,'h':b.size.y,'disabled':b.disabled})
	JavaScriptBridge.eval('window.strideSnapshot && window.strideSnapshot('+JSON.stringify(d)+')')

