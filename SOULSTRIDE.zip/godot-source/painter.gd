extends Node2D
const Art=preload('res://art.gd')
const FONT=preload('res://fonts/pixel.ttf')
var g
var w=600
var h=270
var fx=[]
var pops=[]
var visual_time=0.0
var palette=[['#4e9fd4','#a8dcdf','#679ebe','#73b17c','#38876c','#6eb056','#a6cf68','#654c46'],['#b289aa','#f2c3a3','#c7a2ac','#b3a380','#99765d','#b69461','#dfbd78','#694e4b'],['#282e63','#8e83b5','#46518a','#4c6189','#314a6c','#596995','#91a8bb','#33364e'],['#7698c5','#e1edf3','#aabfd8','#b4ccda','#64889b','#b8d0d9','#edf0de','#647a8e'],['#86b8c4','#e1d5b7','#b8c8bd','#bec69b','#949b73','#aaa26d','#e0cb8b','#7e6c57'],['#cb9ec7','#f5d1de','#b5a4cb','#bfa3c9','#976f9d','#aa829e','#edd0d4','#77596f']]
func b(x,y,ww,hh,col):Art.b(self,x,y,ww,hh,col)
func hill(y,amp,period,offset,col):
	var pts=PackedVector2Array([Vector2(-20,h),Vector2(-20,y)])
	for x in range(-20,w+21,8):pts.append(Vector2(x,round(y+sin((x+offset)/period)*amp+sin((x+offset)*.025)*amp*.3)))
	pts.append(Vector2(w+20,h));draw_colored_polygon(pts,Color(col))
func cloud(x,y,s=1.0):
	var c='#ecf0da' if g.realm%6<2 else '#d7dae5'
	b(x,y,54*s,11*s,c);b(x+8*s,y-7*s,39*s,8*s,c);b(x+17*s,y-12*s,21*s,7*s,c);b(x+4*s,y+10*s,45*s,3*s,Color(c).darkened(.09))
func tree(x,ground_,size_,c,leaf,realm_):
	var hh=57*size_;var trunk=Color(c);b(x-3*size_,ground_-hh,7*size_,hh,trunk);b(x-2*size_,ground_-hh,2*size_,hh,Color(c).lightened(.09))
	if realm_==3:
		for i in range(3):
			var yy=ground_-hh-18*size_+i*15*size_;var ww=(12+i*8)*size_;Art.poly(self,[Vector2(x,yy-15*size_),Vector2(x-ww,yy+14*size_),Vector2(x+ww,yy+14*size_)],leaf);b(x-ww/2,yy+3*size_,ww,3*size_,'#e4ecdf')
	else:
		for i in range(5):
			var xx=x+[-23,-10,4,20,-2][i]*size_;var yy=ground_-hh+[-4,-21,-24,-6,3][i]*size_
			b(xx-12*size_,yy-9*size_,24*size_,23*size_,Color(leaf).darkened(i*.018));b(xx-9*size_,yy-12*size_,18*size_,4*size_,Color(leaf).lightened(.05))
			for k in range(3):b(xx-8*size_+k*6*size_,yy-4*size_,3*size_,2*size_,Color(leaf).lightened(.13))
			for k in range(7):
				var lx=xx+((k*7+i*3)%20-10)*size_;var ly=yy+((k*5+i)%15-6)*size_
				b(lx,ly,(2+k%2)*size_,2*size_,Color(leaf).lightened(.12 if k%3 else -.13))
func ruin(x,ground_,realm_):
	var base='#a7b6aa' if realm_!=4 else '#bcb38d';var shade='#6b8587' if realm_!=4 else '#8b876e'
	b(x,ground_-42,18,42,shade);b(x+3,ground_-44,12,42,base);b(x-3,ground_-45,24,5,base);b(x+2,ground_-38,3,30,Color(base).lightened(.13));b(x+10,ground_-26,7,2,shade);b(x-5,ground_-3,28,4,shade)
	if realm_==4:
		b(x+44,ground_-42,18,42,shade);b(x+47,ground_-44,12,42,base);b(x+5,ground_-57,54,7,base);b(x+15,ground_-64,34,8,base);b(x+17,ground_-50,30,3,shade)
func _draw():
	if g==null:return
	var realm_=int(g.realm)%6;var p=palette[realm_];var ground_=int(h*.8);var dy=ground_-216;var d=g.distance
	for yy in range(0,ground_,4):b(0,yy,w,4,Color(p[0]).lerp(Color(p[1]),float(yy)/maxf(1,ground_)))
	if realm_ in [2,5]:
		for i in range(30):b(fposmod(i*73-d*.025,w),8+(i*37)%maxi(30,int(ground_*.55)),1,1,'#e9d9e6')
		b(w*.74,ground_*.19,18,18,'#f6e4c4');b(w*.74+8,ground_*.19-2,15,18,p[0])
	else:b(w*.76,ground_*.22,24,24,'#f3e8ad');b(w*.76-3,ground_*.22+3,30,18,Color('#f3e8ad').lightened(.05))
	for i in range(5):cloud(fposmod(i*163-d*.035,w+110)-70,ground_*.13+(i%3)*19,.7+(i%2)*.35)
	hill(ground_*.58,22,110,d*.09,p[2]);hill(ground_*.69,28,72,d*.16,p[3])
	# Distant miniature keep, windows and stone courses.
	var cx=fposmod(520-d*.09,w+240)-120;var cy=ground_*.63
	b(cx,cy-35,53,42,Color(p[2]).darkened(.05));b(cx+7,cy-53,12,23,Color(p[2]).darkened(.08));b(cx+35,cy-60,12,30,Color(p[2]).darkened(.08))
	for i in range(4):b(cx+i*15,cy-39,7,5,Color(p[2]).darkened(.08))
	for i in range(3):b(cx+8+i*16,cy-23,4,7,Color(p[2]).darkened(.25))
	for i in range(7):
		var x=fposmod(i*127-d*.3,w+190)-70
		tree(x,ground_-8,.63,p[4],Color(p[4]).lightened(.10),realm_)
	hill(ground_-17,11,85,d*.48,p[4])
	if realm_ in [1,2,3]:
		for i in range(3):tree(fposmod(i*273-d*.62,w+250)-110,ground_,1.45,Color(p[7]).darkened(.12),Color(p[4]).lightened(.07),realm_)
	for i in range(3):
		var x=fposmod(i*359-d*.7,w+360)-130
		if realm_ in [0,4]:ruin(x,ground_,realm_)
		elif realm_==5:tree(x,ground_,1.0,'#8a6381','#dbb1cc',realm_)
	# Grass over layered rock, roots and deterministic pebble/fern patterns.
	b(0,ground_,w,h-ground_,p[7]);b(0,ground_,w,5,p[5]);b(0,ground_,w,2,p[6]);b(0,ground_+5,w,3,Color(p[5]).darkened(.15))
	var tile=int(floor(d/24))
	for k in range(-1,int(w/24)+2):
		var x=k*24-fmod(d,24);var key=k+tile
		b(x+3,ground_+13+(key%3)*4,8,4,Color(p[7]).lightened(.12));b(x+17,ground_+30-(key%2)*4,5,3,Color(p[7]).darkened(.13));b(x+10,ground_+7,2,5,p[5]);b(x+18,ground_-3-(key%3),2,5,p[6]);b(x+16,ground_-2,6,1,p[6])
		if key%5==0:b(x+9,ground_-6,1,6,'#5d8e55');b(x+7,ground_-7,5,2,'#f0d67b');b(x+8,ground_-8,3,4,'#eedc9d')
		if key%7==0:
			for j in range(4):b(x+j*3,ground_+30-j*3,2,2,'#8c7964')
	var hx=int(w*.22)
	for e in g.entities:
		var x=e.x-d+hx
		if x< -50 or x>w+50:continue
		if e.type=='coin':Art.coin(self,Vector2(x,e.y+dy),visual_time+e.x*.01,e.rare)
		elif e.type=='enemy':Art.monster(self,Vector2(x,e.y+14+dy+(sin(g.elapsed*4+e.phase)*3 if e.kind==2 else 0)),int(e.kind),visual_time+e.phase,e.hp)
		else:
			b(x-13,ground_-20,26,20,'#5a3e3a');b(x-11,ground_-22,22,5,'#b37a49');b(x-12,ground_-16,24,11,'#9c6740');b(x-11,ground_-18,22,2,'#edc179');b(x-12,ground_-6,24,2,'#d4a563');b(x-2,ground_-14,5,8,'#f6cd75')
	for a in g.arrows:
		var x=a.x-d+hx;b(x-9,a.y+dy,18,2,'#e7d9a8');Art.poly(self,[Vector2(x+9,a.y+dy-2),Vector2(x+14,a.y+dy+1),Vector2(x+9,a.y+dy+4)],'#e2f0da')
	b(hx-12,ground_+2,25,2,Color(0,0,0,.18))
	if int(g.hit_time*20)%2==0:Art.hero(self,Vector2(hx,g.y+dy),visual_time,g.y<216,g.attack_fx,g.boost_time>0)
	if g.distance>100:
		for i in range(3):b(hx-15-i*6,ground_-1+(i%2)*2,2+(i%2),2,Color(p[6]).darkened(.2))
	# Gate comes into view before the world palette changes.
	var gate=(floor(d/4200)+1)*4200;var gx=gate-d+hx
	if gx<w+50:
		for i in range(4):draw_arc(Vector2(gx,ground_-36),Vector2(1,1).length()*(28+i*2),-PI,0,18,Color('#b6a2e4').lightened(i*.06),2,false)
		b(gx-36,ground_-36,5,37,'#9c8bcb');b(gx+32,ground_-36,5,37,'#9c8bcb');b(gx-35,ground_-3,72,4,'#d6c8e8')
	for f in fx:
		var x=f.x-d+hx;b(x,f.y+dy,f.size,f.size,Color(f.col,clampf(f.life*2,0,1)))
	for f in pops:
		var x=f.x-d+hx;draw_string(FONT,Vector2(x,f.y+dy),f.text,HORIZONTAL_ALIGNMENT_CENTER,55,11,Color(1,.95,.72,clampf(f.life*1.6,0,1)))
	if realm_ in [2,5]:
		for i in range(12):b(fposmod(i*71-d*.12,w),ground_-18-(i*19)%90+sin(visual_time+i)*5,2,2,'#d6dba4')
