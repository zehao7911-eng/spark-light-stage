extends RefCounted
const FLOOR=216.0
const PRICES=[20,35,45,60,75,100]
const NAMES=['Gold','Sword','Boots','Magnet','Satchel','Fortune']
const REALMS=['GREENHAVEN','AMBER WOODS','MOONLIT GROVE','FROSTFALL','SUNLIT RUINS','ROSE HIGHLANDS']
var gold=0.0
var souls=0.0
var all_gold=0.0
var all_souls=0.0
var distance=0.0
var lifetime_distance=0.0
var y=FLOOR
var vy=0.0
var hold=false
var air_jumps=0
var jump_buffer=0.0
var boost_time=0.0
var boost_cd=0.0
var attack_cd=0.0
var hit_time=0.0
var attack_fx=0.0
var combo=0
var combo_time=0.0
var best_combo=0
var jumps=0
var kills=0
var coins=0
var portals=0
var boosts=0
var elapsed=0.0
var upgrades=[0,0,0,0,0,0]
var skills=[0,0,0,0]
var gems=0
var ascensions=0
var run_souls=0.0
var claimed=[]
var entities=[]
var arrows=[]
var spawn_to=0
var realm=0
var started=false
var paused=false
var muted=false
var calm=false
var events=[]
var rng=RandomNumberGenerator.new()

func _init():rng.seed=781332
func fmt(n):
	if n<1000:return str(int(n))
	var k=int(floor(log(maxf(1,n))/log(1000.0)))
	return ('%.2f'%(n/pow(1000,k))).trim_suffix('0').trim_suffix('.')+['','K','M','B','T','Qa','Qi'][mini(6,k)]
func cost(i):return ceil(PRICES[i]*pow(1.65,upgrades[i]))
func buy(i):
	if paused or i<0 or i>5 or upgrades[i]>=20 or gold<cost(i):return false
	gold-=cost(i);upgrades[i]+=1;events.append(['buy',i]);return true
func skill_cost(i):return [6,12,18,30][i]*pow(2,skills[i])
func learn(i):
	if paused or i<0 or i>3 or skills[i]>=[1,1,5,3][i] or souls<skill_cost(i):return false
	souls-=skill_cost(i);skills[i]+=1;events.append(['skill',i]);return true
func earn_gold(amount):
	gold+=amount;all_gold+=amount
func coin_value():return (1.0+upgrades[0]*.5)*(1.0+gems*.25)
func soul_value():return (1.0+skills[2]*.6)*(1.0+gems*.25)
func idle_rate():return (.15+upgrades[4]*.55+upgrades[5]*.9)*(1+gems*.25)
func jump():
	if not started or paused:return false
	if y>=FLOOR-.01 or (skills[0]>0 and air_jumps==0):
		if y<FLOOR-.01:air_jumps+=1
		vy=-345;hold=true;jumps+=1;events.append(['jump',0]);return true
	jump_buffer=.12;return false
func release_jump():
	hold=false
	if vy< -110:vy*=.55
func boost():
	if not started or paused or boost_cd>0:return false
	boost_time=2.2+skills[3]*.35;boost_cd=maxf(3,8-upgrades[2]*.2);boosts+=1;events.append(['boost',0]);return true
func hurt():
	if hit_time>0 or boost_time>0:return
	hit_time=.7;combo=0;combo_time=0;events.append(['hit',0])
func collect(e):
	combo+=1;combo_time=2.0;best_combo=maxi(best_combo,combo);coins+=1
	var value=coin_value()*(1+minf(1.5,floor(combo/10.0)*.25))*(3 if e.get('rare',false) else 1)
	earn_gold(value);events.append(['coin',value,e.x,e.y]);e.dead=true
func kill(e):
	e.dead=true;kills+=1
	var value=soul_value()*(4 if e.kind==3 else 1)
	souls+=value;run_souls+=value;all_souls+=value
	earn_gold(coin_value()*(6 if e.kind==3 else 2));events.append(['kill',e.kind,e.x,e.y]);attack_fx=.18
func spawn(width):
	while spawn_to<distance+width+250:
		var section=spawn_to;spawn_to+=420
		var wave=int(section/420)
		for i in range(9):
			var yy=FLOOR-15
			if wave%3==1:yy=FLOOR-20-sin(i*PI/8)*65
			elif wave%3==2:yy=FLOOR-50
			entities.append({'type':'coin','x':section+150+i*23,'y':yy,'dead':false,'rare':i==4 and wave%4==2})
		var kind=wave%3
		if wave%7==6:kind=3
		entities.append({'type':'enemy','x':section+380,'y':FLOOR-14-(48 if kind==2 else 0),'kind':kind,'hp':1+int(wave/30)+(3 if kind==3 else 0),'dead':false,'phase':wave*.7})
		if wave%5==4:entities.append({'type':'chest','x':section+110,'y':FLOOR-20,'dead':false})
func update(dt,width=600.0):
	if not started or paused:return
	dt=clampf(dt,0,.05);elapsed+=dt
	var speed=158+upgrades[2]*2.0
	if boost_time>0:speed*=2.25
	if hit_time>0:speed*=.65
	distance+=speed*dt;lifetime_distance+=speed*dt
	earn_gold(idle_rate()*dt)
	boost_time=maxf(0,boost_time-dt);boost_cd=maxf(0,boost_cd-dt);attack_cd=maxf(0,attack_cd-dt);attack_fx=maxf(0,attack_fx-dt);hit_time=maxf(0,hit_time-dt);combo_time=maxf(0,combo_time-dt)
	if combo_time==0:combo=0
	jump_buffer=maxf(0,jump_buffer-dt)
	vy+=(720.0 if hold and vy<0 else 1100.0)*dt;y+=vy*dt
	if y>=FLOOR:
		var was_air=vy>0 and y>FLOOR+1;y=FLOOR;vy=0;air_jumps=0
		if was_air:events.append(['land',0])
		if jump_buffer>0:jump_buffer=0;jump()
	spawn(width)
	var hero=Vector2(distance,y-14)
	for e in entities:
		if e.dead:continue
		if e.type=='coin':
			var delta_=Vector2(e.x,e.y)-hero
			var r=16+upgrades[3]*5
			if delta_.length()<r:
				collect(e)
			elif upgrades[3]>0 and delta_.length()<r+22:
				var p=Vector2(e.x,e.y).move_toward(hero,170*dt);e.x=p.x;e.y=p.y
		elif e.type=='chest':
			if absf(e.x-distance)<22 and absf(e.y-hero.y)<30:e.dead=true;var value=25*coin_value();earn_gold(value);events.append(['chest',value,e.x,e.y])
		else:
			var dx=e.x-distance;var ey=e.y+sin(elapsed*4+e.phase)*3 if e.kind==2 else e.y
			if dx> -7 and dx<40 and absf(ey-hero.y)<30 and attack_cd<=0:
				e.hp-=1+upgrades[1]+(5 if boost_time>0 else 0);attack_cd=maxf(.10,.36-upgrades[1]*.01);attack_fx=.18;events.append(['slash',0])
				if e.hp<=0:kill(e)
			if absf(dx)<13 and absf(ey-hero.y)<23 and not e.dead:hurt()
			if skills[1]>0 and attack_cd<=0 and dx>50 and dx<280 and absf(ey-hero.y)<90:
				var v=(Vector2(e.x,ey)-hero).normalized()*500;arrows.append({'x':distance+12,'y':hero.y-4,'vx':v.x,'vy':v.y,'life':1.2});attack_cd=.5;events.append(['bow',0])
	for a in arrows:
		a.x+=a.vx*dt;a.y+=a.vy*dt;a.life-=dt
		for e in entities:
			if e.type=='enemy' and not e.dead and Vector2(e.x-a.x,e.y-a.y).length()<20:e.hp-=1+upgrades[1];a.life=0;if e.hp<=0:kill(e)
	arrows=arrows.filter(func(a):return a.life>0)
	entities=entities.filter(func(e):return not e.dead and e.x>distance-100)
	var stage=int(distance/4200)
	if stage>portals:
		portals=stage;realm=stage%6;var reward=40*coin_value()*(1+stage*.2);earn_gold(reward);events.append(['portal',realm,reward])
func quest_goal(i):return [40,10,3,4][i]
func quest_progress(i):return [coins,kills,portals,boosts][i]
func claim(i):
	if paused or i<0 or i>3 or i in claimed or quest_progress(i)<quest_goal(i):return false
	claimed.append(i);earn_gold(100*(i+1));souls+=5;all_souls+=5;events.append(['quest',i]);return true
func ascend_gain():return int(floor(sqrt(run_souls/60.0)))
func ascend():
	var gain=ascend_gain()
	if paused or gain<1:return false
	gems+=gain;ascensions+=1;run_souls=0;gold=0;souls=0;upgrades.fill(0);distance=0;y=FLOOR;vy=0;air_jumps=0;spawn_to=0;entities.clear();arrows.clear();boost_time=0;boost_cd=0;combo=0;combo_time=0;hit_time=0;attack_cd=0;attack_fx=0;hold=false;jump_buffer=0;realm=0;portals=0;events.append(['ascend',gain]);return true
func snapshot():
	return {'v':1,'gold':gold,'souls':souls,'all_gold':all_gold,'all_souls':all_souls,'distance':distance,'lifetime_distance':lifetime_distance,'y':y,'vy':vy,'boost_time':boost_time,'boost_cd':boost_cd,'attack_cd':attack_cd,'hit_time':hit_time,'attack_fx':attack_fx,'combo':combo,'combo_time':combo_time,'best_combo':best_combo,'jumps':jumps,'kills':kills,'coins':coins,'portals':portals,'boosts':boosts,'elapsed':elapsed,'upgrades':upgrades.duplicate(),'skills':skills.duplicate(),'gems':gems,'ascensions':ascensions,'run_souls':run_souls,'claimed':claimed.duplicate(),'entities':entities.duplicate(true),'arrows':arrows.duplicate(true),'spawn_to':spawn_to,'realm':realm,'started':started,'paused':paused,'muted':muted,'calm':calm,'air_jumps':air_jumps,'stamp':Time.get_unix_time_from_system()}
func restore(d):
	if not d is Dictionary or d.get('v')!=1:return false
	for key in ['upgrades','skills']:
		if not d.get(key) is Array or d[key].size()!={'upgrades':6,'skills':4}[key]:return false
		for x in d[key]:
			if not (x is int or x is float) or not is_finite(x) or x!=floor(x) or x<0 or x>20:return false
	for key in ['entities','arrows','claimed']:
		if not d.get(key) is Array or d[key].size()>200:return false
	var keys=['gold','souls','all_gold','all_souls','distance','lifetime_distance','y','vy','boost_time','boost_cd','attack_cd','hit_time','attack_fx','combo','combo_time','best_combo','jumps','kills','coins','portals','boosts','elapsed','gems','ascensions','run_souls','spawn_to','realm','air_jumps']
	for key in keys:
		if not (d.get(key) is float or d.get(key) is int) or not is_finite(d[key]) or absf(d[key])>1e15:return false
	for e in d.entities:
		if not e is Dictionary or not e.get('type') in ['coin','enemy','chest'] or not (e.get('x') is float or e.get('x') is int) or not (e.get('y') is float or e.get('y') is int):return false
	for a in d.arrows:
		if not a is Dictionary:return false
		for key in ['x','y','vx','vy','life']:
			if not (a.get(key) is float or a.get(key) is int) or not is_finite(a[key]):return false
	for i in range(4):
		if d.skills[i]>[1,1,5,3][i]:return false
	for x in d.claimed:
		if not (x is float or x is int) or x!=floor(x) or x<0 or x>3:return false
	for e in d.entities:
		if not e.get('dead') is bool:return false
		for key in ['x','y']:
			if not is_finite(e[key]) or absf(e[key])>1e15:return false
		if e.type=='coin' and not e.get('rare') is bool:return false
		if e.type=='enemy':
			for key in ['kind','hp','phase']:
				if not (e.get(key) is int or e.get(key) is float) or not is_finite(e[key]):return false
			if e.kind<0 or e.kind>3 or e.kind!=floor(e.kind):return false
	for key in keys:set(key,d[key])
	upgrades=d.upgrades.map(func(x):return int(x));skills=d.skills.map(func(x):return int(x));claimed=d.claimed.map(func(x):return int(x));entities=d.entities.duplicate(true);arrows=d.arrows.duplicate(true)
	for key in ['started','paused','muted','calm']:set(key,d.get(key,false)==true)
	hold=false;jump_buffer=0;events.clear();return true
func away(seconds):
	if paused:return 0.0
	var reward=idle_rate()*clampf(seconds,0,14400);earn_gold(reward);return reward
