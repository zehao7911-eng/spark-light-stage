extends SceneTree
func _initialize():call_deferred('test')
func test():
	var game=load('res://main.tscn').instantiate();root.add_child(game);game.fixture=true;game.g=load('res://sim.gd').new();game.painter.g=game.g
	game.g.started=true;game.g.gold=10000;game.g.souls=100;game.popup='';game.layout()
	for dimensions in [Vector2i(320,480),Vector2i(320,667),Vector2i(390,844),Vector2i(640,360),Vector2i(844,390),Vector2i(1280,720)]:
		root.size=dimensions
		await process_frame;await process_frame
		game.layout()
		assert(game.image.size==game.scene_rect.size,'Scene image must fit assigned mobile rectangle')
		var rects=[]
		for b in game.buttons:
			var r=Rect2(b.position,b.size)
			assert(Rect2(Vector2.ZERO,game.view).encloses(r),'Control outside screen')
			assert(b.size.x>=44 and b.size.y>=44,'Touch target too small')
			for r2 in rects:assert(not r.intersects(r2),'Overlapping controls')
			rects.append(r)
		for menu in ['welcome','upgrades','skills','settings','quests','ascend','help','stats','reset']:
			game.open_popup(menu);await process_frame
			assert(is_instance_valid(game.overlay))
			assert(game.overlay.size==game.view)
		game.command('close')
	game.g.gold=100;game.command('buy',0);assert(game.g.upgrades[0]==1)
	game.g.souls=12;game.command('learn',1);assert(game.g.skills[1]==1)
	game.command('close');game.open_popup('settings');var d=game.g.distance
	await create_timer(.1).timeout
	assert(game.g.distance==d,'Menus must freeze road')
	game.g.muted=false;game.command('mute');game.sound('coin');for p in game.players:assert(not p.playing)
	print('SOULSTRIDE UI QA PASSED: six layouts, nine menus, native purchases and menu pause')
	game.fixture=true;game.free();quit()
