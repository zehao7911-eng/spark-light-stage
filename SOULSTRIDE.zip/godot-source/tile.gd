extends Button
const Art=preload('res://art.gd')
const FONT=preload('res://fonts/pixel.ttf')
var icon_=0
var title_=''
var sub=''
var small=false
var meter=0.0
var gold=false
func _ready():flat=true;mouse_default_cursor_shape=Control.CURSOR_POINTING_HAND
func _draw():
	var c=Color('#25364d') if not gold else Color('#53442f')
	if is_hovered() and not disabled:c=c.lightened(.1)
	if is_pressed():c=c.darkened(.15)
	draw_rect(Rect2(Vector2.ZERO,size),Color('#0d1527'));draw_rect(Rect2(2,2,size.x-4,size.y-4),c);draw_rect(Rect2(3,3,size.x-6,2),Color('#587080'));draw_rect(Rect2(3,size.y-5,size.x-6,2),Color('#172235'))
	if meter>0:draw_rect(Rect2(2,size.y-4,(size.x-4)*clampf(meter,0,1),2),Color('#d1c18a'))
	Art.icon(self,icon_,Vector2(7,6 if small else (size.y-32)/2),1.0)
	var f=FONT;var col=Color('#f2ecd9') if not disabled else Color('#85949b')
	if small:draw_string(f,Vector2(2,size.y-6),sub,HORIZONTAL_ALIGNMENT_CENTER,size.x-4,16,col)
	else:draw_string(f,Vector2(48,25),title_,HORIZONTAL_ALIGNMENT_LEFT,size.x-54,21,col);draw_string(f,Vector2(48,46),sub,HORIZONTAL_ALIGNMENT_LEFT,size.x-54,17,Color('#dbca99') if not disabled else Color('#849092'))
	if has_focus():draw_rect(Rect2(2,2,size.x-4,size.y-4),Color('#e1cd93'),false,2)
