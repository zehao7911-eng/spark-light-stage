extends RefCounted
const INK='#24324a'
static func b(c,x,y,w,h,col):c.draw_rect(Rect2(floor(x),floor(y),w,h),Color(col))
static func poly(c,points,col):c.draw_colored_polygon(PackedVector2Array(points),Color(col))
static func coin(c,p,t=0.0,rare=false):
	var x=floor(p.x);var y=floor(p.y)
	if rare:
		poly(c,[Vector2(x,y-7),Vector2(x+5,y-2),Vector2(x,y+7),Vector2(x-5,y-2)],'#583984');poly(c,[Vector2(x,y-5),Vector2(x+3,y-1),Vector2(x,y+4),Vector2(x-3,y-1)],'#cf94ef');b(c,x-1,y-4,2,5,'#ffe1ff');return
	var w=2+int(absf(sin(t*7))*3);b(c,x-w,y-6,w*2+1,12,'#a86c23');b(c,x-w-1,y-4,w*2+3,8,'#b98229');b(c,x-w,y-4,w*2+1,8,'#ffd35c');b(c,x-w+1,y-5,w*2-1,1,'#fff4aa');b(c,x-1,y-3,2,6,'#dd9b34');b(c,x-w,y+4,w*2,1,'#e5a43b')
static func hero(c,p,t,air,slash,boost=false):
	var x=int(p.x);var y=int(p.y);var step=int(t*12)%4;var bob=0 if air else step%2
	y-=bob
	# Separate silhouettes for boots, tunic, leather belt, hair, face, scarf and blade.
	if boost:b(c,x-27,y-24,20,4,'#bae9dd');b(c,x-34,y-16,26,3,'#74c8c8');b(c,x-20,y-8,12,2,'#e5ffff')
	poly(c,[Vector2(x-6,y-23),Vector2(x-23,y-23+sin(t*14)*3),Vector2(x-19,y-16),Vector2(x-8,y-19)],'#a8515e');b(c,x-18,y-23,9,2,'#e78270')
	b(c,x-6,y-26,15,12,INK);b(c,x-5,y-28,11,5,'#c88e4f');b(c,x-6,y-25,14,4,'#e9b66e');b(c,x-4,y-24,8,4,'#e9b66e');b(c,x+1,y-23,7,7,'#ffd1a6');b(c,x+5,y-21,2,2,INK);b(c,x+2,y-16,5,2,'#db9e7f');b(c,x-6,y-20,4,5,'#bc7648')
	b(c,x-7,y-16,15,12,INK);b(c,x-5,y-15,10,10,'#4993af');b(c,x-4,y-14,5,3,'#84c6cc');b(c,x-5,y-6,11,3,'#795846');b(c,x+1,y-6,2,2,'#f2c578')
	var leg=4 if air else ([0,3,0,-3][step]);b(c,x-5-leg*.3,y-3,5,4,'#35445d');b(c,x+2+leg*.3,y-3,5,4,'#35445d');b(c,x-6-leg,y,7,3,'#263047');b(c,x+2+leg,y,7,3,'#35405a')
	if slash>0:
		b(c,x+6,y-14,8,4,'#ffd1a6');b(c,x+12,y-18,3,11,'#b3824e');poly(c,[Vector2(x+14,y-14),Vector2(x+42,y-22),Vector2(x+40,y-18),Vector2(x+14,y-10)],'#f5fff0');b(c,x+22,y-16,11,1,'#9ad3d2')
		c.draw_arc(Vector2(x+15,y-17),25,-1.1,1.0,16,Color('#f9fff0'),3,false);c.draw_arc(Vector2(x+15,y-17),29,-.9,.7,16,Color('#94d8d2'),1,false)
	else:
		b(c,x+6,y-14,5,6,'#eebc93');poly(c,[Vector2(x+10,y-12),Vector2(x+20,y-26),Vector2(x+22,y-23),Vector2(x+13,y-10)],'#e8f1e7');b(c,x+8,y-11,8,2,'#bc985d')
static func monster(c,p,kind,t,hp=1):
	var x=int(p.x);var y=int(p.y);var bob=int(sin(t*7)*2)
	if kind==0:
		b(c,x-12,y-17+bob,24,15-bob,'#37614a');b(c,x-9,y-21+bob,18,5,'#37614a');b(c,x-11,y-16+bob,22,12-bob,'#7cae58');b(c,x-8,y-19+bob,16,11,'#9ecf6a');b(c,x-7,y-18+bob,6,2,'#cce89c');b(c,x-6,y-12+bob,3,4,INK);b(c,x+4,y-12+bob,3,4,INK);b(c,x-4,y-5,9,2,'#5f8d4b');b(c,x-13,y-2,26,3,'#416d48')
	elif kind==1:
		b(c,x-12,y-15,23,13,'#754652');b(c,x-9,y-19,16,5,'#c07565');b(c,x-11,y-14,20,8,'#b96e5c');b(c,x-7,y-16,5,6,'#e0a37b');b(c,x+7,y-13,7,7,'#d7936b');b(c,x+10,y-13,2,3,INK)
		for i in range(4):b(c,x-10+i*6,y-3+(int(t*10+i)%2),3,5,'#583e4b')
		b(c,x-7,y-21,2,5,'#e9c689');b(c,x+2,y-21,2,5,'#e9c689')
	elif kind==2:
		var flap=int(sin(t*13)*6);poly(c,[Vector2(x,y-10),Vector2(x-24,y-18-flap),Vector2(x-16,y-1),Vector2(x-8,y-5),Vector2(x,y+1)],'#564777');poly(c,[Vector2(x,y-10),Vector2(x+24,y-18-flap),Vector2(x+16,y-1),Vector2(x+8,y-5),Vector2(x,y+1)],'#735b9b');b(c,x-7,y-16,14,17,'#463a65');b(c,x-6,y-19,3,6,'#8c75ac');b(c,x+3,y-19,3,6,'#8c75ac');b(c,x-5,y-11,3,3,'#f0ce83');b(c,x+2,y-11,3,3,'#f0ce83')
	else:
		b(c,x-18,y-31,36,29,'#354e65');b(c,x-13,y-39,26,9,'#354e65');b(c,x-16,y-29,31,24,'#668793');b(c,x-10,y-36,20,13,'#8aa5a4');b(c,x-13,y-26,10,5,'#a6bcaf');b(c,x-11,y-30,5,4,'#233a54');b(c,x+5,y-30,5,4,'#233a54');b(c,x-7,y-23,13,3,'#344e61');b(c,x-20,y-24,8,18,'#52778a');b(c,x+14,y-24,8,18,'#52778a');b(c,x-15,y-5,11,7,'#3a566b');b(c,x+5,y-5,11,7,'#3a566b');b(c,x-10,y-44,5,8,'#c1d5b6');b(c,x+6,y-44,5,8,'#c1d5b6')
	if hp>1:b(c,x-12,y-48,24,3,'#26364e');b(c,x-11,y-47,mini(22,hp*4),1,'#e7a474')
static func icon(c,id,p,s=1.0):
	var x=p.x;var y=p.y
	if id==0:coin(c,p+Vector2(16,16)*s,1)
	elif id==1:
		poly(c,[p+Vector2(7,27)*s,p+Vector2(23,3)*s,p+Vector2(27,4)*s,p+Vector2(13,28)*s],'#d8f0ec');b(c,x+7*s,y+21*s,14*s,3*s,'#dda65e');b(c,x+7*s,y+25*s,4*s,6*s,'#895f4a')
	elif id==2:b(c,x+6*s,y+4*s,12*s,20*s,'#719cb0');b(c,x+5*s,y+21*s,23*s,9*s,'#365372');b(c,x+8*s,y+23*s,17*s,3*s,'#a5d1d0')
	elif id==3:c.draw_arc(p+Vector2(16,16)*s,11*s,0,PI,18,Color('#dd8d8b'),6*s,false);b(c,x+2*s,y+7*s,7*s,9*s,'#d6e7e6');b(c,x+23*s,y+7*s,7*s,9*s,'#d6e7e6')
	elif id==4:b(c,x+4*s,y+11*s,24*s,19*s,'#986743');b(c,x+9*s,y+4*s,14*s,10*s,'#71543f');b(c,x+7*s,y+14*s,18*s,5*s,'#cca673');b(c,x+14*s,y+17*s,4*s,6*s,'#f6ce75')
	elif id==5:
		poly(c,[p+Vector2(16,2)*s,p+Vector2(29,14)*s,p+Vector2(16,31)*s,p+Vector2(3,14)*s],'#b18bdd');poly(c,[p+Vector2(16,5)*s,p+Vector2(22,14)*s,p+Vector2(16,25)*s,p+Vector2(11,14)*s],'#e2c6fa')
	elif id==6:
		poly(c,[p+Vector2(3,25)*s,p+Vector2(16,8)*s,p+Vector2(16,17)*s,p+Vector2(28,4)*s,p+Vector2(18,29)*s,p+Vector2(18,19)*s],'#e1efe3')
	elif id==7:c.draw_arc(p+Vector2(8,16)*s,13*s,-1.4,1.4,20,Color('#d5a568'),3*s,false);c.draw_line(p+Vector2(10,3)*s,p+Vector2(10,29)*s,Color('#e6e2bf'),s,false);c.draw_line(p+Vector2(5,16)*s,p+Vector2(30,16)*s,Color('#e6e2bf'),2*s,false)
	elif id==8:
		for i in range(5):c.draw_arc(p+Vector2(16,16)*s,(13-i*2)*s,0,TAU,24,Color('#a689d3').lerp(Color('#e2c6f0'),i/5.0),2*s,false)
	elif id==9:b(c,x+5*s,y+5*s,7*s,22*s,'#d9e6e7');b(c,x+20*s,y+5*s,7*s,22*s,'#d9e6e7')
	elif id==10:
		c.draw_arc(p+Vector2(16,16)*s,10*s,0,TAU,20,Color('#b3c8d8'),3*s,false)
		for i in range(8):c.draw_line(p+Vector2(16,16)*s+Vector2.from_angle(i*TAU/8)*9*s,p+Vector2(16,16)*s+Vector2.from_angle(i*TAU/8)*15*s,Color('#b3c8d8'),4*s,false)
	elif id==11:b(c,x+4*s,y+9*s,24*s,21*s,'#d7ac60');b(c,x+8*s,y+3*s,16*s,8*s,'#ad814f');b(c,x+14*s,y+12*s,4*s,10*s,'#fff1b3')
	elif id==12:c.draw_line(p+Vector2(7,7)*s,p+Vector2(25,25)*s,Color('#e6e8df'),3*s,false);c.draw_line(p+Vector2(7,25)*s,p+Vector2(25,7)*s,Color('#e6e8df'),3*s,false)
	elif id==13:poly(c,[p+Vector2(9,5)*s,p+Vector2(27,16)*s,p+Vector2(9,27)*s],'#d8f3e4')
	elif id==14:poly(c,[p+Vector2(16,2)*s,p+Vector2(21,11)*s,p+Vector2(31,13)*s,p+Vector2(23,20)*s,p+Vector2(25,31)*s,p+Vector2(16,25)*s,p+Vector2(7,31)*s,p+Vector2(9,20)*s,p+Vector2(1,13)*s,p+Vector2(11,11)*s],'#f3cf7e')
	elif id==15:b(c,x+4*s,y+12*s,7*s,10*s,'#e7deb9');poly(c,[p+Vector2(10,12)*s,p+Vector2(19,5)*s,p+Vector2(19,28)*s,p+Vector2(10,22)*s],'#e4bf78');c.draw_arc(p+Vector2(18,17)*s,10*s,-1,1,14,Color('#d2e3de'),2*s,false)
