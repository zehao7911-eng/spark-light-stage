extends SceneTree
const Sim=preload('res://sim.gd')
var count=0
func check(ok,message):
	if not ok:push_error(message);quit(1)
	assert(ok,message);count+=1
func ticks(g,n):
	for i in range(n):g.update(1.0/120,600);g.events.clear()
func _initialize():
	var g=Sim.new();g.started=true
	ticks(g,600)
	check(g.coins>0 and g.gold>0,'Road collision must collect actual coins')
	check(g.kills>0 and g.souls>0,'Sword must defeat road enemies')
	var short=Sim.new();short.started=true;short.jump();short.release_jump()
	var tall=Sim.new();tall.started=true;tall.jump()
	ticks(short,30);ticks(tall,30)
	check(tall.y<short.y-20,'Holding jump must change height')
	check(not tall.jump(),'Second jump locked initially')
	tall.souls=6;check(tall.learn(0),'Air step purchase')
	check(tall.jump() and tall.air_jumps==1,'Air step supplies a real second jump')
	check(not tall.jump(),'No unlimited air jumps')
	var before=g.distance;check(g.boost(),'Rush starts');ticks(g,120)
	check(g.distance-before>300 and not g.boost(),'Rush speeds road and enforces cooldown')
	g.gold=1000;var price=g.cost(0);check(g.buy(0) and g.gold==1000-price and g.cost(0)>price,'Purchases spend exact price and scale')
	g.souls=100;check(g.learn(1),'Unlock bow');g.entities=[{'type':'enemy','x':g.distance+160,'y':202.0,'dead':false,'kind':0,'hp':1,'phase':0.0}];g.spawn_to=g.distance+2000;g.attack_cd=0;var kills=g.kills;ticks(g,60)
	check(g.kills>kills,'Bow projectile must collide and defeat a distant enemy')
	var loaded=Sim.new();check(loaded.restore(JSON.parse_string(JSON.stringify(g.snapshot()))),'JSON save restores')
	ticks(g,240);ticks(loaded,240)
	check(absf(g.distance-loaded.distance)<.001 and absf(g.gold-loaded.gold)<.001 and g.kills==loaded.kills,'Restored live world continues deterministically')
	var bad=g.snapshot();bad.entities=[{'type':'enemy','x':1,'y':2}];check(not Sim.new().restore(bad),'Malformed entity rejected')
	bad=g.snapshot();bad.skills[0]=2;check(not Sim.new().restore(bad),'Invalid skill levels rejected')
	g.paused=true;before=g.distance;var money=g.gold;ticks(g,120);check(g.distance==before and g.gold==money and g.away(10000)==0 and not g.buy(1),'Pause freezes progress and income')
	g.paused=false;money=g.gold;var rate=g.idle_rate();g.away(999999);check(absf(g.gold-money-rate*14400)<.01,'Away reward capped at four hours')
	g.skills=[1,1,2,1];g.claimed=[0];g.run_souls=240;var skills=g.skills.duplicate();check(g.ascend() and g.gems==2 and g.skills==skills and g.claimed==[0] and g.gold==0 and g.distance==0 and not g.hold,'Ascension retains skills and resets run')
	check(g.coin_value()==1.5,'Permanent crystal multiplier')
	var loop=Sim.new();loop.started=true;loop.upgrades=[4,4,4,4,4,4];loop.skills=[1,1,2,1]
	for i in range(120*240):
		if i%150==0:loop.jump()
		if i%150==60:loop.release_jump()
		if i%1000==0:loop.boost()
		loop.update(1.0/120,1400);loop.events.clear()
	check(loop.portals>=6 and loop.coins>100 and loop.kills>20,'Long play crosses all visual realms and earns rewards')
	check(loop.entities.size()<100 and loop.arrows.size()<20,'World entities remain bounded')
	print('SOULSTRIDE QA PASSED: ',count,' checks; long-run coins=',loop.coins,' kills=',loop.kills,' portals=',loop.portals)
	quit()

