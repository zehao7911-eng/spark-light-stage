extends SceneTree
var w
var failures=[]
var checks=0
var backup=""
func check(ok,label):
 checks+=1
 if not ok:failures.append(label);printerr("FAIL "+label)
func _initialize():call_deferred("run")
func run():
 if FileAccess.file_exists("user://stillwater_reach.json"):backup=FileAccess.get_file_as_string("user://stillwater_reach.json")
 w=load("res://World.tscn").instantiate();root.add_child(w);await process_frame
 w.s.cargo=[];w.s.coins=0;w.s.rod=0;w.s.hold=0;w.s.hull=0;w.s.engine=0;w.s.sold=0;w.s.contract=0;w.s.relics=[];w.s.recovered=[];w.s.wins=false;w.s.hour=12;w.s.hp=6
 w.boat.position=w.spots[0].p;w.mode="sail";w.cast();check(w.mode=="fish","shoal starts fishing")
 for i in 3:w.fish_phase=.5;w.reel()
 check(w.mode=="catch" and w.s.cargo.size()==1,"three timed strikes store fish");check(w.spots[0].stock==3,"stock decremented")
 w.mode="sail";w.cast()
 for i in 3:w.fish_phase=0;w.reel()
 check(w.mode=="sail" and w.s.cargo.size()==1,"three slips escape without free catch")
 w.mode="sail";w.boat.position=w.spots[8].p;w.cast();check(w.mode=="sail","deep shoal rod gate")
 var item=w.s.cargo[0];check(not w.fits(item,Vector2i(0,0)),"occupied grid rejects overlap");check(not w.fits(item,Vector2i(5,0),0),"grid bounds")
 w.rotate_item(0);check(item.cells==[[0,0],[0,1]],"cargo rotation geometry");w.pack();check(w.s.cargo.size()==1 and w.fits(w.s.cargo[0],Vector2i(0,0),0),"pack preserves item")
 w.boat.position=w.HOME;w.dock();check(w.mode=="port","dock near harbor");w.sell();check(w.s.coins==12 and w.s.sold==1,"fish sale value")
 w.sell();check(w.s.coins==12,"empty sale no reward");w.upgrade("rod");check(w.s.rod==0,"unaffordable upgrade blocked")
 w.s.coins=100;w.upgrade("rod");check(w.s.rod==1 and w.s.coins==55,"upgrade purchase")
 w.s.cargo=[]
 for i in 6:w.s.cargo.append({"fish":0,"fresh":1.0,"cells":[[0,0]],"x":i%5,"y":int(i/5),"relic":-1})
 w.sell();check(w.s.coins==177 and w.s.contract==2,"multiple orders settled once");var gold=w.s.coins;w.sell();check(w.s.coins==gold,"empty sale cannot claim backlog")
 w.s.rod=3
 for i in 4:
  w.boat.position=w.spots[12+i].p;w.mode="sail";w.cast()
  for j in 3:w.fish_phase=.5;w.reel()
 check(w.s.relics.size()==4,"four salvage targets unique");w.boat.position=w.HOME;w.dock();w.sell();check(w.mode=="ending" and w.s.recovered.size()==4,"four relics finish beacon quest")
 w.mode="sail";w.s.cargo=[{"fish":0,"cells":[[0,0]],"fresh":1,"x":0,"y":0,"relic":-1}];w.s.hp=1;w.damage(1);check(w.mode=="port" and w.s.cargo.is_empty() and w.s.hp==w.max_hp(),"tow handles loss and repair")
 w.s.hour=22;w.s.panic=.7;w.rest();check(w.s.hour==8 and w.s.panic==0,"rest resets risk and dawn")
 w.s.cargo=[];w.s.relics=[];w.s.recovered=[];w.s.hour=12;w.s.hp=6;w.boat.position=w.HOME;w.mode="sail";w.navigate_to(w.spots[0].p)
 Engine.max_fps=0;Engine.time_scale=5
 for i in 420:
  await physics_frame
  if w.goal==Vector3.INF:break
 check(w.boat.position.distance_to(w.spots[0].p)<3.5,"chart course arrives at shoal")
 check(w.s.hp==6,"route avoids rock collisions")
 w.s.engine=3
 for id in [5,8,13,15]:
  w.boat.position=w.HOME;w.boat.speed=0;w.s.hp=6;w.s.hour=12;w.s.panic=0;w.mode="sail";w.navigate_to(w.spots[id].p)
  for i in 1400:
   await physics_frame
   if w.goal==Vector3.INF:break
  check(w.boat.position.distance_to(w.spots[id].p)<4,"long course arrives "+str(id))
  check(w.s.hp==6,"long course avoids damage "+str(id))
 w.s.cargo=[]
 for y in 4:
  for x in 5:w.s.cargo.append({"fish":0,"cells":[[0,0]],"fresh":1,"x":x,"y":y,"relic":-1})
 w.boat.position=w.spots[0].p;w.mode="sail";w.cast();w.fish_id=0
 for i in 3:w.fish_phase=.5;w.reel()
 check(w.pending_catch and w.mode=="cargo" and w.s.cargo.size()==20,"full hold retains pending catch")
 w.s.cargo.pop_back();w.s.cargo.pop_back();w.catch_fish();check(not w.pending_catch and w.mode=="catch" and w.s.cargo.size()==19,"making room retrieves pending fish")
 w.s.coins=222;w.save_game();w.s.coins=0;w.load_save();check(w.s.coins==222,"save round trip")
 Engine.time_scale=1;w.queue_free();await process_frame
 var f=FileAccess.open("user://stillwater_reach.json",FileAccess.WRITE);f.store_string(backup if not backup.is_empty() else "{}");f.close()
 print(JSON.stringify({"checks":checks,"failures":failures}));quit(0 if failures.is_empty() else 1)
