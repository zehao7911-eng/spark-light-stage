extends SceneTree
func _initialize():call_deferred("run")
func own(n,root_node):
 for c in n.get_children():c.owner=root_node;own(c,root_node)
func run():
 var w=load("res://World.tscn").instantiate();root.add_child(w);await process_frame
 var scene=Node3D.new();scene.name="StillwaterReach";scene.set_script(load("res://World.gd"))
 var preview=Node3D.new();preview.name="EditorPreview";scene.add_child(preview)
 preview.add_child(w.map_root.duplicate());preview.add_child(w.sun.duplicate());preview.add_child(w.camera.duplicate())
 for c in w.get_children():
  if c is WorldEnvironment:preview.add_child(c.duplicate())
 var boat=w.boat.rig.duplicate();boat.position=w.HOME;preview.add_child(boat)
 own(scene,scene);var packed=PackedScene.new();packed.pack(scene);ResourceSaver.save(packed,"res://World.tscn")
 scene.free();w.queue_free();await process_frame;print("Editable 3D archipelago baked to World.tscn");quit()
