class_name SeaArt
extends RefCounted
static var materials={}
static func clockwise(vertices):
 var result=[]
 for i in range(0,vertices.size(),3):result.append_array([vertices[i],vertices[i+2],vertices[i+1]])
 return result
static func mat(c:String,glow=false):
 var key=c+str(glow)
 if materials.has(key):return materials[key]
 var m=StandardMaterial3D.new();m.albedo_color=Color(c);m.roughness=.9
 if glow:m.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED;m.emission_enabled=true;m.emission=Color(c)
 if m.albedo_color.a<1:m.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA;m.cull_mode=BaseMaterial3D.CULL_DISABLED
 materials[key]=m;return m
static func mesh(p,m,pos,c,glow=false):
 var n=MeshInstance3D.new();n.mesh=m;n.position=pos;n.material_override=mat(c,glow);p.add_child(n);return n
static func box(p,pos,size,c):
 var b=BoxMesh.new();b.size=size;return mesh(p,b,pos,c)
static func cone(p,pos,r,h,c,top=0):
 var b=CylinderMesh.new();b.bottom_radius=r;b.top_radius=top;b.height=h;b.radial_segments=10;return mesh(p,b,pos,c)
static func sphere(p,pos,size,c):
 var b=SphereMesh.new();b.radial_segments=10;b.rings=5;var n=mesh(p,b,pos,c);n.scale=size;return n
static func rod(p,a,b,r,c):
 var n=cone(p,(a+b)/2,r,a.distance_to(b),c,r);n.quaternion=Quaternion(Vector3.UP,(b-a).normalized());return n
static func torus(p,pos,r,c):
 var m=TorusMesh.new();m.inner_radius=r-.07;m.outer_radius=r+.07;m.rings=24;m.ring_segments=6;return mesh(p,m,pos,c,true)
static func roof(p,pos,size,c):
 var st=SurfaceTool.new();st.begin(Mesh.PRIMITIVE_TRIANGLES)
 var v=[Vector3(-size.x/2,0,-size.z/2),Vector3(size.x/2,0,-size.z/2),Vector3(0,size.y,-size.z/2),Vector3(-size.x/2,0,size.z/2),Vector3(size.x/2,0,size.z/2),Vector3(0,size.y,size.z/2)]
 for i in clockwise([0,2,1,3,4,5,0,3,5,0,5,2,1,2,5,1,5,4]):st.add_vertex(v[i])
 st.generate_normals();return mesh(p,st.commit(),pos,c)
static func house(p,pos,scale=1.0):
 var n=Node3D.new();n.position=pos;n.scale=Vector3.ONE*scale;p.add_child(n)
 box(n,Vector3(0,1.1,0),Vector3(3,2.2,3.5),"c9b29e");roof(n,Vector3(0,2.2,0),Vector3(3.5,1.2,4),"704348")
 box(n,Vector3(.5,1.05,1.77),Vector3(.6,1.7,.05),"4c4449")
 for x in [-.9,.9]:box(n,Vector3(x,1.6,1.8),Vector3(.55,.65,.06),"ffda91");box(n,Vector3(x,1.6,1.86),Vector3(.05,.65,.02),"70575a")
 box(n,Vector3(-.85,3.2,-.65),Vector3(.4,1.3,.5),"82716b")
 for y in [0.4,.8,1.2,1.8]:box(n,Vector3(0,y,1.82),Vector3(2.9,.025,.03),"a28b83")
 return n
static func boat():
 var n=Node3D.new();n.name="TrawlerRig"
 var st=SurfaceTool.new();st.begin(Mesh.PRIMITIVE_TRIANGLES)
 var rings=[[-.36,.65,1.6],[.2,.98,1.75],[.6,1.05,1.8]]
 var points=[]
 for ring in rings:
  points.append([Vector3(0,ring[0],-ring[2]),Vector3(ring[1]*.8,ring[0],-ring[2]*.55),Vector3(ring[1],ring[0],ring[2]*.7),Vector3(ring[1]*.7,ring[0],ring[2]),Vector3(-ring[1]*.7,ring[0],ring[2]),Vector3(-ring[1],ring[0],ring[2]*.7),Vector3(-ring[1]*.8,ring[0],-ring[2]*.55)])
 for k in 2:
  for i in 7:
   var j=(i+1)%7
   for v in clockwise([points[k][i],points[k+1][i],points[k+1][j],points[k][i],points[k+1][j],points[k][j]]):st.add_vertex(v)
 st.generate_normals();var hull=mesh(n,st.commit(),Vector3.ZERO,"713a3e");hull.material_override=hull.material_override.duplicate();hull.material_override.cull_mode=BaseMaterial3D.CULL_DISABLED
 var deck=SurfaceTool.new();deck.begin(Mesh.PRIMITIVE_TRIANGLES)
 for i in 7:
  for v in [Vector3(0,.6,0),points[2][i],points[2][(i+1)%7]]:deck.add_vertex(v)
 deck.generate_normals();var cap=mesh(n,deck.commit(),Vector3.ZERO,"c6b59a");cap.material_override=cap.material_override.duplicate();cap.material_override.cull_mode=BaseMaterial3D.CULL_DISABLED
 box(n,Vector3(0,.58,.18),Vector3(1.85,.15,2.8),"c6b59a")
 for x in [-1,1]:rod(n,Vector3(x,.69,-.9),Vector3(x,.69,1.3),.05,"e0cbb0")
 box(n,Vector3(0,1.1,-.15),Vector3(1.25,1.12,1.0),"d5c8ab");box(n,Vector3(0,1.67,-.15),Vector3(1.65,.14,1.3),"783d42")
 box(n,Vector3(0,1.25,-.66),Vector3(.9,.4,.03),"24404b").name="FrontWindow"
 for side in [-1,1]:
  box(n,Vector3(side*.64,1.3,-.25),Vector3(.025,.43,.65),"273e49").name="PortWindow" if side==-1 else "StarboardWindow"
  var tire=torus(n,Vector3(side*1.04,.33,.7),.24,"202832");tire.rotation.z=PI/2
  cone(n,Vector3(side*.82,.75,1.25),.055,.4,"a97871",.055)
 box(n,Vector3(-.65,.88,.9),Vector3(.43,.45,.45),"80684f")
 for z in [0.72,.9,1.08]:box(n,Vector3(-.65,1.115,z),Vector3(.44,.015,.03),"bca382")
 rod(n,Vector3(.65,.75,.5),Vector3(.65,2.8,.5),.035,"3d4c4d");rod(n,Vector3(.65,2.1,.5),Vector3(-.3,2.4,.5),.035,"3d4c4d")
 rod(n,Vector3(-.3,2.4,.5),Vector3(-.3,1.3,1.35),.008,"b4a69a")
 cone(n,Vector3(.2,1.95,-.13),.13,.52,"566562",.13);cone(n,Vector3(.2,2.2,-.13),.17,.1,"934c4a",.17)
 sphere(n,Vector3(-.2,2.4,.5),Vector3(.18,.25,.18),"ffdc9b")
 var lamp=SpotLight3D.new();lamp.name="Lamp";lamp.position=Vector3(0,1.25,-.8);lamp.rotation_degrees.x=-12;lamp.spot_range=18;lamp.spot_angle=35;lamp.light_color=Color("ffdba2");lamp.light_energy=1.3;n.add_child(lamp)
 var deck_light=OmniLight3D.new();deck_light.name="DeckLight";deck_light.position=Vector3(0,1.1,0);deck_light.omni_range=5;deck_light.light_color=Color("ffdba2");deck_light.light_energy=.65;n.add_child(deck_light)
 return n
static func island(p,pos,r,h,c):
 var n=Node3D.new();n.position=pos;p.add_child(n)
 var st=SurfaceTool.new();st.begin(Mesh.PRIMITIVE_TRIANGLES)
 var cols=[Color("5c636b"),Color("8b8a85"),Color("a39c8e")]
 var rows=[]
 for k in 3:
  var ring=[]
  for i in 18:
   var a=i*TAU/18;var f=1+sin(i*2.7)*.1
   ring.append(Vector3(cos(a)*r*f*([1.05,1.0,.78][k]),[-.8,h*.45,h][k],sin(a)*r*f*([1.05,1.0,.78][k])))
  rows.append(ring)
 for k in 2:
  for i in 18:
   var j=(i+1)%18;var color=cols[(i+k)%3]
   for v in clockwise([rows[k][i],rows[k+1][i],rows[k+1][j],rows[k][i],rows[k+1][j],rows[k][j]]):st.set_color(color);st.add_vertex(v)
 for i in 18:
  for v in [Vector3(0,h,0),rows[2][i],rows[2][(i+1)%18]]:st.set_color(Color(c).darkened((i%3)*.025));st.add_vertex(v)
 st.generate_normals();var land=MeshInstance3D.new();land.mesh=st.commit();var material=StandardMaterial3D.new();material.vertex_color_use_as_albedo=true;material.roughness=1;land.material_override=material;n.add_child(land)
 var body=StaticBody3D.new();var shape=CylinderShape3D.new();shape.radius=r*.94;shape.height=h+3;var col=CollisionShape3D.new();col.shape=shape;col.position.y=h/2;body.add_child(col);n.add_child(body)
 return n
static func lighthouse(p,pos):
 var n=Node3D.new();n.position=pos;p.add_child(n)
 for i in 7:cone(n,Vector3(0,i*.85+.42,0),.88-i*.035,.85,"b7ad98" if i%2==0 else "87414a",.845-i*.035)
 cone(n,Vector3(0,6.15,0),1.06,.3,"504c4e",1.06);var lantern=cone(n,Vector3(0,6.8,0),.65,1.0,"ffd48c",.65);lantern.name="Lantern";lantern.material_override=mat("ffdc97",true)
 for i in 8:rod(n,Vector3(cos(i*TAU/8)*.7,6.25,sin(i*TAU/8)*.7),Vector3(cos(i*TAU/8)*.7,7.3,sin(i*TAU/8)*.7),.04,"584c4d")
 cone(n,Vector3(0,7.55,0),1.02,.75,"6e3d45");rod(n,Vector3(0,7.9,0),Vector3(0,8.6,0),.025,"6d5455")
 return n
static func trees(p,positions):
 for layer in 4:
  var mm=MultiMesh.new();mm.transform_format=MultiMesh.TRANSFORM_3D;mm.use_colors=true
  var mesh=CylinderMesh.new();mesh.radial_segments=6;mesh.height=1;mesh.bottom_radius=.5;mesh.top_radius=.12 if layer==0 else 0;mm.mesh=mesh;mm.instance_count=positions.size()
  var ins=MultiMeshInstance3D.new();ins.multimesh=mm;var material=StandardMaterial3D.new();material.vertex_color_use_as_albedo=true;ins.material_override=material;p.add_child(ins)
  for i in positions.size():
   var a=positions[i];var h=3.0+fmod(i*1.71,2.5);var size=Vector3(.3,h,.3) if layer==0 else Vector3(h*(1.3-layer*.16),h*.75,h*(1.3-layer*.16))
   var pos=a+Vector3(0,h*.5 if layer==0 else h*(.65+layer*.2),0)
   mm.set_instance_transform(i,Transform3D(Basis.from_scale(size),pos));mm.set_instance_color(i,Color("65554e") if layer==0 else Color(["334a46","465752","5c5e55"][i%3]))
