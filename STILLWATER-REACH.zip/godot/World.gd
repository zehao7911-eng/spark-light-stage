extends Node3D
const BoatScript=preload("res://Boat.gd")
const HudScript=preload("res://HUD.gd")
const SAVE="user://stillwater_reach.json"
const HOME=Vector3(-12,0,21)
const SPECIES=[
 ["Coastal Cod",12,[[0,0],[1,0]],"c9b890"],["Silver Sardine",8,[[0,0],[0,1]],"9daeba"],["Blue Mackerel",18,[[0,0],[1,0],[2,0]],"648fa1"],["Rock Crab",22,[[0,0],[0,1],[1,1]],"cf8170"],
 ["Rose Herring",14,[[0,0],[1,0]],"ce9a92"],["Ribbon Eel",26,[[0,0],[0,1],[0,2]],"a2af84"],["Red Snapper",30,[[0,0],[1,0],[0,1],[1,1]],"cd765e"],["Midnight Ray",40,[[0,0],[1,0],[2,0],[1,1]],"889bb5"],
 ["Lantern Angler",52,[[0,0],[1,0],[2,0],[0,1],[1,1]],"bfad72"],["Coiled Horror",75,[[0,0],[1,0],[0,1],[1,1]],"af7291"],["Pale Tusk",95,[[0,0],[1,0],[2,0]],"d6c6a5"],["Abyssal Eye",115,[[0,0],[1,0],[0,1],[1,1],[0,2]],"9b799a"],
 ["Sunken Relic",0,[[0,0],[1,0],[0,1],[1,1]],"d7ba7b"]]
const ISLANDS=[[Vector3(-28,0,29),12.0,5.0,"666754"],[Vector3(32,0,14),10.0,6.5,"65665c"],[Vector3(-31,0,-34),13.0,8.0,"687569"],[Vector3(35,0,-40),11.0,7.5,"686477"],[Vector3(8,0,56),8.0,3.5,"826e63"]]
var s={"coins":0,"engine":0,"rod":0,"hold":0,"hull":0,"hp":6.0,"hour":16.0,"day":1,"panic":0.0,"cargo":[],"journal":[],"relics":[],"recovered":[],"catch":0,"sold":0,"contract":0,"wins":false,"pos":[-12,21],"heading":0.0,"low":false,"muted":false}
var mode="title"
var previous="sail"
var boat
var camera:Camera3D
var hud
var env:Environment
var sky_mat:ProceduralSkyMaterial
var sun:DirectionalLight3D
var sea_material:ShaderMaterial
var map_root:Node3D
var spots:Array=[]
var wake:Array=[]
var sea_nodes:Array=[]
var lighthouses:Array=[]
var move_vec=Vector2.ZERO
var goal=Vector3.INF
var route:Array=[]
var nav=AStarGrid2D.new()
var clock=0.0
var autosave=0.0
var wake_timer=0.0
var fish_phase=0.0
var fish_hits=0
var fish_misses=0
var fishing=-1
var fish_id=0
var pending_catch=false
var monster:Node3D
var monster_cd=0.0
var horn_cd=0.0
var rng=RandomNumberGenerator.new()
var audio:Array=[]
var music:AudioStreamPlayer
var sound_bank={}
var notice=""
var notice_time=0.0
var bridge=0.0
var fov_target=54.0
var camera_offset=Vector3(14,13,23)
var camera_aim=Vector3(0,4,-4)
func _ready():
 if has_node("EditorPreview"):get_node("EditorPreview").queue_free()
 rng.randomize();Engine.max_fps=30;load_save()
 var we=WorldEnvironment.new();env=Environment.new();env.background_mode=Environment.BG_SKY;var sky=Sky.new();sky_mat=ProceduralSkyMaterial.new();sky_mat.sky_top_color=Color("284750");sky_mat.sky_horizon_color=Color("d1aa84");sky_mat.ground_bottom_color=Color("223e48");sky_mat.ground_horizon_color=Color("af8b75");sky.sky_material=sky_mat;env.sky=sky;env.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;env.ambient_light_color=Color("9badb0");env.ambient_light_energy=.55;env.fog_enabled=true;env.fog_light_color=Color("8b9b98");env.fog_density=.012;we.environment=env;add_child(we)
 sun=DirectionalLight3D.new();sun.rotation_degrees=Vector3(-28,-35,0);sun.light_color=Color("ffd3a0");sun.light_energy=1;sun.shadow_enabled=not s.low;sun.directional_shadow_max_distance=75;add_child(sun)
 camera=Camera3D.new();camera.fov=54;camera.far=250;camera.near=.2;add_child(camera);camera.current=true
 map_root=Node3D.new();map_root.name="Archipelago";add_child(map_root);make_world()
 nav.region=Rect2i(-16,-16,33,33);nav.cell_size=Vector2(5,5);nav.diagonal_mode=AStarGrid2D.DIAGONAL_MODE_ONLY_IF_NO_OBSTACLES;nav.update()
 for x in range(-16,17):
  for z in range(-16,17):
   for data in ISLANDS:
    if Vector2(x*5,z*5).distance_to(Vector2(data[0].x,data[0].z))<float(data[1])+3:nav.set_point_solid(Vector2i(x,z),true)
 boat=BoatScript.new();boat.world=self;add_child(boat);boat.position=Vector3(float(s.pos[0]),0,float(s.pos[1]));boat.heading=float(s.heading)
 camera.position=boat.position+Vector3(14,13,23);camera.look_at(boat.position+Vector3(0,0,-3))
 hud=HudScript.new();hud.world=self;add_child(hud)
 for n in ["shot","move","hit","coin","hurt"]:sound_bank[n]=load("res://audio/"+n+".wav")
 for i in 5:var a=AudioStreamPlayer.new();a.volume_db=-20;add_child(a);audio.append(a)
 music=AudioStreamPlayer.new();music.stream=load("res://audio/ambient.wav");music.stream.loop_mode=AudioStreamWAV.LOOP_FORWARD;music.stream.loop_end=int(music.stream.get_length()*22050);music.volume_db=-26;add_child(music)
 get_viewport().size_changed.connect(resize);resize();mode="title"
func resize():
 var a=DisplayServer.window_get_size();var target=Vector2i(480,800) if a.x<a.y*1.1 else Vector2i(900,500)
 if get_viewport().content_scale_size!=target:get_viewport().content_scale_size=target
 camera.keep_aspect=Camera3D.KEEP_WIDTH if a.x<a.y else Camera3D.KEEP_HEIGHT
 fov_target=62 if a.x<a.y else 54
 camera_offset=Vector3(-4,12,24) if a.x<a.y else Vector3(14,13,23)
 camera_aim=Vector3(0,2,-4) if a.x<a.y else Vector3(0,4,-4)
func make_world():
 var plane=PlaneMesh.new();plane.size=Vector2(220,220);plane.subdivide_width=64;plane.subdivide_depth=64
 var sea=MeshInstance3D.new();sea.mesh=plane;sea_material=ShaderMaterial.new();sea_material.shader=load("res://Sea.gdshader");sea.material_override=sea_material;map_root.add_child(sea)
 var tree_positions=[]
 for i in ISLANDS.size():
  var data=ISLANDS[i];var island=SeaArt.island(map_root,data[0],data[1],data[2],data[3]);rng.seed=204+i*25
  for j in 20:
   var a=j*2.4;var r=rng.randf_range(2,data[1]*.69);var candidate=data[0]+Vector3(cos(a)*r,data[2],sin(a)*r)
   var center_lamp=Vector3(-24,5,25) if data==ISLANDS[0] else data[0]+Vector3(-2,data[2],-1)
   if candidate.distance_to(center_lamp)>4.5 and candidate.distance_to(data[0]+Vector3(4,data[2],3))>3:tree_positions.append(candidate)
  var lighthouse_pos=data[0]+Vector3(-2,data[2],-1)
  if data==ISLANDS[0]:lighthouse_pos=Vector3(-24,5,25)
  var light=SeaArt.lighthouse(map_root,lighthouse_pos);light.scale=Vector3.ONE*1.2;lighthouses.append(light)
  var lamp=SpotLight3D.new();lamp.name="Beacon";lamp.position=Vector3(0,7,0);lamp.spot_angle=12;lamp.spot_range=70;lamp.light_color=Color("ffdc92");lamp.light_energy=3;light.add_child(lamp)
  var beam=SeaArt.cone(lamp,Vector3(0,0,-18),3.2,36,"f3d79709");beam.name="Beam";beam.rotation.x=PI/2;beam.material_override=SeaArt.mat("f3d79709",true);beam.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
  SeaArt.house(map_root,data[0]+Vector3(4,data[2],3),.7)
  for k in 13:
   var p=data[0]+Vector3(cos(k*TAU/13)*data[1]*1.05,.04,sin(k*TAU/13)*data[1]*1.05)
   var foam=SeaArt.box(map_root,p,Vector3(2.4,.02,.15),"b5c6b688");foam.rotation.y=-k*TAU/13
 SeaArt.trees(map_root,tree_positions)
 var harbor=Node3D.new();harbor.position=Vector3(-12,0,26);map_root.add_child(harbor)
 SeaArt.box(harbor,Vector3(-2,.25,0),Vector3(7,.5,4),"746b61")
 for j in 12:SeaArt.box(harbor,Vector3(-2,.53,-1.8+j*.3),Vector3(7,.035,.2),"af9580")
 for x in [-5,1]:
  for z in [-1.7,1.7]:SeaArt.cone(harbor,Vector3(x,.3,z),.17,1.5,"796552",.17)
 SeaArt.house(map_root,Vector3(-25,5,34),1.0);SeaArt.house(map_root,Vector3(-31,5,34),.85)
 SeaArt.box(map_root,Vector3(-13.5,1.1,26),Vector3(.9,1.1,.8),"9b7662")
 for i in 7:SeaArt.box(map_root,Vector3(-18.8+i*.65,4.5-i*.6,26),Vector3(1.2,.3,1.8),"a79a83")
 var beacon=OmniLight3D.new();beacon.position=Vector3(-15,2,23);beacon.light_color=Color("ffd898");beacon.omni_range=9;beacon.light_energy=1.4;map_root.add_child(beacon)
 var positions=[Vector3(-3,0,15),Vector3(3,0,28),Vector3(16,0,3),Vector3(23,0,30),Vector3(-16,0,-14),Vector3(-40,0,-16),Vector3(2,0,-34),Vector3(18,0,-51),Vector3(46,0,-17),Vector3(-42,0,9),Vector3(-8,0,44),Vector3(36,0,48),Vector3(-1,0,4),Vector3(-13,0,-34),Vector3(31,0,-22),Vector3(3,0,-55)]
 for i in positions.size():
  var salvage=i>=12;var n=Node3D.new();n.position=positions[i]+Vector3(0,.08,0);map_root.add_child(n)
  for k in 3:
   var ring=SeaArt.torus(n,Vector3.ZERO,1.2+k*.45,"cfbb8266" if salvage else "bdd4cf66");sea_nodes.append(ring)
  for k in 3:
   var fish=SeaArt.sphere(n,Vector3(k*.7-1,.0,(k%2)*.6),Vector3(.45,.05,.13),"203b4488");fish.rotation.y=k*.7
  spots.append({"p":positions[i],"node":n,"tier":maxi(0,int(i/4)-1) if not salvage else i-12,"salvage":salvage,"id":i-12 if salvage else -1,"stock":4,"cool":0.0})
 monster=Node3D.new();map_root.add_child(monster);SeaArt.sphere(monster,Vector3(0,-.12,0),Vector3(3.2,.3,7),"191a2d");SeaArt.sphere(monster,Vector3(-.5,.12,-2),Vector3(.13,.04,.18),"e16077").material_override=SeaArt.mat("e16077",true);SeaArt.sphere(monster,Vector3(.5,.12,-2),Vector3(.13,.04,.18),"e16077").material_override=SeaArt.mat("e16077",true);monster.visible=false
func screen_dir(v):
 var right=camera.global_basis.x;right.y=0;right=right.normalized();var down=camera.global_basis.z;down.y=0;down=down.normalized();return (right*v.x+down*v.y).limit_length(1)
func closest_water(p:Vector3):
 var best=Vector2i.ZERO;var dist=INF
 for x in range(-15,16):
  for z in range(-15,16):
   var a=Vector2i(x,z)
   if nav.is_point_solid(a):continue
   var d=Vector2(x*5,z*5).distance_squared_to(Vector2(p.x,p.z))
   if d<dist:dist=d;best=a
 return best
func navigate_to(p:Vector3):
 var nearest=p;var d=9.0
 for a in spots:
  var distance=a.p.distance_to(p)
  if distance<d:nearest=a.p;d=distance
 if HOME.distance_to(p)<8:nearest=HOME
 var path=nav.get_point_path(closest_water(boat.position),closest_water(nearest))
 route.clear()
 for a in path:route.append(Vector3(a.x,0,a.y))
 if route.is_empty():toast("NO CLEAR COURSE");return
 for data in ISLANDS:
  if nearest.distance_to(Vector3(data[0].x,0,data[0].z))<float(data[1])+2:nearest=route[-1]
 route.append(nearest);goal=route[0];toast("COURSE PLOTTED")
func course_dir():
 while not route.is_empty() and boat.position.distance_to(route[0])<1.6:route.pop_front()
 if route.is_empty():goal=Vector3.INF;return Vector3.ZERO
 goal=route[0];return (goal-boat.position).normalized()
func near_spot():
 var best=-1;var d=4.0
 for i in spots.size():
  var q=boat.position.distance_to(spots[i].p)
  if q<d and (not spots[i].salvage or spots[i].id not in s.relics+s.recovered):best=i;d=q
 return best
func near_home():return boat.position.distance_to(HOME)<7.0
func cast():
 var id=near_spot()
 if id<0:toast("APPROACH A SHOAL");return
 var spot=spots[id]
 if spot.stock<=0:toast("THE SHOAL IS RECOVERING");return
 if int(s.rod)<spot.tier:toast("NEED ROD UPGRADE "+str(spot.tier));return
 fishing=id;fish_hits=0;fish_misses=0;fish_phase=0
 fish_id=12 if spot.salvage else mini(8,id%9)
 if not spot.salvage and is_night() and rng.randf()<.28:fish_id=rng.randi_range(9,11)
 mode="fish";reset_input();sound("move")
func reel():
 if mode!="fish":return
 var phase=fmod(fish_phase,1.0);var window=.18+int(s.rod)*.025
 if absf(phase-.5)<window:
  fish_hits+=1;sound("coin");hud.flash=.14;advance(1.1)
  if fish_hits>=3:catch_fish()
 else:
  fish_misses+=1;sound("hurt");advance(.6)
  if fish_misses>=3:mode="sail";toast("THE LINE WENT SLACK")
func catch_fish():
 var cells=SPECIES[fish_id][2].duplicate(true);var item={"fish":fish_id,"cells":cells,"x":0,"y":0,"fresh":1.0,"relic":spots[fishing].id if fish_id==12 else -1}
 var p=find_slot(item)
 if p.x<0:pending_catch=true;mode="cargo";toast("HOLD FULL · MAKE ROOM");return
 pending_catch=false
 item.x=p.x;item.y=p.y;s.cargo.append(item);s.catch+=1;spots[fishing].stock-=1;spots[fishing].cool=45
 if fish_id==12:s.relics.append(spots[fishing].id)
 elif fish_id not in s.journal:s.journal.append(fish_id)
 mode="catch";save_game();sound("coin")
func grid_size():return Vector2i(5+int(s.hold),4)
func fits(item,pos:Vector2i,ignore=-1):
 var bounds=grid_size()
 for a in item.cells:
  var p=pos+Vector2i(int(a[0]),int(a[1]))
  if p.x<0 or p.y<0 or p.x>=bounds.x or p.y>=bounds.y:return false
  for i in s.cargo.size():
   if i==ignore:continue
   var b=s.cargo[i]
   for c in b.cells:if p==Vector2i(int(b.x)+int(c[0]),int(b.y)+int(c[1])):return false
 return true
func find_slot(item,ignore=-1):
 for y in 4:
  for x in grid_size().x:if fits(item,Vector2i(x,y),ignore):return Vector2i(x,y)
 return Vector2i(-1,-1)
func rotate_item(i):
 if i<0 or i>=s.cargo.size():return
 var a=s.cargo[i];var old=a.cells.duplicate(true);var cells=[];var maxy=0
 for c in old:maxy=maxi(maxy,int(c[1]))
 for c in old:cells.append([maxy-int(c[1]),int(c[0])])
 a.cells=cells;var pos=Vector2i(int(a.x),int(a.y))
 if not fits(a,pos,i):pos=find_slot(a,i)
 if pos.x<0:a.cells=old;toast("NO ROOM TO ROTATE")
 else:a.x=pos.x;a.y=pos.y;sound("move");save_game()
func pack():
 var old=s.cargo.duplicate(true);var items=s.cargo.duplicate(true);items.sort_custom(func(a,b):return a.cells.size()>b.cells.size());s.cargo=[]
 for item in items:
  var p=find_slot(item)
  if p.x<0:s.cargo=old;toast("ARRANGE BY HAND");return
  item.x=p.x;item.y=p.y;s.cargo.append(item)
 save_game();sound("move")
func dock():
 if not near_home():toast("RETURN TO THE LIGHTHOUSE");return
 mode="port";reset_input();save_game()
func sell():
 if s.cargo.is_empty():toast("THE HOLD IS EMPTY");return
 var earned=0;var relic_count=0
 for item in s.cargo:
  if item.fish==12:
   if item.relic not in s.recovered:s.recovered.append(item.relic);relic_count+=1
  else:earned+=int(SPECIES[int(item.fish)][1]*maxf(.5,float(item.fresh)));s.sold+=1
 s.cargo=[];s.coins+=earned+relic_count*30
 if s.sold>=int(s.contract+1)*3:
  var orders=int(s.sold/3)-int(s.contract);s.coins+=25*orders;s.contract+=orders;toast("HARBOR ORDERS +$"+str(25*orders))
 else:toast("SOLD FOR $"+str(earned))
 if s.recovered.size()>=4 and not s.wins:s.wins=true;mode="ending"
 save_game();sound("coin")
func upgrade(kind):
 var level=int(s[kind]);var cap=3;var cost=(45 if kind=="rod" else 55 if kind=="engine" else 40 if kind=="hold" else 50)*(level+1)
 if level>=cap:toast("FULLY UPGRADED");return
 if int(s.coins)<cost:toast("NEED $"+str(cost));return
 s.coins-=cost;s[kind]=level+1
 if kind=="hull":s.hp=max_hp()
 save_game();sound("coin")
func max_hp():return 6+int(s.hull)*2
func rest():
 s.hour=8;s.day+=1;s.panic=0;s.hp=max_hp();monster.visible=false
 for p in spots:p.stock=4;p.cool=0
 save_game();sound("coin");toast("A NEW TIDE")
func horn():
 if horn_cd>0:return
 horn_cd=12;monster_cd=5;s.panic=maxf(0,float(s.panic)-.25);sound("shot");toast("THE FOG ANSWERS")
 if monster.visible:monster.position+=(monster.position-boat.position).normalized()*10
func damage(n):
 s.hp-=n;sound("hurt");hud.flash=.4
 if s.hp<=0:
  s.coins=int(s.coins*.85);s.cargo=[];s.relics=s.recovered.duplicate();boat.position=HOME;boat.speed=0;s.hp=max_hp();s.hour=8;s.panic=0;mode="port";toast("TOWED HOME · CARGO LOST")
 save_game()
func is_night():return s.hour>=19 or s.hour<6
func advance(hours):
 s.hour+=hours
 if s.hour>=24:s.hour-=24;s.day+=1
func reset_input():move_vec=Vector2.ZERO;goal=Vector3.INF;route.clear();boat.speed=0
func toast(a):notice=a;notice_time=2.7
func sound(n):
 if s.muted:return
 for a in audio:if not a.playing:a.stream=sound_bank[n];a.play();return
func _process(dt):
 clock+=dt;autosave+=dt;bridge+=dt;notice_time=maxf(0,notice_time-dt);horn_cd=maxf(0,horn_cd-dt);monster_cd=maxf(0,monster_cd-dt)
 if mode=="sail":
  if boat.speed>.5:advance(dt*.05)
  s.panic=clampf(s.panic+dt*(.009 if is_night() else -.04),0,1)
  wake_timer+=dt
  if boat.speed>1 and wake_timer>.1:
   wake_timer=0;var p=boat.position+Vector3(sin(boat.heading),.12,cos(boat.heading))*1.7
   var n=SeaArt.torus(map_root,p,.25,"d2ddc477");wake.append({"n":n,"life":1.5})
  for item in s.cargo:
   if int(item.fish)!=12:item.fresh=maxf(.5,float(item.fresh)-dt*.0007)
  if is_night() and s.panic>.45:
   if not monster.visible:monster.position=boat.position+Vector3(14,0,-12);monster.visible=true
   monster.look_at(boat.position);monster.position=monster.position.move_toward(boat.position,dt*(2+float(s.panic)*2))
   if monster.position.distance_to(boat.position)<3.3 and monster_cd<=0:damage(1);monster_cd=4
  else:monster.visible=false
 if mode=="fish":fish_phase+=dt*(.75+fishing*.012)
 for p in spots:
  p.cool=maxf(0,p.cool-dt)
  if p.cool<=0 and p.stock<=0:p.stock=4
  p.node.visible=p.stock>0 and (not p.salvage or p.id not in s.relics+s.recovered)
 for a in wake.duplicate():
  a.life-=dt;a.n.scale+=Vector3.ONE*dt*.6
  if a.life<=0:a.n.queue_free();wake.erase(a)
 sea_material.set_shader_parameter("clock",clock)
 var night=1.0 if is_night() else 0.0
 var dusk=clampf((float(s.hour)-15)/4,0,1) if s.hour>=12 else 0
 sun.light_energy=lerpf(sun.light_energy,.18 if night else 1.0,dt*.7);sun.light_color=Color("a5b7d1") if night else Color("ffd6b5");sun.rotation_degrees.x=-18 if dusk>.4 else -42
 env.ambient_light_energy=.34 if night else .42;env.fog_density=.007+float(s.panic)*.012 if night else .0025
 env.fog_light_color=Color("253442") if night else Color("a0abb0");env.fog_sky_affect=.18;sky_mat.sky_top_color=Color("101b30") if night else Color("31545e");sky_mat.sky_horizon_color=Color("3b3b52") if night else Color("d8ae83");sky_mat.ground_horizon_color=sky_mat.sky_horizon_color
 sea_material.set_shader_parameter("deep_color",Color("102632") if night else Color("174b58"));sea_material.set_shader_parameter("shallow_color",Color("294758") if night else Color("377986"))
 for i in lighthouses.size():
  var lamp=lighthouses[i].get_node("Beacon");lamp.rotation.y=clock*.23+i;var lit=i==0 or (i-1) in s.recovered;lamp.visible=lit;lamp.get_node("Beam").visible=lit and bool(night)
  lighthouses[i].get_node("Lantern").material_override=SeaArt.mat("ffdc97",true) if lit else SeaArt.mat("74665a")
 for window in ["FrontWindow","PortWindow","StarboardWindow"]:boat.rig.get_node(window).material_override=SeaArt.mat("ffce83",true) if night else SeaArt.mat("273e49")
 boat.rig.get_node("DeckLight").visible=bool(night)
 camera.fov=lerpf(camera.fov,fov_target,dt*3);camera.position=camera.position.lerp(boat.position+camera_offset,minf(1,dt*3));camera.look_at(boat.position+camera_aim)
 if autosave>8:autosave=0;save_game()
 if OS.has_feature("web") and bridge>.3:
  bridge=0;var sp=[]
  for i in spots.size():
   var p=camera.unproject_position(spots[i].p);sp.append({"id":i,"p":[spots[i].p.x,spots[i].p.z],"tier":spots[i].tier,"screen":[p.x,p.y]})
  var controls=[]
  for b in hud.buttons:controls.append({"id":b.id,"r":[b.r.position.x,b.r.position.y,b.r.size.x,b.r.size.y]})
  JavaScriptBridge.eval("window.ReachSnapshot="+JSON.stringify({"mode":mode,"s":s,"viewport":[get_viewport().get_visible_rect().size.x,get_viewport().get_visible_rect().size.y],"boat":[boat.position.x,boat.position.z,boat.speed],"spots":sp,"near":near_spot(),"home":near_home(),"phase":fmod(fish_phase,1.0),"hits":fish_hits,"misses":fish_misses,"fish":fish_id,"controls":controls,"route":route.size(),"chart":[hud.chart_rect.position.x,hud.chart_rect.position.y,hud.chart_rect.size.x,hud.chart_rect.size.y]}),true)
func save_game():
 if boat:s.pos=[boat.position.x,boat.position.z];s.heading=boat.heading
 var raw=JSON.stringify(s);var f=FileAccess.open(SAVE,FileAccess.WRITE)
 if f:f.store_string(raw);f.close()
 if OS.has_feature("web"):JavaScriptBridge.eval("try{localStorage.setItem('stillwater_reach_v1',"+JSON.stringify(raw)+")}catch(e){}",true)
func load_save():
 var d=null
 if OS.has_feature("web"):
  var raw=JavaScriptBridge.eval("(()=>{try{return localStorage.getItem('stillwater_reach_v1')||''}catch(e){return ''}})()",true)
  if raw is String and not raw.is_empty():d=JSON.parse_string(raw)
 if not d is Dictionary and FileAccess.file_exists(SAVE):d=JSON.parse_string(FileAccess.get_file_as_string(SAVE))
 if d is Dictionary:s.merge(d,true)
func _notification(n):
 if n==NOTIFICATION_APPLICATION_FOCUS_OUT and mode in ["sail","fish"]:previous="sail";mode="pause";reset_input();save_game()


