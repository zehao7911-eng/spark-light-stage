extends CharacterBody3D
var world
var rig:Node3D
var heading=0.0
var speed=0.0
var impact_cd=0.0
func _ready():
 collision_layer=2;collision_mask=1;var c=CollisionShape3D.new();var q=CapsuleShape3D.new();q.radius=.72;q.height=1.9;c.shape=q;add_child(c)
 rig=SeaArt.boat();add_child(rig)
func _physics_process(dt):
 if not world or world.mode!="sail":return
 impact_cd=maxf(0,impact_cd-dt)
 var input=world.move_vec
 var keyboard=Vector2(float(Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT))-float(Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT)),float(Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN))-float(Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP)))
 if keyboard.length()>.1:input=keyboard.normalized()
 if input.length()>.01:world.goal=Vector3.INF;world.route.clear()
 var d=world.screen_dir(input)
 if world.goal!=Vector3.INF and input.length()<.01:
  d=world.course_dir()
 if d.length()>.1:heading=lerp_angle(heading,atan2(-d.x,-d.z),minf(1,dt*4))
 var top=4.5+int(world.s.engine)*1.0
 speed=move_toward(speed,top*minf(1,d.length()),dt*5)
 velocity=Vector3(-sin(heading),0,-cos(heading))*speed
 move_and_slide()
 if get_slide_collision_count()>0 and speed>2.8 and impact_cd<=0:
  world.damage(1);impact_cd=3;speed*=.3;world.toast("WATCH THE ROCKS")
 position.y=0;position.x=clampf(position.x,-76,76);position.z=clampf(position.z,-76,76)
 rig.rotation.y=heading;rig.position.y=sin(world.clock*2.1)*.06;rig.rotation.z=sin(world.clock*1.7)*.022
