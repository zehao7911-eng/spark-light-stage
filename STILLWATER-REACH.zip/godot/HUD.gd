extends Control
var world
var flash=0.0
var font=preload("res://art/Cinzel.ttf")
var body=ThemeDB.fallback_font
var ink=Color("e9e1cd")
var gold=Color("cfad72")
var buttons=[]
var joystick=-1
var stick=Vector2.ZERO
var selected=-1
var dragging=false
var pointer_pos=Vector2.ZERO
var drag_offset=Vector2i.ZERO
var grid_rect=Rect2()
var cell=45.0
var chart_rect=Rect2()
var textures=[]
func _ready():
 set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);mouse_filter=Control.MOUSE_FILTER_IGNORE
 for i in 13:textures.append(load("res://art/fish%d.png"%i))
func _process(dt):
 flash=maxf(0,flash-dt);queue_redraw()
func text(t,p,size=16,c=Color("e9e1cd"),serif=false):draw_string(font if serif else body,p,str(t),HORIZONTAL_ALIGNMENT_LEFT,-1,size,c)
func center(t,y,size=20,c=Color("e9e1cd"),serif=false):
 var f=font if serif else body;var w=f.get_string_size(str(t),HORIZONTAL_ALIGNMENT_LEFT,-1,size).x;text(t,Vector2((size_view().x-w)/2,y),size,c,serif)
func size_view():return get_viewport_rect().size
func panel(r):
 draw_rect(Rect2(r.position+Vector2(0,5),r.size),Color("00000044"));draw_rect(r,Color("16272bf5"));draw_rect(r,gold.darkened(.48),false,1)
 draw_line(r.position+Vector2(6,6),r.position+Vector2(r.size.x-6,6),Color("cfad7255"),1)
func button(id,label,r,active=true):
 draw_rect(r,Color("ad8d53") if active else Color("2a3b3e"));draw_rect(r,gold if active else Color("536466"),false,1)
 var sz=16 if label.length()<19 else 13;var w=body.get_string_size(label,HORIZONTAL_ALIGNMENT_LEFT,-1,sz).x;text(label,r.position+Vector2((r.size.x-w)/2,(r.size.y+sz)/2-3),sz,Color("15272a") if active else ink)
 buttons.append({"id":id,"r":r})
func fish_image(id,r):
 if id>=0 and id<textures.size() and textures[id]:draw_texture_rect(textures[id],r,false)
func _draw():
 if not world or not world.boat:return
 buttons=[];var v=size_view();var w=v.x;var h=v.y;var s=world.s;var m=world.mode
 if m!="title":
  draw_rect(Rect2(0,0,w,65),Color("102329d9"));text("DAY %02d"%int(s.day),Vector2(20,26),14,gold,true)
  var hour=int(s.hour);text("%02d:%02d"%[hour,int((float(s.hour)-hour)*60)],Vector2(20,48),16)
  text("$%d"%int(s.coins),Vector2(w-100,34),24,gold,true)
  for i in world.max_hp():draw_rect(Rect2(130+i*12,22,8,16),Color("b0c6b6") if i<s.hp else Color("384b4e"))
  if world.is_night():draw_rect(Rect2(130,47,95,3),Color("384b4e"));draw_rect(Rect2(130,47,float(s.panic)*95,3),Color("cf8170"))
 if m=="sail":
  button("pause","II",Rect2(w-48,72,34,32),false);button("map","CHART",Rect2(w-106,112,92,36),false);button("cargo","HOLD %d"%s.cargo.size(),Rect2(w-106,158,92,36),false)
  var c=Vector2(85,h-91);draw_circle(c,60,Color("142d3266"));draw_arc(c,59,0,TAU,48,Color("dfd8bd88"),2);draw_circle(c+stick*36,23,Color("d6cfb3aa"))
  text("STEER",Vector2(60,h-17),12,Color("e9e1cd88"))
  var near=world.near_spot();var label="DOCK" if world.near_home() else "FISH" if near>=0 else "SAIL"
  button("action",label,Rect2(w-130,h-132,112,68),near>=0 or world.near_home())
  button("horn","HORN" if world.horn_cd<=0 else "%ds"%int(ceil(world.horn_cd)),Rect2(w-130,h-52,112,36),false)
  if near>=0:
   var p=world.spots[near];var projected=world.camera.unproject_position(p.p);draw_arc(projected,19,0,TAU,28,gold,2)
   var caption="SALVAGE" if p.salvage else "SHOAL";text(caption,projected+Vector2(-30,-29),12,gold)
  if int(s.catch)==0:center("Follow the white rings. Bring your catch home.",85,13)
  if world.goal!=Vector3.INF:center("CHART COURSE · STEER TO CANCEL",h-12,12,gold)
 elif m=="title":
  draw_rect(Rect2(0,0,w,h),Color("091d265c"));var r=Rect2(w*.08,h*.26,w*.84,h*.47);panel(r)
  center("STILLWATER",r.position.y+62,34,gold,true);center("REACH",r.position.y+106,34,ink,true)
  center("A light worth returning to.",r.position.y+141,16)
  center("Sail · Fish · Arrange · Return",r.position.y+176,14,gold)
  button("begin","SET SAIL",Rect2(w/2-110,r.end.y-69,220,47))
  center("Touch to steer  /  WASD + E",h-24,13,ink)
 elif m=="fish":
  var r=Rect2(w/2-180,h/2-180,360,355);panel(r);center("REEL IN",r.position.y+36,23,gold,true)
  var c=Vector2(w/2,h/2-12);var radius=83.0;draw_arc(c,radius,0,TAU,70,Color("50666a"),9)
  var win=.18+int(s.rod)*.025;draw_arc(c,radius,(.5-win)*TAU-PI/2,(.5+win)*TAU-PI/2,40,Color("a9b99a"),10)
  var a=fmod(world.fish_phase,1.0)*TAU-PI/2;draw_line(c,c+Vector2(cos(a),sin(a))*radius,ink,3);draw_circle(c,6,gold)
  fish_image(world.fish_id,Rect2(c-Vector2(42,30),Vector2(84,60)))
  for i in 3:draw_circle(Vector2(w/2-25+i*25,r.position.y+247),6,gold if i<world.fish_hits else Color("455b5e"))
  text("%d / 3 slips"%world.fish_misses,Vector2(w/2-39,r.position.y+272),12)
  button("reel","REEL",Rect2(w/2-90,r.end.y-65,180,45));button("close","X",Rect2(r.end.x-42,r.position.y+12,28,28),false)
 elif m=="catch":
  var r=Rect2(w/2-185,h/2-190,370,380);panel(r);center("A GOOD CATCH",r.position.y+39,22,gold,true)
  fish_image(world.fish_id,Rect2(w/2-120,r.position.y+51,240,160));center(world.SPECIES[world.fish_id][0],r.position.y+238,21,ink,true)
  center("$%d · STORED IN HOLD"%world.SPECIES[world.fish_id][1] if world.fish_id!=12 else "RESTORE A LOST BEACON",r.position.y+266,14,gold)
  button("close","KEEP SAILING",Rect2(w/2-115,r.end.y-69,230,47))
 elif m=="port":
  var r=Rect2(w/2-minf(w*.46,300),85,minf(w*.92,600),minf(h-110,520));panel(r);center("LIGHTHOUSE HARBOR",r.position.y+38,21,gold,true)
  center("BEACONS %d / 4  ·  NEXT ORDER %d / 3"%[s.recovered.size(),int(s.sold)%3],r.position.y+68,13)
  button("sell","SELL CARGO · %d"%s.cargo.size(),Rect2(r.position.x+24,r.position.y+91,r.size.x-48,44),s.cargo.size()>0)
  var kinds=["rod","engine","hold","hull"];var labels=["ROD","ENGINE","HOLD","HULL"]
  for i in 4:
   var k=kinds[i];var cost=(45 if k=="rod" else 55 if k=="engine" else 40 if k=="hold" else 50)*(int(s[k])+1)
   button(k,labels[i]+("  MAX" if s[k]>=3 else " %d · $%d"%[int(s[k])+1,cost]),Rect2(r.position.x+24+(i%2)*(r.size.x-36)/2,r.position.y+148+int(i/2)*58,(r.size.x-60)/2,48),s[k]<3 and s.coins>=cost)
  button("rest","REST & REPAIR",Rect2(r.position.x+24,r.end.y-90,(r.size.x-60)/2,36),false);button("journal","JOURNAL",Rect2(w/2+6,r.end.y-90,(r.size.x-60)/2,36),false)
  button("close","LEAVE HARBOR",Rect2(r.position.x+24,r.end.y-44,r.size.x-48,34))
 elif m=="cargo":draw_cargo(v)
 elif m=="map":
  var side=minf(minf(w-48,h-180),470);var r=Rect2(w/2-side/2-12,80,side+24,side+90);panel(r);center("THE REACH",112,24,gold,true)
  chart_rect=Rect2(w/2-side/2,132,side,side);draw_rect(chart_rect,Color("223d44"))
  for i in world.ISLANDS:
   var p=chart_point(Vector2(i[0].x,i[0].z));draw_circle(p,float(i[1])*side/160,Color("788373"));draw_circle(p,3,gold)
  for p in world.spots:
   if p.salvage and p.id in s.relics+s.recovered:continue
   var a=chart_point(Vector2(p.p.x,p.p.z));draw_circle(a,4,gold if p.salvage else ink);draw_arc(a,7,0,TAU,16,gold if p.salvage else Color("77959b"),1)
  var b=chart_point(Vector2(world.boat.position.x,world.boat.position.z));draw_circle(b,6,Color("e18b74"));text("YOU",b+Vector2(9,4),11)
  var home=chart_point(Vector2(world.HOME.x,world.HOME.z));text("HARBOR",home+Vector2(-20,16),11,gold)
  button("close","CLOSE",Rect2(w/2-80,r.end.y-43,160,34));center("Tap a shoal to plot a safe course.",r.end.y+22,13)
 elif m=="journal":
  var r=Rect2(w*.05,85,w*.9,h-110);panel(r);center("FIELD JOURNAL",121,23,gold,true)
  var cols=3 if w<650 else 4;var cw=(r.size.x-28)/cols;var ch=minf(100,(r.size.y-120)/ceil(12.0/cols))
  for i in 12:
   var p=r.position+Vector2(14+(i%cols)*cw,55+int(i/cols)*ch);var found=i in s.journal
   if found:fish_image(i,Rect2(p.x+7,p.y,cw-14,ch-24))
   else:text("?",p+Vector2(cw/2-6,ch/2),25,Color("738589"),true)
   text(world.SPECIES[i][0] if found else "Unknown",p+Vector2(5,ch-7),11,gold if found else Color("738589"))
  button("backport","BACK",Rect2(w/2-80,r.end.y-44,160,33))
 elif m=="pause":
  var r=Rect2(w/2-170,h/2-140,340,280);panel(r);center("AT ANCHOR",r.position.y+43,25,gold,true)
  button("mute","SOUND · OFF" if s.muted else "SOUND · ON",Rect2(w/2-135,r.position.y+70,270,42),false)
  button("quality","SHADOWS · OFF" if s.low else "SHADOWS · ON",Rect2(w/2-135,r.position.y+125,270,42),false)
  button("close","RESUME",Rect2(w/2-135,r.end.y-68,270,45))
 elif m=="ending":
  var r=Rect2(w/2-190,h/2-185,380,370);panel(r);center("THE LIGHTS RETURN",r.position.y+46,25,gold,true)
  for i in 4:
   var p=Vector2(w/2-105+i*70,r.position.y+132);draw_rect(Rect2(p.x-7,p.y-30,14,72),ink);draw_circle(p-Vector2(0,37),10,gold);draw_line(p-Vector2(0,37),p-Vector2(24,42),gold,1)
  center("Four relics. Four beacons. A way home.",r.position.y+230,15)
  center("The sea still has stories to tell.",r.position.y+259,14,gold)
  button("end","KEEP EXPLORING",Rect2(w/2-140,r.end.y-64,280,44))
 if world.notice_time>0:
  var tw=body.get_string_size(world.notice,HORIZONTAL_ALIGNMENT_LEFT,-1,14).x;draw_rect(Rect2(w/2-tw/2-14,h-183,tw+28,33),Color("13282bee"));center(world.notice,h-161,14,gold)
 if flash>0:draw_rect(Rect2(Vector2.ZERO,v),Color(1,.87,.65,flash*.25))
func draw_cargo(v):
 var w=v.x;var h=v.y;var r=Rect2(w*.05,85,w*.9,h-110);panel(r);center("THE HOLD",122,25,gold,true)
 var dims=world.grid_size();cell=minf(minf(60,(r.size.x-32)/dims.x),(r.size.y-235)/4);grid_rect=Rect2(w/2-dims.x*cell/2,150,dims.x*cell,4*cell)
 for y in 4:
  for x in dims.x:draw_rect(Rect2(grid_rect.position+Vector2(x,y)*cell+Vector2(2,2),Vector2.ONE*(cell-4)),Color("2d4447"))
 for i in world.s.cargo.size():
  var a=world.s.cargo[i];var c=Color(world.SPECIES[int(a.fish)][3]);var bounds=Vector2.ZERO
  for tile in a.cells:
   var p=Vector2(int(a.x)+int(tile[0]),int(a.y)+int(tile[1]));var rr=Rect2(grid_rect.position+p*cell+Vector2(2,2),Vector2.ONE*(cell-4));draw_rect(rr,c.darkened(.5));draw_rect(rr,gold if i==selected else c,false,2)
   bounds.x=maxf(bounds.x,int(tile[0])+1);bounds.y=maxf(bounds.y,int(tile[1])+1)
  fish_image(int(a.fish),Rect2(grid_rect.position+Vector2(a.x,a.y)*cell+Vector2(4,4),bounds*cell-Vector2(8,8)))
 if dragging and selected>=0:
  var a=world.s.cargo[selected];var pos=Vector2i((pointer_pos-grid_rect.position)/cell)-drag_offset;var c=Color("b1d5a5") if world.fits(a,pos,selected) else Color("d88877")
  for tile in a.cells:draw_rect(Rect2(grid_rect.position+Vector2(pos+Vector2i(int(tile[0]),int(tile[1])))*cell+Vector2(1,1),Vector2.ONE*(cell-2)),c,false,3)
 var yy=grid_rect.end.y+31;center("Drag to arrange · Select, then rotate",yy,13)
 if selected>=0 and selected<world.s.cargo.size():center(world.SPECIES[int(world.s.cargo[selected].fish)][0],yy+27,16,gold)
 var bw=(r.size.x-48)/3
 button("rotate","ROTATE",Rect2(r.position.x+12,yy+43,bw,38),selected>=0);button("pack","PACK",Rect2(r.position.x+24+bw,yy+43,bw,38),false);button("release","RELEASE",Rect2(r.position.x+36+bw*2,yy+43,bw,38),false)
 button("close","CLOSE HOLD",Rect2(w/2-110,r.end.y-46,220,34))
func chart_point(p):return chart_rect.position+(p+Vector2(80,80))/160*chart_rect.size
func unlock_audio():
 if world.music and not world.music.playing and not world.s.muted:world.music.play()
func act(id):
 unlock_audio()
 if id=="close" and world.mode=="cargo" and world.pending_catch:world.catch_fish();return
 match id:
  "begin","close":world.mode="sail";world.reset_input();world.save_game()
  "action":
   if world.near_home():world.dock()
   else:world.cast()
  "reel":world.reel()
  "cargo":selected=-1;world.mode="cargo";world.reset_input()
  "map":world.mode="map";world.reset_input()
  "pause":world.mode="pause";world.reset_input();world.save_game()
  "horn":world.horn()
  "sell":world.sell()
  "rest":world.rest()
  "rod","engine","hold","hull":world.upgrade(id)
  "journal":world.mode="journal"
  "backport","end":world.mode="port"
  "rotate":world.rotate_item(selected)
  "pack":world.pack();selected=-1
  "release":
   if selected>=0 and selected<world.s.cargo.size():
    var a=world.s.cargo[selected]
    if a.fish==12:world.s.relics.erase(a.relic)
    world.s.cargo.remove_at(selected);selected=-1;world.save_game();world.sound("move")
  "mute":world.s.muted=not world.s.muted;world.music.stream_paused=world.s.muted;world.save_game()
  "quality":world.s.low=not world.s.low;world.sun.shadow_enabled=not world.s.low;world.save_game()
func pointer(p,down,id):
 pointer_pos=p
 if down:
  unlock_audio()
  for b in buttons:
   if b.r.has_point(p):act(b.id);return
  if world.mode=="sail" and p.distance_to(Vector2(85,size_view().y-91))<80:joystick=id;update_stick(p);return
  if world.mode=="map" and chart_rect.has_point(p):
   var q=(p-chart_rect.position)/chart_rect.size*160-Vector2(80,80);world.navigate_to(Vector3(q.x,0,q.y));world.mode="sail";return
  if world.mode=="cargo" and grid_rect.has_point(p):
   var tile=Vector2i((p-grid_rect.position)/cell);selected=-1
   for i in world.s.cargo.size():
    var a=world.s.cargo[i]
    for c in a.cells:
     if tile==Vector2i(int(a.x)+int(c[0]),int(a.y)+int(c[1])):selected=i;drag_offset=Vector2i(int(c[0]),int(c[1]));dragging=true;return
 else:
  if joystick==id:joystick=-1;stick=Vector2.ZERO;world.move_vec=Vector2.ZERO
  if dragging and selected>=0:
   var pos=Vector2i((p-grid_rect.position)/cell)-drag_offset;var a=world.s.cargo[selected]
   if world.fits(a,pos,selected):a.x=pos.x;a.y=pos.y;world.sound("move");world.save_game()
   dragging=false
func update_stick(p):
 stick=((p-Vector2(85,size_view().y-91))/46).limit_length(1);world.move_vec=stick;world.goal=Vector3.INF;world.route.clear()
func _input(e):
 if e is InputEventScreenTouch:pointer(e.position,e.pressed,e.index)
 elif e is InputEventScreenDrag:
  pointer_pos=e.position
  if joystick==e.index:update_stick(e.position)
 elif e is InputEventMouseButton and e.button_index==MOUSE_BUTTON_LEFT:pointer(e.position,e.pressed,99)
 elif e is InputEventMouseMotion:
  pointer_pos=e.position
  if joystick==99:update_stick(e.position)
 elif e is InputEventKey and e.pressed and not e.echo:
  if e.keycode==KEY_ESCAPE:act("close" if world.mode!="sail" else "pause")
  elif e.keycode in [KEY_E,KEY_SPACE,KEY_ENTER]:act("begin" if world.mode=="title" else "reel" if world.mode=="fish" else "close" if world.mode=="catch" else "action" if world.mode=="sail" else "sell" if world.mode=="port" else "close")
  elif e.keycode==KEY_M and world.mode=="sail":act("map")
  elif e.keycode==KEY_H and world.mode=="sail":act("cargo")

