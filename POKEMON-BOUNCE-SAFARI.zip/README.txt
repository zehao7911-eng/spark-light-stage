POKEMON BOUNCE SAFARI
Open index.html in a modern browser. No internet connection is required.

Drag or tap the playfield to aim and release a Poke Ball. While it flies, tap the lower left or right side when it falls toward the flippers to save it. Tap the upper playfield once to nudge it toward a target. Catch chains and successful flips fill the Fever gauge; Fever doubles rewards. Every third round includes a two-hit boss. Complete three-shot rounds to buy upgrades and expand the collection.

This is an unofficial fan-made mini-game and is not affiliated with Nintendo, Game Freak, or The Pokemon Company. Pokemon names and sprites belong to their respective owners. Sprite files were sourced from the PokeAPI/sprites GitHub repository: https://github.com/PokeAPI/sprites
