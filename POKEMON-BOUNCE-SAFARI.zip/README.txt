POKEMON BOUNCE SAFARI
Open index.html in a modern browser. No internet connection is required.
Aim by dragging or tapping the board, then release to launch. Tap once while the ball is flying to nudge it toward another Pokemon. Catch creatures, complete three-shot rounds, buy upgrades, and fill the collection.

This is an unofficial fan-made mini-game and is not affiliated with Nintendo, Game Freak, or The Pokemon Company. Pokemon names and sprites belong to their respective owners. Sprite files were sourced from the PokeAPI/sprites GitHub repository: https://github.com/PokeAPI/sprites
