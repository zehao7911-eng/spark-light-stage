/* Marmalade Masquerade -- browser edition. AGPL-3.0-or-later. */
const $=s=>document.querySelector(s), TAU=Math.PI*2;
const clip=(x,a,b)=>Math.max(a,Math.min(b,x)),lerp=(a,b,t)=>a+(b-a)*t,ease=u=>u*u*(3-2*u);
const key='marmalade-masquerade.timetable.v1';
const blank=()=>({stamps:Array(6).fill(0),bestStreak:0,rewards:{},mute:false,bookmark:null,revision:0});
let profile=blank(),sdk=null,level=0,service=0,state='cover',previous='',age=0,time=0,slots=[],cars=[],moves=[],moveIndex=0,seed=0,tries=3,faults=0,assists=0,streak=0,fresh=0,picked=-1,clue=null,cheer=0,opinion=1,notice='',noticeTime=0,award=0,live=false,flashes=[],memory=null,guest=false;
let slowTime=0,usedBrake=false,nightScarf=false;
const isTarget=c=>c.fox&&(!guest||c.alt===nightScarf);
const targets=()=>cars.filter(isTarget);
function unlocked(){let n=0;while(n<5&&profile.stamps[n]>0)n++;return n;}
function storeProfile(){try{localStorage.setItem(key,JSON.stringify(profile));}catch{}}
function validMark(b){return b&&Number.isInteger(b.level)&&b.level>=0&&b.level<6&&Number.isInteger(b.service)&&b.service>=0&&b.service<3&&Number.isInteger(b.tries)&&b.tries>0&&b.tries<=3&&Number.isFinite(b.seed);}
function merge(raw,remote){
 if(!raw||typeof raw!=='object')return;
 if(Array.isArray(raw.stamps))for(let i=0;i<6;i++){let n=raw.stamps[i];if(Number.isFinite(n))profile.stamps[i]=Math.max(profile.stamps[i],clip(Math.floor(n),0,3));}
 if(Number.isFinite(raw.bestStreak))profile.bestStreak=Math.max(profile.bestStreak,clip(raw.bestStreak,0,99999));
 for(const k of ['like','comment'])if(raw.rewards?.[k]===true)profile.rewards[k]=true;
 if(!remote&&typeof raw.mute==='boolean')profile.mute=raw.mute;
 if(Number.isFinite(raw.revision)&&raw.revision>profile.revision){profile.revision=raw.revision;profile.bookmark=validMark(raw.bookmark)?{...raw.bookmark}:null;}
}
try{merge(JSON.parse(localStorage.getItem(key)),false);}catch{}
function connectHost(){sdk=bridge({read:()=>profile,write:(p,remote)=>{merge(p,remote);storeProfile();},changed:e=>{if(e.type==='reward'){say(e.kind==='like'?'Brass service pin unlocked':'Ribbon shower unlocked');view.refreshCostume();}
 if(e.type==='cloud'||e.type==='support'||e.type==='reward')updateUI();}});}
function commit(clear=false){
 profile.bookmark=clear||guest?null:{level,service,tries,faults,assists,seed,streak,
  phase:['hunt','lift','served'].includes(state)?'hunt':'peek',
  inspected:cars.filter(c=>c.checked).map(c=>c.id),usedBrake};
 profile.revision=Math.max(Date.now(),profile.revision+1);storeProfile();sdk?.save();
}
function say(text,dur=1.7){notice=text;noticeTime=dur;if(typeof updateNotice==='function')updateNotice();}
function randomGen(n){return()=>{n=(Math.imul(n,1664525)+1013904223)>>>0;return n/4294967296;};}
function newSeed(){return (Math.random()*4294967296)>>>0;}
function coordinates(n){
 if(n===3)return[[-1.71,-.46],[1.71,-.46],[0,2.35]];
 if(n===4)return[[-1.64,-.77],[1.64,-.77],[1.64,2.31],[-1.64,2.31]];
 return[[0,-1.27],[2.12,.16],[1.42,2.67],[-1.42,2.67],[-2.12,.16]];
}
function buildService(){
 const rng=randomGen(seed+service*40343+level*727),spec=stops[level];slots=coordinates(guest?Math.max(4,spec.count):spec.count);
 const ids=slots.map((_,i)=>i),order=ids.slice();
 for(let i=ids.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[ids[i],ids[j]]=[ids[j],ids[i]];}
 const pair=guest||(level>=4&&service>=1),marked=new Set(ids.slice(0,pair?2:1));
 cars=slots.map(([x,z],i)=>({id:i,slot:i,x,z,spin:0,open:0,fox:marked.has(i),alt:pair&&i===ids[1],checked:false,caught:false,lastTell:-20,lastKind:-1,wiggle:0,kind:0}));
 const count=spec.swaps+(service===2?1:0)+(guest?1:0);moves=[];let prev=-1;
 for(let j=0;j<count;j++){
  let start=(j===0||j%3===2)?order.indexOf(ids[j%ids.slice(0,marked.size).length]):Math.floor(rng()*order.length);
  const dir=rng()<.5?-1:1,other=(start+dir+order.length)%order.length;
  const feint=(guest||level>=2)&&j===1&&service!==0,carousel=(guest||level>=3)&&j===count-2&&!feint;
  const pairs=[];if(carousel){const before=order.slice();for(let k=0;k<order.length;k++){let dest=(k+dir+order.length)%order.length;pairs.push({id:before[k],from:k,to:dest});order[dest]=before[k];}}
  else{const first=order[start],second=order[other];pairs.push({id:first,from:start,to:other},{id:second,from:other,to:start});if(!feint){order[start]=second;order[other]=first;}}
  moves.push({pairs,feint,carousel,duration:(level===0?1.42:Math.max(.86,1.30-.055*level))*(carousel?1.49:1)*(feint?.95:1)});
 }
 moveIndex=0;picked=-1;clue=null;cheer=0;flashes=[];noticeTime=0;fresh=0;slowTime=0;usedBrake=false;nightScarf=(service%2===1)!==((seed%2)===0);
}
function setState(next){state=next;age=0;updateUI();}
function setup(n=unlocked()){level=clip(n,0,unlocked());service=0;seed=newSeed();tries=3;faults=assists=streak=0;guest=false;buildService();view.rebuild();setState('cover');}
function start(n=unlocked(),resume=false,special=false){
 audio.wake();memory=null;guest=special&&profile.stamps[5]>0;const b=resume&&validMark(profile.bookmark)?profile.bookmark:null;
 level=b?b.level:guest?(level+1+Math.floor(Math.random()*5))%6:clip(n,0,unlocked());service=b?b.service:0;seed=b?b.seed:newSeed();
 tries=b?b.tries:3;faults=b?(b.faults||0):0;assists=b?(b.assists||0):0;streak=b?(b.streak||0):0;
 live=true;sdk?.prepare();sdk?.start();buildService();view.rebuild();setState('peek');
 if(b?.phase==='hunt'){
  for(const m of moves)for(const p of m.pairs)cars[p.id].slot=m.feint?p.from:p.to;
  beginHunt();usedBrake=b.usedBrake===true;
  const ids=new Set(Array.isArray(b.inspected)?b.inspected:[]);
  for(const c of cars){if(ids.has(c.id)){c.checked=true;c.caught=isTarget(c);c.open=1;if(c.caught)fresh++;}}
  if(targets().every(c=>c.caught)){setState('served');}
 }
 commit();updateUI();audio.signal('welcome');
}
function hide(){if(state!=='peek')return;audio.wake();audio.signal('hide');setState('hide');}
function beginHunt(){
 for(const car of cars){car.x=slots[car.slot][0];car.z=slots[car.slot][1];car.spin=0;}
 setState('hunt');say(guest?(nightScarf?'Find the rose scarf.':'Find the green scarf.'):targets().length===2?'Find both foxes.':'Where is the fox?',1.4);
}
function motion(m,u){
 const t=ease(u),phase=m.feint?Math.sin(Math.PI*t)*.43:t;
 for(const q of m.pairs){
  const car=cars[q.id],[x0,z0]=slots[q.from],[x1,z1]=slots[q.to],dx=x1-x0,dz=z1-z0,d=Math.hypot(dx,dz);
  const arc=m.carousel?.36:.96,offset=Math.sin(Math.PI*phase)*arc;
  car.x=lerp(x0,x1,phase)+dz/d*offset;car.z=lerp(z0,z1,phase)-dx/d*offset;car.spin=Math.sin(Math.PI*phase)*.093*(q.from<q.to?1:-1);
 }
}
// Port of ShowSpare1 in SnabbSpelare/prophunt: active hider, cooldown,
// and choose a visible/audio taunt different from the previous taunt.
function tell(car,manual){
 if(state!=='hunt'||!car.fox||car.caught||time<car.lastTell+2)return false;
 const kinds=[0,1,2].filter(x=>x!==car.lastKind);car.lastKind=kinds[Math.floor(Math.random()*kinds.length)];car.lastTell=time;car.wiggle=1;car.kind=car.lastKind;
  if(manual){assists++;say(['A little sneeze…','Listen for a giggle…','A tiny whisper…'][car.kind]);}
 audio.tell(car.kind);return true;
}
function listen(){
 if(state!=='hunt')return;const h=targets().filter(c=>!c.caught).sort((a,b)=>a.lastTell-b.lastTell)[0];
 if(h&&tell(h,true))commit();
}
function brake(){
 if(usedBrake||(!guest&&level<2)||!['beat','shuffle'].includes(state))return;
 usedBrake=true;slowTime=1.55;audio.signal('brake');updateUI();
}
function pick(id){
 if(state!=='hunt'||!Number.isInteger(id))return;const car=cars[id];if(!car||car.checked)return;
 audio.wake();car.checked=true;picked=id;opinion=isTarget(car)?1:-1;cheer=1;
 if(isTarget(car)){car.caught=true;streak++;fresh++;profile.bestStreak=Math.max(profile.bestStreak,streak);audio.signal('fox');confetti(car);}
 // Adapted from EntityTakeDamage in Prop Hunt: an incorrect prop costs
 // the hunter a finite resource, and running out ends the hunt.
 else{tries--;faults++;streak=0;audio.signal('cake');}
 setState('lift');
 if(tries>0&&!targets().every(c=>c.caught))commit();
}
function confetti(car){for(let i=0;i<19;i++){const a=i*2.399,r=.51+Math.random()*.85;
 flashes.push({x:car.x,y:1.36,z:car.z,vx:Math.cos(a)*r,vz:Math.sin(a)*r,vy:1.24+Math.random()*2.2,life:.85+Math.random()*.45,rot:a,color:[0xffbd67,0xf18080,0x98cebc,0xffdf9c][i%4]});}}
function completeStop(won){
 live=false;award=won?Math.max(1,3-(faults?1:0)-(assists||faults>1?1:0)):0;
 if(won&&!guest)profile.stamps[level]=Math.max(profile.stamps[level],award);
 commit(true);sdk?.end();audio.signal(won?'finish':'retry');setState(won?'win':'lose');
}
function advance(){
 if(state!=='served')return;if(service===2){completeStop(true);return;}
 service++;buildService();view.populate();setState('peek');commit();audio.signal('welcome');
}
function pause(){if(!live||['pause','book'].includes(state))return;previous=state;memory=age;setState('pause');}
function unpause(){if(state!=='pause')return;state=previous;age=memory||0;updateUI();}
function leave(){if(live){live=false;sdk?.end();}setup(level);}
function tick(dt){
 if(['pause','book','win','lose'].includes(state))return;
 time+=dt;age+=dt*(state==='shuffle'&&slowTime>0?.34:1);slowTime=Math.max(0,slowTime-dt);cheer=Math.max(0,cheer-dt*.66);
 if(noticeTime>0){noticeTime-=dt;if(noticeTime<=0)updateNotice();}
 for(const f of flashes){f.life-=dt;f.x+=f.vx*dt;f.y+=f.vy*dt;f.z+=f.vz*dt;f.vy-=4.6*dt;f.rot+=dt*4;}
 flashes=flashes.filter(f=>f.life>0);
 for(const c of cars){c.wiggle=Math.max(0,c.wiggle-dt*1.19);
  let lift=c.checked?1:0;if(state==='cover'||state==='peek')lift=c.fox?1:0;
  c.open=lerp(c.open,lift,1-Math.exp(-dt*(state==='hide'?9:7)));
 }
 if(state==='hide'&&age>.58){setState('shuffle');audio.signal('roll');}
 else if(state==='shuffle'){
  const m=moves[moveIndex];motion(m,clip(age/m.duration,0,1));
  if(age>=m.duration){for(const p of m.pairs)cars[p.id].slot=m.feint?p.from:p.to;
   moveIndex++;if(moveIndex>=moves.length)beginHunt();else{setState('beat');}}
 }else if(state==='beat'&&age>.18){setState('shuffle');audio.signal('roll');}
 else if(state==='hunt'&&age>7.7){const h=targets().find(c=>!c.caught);if(h&&time-h.lastTell>5.8)tell(h,false);}
 else if(state==='lift'&&age>1.72){if(tries<=0)completeStop(false);else if(targets().every(c=>c.caught)){if(service===2)completeStop(true);else{setState('served');commit();}}else setState('hunt');}
}

