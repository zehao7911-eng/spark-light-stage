function furnish(o,stop){
 const deep=0x254c51,oak=0x7c4c36,pale=0xe8c494,metal=0xbd9059;
 // An arched barrel ceiling, its seams and a scalloped luggage rack.
 cube(o,deep,0,5.52,-6.8,14.1,3.34,.42);
 for(let j=-5;j<=5;j++){
  const x=j*1.015;cube(o,j%2?0x3e6563:0x466c66,x,5.53,-6.50,.96,3.52,.10);
  cube(o,metal,x+.42,5.53,-6.428,.025,3.49,.026);
 }
 for(const y of [4.51,4.73,5.62]){
  cube(o,oak,0,y,-5.68,11.5,.16,.47);cube(o,metal,0,y+.042,-5.424,11.5,.037,.035);
 }
 for(const s of [-1,1]){
  for(let j=0;j<2;j++){const x=s*(2.17+j*1.18),y=4.38,z=-5.25;
   cube(o,j?0x866152:0x6d827a,x,y,z,.98,.42,.49);for(const k of [-1,1])cube(o,0xc59964,x+k*.30,y+.006,z+.013,.073,.43,.51);
   rod(o,P.choc,[x-.12,y+.255,z],[x+.12,y+.255,z],.027);for(const k of [-1,1])rod(o,P.choc,[x+k*.12,y+.212,z],[x+k*.12,y+.255,z],.021);
  }
 }
 // Enamel station clock with minute ticks and separate hands.
 const clock=g(o,.1,4.26,-4.90);egg(clock,oak,0,0,0,.43,.43,.083);egg(clock,pale,0,0,.065,.377,.377,.04);ring(clock,metal,0,0,.092,.362,.021);
 for(let j=0;j<12;j++){const a=j*Math.PI/6;rod(clock,deep,[.272*Math.sin(a),.272*Math.cos(a),.112],[.330*Math.sin(a),.330*Math.cos(a),.112],j%3?.010:.019);}
 rod(clock,P.choc,[0,0,.122],[.137,.132,.122],.019);rod(clock,P.choc,[0,0,.125],[-.20,.13,.125],.014);egg(clock,metal,0,0,.134,.03,.031,.016);
 const secondHand=g(clock,0,0,.141);rod(secondHand,P.berry,[0,-.056,0],[0,.29,0],.007);o.userData.secondHand=secondHand;
 // A silver sink, folded tea towels, recipe spike and stacked cups beside the cook.
 for(const side of [-1,1]){
  const x=side*2.82,z=-3.03;cube(o,oak,x,.47,z,1.37,.32,.78);cube(o,0xd5b795,x,.66,z,1.41,.080,.81);
  for(let j=0;j<(side>0?3:2);j++){
   const y=.747+j*.072;turned(o,P.milk,x-.13,y,z,[[.03,0],[.308,.007],[.34,.043],[.37,.071],[.36,.087],[.30,.058],[.03,.054]],.83);
   ring(o,stop.paint,x-.13,y+.078,z,.337,.009,Math.PI/2);
  }
  if(side===1){
   turned(o,0xe6c19b,x+.27,.74,z+.086,[[.07,0],[.125,.014],[.153,.12],[.15,.20],[.125,.207],[.122,.18],[.097,.07]],.9);
   ring(o,0xd8aa7a,x+.422,.858,z+.079,.071,.021);egg(o,0x5c4033,x+.27,.927,z+.086,.117,.011,.102);
  }else{for(let k=0;k<2;k++){cube(o,k?0xe5c2a4:0xc37c67,x+.30,.75+k*.072,z+.09,.44,.074,.39,0,.06,0);cube(o,0x7f9d87,x+.23,.79+k*.072,z+.08,.033,.009,.37);}}
 }
 // A striped stitched edge and small maker's marks on the green cutting mat.
 for(const s of [-1,1])for(let j=0;j<24;j++){
  let z=-2.17+j*.278;cube(o,0xa0b196,s*3.50,.802,z,.020,.007,.103);
 }
 for(const x of [-3.32,3.32])for(const z of [-2.07,4.03]){
  ring(o,0xb2b28a,x,.806,z,.117,.010,Math.PI/2);
  for(let j=0;j<4;j++){let a=j*Math.PI/2;egg(o,0xb1b48e,x+Math.cos(a)*.088,.805,z+Math.sin(a)*.088,.073,.005,.035,0,-a);}
 }
 // Floor extension and facing booths give the cutaway a foreground and scale.
 cube(o,deep,0,-1.0,8.2,10.9,.94,5.4);
 for(let row=0;row<6;row++)for(let j=-6;j<=6;j++)cube(o,(row+j)%2?0xc7ad87:0x809a8f,j*.81,-.505,7.06+row*.78,.80,.051,.77);
 for(const s of [-1,1]){
  const x=s*3.74,z=6.43;cube(o,oak,x,-.18,z,2.9,.54,1.33);
  cube(o,0xa86050,x,.137,z,2.90,.23,1.19);cube(o,0x894e45,x,.55,z+.48,2.91,1.05,.26);
  for(let j=0;j<5;j++){egg(o,0xb57160,x+(j-2)*.565,.55,z+.61,.30,.45,.10);egg(o,metal,x+(j-2)*.565,.56,z+.704,.031,.034,.019);}
  cube(o,metal,x,1.04,z+.51,2.97,.063,.28);
 }
 // Brass carriage rail at the open side. 
 for(let j=-4;j<=4;j++){const x=j*1.16;rod(o,metal,[x,-.55,9.24],[x,.36,9.24],.047);egg(o,pale,x,.39,9.24,.068,.069,.067);}
 rod(o,metal,[-5.05,.34,9.24],[5.05,.34,9.24],.042);
}
function passenger(species){
 const o=g(),body=g(o),head=g(body,0,.77,0),paper=g(body,0,.38,-.22),pal=species?0xe6c693:0xb3b1a4,fur=species?0xbb8e5c:0x868f89;
 silk(body,species?0x587b7a:0x965d63,0,.31,0,.32,.39,.285);
 silk(head,pal,0,0,0,.262,.281,.242);
 for(const s of [-1,1]){egg(head,fur,s*.171,.254,0,species?.116:.082,species?.102:.242,.085,0,0,-s*.16);
  egg(head,pal,s*.17,.28,-.027,species?.068:.039,species?.051:.162,.056,0,0,-s*.16);
  egg(head,P.choc,s*.118,.034,-.209,.032,.041,.017);}
 egg(head,pal,0,-.097,-.192,.122,.088,.111);egg(head,P.choc,0,-.075,-.293,.043,.035,.028);
 cube(paper,0xe8d9bb,-.15,.01,.017,.31,.39,.026,-.19,-.18);cube(paper,0xf1e4c9,.154,.01,.023,.31,.39,.026,-.19,.18);
 for(let j=0;j<3;j++){for(const s of [-1,1])cube(paper,0x9c9b89,s*.143,.08-j*.065,-.018,.21,.018,.012,-.19,s*.15);}
 for(const s of [-1,1])egg(body,fur,s*.25,.33,-.20,.088,.091,.084);
 finish(o);o.userData={head,paper};return o;
}
function plateMetal(lid){
 const mat=plateMetal.material||(plateMetal.material=new THREE.MeshStandardMaterial({vertexColors:true,metalness:.53,roughness:.28,envMapIntensity:.87}));
 lid.traverse(a=>{if(a.isMesh)a.material=mat;});
}
function lightingMap(renderer,scene){
 // An equirectangular card with two window softboxes and a narrow brass bounce.
 const c=document.createElement('canvas');c.width=256;c.height=128;const p=c.getContext('2d'),v=p.createLinearGradient(0,0,0,128);
 v.addColorStop(0,'#adc2bd');v.addColorStop(.41,'#f8ecd3');v.addColorStop(.50,'#58736d');v.addColorStop(.72,'#aa9376');v.addColorStop(1,'#5c4637');p.fillStyle=v;p.fillRect(0,0,256,128);
 p.fillStyle='#fff4da';p.fillRect(28,19,39,47);p.fillRect(86,29,13,30);p.fillStyle='#ffe9af';p.fillRect(173,43,30,9);p.fillStyle='#38554f';p.fillRect(133,38,11,40);
 const t=new THREE.CanvasTexture(c);t.mapping=THREE.EquirectangularReflectionMapping;t.encoding=THREE.sRGBEncoding;
 const pm=new THREE.PMREMGenerator(renderer),target=pm.fromEquirectangular(t);pm.dispose();t.dispose();return target;
}
