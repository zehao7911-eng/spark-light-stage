/* Small batch sculptor. Static parts share one draw per joint, with vertex colours. */
const Craft = (() => {
 const material = new THREE.MeshStandardMaterial({vertexColors:true,roughness:.78,metalness:.065});
 const store=new Map(), build=new WeakMap();
 const geom=(name,create)=>{if(!store.has(name))store.set(name,create());return store.get(name);};
 const box=geom('box',()=>new THREE.BoxGeometry(1,1,1));
 const oval=geom('oval',()=>new THREE.SphereGeometry(1,12,8));
 const bead=geom('bead',()=>new THREE.SphereGeometry(1,9,6));
 const ball=geom('ball',()=>new THREE.SphereGeometry(1,20,16));
 const matrix=new THREE.Matrix4(),quaternion=new THREE.Quaternion(),pos=new THREE.Vector3(),size=new THREE.Vector3(),euler=new THREE.Euler(),normalMatrix=new THREE.Matrix3(),v=new THREE.Vector3(),n=new THREE.Vector3();
 const shades=new Map();function color(hex){if(!shades.has(hex))shades.set(hex,new THREE.Color(hex).convertSRGBToLinear());return shades.get(hex);}
 function g(parent,x=0,y=0,z=0){const o=new THREE.Group();o.position.set(x,y,z);if(parent)parent.add(o);return o;}
 function part(o,geometry,c,x,y,z,sx=1,sy=1,sz=1,rx=0,ry=0,rz=0){
  if(!build.has(o))build.set(o,{p:[],n:[],c:[],i:[]});
  const b=build.get(o),offset=b.p.length/3;
  matrix.compose(pos.set(x,y,z),quaternion.setFromEuler(euler.set(rx,ry,rz)),size.set(sx,sy,sz));normalMatrix.getNormalMatrix(matrix);
  const P=geometry.attributes.position,N=geometry.attributes.normal,C=color(c);
  for(let j=0;j<P.count;j++){v.fromBufferAttribute(P,j).applyMatrix4(matrix);n.fromBufferAttribute(N,j).applyMatrix3(normalMatrix).normalize();b.p.push(v.x,v.y,v.z);b.n.push(n.x,n.y,n.z);b.c.push(C.r,C.g,C.b);}
  const idx=geometry.index;if(idx){for(let j=0;j<idx.count;j++)b.i.push(offset+idx.getX(j));}else for(let j=0;j<P.count;j++)b.i.push(offset+j);
 }
 function cube(o,c,x,y,z,w,h,d,rx=0,ry=0,rz=0){part(o,box,c,x,y,z,w,h,d,rx,ry,rz);}
 function egg(o,c,x,y,z,w,h,d,rx=0,ry=0,rz=0){part(o,Math.max(w,h,d)<=.10?bead:oval,c,x,y,z,w,h,d,rx,ry,rz);}
 function silk(o,c,x,y,z,w,h,d,rx=0,ry=0,rz=0){part(o,ball,c,x,y,z,w,h,d,rx,ry,rz);}
 function ring(o,c,x,y,z,r,t,rx=0,ry=0,rz=0,arc=Math.PI*2){
  const shape=geom('t'+[r,t,arc].join(),()=>new THREE.TorusGeometry(r,t,7,Math.max(14,Math.round(36*arc/(2*Math.PI))),arc));
  part(o,shape,c,x,y,z,1,1,1,rx,ry,rz);
 }
 function turned(o,c,x,y,z,points,depth=1){
  const k='l'+JSON.stringify(points);
  const shape=geom(k,()=>new THREE.LatheGeometry(points.map(([r,h])=>new THREE.Vector2(Math.max(r,.001),h)),24));
  part(o,shape,c,x,y,z,1,1,depth);
 }
 function rod(o,c,a,b,r,end=r){
  const A=new THREE.Vector3(...a),B=new THREE.Vector3(...b),dir=B.clone().sub(A),mid=A.add(B).multiplyScalar(.5);
  const rot=new THREE.Euler().setFromQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),dir.clone().normalize()));
  const key='rod'+end/r;part(o,geom(key,()=>new THREE.CylinderGeometry(end/r,1,1,10)),c,mid.x,mid.y,mid.z,r,dir.length(),r,rot.x,rot.y,rot.z);
 }
 function poly(o,c,x,y,z,points,depth=.04,rx=0,ry=0,rz=0){
  const key='poly'+JSON.stringify([points,depth]);const shape=geom(key,()=>{let s=new THREE.Shape();points.forEach(([a,b],i)=>i?s.lineTo(a,b):s.moveTo(a,b));s.closePath();return new THREE.ExtrudeGeometry(s,{depth,bevelEnabled:false});});part(o,shape,c,x,y,z,1,1,1,rx,ry,rz);
 }
 function finish(o){
  o.traverse(obj=>{const b=build.get(obj);if(!b)return;const geo=new THREE.BufferGeometry();for(const [key,arr] of [['position',b.p],['normal',b.n],['color',b.c]])geo.setAttribute(key,new THREE.Float32BufferAttribute(arr,3));geo.setIndex(b.i);geo.computeBoundingSphere();const mesh=new THREE.Mesh(geo,material);mesh.castShadow=mesh.receiveShadow=true;obj.add(mesh);build.delete(obj);});return o;
 }
 function remove(o){o.removeFromParent();o.traverse(a=>{if(a.isMesh)a.geometry.dispose();});}
 return{g,part,cube,egg,silk,ring,turned,rod,poly,finish,remove};
})();
const {g,cube,egg,silk,ring,turned,rod,poly,finish}=Craft;
const ink=0x222438,gold=0xe8a641,cream=0xffe8ac,rose=0xdc364b,jade=0x087b79,brass=0xa46937;

