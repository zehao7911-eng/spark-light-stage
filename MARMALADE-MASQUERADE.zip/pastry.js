const stops=[
 {name:'Orchard Halt',dessert:'Citrus tart',sky:0xffdbaa,hill:0x8ba480,paint:0x417f76,fruit:0xe59a40,count:3,swaps:2},
 {name:'Rosewater Pier',dessert:'Berry charlotte',sky:0xf3cfbf,hill:0x83aeaa,paint:0xb36673,fruit:0xb3435b,count:3,swaps:3},
 {name:'Pistachio Pass',dessert:'Pistachio choux',sky:0xbddee0,hill:0x6b9690,paint:0x56877d,fruit:0x91ae68,count:4,swaps:3},
 {name:'Cocoa Crossing',dessert:'Chocolate opera',sky:0xf0c399,hill:0xa48082,paint:0x855864,fruit:0x744638,count:4,swaps:4},
 {name:'Plum Lanterns',dessert:'Plum millefeuille',sky:0xabacc9,hill:0x74759b,paint:0x655d84,fruit:0x9e5d83,count:5,swaps:4},
 {name:'Grand Terminus',dessert:'Celebration cake',sky:0xefba93,hill:0xc18d88,paint:0x397977,fruit:0xcd5470,count:5,swaps:5}
];
function pastry(n){
 const o=g(),honey=0xd89a52,crust=0xc8874b,ice=0xffe4b5,red=0xc94c61;
 if(n===0){
  turned(o,crust,0,0,0,[[.06,0],[.36,.01],[.424,.10],[.44,.21],[.395,.245],[.347,.19],[.02,.17]]);
  for(let i=0;i<20;i++){let a=i*Math.PI/10;egg(o,honey,Math.cos(a)*.405,.145,Math.sin(a)*.405,.053,.074,.052,0,a);}
  egg(o,0xedb649,0,.192,0,.393,.081,.393);
  for(let j=0;j<8;j++){let a=j*Math.PI/4;let slice=g(o,Math.sin(a)*.198,.252,Math.cos(a)*.198);slice.rotation.y=a;
   poly(slice,0xffdeb1,0,0,0,[[-.113,0],[.113,0],[.08,.168],[0,.215],[-.08,.168]],.020,-Math.PI/2);
   poly(slice,0xe99a39,0,.010,-.008,[[-.087,0],[.086,0],[.058,.141],[0,.172],[-.061,.13]],.013,-Math.PI/2);
  }
 }else if(n===1){
  turned(o,red,0,.016,0,[[0,0],[.39,0],[.41,.075],[.41,.35],[.37,.41],[0,.41]]);
  for(let i=0;i<15;i++){let a=i*2*Math.PI/15;egg(o,0xe3b381,Math.sin(a)*.38,.215,Math.cos(a)*.38,.081,.228,.084,0,a);}
  ring(o,0xc34b67,0,.16,0,.418,.026,Math.PI/2);egg(o,ice,0,.395,0,.367,.061,.367);
  for(let i=0;i<8;i++){let a=i*Math.PI/4;egg(o,red,Math.sin(a)*.24,.467,Math.cos(a)*.24,.09,.104,.093);egg(o,0xf19e8b,Math.sin(a)*.24-.025,.505,Math.cos(a)*.24+.063,.025,.023,.013);}
 }else if(n===2){
  silk(o,crust,0,.156,0,.38,.18,.36);
  for(let j=0;j<10;j++){let a=j*Math.PI/5;egg(o,ice,Math.cos(a)*.262,.258,Math.sin(a)*.24,.126,.103,.111);}
  silk(o,honey,0,.327,0,.376,.165,.351);silk(o,0x91ad73,0,.377,0,.359,.135,.332);
  for(let j=0;j<16;j++){let a=j*2.4,r=.06+(j%4)*.068;egg(o,j%2?0xd1cb85:0x7b9558,Math.cos(a)*r,.497-r*.22,Math.sin(a)*r,.033,.018,.052,0,a);}
 }else if(n===3||n===4){
  const jam=n===3?0x643a34:0x9a5370;
  for(let j=0;j<7;j++){let y=.033+j*.059;cube(o,j%2?jam:n===3?0xc29a71:0xf4c77e,0,y,0,.68,.058,.55);}
  cube(o,n===3?0x542f2d:ice,0,.445,0,.71,.061,.57);
  for(let j=0;j<5;j++)rod(o,n===3?0xbe8a62:jam,[-.31,.48,-.215+j*.102],[.31,.48,-.19+j*.102],.014);
  for(let j=0;j<3;j++)egg(o,n===3?0x865634:0x8d4c73,-.14+j*.14,.52,-.04,.067,.058,.075,0,j);
 }else{
  turned(o,ice,0,.01,0,[[0,0],[.40,0],[.42,.04],[.42,.32],[.39,.35],[.27,.35],[.27,.57],[.22,.60],[0,.60]]);
  for(let j=0;j<14;j++){let a=j*Math.PI/7;egg(o,j%2?0xeaad9e:ice,Math.sin(a)*.39,.30,Math.cos(a)*.39,.076,.067,.071);}
  for(let j=0;j<6;j++){let a=j*Math.PI/3;egg(o,red,Math.sin(a)*.186,.64,Math.cos(a)*.186,.060,.078,.059);}
 }
 for(let s of [-1,1])egg(o,0x73946c,s*.046,n===0?.309:n===1?.49:n===2?.53:n===5?.71:.53,-.04,.088,.024,.043,0,s*.42,s*.24);
 return finish(o);
}
function servingCart(tint){
 const o=g(),lid=g(o),bottom=g(o);
 turned(bottom,0xa7774e,0,-.10,0,[[0,0],[.59,0],[.69,.045],[.71,.112],[.67,.145],[0,.15]]);
 turned(bottom,P.milk,0,.033,0,[[0,0],[.54,.003],[.67,.027],[.695,.059],[.67,.083],[.55,.062],[0,.058]]);
 ring(bottom,gold,0,.095,0,.658,.009,Math.PI/2);
 for(const s of [-1,1])for(const t of [-1,1]){egg(bottom,P.choc,s*.37,-.132,t*.29,.076,.08,.065);egg(bottom,brass,s*.39,-.130,t*.33,.050,.052,.027);}
 const tintMid=tint,light=0xd7dfcd,shade=0x6b9790;
 turned(lid,tintMid,0,.095,0,[[0,.008],[.55,.008],[.617,.035],[.62,.083],[.587,.122],[.571,.238],[.529,.376],[.451,.505],[.339,.603],[.201,.673],[.04,.696],[0,.70]]);
 turned(lid,P.butter,0,.105,0,[[.616,.034],[.629,.047],[.628,.071],[.61,.082]]);
 for(let j=0;j<16;j++){let a=j*Math.PI/8;
  for(const [r0,y0,r1,y1] of [[.22,.757,.341,.69],[.341,.69,.448,.591],[.448,.591,.529,.460],[.529,.46,.57,.326]]){
   rod(lid,j%2?light:shade,[Math.sin(a)*r0,y0,Math.cos(a)*r0],[Math.sin(a)*r1,y1,Math.cos(a)*r1],.008,.009);
  }
 }
 turned(lid,brass,0,.77,0,[[.105,0],[.112,.024],[.051,.057],[.045,.115],[.085,.13]]);
 egg(lid,P.butter,0,.915,0,.087,.076,.087);egg(lid,0xffe3a0,-.017,.95,.021,.048,.037,.047);
 finish(o);o.userData={lid,bottom};return o;
}

