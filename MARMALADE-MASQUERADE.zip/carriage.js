/* Cross-section of a 1930s dessert car, seen from its open long side. */
function carriage(stop,night=false){
 const o=g(),dark=0x344d4e,frame=0x9c6647,trim=0xd5ab70,wood=0x854e3a,c=stop.paint,iv=P.milk;
 const scenery=[];
 cube(o,0x845748,0,-1.22,.05,10.8,1.55,13.4);
 for(let j=0;j<18;j++)for(let i=0;i<13;i++){
  const x=(i-6)*.81,z=-6.58+j*.79;cube(o,(i+j)%2?0xdfc5a1:0x799890,x,-.414,z,.801,.051,.78);
 }
 // Back panelling and a triptych window framed in walnut and brass.
 cube(o,c,0,2.0,-5.66,10.55,4.98,.29);
 for(let j=-4;j<=4;j++){cube(o,0x586f68,j*1.02,.29,-5.43,.88,1.15,.08);cube(o,c,j*1.02,.31,-5.37,.74,.98,.05);}
 cube(o,wood,0,1.04,-5.33,10.53,.19,.54);cube(o,trim,0,1.14,-5.19,10.53,.045,.34);
 for(let j=-1;j<=1;j++){
  const x=j*2.76;cube(o,wood,x,2.63,-5.45,2.79,2.74,.29);cube(o,trim,x,2.65,-5.273,2.61,2.55,.07);
  cube(o,night?0x35496c:stop.sky,x,2.65,-5.225,2.51,2.44,.054);
  if(night){for(let k=0;k<9;k++){
   const sx=x-1.02+(k*.674)%2.05,sy=2.68+(k*.349)%1.00;
   egg(o,k%3?0xc5d9d3:0xffda8f,sx,sy,-5.177,.014+(k%3)*.006,.017+(k%3)*.008,.008);
  }}
  const h=night?0x536680:stop.hill;
  poly(o,h,x,1.56,-5.17,[[-1.255,0],[-1.255,.59],[-.90,.88],[-.70,.69],[-.28,1.09],[.15,.65],[.58,.81],[.99,.55],[1.255,.71],[1.255,0]],.016);
  poly(o,night?0x3d5b68:0x73978b,x,1.48,-5.13,[[-1.255,0],[-1.255,.33],[-.82,.51],[-.5,.31],[.1,.63],[.60,.35],[1.255,.49],[1.255,0]],.012);
  for(let i=0;i<5;i++){let xx=x-1.00+i*.48,yy=1.51+Math.sin(i+j)*.09;
   if(stop===stops[4]||stop===stops[5]){cube(o,0xab8277,xx,yy+.16,-5.08,.32,.32,.07);poly(o,0x826b6d,xx,yy+.32,-5.05,[[-.19,0],[0,.17],[.19,0]],.035);cube(o,iv,xx,yy+.18,-5.035,.053,.082,.018);}
   else {rod(o,0x84785b,[xx,yy,-5.07],[xx,yy+.25,-5.07],.023);egg(o,i%2?0x678771:0x829a73,xx,yy+.28,-5.07,.139,.22,.059);}
  }
  if(j===1){egg(o,night?0xffedc4:0xffe3a2,x+.53,3.33,-5.138,.33,.33,.032);if(night)egg(o,0x35496c,x+.63,3.40,-5.095,.265,.27,.014);}
  for(let k=0;k<3;k++){let xx=x-.9+k*.67;egg(o,iv,xx,3.46+k%2*.23,-5.13,.19,.038,.016);}
  // Tiny moving silhouettes remain inside their own window pane.
  const moving=g(o,x,2.90+(j+1)*.11,-5.04);
  if(j===0){
   const basket=g(moving,0,-.09,0);cube(basket,frame,0,-.01,0,.12,.088,.04);
   for(const s of [-1,1])rod(basket,wood,[s*.047,.024,0],[s*.096,.17,0],.006);
   egg(moving,stop.fruit,0,.17,0,.132,.171,.048);egg(moving,iv,-.027,.17,.032,.030,.15,.012);
  }else{
   for(const s of [-1,1]){poly(moving,dark,s*.016,0,0,[[0,0],[s*.079,.054],[s*.183,.078],[s*.119,.018],[s*.035,-.016]],.013);}
  }
  scenery.push({moving,x,j,height:moving.position.y});
  for(const s of [-1,1]){cube(o,frame,x+s*1.31,2.65,-5.10,.085,2.67,.19);cube(o,trim,x+s*1.30,2.65,-5.005,.022,2.59,.018);}
  cube(o,wood,x,3.97,-5.08,2.75,.136,.24);cube(o,wood,x,1.36,-5.05,2.80,.14,.32);
  for(let k=0;k<7;k++){let xx=x-1.15+k*.382;egg(o,k%2?iv:stop.fruit,xx,3.80,-5.00,.207,.15,.069);}
 }
 for(const s of [-1,1]){
  cube(o,c,s*5.01,1.61,-3.80,.26,4.25,3.85);
  for(let j=0;j<4;j++)cube(o,trim,s*4.84,1.52,-5.22+j*.92,.041,3.55,.044);
  cube(o,wood,s*5.01,3.73,-3.81,.41,.22,3.97);
  const x=s*3.42,z=-4.43;
  cube(o,wood,x,.19,z,1.68,1.16,1.06);cube(o,0xae7b55,x,.79,z,1.78,.13,1.16);
  for(const k of [-1,1]){cube(o,c,x+k*.37,.27,z+.54,.65,.82,.06);egg(o,trim,x+k*.26,.37,z+.59,.062,.049,.035);}
  for(let j=0;j<3;j++){const xx=x+(j-1)*.41,zz=z+.10*(j%2);
   turned(o,[0xba7962,0x9bac91,0xd3aa77][j],xx,.86,zz,[[0,0],[.149,.015],[.17,.055],[.16,.47],[.12,.52],[.1,.56],[0,.57]]);
   turned(o,brass,xx,1.41,zz,[[.115,0],[.12,.04],[.09,.07],[.01,.072]]);
   cube(o,iv,xx,1.13,zz+.159,.135,.17,.021);cube(o,frame,xx,1.15,zz+.173,.085,.017,.009);cube(o,frame,xx,1.11,zz+.173,.069,.013,.009);
  }
 }
 // Display island, rim, drawers and fluted brass supports.
 cube(o,0x314f51,0,.06,.99,8.78,.94,7.89);
 for(let row=0;row<2;row++)for(let j=-2;j<=2;j++){let x=j*1.63,y=-.145+row*.41,z=4.965;
  cube(o,wood,x,y,z,1.59,.369,.10);cube(o,0x98694e,x,y,z+.061,1.43,.272,.03);
  rod(o,brass,[x-.17,y+.016,z+.10],[x+.17,y+.016,z+.10],.031);for(const s of [-1,1])egg(o,trim,x+s*.16,y+.015,z+.087,.042,.042,.042);
 }
 cube(o,frame,0,.54,.99,8.98,.155,8.04);cube(o,trim,0,.63,.99,9.05,.063,8.09);
 cube(o,0xe6cca6,0,.711,.99,9.1,.126,8.11);
 for(let i=0;i<5;i++){const x=(i-2)*1.65;for(let j=0;j<6;j++){
  let z=-2.05+j*1.21;const r=(Math.sin(3*i+7*j)+1)*.024+.013;
  egg(o,0xcab396,x+.22*Math.sin(j*3),.776,z,r*2,.002,r,0,i+j);
 }}
 // Woven runner underneath the rolling porcelain.
 cube(o,0x466f69,0,.784,1.0,7.59,.018,6.87);
 for(const x of [-3.68,-3.59,3.59,3.68])cube(o,0xd9b67f,x,.796,1.0,.024,.010,6.81);
 for(const z of [-2.32,4.32])for(let i=-9;i<=9;i++){
  let x=i*.372;poly(o,i%2?0xd8b88d:0x85a99b,x,.804,z,[[0,.07],[.09,0],[0,-.07],[-.09,0]],.008,-Math.PI/2);
 }
 for(const s of [-1,1]){cube(o,wood,s*4.34,-.62,4.71,.27,1.03,.28);turned(o,brass,s*4.34,-1.11,4.71,[[.14,0],[.16,.08],[.105,.19],[.11,.37]],1);}
 // Ceiling lamp and scalloped pastry shelf above the distant windows.
 for(const s of [-1,1]){let x=s*2.93,z=-4.12;
  rod(o,brass,[x,4.37,z],[x,3.82,z],.038);turned(o,0xc09966,x,3.66,z,[[.34,0],[.33,.065],[.12,.20],[.07,.235]]);
  silk(o,0xffdf9a,x,3.60,z,.234,.19,.234);
 }
 furnish(o,stop);o.userData.scenery=scenery;return finish(o);
}

