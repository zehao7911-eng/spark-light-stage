const view=(()=>{
 const main=$('#frame'),surface=$('#stage'),fx=$('#dust'),ctx=fx.getContext('2d');
 const scene=new THREE.Scene(),camera=new THREE.OrthographicCamera(-5,5,8,-8,.1,80),scratch=new THREE.Vector3();
 let guests=[],environment=null;let renderer=null,lite=null,room=null,chef=null,models=[],width=1,height=1,zoom=1,lookX=0,lookY=0,lookZ=0,angle=0,shadowClock=0,active=false,cache={},badges=[];
 const normalEye=[.05,12.9,17.8],normalTarget=[0,1.16,.13],table=1.045;
 try{renderer=new THREE.WebGLRenderer({canvas:surface,antialias:true,alpha:false,powerPreference:'high-performance'});renderer.outputEncoding=THREE.sRGBEncoding;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.02;
 renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.shadowMap.autoUpdate=false;}catch{const c=document.createElement('canvas');c.className='backup';surface.after(c);lite=c.getContext('2d');}
 scene.background=new THREE.Color(0x758985);
 if(renderer)environment=lightingMap(renderer,scene);const hemi=new THREE.HemisphereLight(0xffeed5,0x9e8882,.82);scene.add(hemi);
 const sun=new THREE.DirectionalLight(0xffe8bf,1.53);sun.position.set(-5.5,11,6.1);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);Object.assign(sun.shadow.camera,{left:-8,right:8,top:9,bottom:-8,near:.1,far:33});sun.shadow.normalBias=.026;sun.shadow.bias=-.0004;scene.add(sun);
 const rim=new THREE.DirectionalLight(0xb3d9da,.64);rim.position.set(4.1,4,-3);scene.add(rim);
 const fill=new THREE.DirectionalLight(0xffc39d,.22);fill.position.set(.7,3.1,5.9);scene.add(fill);
 const shade=document.createElement('canvas');shade.width=shade.height=48;const b=shade.getContext('2d'),grad=b.createRadialGradient(24,24,0,24,24,23);grad.addColorStop(0,'rgba(52,36,39,.54)');grad.addColorStop(.56,'rgba(52,36,39,.31)');grad.addColorStop(1,'rgba(52,36,39,0)');b.fillStyle=grad;b.fillRect(0,0,48,48);
 const sm=new THREE.MeshBasicMaterial({map:new THREE.CanvasTexture(shade),transparent:true,depthWrite:false}),sg=new THREE.PlaneGeometry(1,1);
 function stampMaterial(){return profile.rewards.like?0xffca54:profile.stamps.reduce((a,b)=>a+b,0)>=7?0xd79491:0xafc5ba;}
 function refreshCostume(){if(!active||!renderer)return;for(const m of models){if(m.fox&&!m.bonus&&profile.rewards.like){const pin=g(m.fox.userData.spine,-.12,.253,.28);egg(pin,gold,0,0,0,.058,.055,.018);finish(pin);m.bonus=true;}}}
 function clearCarts(){
  for(const m of models){if(m.shadow)m.root.remove(m.shadow);Craft.remove(m.root);}models=[];
  $('#picks').replaceChildren();badges=[];
 }
 function populate(){
  clearCarts();
  for(const c of cars){
   if(renderer){
    const root=g(scene),cart=servingCart(stampMaterial());root.add(cart);root.scale.setScalar(1.14);plateMetal(cart.userData.lid);if(environment)plateMetal.material.envMap=environment.texture;
    const m={root,cart,fox:null,sweet:null};if(c.fox){m.fox=foxModel(c.alt);dressFox(m.fox,profile.stamps.reduce((a,b)=>a+b,0),profile.rewards.like);m.bonus=!!profile.rewards.like;root.add(m.fox);}
    else{m.sweet=pastry(level);root.add(m.sweet);}
    const shadow=new THREE.Mesh(sg,sm);shadow.rotation.x=-Math.PI/2;shadow.scale.set(1.65,1.46,1);shadow.position.y=-.218;root.add(shadow);m.shadow=shadow;models.push(m);
   }
   const btn=document.createElement('button');btn.className='picker';btn.setAttribute('aria-label','Lift serving cover '+(c.id+1));btn.onclick=()=>pick(c.id);$('#picks').append(btn);badges.push(btn);
  }
  shadowClock=0;
 }
 function rebuild(){
  active=false;if(room)Craft.remove(room);if(chef)Craft.remove(chef);for(const guest of guests)Craft.remove(guest);guests=[];room=chef=null;zoom=1;lookX=lookY=lookZ=angle=0;
  if(renderer){room=carriage(stops[level],guest);chef=chefModel();scene.add(room,chef);chef.position.set(.1,-.32,-3.78);chef.scale.setScalar(1.49);for(const s of [-1,1]){let q=passenger(s>0);q.position.set(s*3.19,.21,6.16);q.rotation.y=s*.18;scene.add(q);guests.push(q);}}
  populate();active=true;resize();
 }
 function resize(){
  const r=main.getBoundingClientRect();width=Math.max(1,r.width);height=Math.max(1,r.height);const d=Math.min(devicePixelRatio||1,1.6);
  if(renderer){renderer.setPixelRatio(d);renderer.setSize(width,height,false);}
  if(lite){lite.canvas.width=Math.round(width*d);lite.canvas.height=Math.round(height*d);lite.setTransform(d,0,0,d,0,0);}
  fx.width=Math.round(width*d);fx.height=Math.round(height*d);ctx.setTransform(d,0,0,d,0,0);cam();
 }
 function cam(){const ar=width/height,hh=Math.max(4.46/ar,6.76);Object.assign(camera,{left:-hh*ar,right:hh*ar,top:hh,bottom:-hh,zoom});
  camera.position.set(normalEye[0]+lookX+angle*1.47,normalEye[1]+lookY-angle*3.8,normalEye[2]+lookZ);
  camera.lookAt(normalTarget[0]+lookX,normalTarget[1]+lookY,normalTarget[2]+lookZ);camera.updateProjectionMatrix();camera.updateMatrixWorld(true);}
 function project(x,y,z){scratch.set(x,y,z).project(camera);return{x:(scratch.x+1)*width*.5,y:(1-scratch.y)*height*.5};}
 function image(key){if(!cache[key]){let img=new Image();img.src=(typeof bakedArt!=='undefined'&&bakedArt[key])||'plates/'+key+'.webp';cache[key]=img;}return cache[key];}
 function sprite(k,x,y,w,h=w){const i=image(k);if(i.complete&&i.naturalWidth)lite.drawImage(i,x-w/2,y-h/2,w,h);}
 function liteDraw(){
  const c=lite,unit=width*zoom/(2*camera.right),pw=unit*8.92,ph=pw*16/9;
  c.fillStyle='#597570';c.fillRect(0,0,width,height);sprite((guest?'room-night-':'room-')+level,width/2,height/2,pw,ph);
  const cp=project(.1,1.60,-3.78);sprite(opinion<0&&cheer>.12?'chef-sigh':cheer>.12?'chef-cheer':'chef',cp.x,cp.y,unit*4.9);
  for(const car of cars.slice().sort((a,b)=>a.z-b.z)){
   const pt=project(car.x,table+.51,car.z),sw=unit*2.35*1.14;
   sprite('cart-'+(car.open>.77?'open':car.open>.4?'half':car.open>.14?'crack':'shut'),pt.x,pt.y-Math.sin(car.wiggle*Math.PI)*unit*.11,sw);
   if(car.open>.47){const f=project(car.x,table+(car.fox?.70:.37),car.z+.067),stamps=profile.stamps.reduce((a,b)=>a+b,0),costume=stamps>=8?'-glasses':stamps>=3?'-cap':'';sprite(car.fox?((car.alt?'fox-rose':'fox')+costume+(car.caught?['-happy','-cream','-note'][service]:'')):'sweet-'+level,f.x,f.y,unit*1.14*(car.fox?1.79:1.41));}
  }
 }
 function motionCamera(dt){
  const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches, cinematic=renderer&&!reduced;
  let n=1,x=0,y=0,z=0,a=0;if(cinematic&&state==='cover'){n=1.42;z=-.84;y=.17;a=.75;}
  if(cinematic&&state==='lift'&&picked>=0){const f=Math.sin(Math.PI*clip(age/1.38,0,1));n=1+f*.40;x=cars[picked].x*.62*f;z=cars[picked].z*.56*f;y=.069*f;a=.35*f;}
  if(cinematic&&state==='served'){n=1.16;x=cars[picked]?.x*.20||0;z=.16;a=.22;}
  const s=1-Math.exp(-dt*5.8);zoom=lerp(zoom,n,s);lookX=lerp(lookX,x,s);lookY=lerp(lookY,y,s);lookZ=lerp(lookZ,z,s);angle=lerp(angle,a,s);cam();
 }
 function updateButtons(){
  cars.forEach((car,i)=>{const b=badges[i];if(!b)return;const usable=state==='hunt'&&!car.checked;
   b.hidden=!usable;b.disabled=!usable;if(!usable)return;
   const pt=project(car.x,table+.43,car.z),td=project(car.x+.76,table+.43,car.z);
   const w=Math.max(44,(td.x-pt.x)*2.22),h=Math.max(43,w*.85);Object.assign(b.style,{left:(pt.x-w/2)+'px',top:(pt.y-h/2)+'px',width:w+'px',height:h+'px'});
  });
 }
 function draw(dt){
  if(!active)return;motionCamera(dt);
  if(renderer){
   chefPose(chef,time,cheer,opinion);
   room.userData.secondHand.rotation.z=-(Math.floor(time)+level*7)*Math.PI/30;
   if(picked>=0&&cheer>0){chef.userData.head.rotation.y+=cars[picked].x*.16*cheer;chef.userData.head.rotation.x+=cheer*.16;}
   for(const {moving,x,j,height:h} of room.userData.scenery){
    moving.position.x=x+.92*Math.sin(time*(j===0?.15:.26)+j*2);
    moving.position.y=h+.08*Math.sin(time*.9+j);
    moving.rotation.z=.069*Math.sin(time*(j===0?1.3:3.4)+j);
   }
   for(const [i,q] of guests.entries()){q.userData.head.rotation.y=.30*Math.sin(time*.69+i)+cheer*.4;q.userData.paper.rotation.x=.06*Math.sin(time*1.4+i)-cheer*.66;}
   for(const car of cars){
    const m=models[car.id],u=car.open,w=car.wiggle,wig=Math.sin((1-w)*Math.PI*7)*w;
    m.root.position.set(car.x,table+.012,car.z);m.cart.rotation.z=car.spin*.25;
    const lid=m.cart.userData.lid,ang=-u*1.96;lid.rotation.set(ang,0,wig*.102);
    lid.position.set(0,.62*(-Math.sin(ang))+(w>0?Math.sin((1-w)*Math.PI)*.064:0),-.62+.62*Math.cos(ang));
    if(m.fox){m.fox.visible=u>.20;m.fox.position.set(0,.112,0);m.fox.scale.set(.83,.83*(.28+.72*ease(u)),.83);
     foxPose(m.fox,time+car.id,car.caught?(.38+.46*Math.max(0,Math.sin(age*4))):0,w);
     const fd=m.fox.userData;fd.gags.forEach((q,i)=>q.visible=car.caught&&service===i);
     if(car.caught){if(service===0)fd.arms[1].rotation.x=-1.38+.22*Math.cos(age*7);
      if(service===1)fd.head.rotation.z+=.14*Math.sin(age*7);
      if(service===2){fd.spine.rotation.x=.25+.17*Math.sin(age*4);fd.arms[0].rotation.x=-1.6;}}
    }
    if(m.sweet){m.sweet.position.y=.112;m.sweet.visible=u>.18;}
   }
   shadowClock-=dt;if(shadowClock<=0){renderer.shadowMap.needsUpdate=true;shadowClock=.085;}
   renderer.render(scene,camera);
  }else if(lite)liteDraw();
  updateButtons();overlays();
 }
 function overlays(){
  ctx.clearRect(0,0,width,height);
  if(!matchMedia('(prefers-reduced-motion: reduce)').matches){
   // Two short whorls over the coffee cup curl above the saucer.
   const tea=project(3.09,.98,-2.944),size=width/390;ctx.save();ctx.translate(tea.x,tea.y);ctx.scale(size,size);
   for(let i=0;i<2;i++){const t=(time*.48+i*.5)%1;
    ctx.beginPath();ctx.moveTo(Math.sin(time*1.9+i)*2,-2-t*13);
    ctx.bezierCurveTo(4,-5-t*13,-3,-7-t*13,Math.sin(time+i)*2,-11-t*13);
    ctx.strokeStyle='rgba(253,244,211,'+(.45*Math.sin(Math.PI*t))+')';ctx.lineWidth=1.3;ctx.stroke();}
   ctx.restore();
  }
  for(const f of flashes){const p=project(f.x,f.y,f.z);ctx.save();ctx.translate(p.x,p.y);ctx.rotate(f.rot);ctx.fillStyle='#'+f.color.toString(16);ctx.globalAlpha=clip(f.life*2,0,1);
   ctx.fillRect(-2.3,-1.2,profile.rewards.comment?7:4.8,2.4);ctx.restore();}
  for(const car of cars){if(car.wiggle<=0||state!=='hunt')continue;const p=project(car.x,table+1.33,car.z);
   ctx.save();ctx.globalAlpha=Math.min(1,car.wiggle*4);ctx.font='italic bold '+Math.max(15,width*.044)+'px Georgia';ctx.textAlign='center';ctx.strokeStyle='#764338';ctx.lineWidth=3;ctx.strokeText(['Achoo!','Hee!','Psst!'][car.kind],p.x,p.y);ctx.fillStyle='#fff0bd';ctx.fillText(['Achoo!','Hee!','Psst!'][car.kind],p.x,p.y);ctx.restore();}
 }
 surface.addEventListener('webglcontextlost',e=>{e.preventDefault();if(!renderer)return;const c=document.createElement('canvas');c.className='backup';surface.after(c);lite=c.getContext('2d');renderer=null;zoom=1;lookX=lookY=lookZ=angle=0;resize();});
 return{draw,rebuild,populate,resize,project,refreshCostume,studio:()=>({renderer,scene,camera,room,chef,models,normalEye,normalTarget}),isLite:()=>!renderer};
})();


