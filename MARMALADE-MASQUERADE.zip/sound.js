const audio=(()=>{
 let ac,master,reverb,pulse=0,beat=0,air;
 function wake(){try{if(!ac){ac=new(window.AudioContext||window.webkitAudioContext)();master=ac.createGain();master.gain.value=.31;master.connect(ac.destination);reverb=ac.createDelay();reverb.delayTime.value=.092;const g=ac.createGain();g.gain.value=.13;reverb.connect(g);g.connect(master);}if(ac.state==='suspended')ac.resume().catch(()=>{});}catch{}}
 function tone(f,d,t='triangle',v=.17,delay=0,end=0){if(!ac||profile.mute||ac.state!=='running')return;
  const osc=ac.createOscillator(),gain=ac.createGain(),now=ac.currentTime+delay;osc.type=t;osc.frequency.setValueAtTime(f,now);if(end)osc.frequency.exponentialRampToValueAtTime(end,now+d);
  gain.gain.setValueAtTime(.0001,now);gain.gain.exponentialRampToValueAtTime(v,now+.009);gain.gain.exponentialRampToValueAtTime(.0001,now+d);
  osc.connect(gain);gain.connect(master);gain.connect(reverb);osc.start(now);osc.stop(now+d+.013);osc.onended=()=>{osc.disconnect();gain.disconnect();};}
 function ting(f,delay=0){tone(f,.39,'sine',.19,delay);tone(f*2.76,.126,'sine',.049,delay);}
 function fizz(amp=.14){if(!ac||profile.mute||ac.state!=='running')return;if(!air){air=ac.createBuffer(1,Math.ceil(ac.sampleRate*.17),ac.sampleRate);let d=air.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=(Math.random()*2-1)*Math.sin(Math.PI*i/d.length)**2;}
  const src=ac.createBufferSource(),v=ac.createGain(),b=ac.createBiquadFilter();src.buffer=air;b.type='bandpass';b.frequency.value=1650;b.Q.value=.72;v.gain.value=amp;src.connect(b);b.connect(v);v.connect(master);src.start();src.onended=()=>{src.disconnect();b.disconnect();v.disconnect();};}
 function signal(k){if(k==='welcome'){ting(660);ting(880,.14);}if(k==='hide'){tone(310,.15,'triangle',.16,0,155);fizz(.12);}
  if(k==='roll'){tone(112,.13,'triangle',.12,0,160);tone(165,.08,'triangle',.10,.11);fizz(.08);}
  if(k==='brake'){fizz(.21);tone(440,.32,'sine',.10,0,210);}
  if(k==='fox'){[523,659,784,1046].forEach((f,i)=>ting(f,i*.067));}
  if(k==='cake'){tone(295,.2,'triangle',.22,0,225);tone(220,.23,'triangle',.15,.12,157);}
  if(k==='finish'){[392,494,587,659,784,988,1175].forEach((f,i)=>ting(f,i*.09));}
  if(k==='retry'){tone(392,.22);tone(294,.33,'triangle',.17,.19);}}
 function tell(k){if(k===0){fizz(.25);tone(610,.14,'sine',.14,0,260);}if(k===1){tone(580,.09,'triangle',.11);tone(660,.09,'triangle',.12,.12);}if(k===2){ting(784);ting(659,.13);}}
 function update(dt){if(!ac||profile.mute||!live||state==='pause')return;pulse-=dt;if(pulse>0)return;
  const bass=[130.81,110,146.83,98],top=[329.63,261.63,349.23,293.66],bar=Math.floor(beat/4)%4,sub=beat%4;
  if(sub===0||sub===2)tone(bass[bar]*(sub===2?1.5:1),.20,'triangle',.105);
  else{tone(top[bar],.105,'triangle',.054);tone(top[bar]*1.25,.10,'sine',.041);}
  beat++;pulse=state==='shuffle'?.246:.34;}
 return{wake,signal,tell,update,ting};
})();
