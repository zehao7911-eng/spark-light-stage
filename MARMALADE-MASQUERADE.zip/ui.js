const soundGlyph=()=>'<svg viewBox="0 0 24 24"><path d="M4 9h4l5-4v14l-5-4H4z"/>'+(profile.mute?'<path d="m17 9 5 6m0-6-5 6"/>':'<path d="M16 9q4 3 0 6m3-9q6 6 0 12"/>')+'</svg>';
function sheet(k,t,d,p,act,alt,second){
 $('#label').textContent=k;$('#title').textContent=t;$('#desc').textContent=d;$('#mainAction').textContent=p;$('#mainAction').onclick=act;
 $('#secondary').hidden=!alt;$('#secondary').textContent=alt||'';$('#secondary').onclick=second||null;
}
function dessertIcon(i){
 const img=document.createElement('img'),k='sweet-'+i;img.alt='';img.draggable=false;
 img.src=(typeof bakedArt!=='undefined'&&bakedArt[k])||'plates/'+k+'.webp';return img;
}
function punchTicket(){
 const ticket=document.createElement('div');ticket.className='ticket';ticket.setAttribute('aria-label',award+' of three stamps');
 const holes=document.createElement('div');holes.className='punches';
 for(let i=0;i<3;i++){const dot=document.createElement('i');dot.className=i<award?'punched':'';dot.style.setProperty('--delay',(i*135+180)+'ms');holes.append(dot);}
 const stub=document.createElement('div');stub.className='stub';const mark=document.createElement('b');mark.textContent=guest?'MIDNIGHT SPECIAL':'MENU No. 0'+(level+1);
 const station=document.createElement('span');station.textContent=stops[level].name;stub.append(mark,station);ticket.append(dessertIcon(level),stub,holes);$('#album').append(ticket);
}
function showBook(){state='book';updateUI();}
function updateNotice(){const n=$('#notice');n.textContent=notice;n.classList.toggle('on',noticeTime>0&&['hunt','lift'].includes(state));}
function updateUI(){
 const menu=['cover','pause','book','served','win','lose'].includes(state),spec=stops[level];
 $('#frame').dataset.state=state;$('#sheet').hidden=!menu;$('#rail').hidden=menu;$('#status').hidden=['cover','book'].includes(state);
 $('#pause').hidden=!live||['pause','served'].includes(state);$('#sound').innerHTML=soundGlyph();$('#sound').setAttribute('aria-label',profile.mute?'Turn sound on':'Mute music');
 $('#source').hidden=state!=='cover'&&state!=='book';$('#album').replaceChildren();updateNotice();
 $('#section').textContent=(guest?'NIGHT TRAIN':'STOP '+String(level+1).padStart(2,'0'))+'  /  SERVICE '+(service+1)+' OF 3';$('#station').textContent=spec.name;
 $('#hearts').innerHTML='♥'.repeat(tries)+'<em>'+'♥'.repeat(3-tries)+'</em>';$('#hearts').setAttribute('aria-label',tries+' chances remaining');
 const aside=$('#aside');aside.hidden=true;aside.onclick=null;$('#stageLabel').textContent=spec.dessert.toUpperCase();
 if(state==='cover'){
  const resume=validMark(profile.bookmark);sheet('THE DESSERT-CAR MYSTERY','Marmalade Masquerade',resume?'Your table is waiting. Pick up your saved service.':'A fox in the dessert car! Follow the silver cover and catch the little thief.',resume?'Resume service':'All aboard',()=>start(unlocked(),resume),'Menu book',showBook);
 }else if(state==='peek'){
  $('#prompt').textContent=guest?(nightScarf?'Watch the rose scarf':'Watch the green scarf'):targets().length===2?'Remember both foxes':'Remember the fox';aside.hidden=false;aside.textContent='Shuffle';aside.onclick=hide;
 }else if(state==='hide'||state==='beat'||state==='shuffle'){$('#prompt').textContent=slowTime>0?'Easy does it…':'Follow the cover';if((guest||level>=2)&&!usedBrake&&state!=='hide'){aside.textContent='Slow down';aside.hidden=false;aside.onclick=brake;}}
 else if(state==='hunt'){$('#prompt').textContent=fresh?'Find the other fox':'Tap the hiding place';aside.hidden=false;aside.textContent='Listen';aside.onclick=listen;}
 else if(state==='lift')$('#prompt').textContent=cars[picked].caught?['Caught with jam!','Cream moustache!','A little apology!'][service]:cars[picked].fox?'Wrong scarf!':spec.dessert+'!';
 else if(state==='served')sheet('SERVICE '+(service+1)+' COMPLETE',fresh===2?'Double trouble!':'There you are!',service===0?'The next tray is ready to roll.':'One last service before the train leaves.','Next service',advance);
 else if(state==='pause')sheet('TEA BREAK','A little pause','Your trays will stay right here.','Back to service',unpause,'Leave carriage',leave);
 else if(state==='lose')sheet('THE FOX GOT AWAY','A clean getaway','Hold the hiding place in mind as the covers cross. Listen if you lose the trail.','Try this stop',()=>start(level,false,guest),'Menu book',showBook);
 else if(state==='win'){
  const last=level===5;sheet(('✦ '.repeat(award)).trim()+'   ·   SERVICE COMPLETE',guest?'Midnight special':spec.dessert,
   guest?'The company is ready for another secret menu.':last?'Your menu is complete. The night train now takes surprise orders.':'Recipe stamped into your menu book.',
   guest?'Another special':last?'Night train':'Next station',()=>guest||last?start(5,false,true):start(level+1),'Menu book',showBook);punchTicket();
 }else if(state==='book'){
  const score=profile.stamps.reduce((a,b)=>a+b,0),sup=sdk?.support()||{};
  let info=sup.like&&!profile.rewards.like?' A host like adds a brass pin.':sup.comment&&!profile.rewards.comment?' A direct host comment unlocks ribbon confetti.':'';
  sheet('THE CITRUS EXPRESS','Menu book',score+' / 18 stamps · '+(score>=8?'Reading glasses':score>=3?'Porter cap':'Earn a porter cap at 3 stamps')+'.'+info,'Return',()=>setup(unlocked()));
  stops.forEach((s,i)=>{const b=document.createElement('button');b.className='stamp';b.disabled=i>unlocked();b.append(dessertIcon(i),document.createTextNode(s.dessert));const x=document.createElement('span');x.textContent=b.disabled?'Sealed':'✦'.repeat(profile.stamps[i])+'◇'.repeat(3-profile.stamps[i]);b.append(x);b.onclick=()=>start(i);$('#album').append(b);});
  if(profile.stamps[5]){const b=document.createElement('button');b.className='stamp';b.textContent='Night train';b.onclick=()=>start(5,false,true);$('#album').append(b);}
 }
}
$('#sound').onclick=()=>{profile.mute=!profile.mute;storeProfile();audio.wake();if(!profile.mute)audio.ting(660);updateUI();};$('#pause').onclick=pause;
$('#stage').addEventListener('click',()=>{if(state==='peek')hide();});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){if(state==='pause')unpause();else pause();}if(state==='peek'&&e.key===' '&&e.target.tagName!=='BUTTON'){e.preventDefault();hide();}});
let last=0;
document.addEventListener('visibilitychange',()=>{if(document.hidden&&live&&state!=='served')pause();last=0;});
window.addEventListener('pagehide',e=>{if(!e.persisted)sdk?.stop();});
function hostSize(){const v=sdk?.viewport();document.documentElement.style.setProperty('--hw',v?Math.min(innerWidth,v.width)+'px':'100vw');document.documentElement.style.setProperty('--hh',v?Math.min(innerHeight,v.height)+'px':'100dvh');}
connectHost();hostSize();window.addEventListener('resize',hostSize);window.addEventListener('focus',hostSize);document.addEventListener('pointerdown',hostSize,{passive:true});
if(location.protocol==='file:'){$('#source').href='CREDITS.txt';$('#source').removeAttribute('download');}
else if(location.hostname.endsWith('.github.io'))$('#source').href='../MARMALADE-MASQUERADE.zip';
new ResizeObserver(()=>view.resize()).observe($('#frame'));setup();
function loop(ts){const dt=last?Math.min(.065,(ts-last)/1000):.016;last=ts;if(!document.hidden){tick(dt);audio.update(dt);view.draw(state==='pause'?0:dt);}requestAnimationFrame(loop);}requestAnimationFrame(loop);

