/* Painted confectionery figurines. All joints pivot from inside their sockets. */
const P={choc:0x442c36,umber:0x70412f,orange:0xdf7437,peel:0xf2a444,milk:0xffead1,mint:0x72af9a,teal:0x235d60,glass:0x7cb8b6,berry:0xd64c65,blush:0xe99591,butter:0xf4ca76,metal:0xacb6ad,shine:0xf5e5c9};
function eye(o,s,x,y,z,sz){
 egg(o,P.choc,s*x,y,z,sz*.74,sz,sz*.48,0,s*.22);
 egg(o,0xfff9e6,s*x-sz*.19,y+sz*.29,z+sz*.42,sz*.19,sz*.22,sz*.10);
}
function whiskers(o,x,y,z,s){
 for(let i=0;i<3;i++)rod(o,0x926a53,[s*x,y-i*.034,z],[s*(x+.14+i*.026),y+.056-i*.062,z+.012],.008,.004);
}
function foxModel(alt=false){
 const root=g(),hips=g(root),spine=g(hips,0,.33,0),head=g(spine,0,.61,.05),ears=[],arms=[],feet=[],tail=g(hips,.13,.35,-.20);
 const fur=alt?0xcc754d:P.orange,edge=alt?0xf6b979:P.peel,boots=0x503843;
 silk(spine,fur,0,.09,-.015,.326,.403,.294);
 silk(spine,P.milk,0,.113,.211,.205,.29,.104,-.15);
 for(const s of [-1,1]){
  const ft=g(hips,s*.168,.16,.06);feet.push(ft);egg(ft,boots,0,-.058,.05,.127,.106,.195);egg(ft,fur,0,.016,-.016,.132,.147,.14);
  const arm=g(spine,s*.274,.27,.027);arms.push(arm);egg(arm,fur,s*.027,-.114,.03,.10,.165,.107,0,0,s*.20);
  egg(arm,boots,s*.035,-.237,.072,.081,.085,.087);
 }
 silk(head,fur,0,.016,.012,.404,.331,.31);
 for(const s of [-1,1]){
  egg(head,edge,s*.29,-.04,.116,.158,.146,.144,0,0,s*.25);
  egg(head,P.milk,s*.17,-.093,.221,.206,.144,.155,0,0,-s*.34);
  const er=g(head,s*.239,.247,-.044);ears.push(er);
  poly(er,fur,0,0,-.080,[[-.15,-.055],[.15,-.052],[s*.095,.334]],.142);
  poly(er,boots,0,0,-.076,[[s*.003,.212],[s*.129,.160],[s*.095,.334]],.14);
  poly(er,0xc77d73,0,.012,.064,[[-.081,.014],[.081,.012],[s*.068,.208]],.012);
  eye(head,s,.159,.062,.285,.050);egg(head,0xa45e3e,s*.163,.145,.255,.073,.02,.033,0,0,s*.14);
  whiskers(head,.247,-.092,.302,s);
 }
 egg(head,P.milk,0,-.084,.298,.139,.092,.143);egg(head,boots,0,-.054,.401,.072,.056,.054);egg(head,0xa67d72,-.022,-.036,.44,.022,.012,.009);
 egg(head,0x6b4341,0,-.165,.338,.043,.019,.027);
 turned(spine,alt?P.berry:P.teal,0,.318,.006,[[.21,0],[.285,.02],[.263,.105],[.18,.125]],.91);
 poly(spine,alt?P.berry:P.teal,-.084,.327,.255,[[-.062,.047],[.068,.04],[.06,-.13],[-.043,-.203]],.032,0,0,-.23);
 egg(spine,P.butter,-.03,.355,.249,.036,.038,.028);
 egg(tail,fur,.10,.015,-.14,.144,.161,.279,-.35,-.21);
 silk(tail,fur,.18,.19,-.326,.196,.264,.207,-.6,0,-.18);
 egg(tail,P.milk,.22,.349,-.402,.166,.18,.147,-.51,0,-.14);
 const spoon=g(arms[1],.036,-.225,.097);
 rod(spoon,brass,[0,0,0],[.13,.135,.135],.019);
 egg(spoon,0xe5bb88,.151,.15,.16,.072,.026,.092,-.41);
 egg(spoon,0xaa3861,.154,.17,.157,.061,.038,.072,-.39);
 egg(spoon,0xcb4c60,.186,.137,.213,.022,.053,.021);
 const cream=g(head,0,-.138,.387);
 for(const s of [-1,1]){egg(cream,0xfff4ce,s*.073,0,0,.091,.052,.036,0,0,s*.24);egg(cream,0xffe9bc,s*.135,.027,0,.043,.027,.031,0,0,s*.45);}
 const note=g(arms[0],-.03,-.23,.099);
 poly(note,0xffe1a8,0,0,0,[[-.13,-.094],[.13,-.094],[.13,.095],[-.13,.095]],.014);
 rod(note,0xc49a70,[-.124,.088,.018],[0,-.012,.018],.008);
 rod(note,0xc49a70,[0,-.012,.018],[.124,.088,.018],.008);
 egg(note,P.berry,0,-.011,.024,.027,.025,.01);
 const gags=[spoon,cream,note];gags.forEach(q=>q.visible=false);
 finish(root);root.userData={spine,head,ears,arms,feet,tail,gags};return root;
}
function foxPose(o,t,k,taunt){
 const d=o.userData;d.spine.position.y=.33+.018*Math.sin(t*4.1)+k*.08;
 d.head.rotation.set(-k*.18+.04*Math.sin(t*2),.20*Math.sin(t*1.7),.09*Math.sin(t*2.2));
 d.ears.forEach((ear,i)=>ear.rotation.z=(i?1:-1)*(.04+taunt*.33+.04*Math.cos(t*3+i)));
 d.arms.forEach((arm,i)=>{arm.rotation.x=-.19-k*.9;arm.rotation.z=(i?1:-1)*(.10+k*(.7+.24*Math.sin(t*8+i)));});
 d.tail.rotation.y=Math.sin(t*(k?6:3.4))*(k?.5:.22);d.tail.rotation.x=-.07-.22*k;
}
function chefModel(){
 const root=g(),chest=g(root,0,.88,0),head=g(chest,0,1.0,.035),ears=[],arms=[],feet=[],eyes=[],brows=[],hat=g(head,0,.39,-.035);
 for(const s of [-1,1]){
  let leg=g(root,s*.26,.64,0);feet.push(leg);rod(leg,P.teal,[0,.075,0],[s*.013,-.43,.035],.146,.13);
  egg(leg,P.choc,s*.015,-.49,.11,.174,.135,.25);egg(leg,0xa37c5e,s*.015,-.586,.123,.177,.047,.237);
 }
 turned(chest,P.milk,0,-.33,0,[[.02,0],[.39,.02],[.54,.14],[.58,.46],[.51,.74],[.37,.89],[.14,.92]],.78);
 for(let k=0;k<4;k++)for(const s of [-1,1])egg(chest,P.choc,s*.127,-.037+k*.135,.410-.014*Math.abs(k-2),.027,.029,.023);
 poly(chest,0x598e85,0,-.36,.387,[[-.36,.47],[.36,.47],[.40,-.26],[.25,-.32],[-.25,-.32],[-.40,-.26]],.032);
 for(let j=-3;j<=3;j++)cube(chest,0x91b6a4,j*.098,-.302,.428,.023,.56,.013);
 cube(chest,P.teal,0,.105,.421,.766,.073,.039);
 for(const s of [-1,1]){
  const arm=g(chest,s*.425,.429,.006);arms.push(arm);
  egg(arm,P.milk,s*.046,-.056,.034,.192,.20,.18);
  rod(arm,P.milk,[s*.077,-.10,.034],[s*.18,-.34,.092],.14,.105);
  egg(arm,0xe4c2a3,s*.156,-.33,.114,.108,.106,.102);
  egg(arm,0xac734d,s*.14,-.405,.161,.109,.12,.105);
 }
 silk(head,0xaf724b,0,0,0,.464,.445,.369);
 egg(head,0xca9564,-.16,.115,.277,.172,.21,.112,-.14,0,-.23);
 for(const s of [-1,1]){
  const er=g(head,s*.34,.198,-.071);ears.push(er);
  silk(er,0x86513c,s*.055,-.22,-.007,.167,.335,.138,0,0,s*.12);
  egg(er,0xb07b58,s*.048,-.235,.075,.103,.20,.056);
  egg(head,0xf6d9ad,s*.13,-.127,.262,.186,.178,.204,-.24);
  const eyeJoint=g(head,s*.165,.083,.380);eyes.push(eyeJoint);eye(eyeJoint,s,0,0,0,.064);
  const brow=g(head,s*.160,.19,.338);brows.push(brow);egg(brow,0x654032,0,0,0,.113,.034,.046,0,0,s*.19);
  for(let i=0;i<3;i++)egg(head,0xb18668,s*(.11+.048*i),-.13-.022*(i%2),.452-.019*i,.014,.014,.008);
 }
 egg(head,P.choc,0,-.058,.415,.117,.09,.079);
 egg(head,0xa37c70,-.031,-.027,.476,.032,.019,.009);
 egg(head,0x904c4e,.06,-.266,.326,.059,.075,.049,0,0,-.18);
 turned(hat,P.milk,0,-.072,0,[[.21,0],[.342,.016],[.328,.22],[.29,.263]],.92);
 for(let i=0;i<8;i++){let a=i*Math.PI/4;silk(hat,i%2?0xfff1d7:0xf0dabb,Math.sin(a)*.228,.245+.033*Math.cos(a),Math.cos(a)*.204,.217,.201,.204);}
 silk(hat,0xffecd0,0,.28,0,.277,.201,.239);
 turned(hat,0xd8ac85,0,-.047,0,[[.343,0],[.343,.035]],.924);
 for(const s of [-1,1])egg(chest,P.berry,s*.11,.594,.359,.158,.085,.068,0,0,s*.24);egg(chest,0xb84454,0,.595,.391,.071,.069,.067);
 // Copper measuring spoon; the cook points at the revealed dish.
 const spoon=g(arms[1],.145,-.405,.181);rod(spoon,brass,[0,0,0],[.06,.22,.30],.027);egg(spoon,0xd49c67,.071,.26,.35,.096,.058,.121,-.81);
 finish(root);root.userData={chest,head,arms,ears,hat,feet,eyes,brows};return root;
}
function chefPose(o,t,reaction,mood){
 const d=o.userData,r=reaction;
 d.chest.position.y=.88+.019*Math.sin(t*2.3)+r*.064;d.head.rotation.y=.24*Math.sin(t*.72)+mood*r*.31;
 d.head.rotation.z=.036*Math.sin(t*1.38)+r*(mood>0?-.17:.23);d.head.rotation.x=.028*Math.cos(t)-r*(mood>0?.19:-.16);
 d.hat.rotation.z=r*.19;d.ears.forEach((er,i)=>er.rotation.z=(i?1:-1)*r*.21);
 const blink=Math.max(0,1-Math.abs((t%3.91)-3.61)/.114);
 d.eyes.forEach(q=>q.scale.y=1-.89*blink);
 d.brows.forEach((q,i)=>{q.position.y=.19+r*(mood>0?.04:(i?.083:-.015));q.rotation.z=(i?1:-1)*r*(mood>0?.12:-.28);});
 d.arms.forEach((arm,i)=>{arm.rotation.x=-.17+.045*Math.sin(t*2+i)-r*(i?.96:.46);arm.rotation.z=(i?1:-1)*(.09+.032*Math.sin(t)+r*(mood>0?.92:.44));});
}

 function dressFox(f,points,pin){
  const bonus=g(f.userData.head);
  if(points>=3){const cap=g(bonus,0,.30,-.05);cap.rotation.z=-.23;egg(cap,0x33817a,0,0,0,.225,.081,.177);egg(cap,0x39746c,-.05,.064,0,.169,.075,.152);egg(cap,gold,-.08,.133,0,.032,.032,.028);}
  if(points>=8){for(const s of [-1,1])ring(bonus,brass,s*.162,.071,.311,.081,.009);rod(bonus,brass,[-.082,.078,.314],[.082,.078,.314],.009);}
  if(pin){const ba=g(f.userData.spine,-.113,.254,.275);egg(ba,gold,0,0,0,.058,.058,.018);finish(ba);}
  finish(bonus);
 }

