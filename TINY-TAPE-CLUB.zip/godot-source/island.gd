extends Node3D
var game
var camera:Camera3D
var sun:DirectionalLight3D
var env:Environment
var surface:SurfaceTool
var material:StandardMaterial3D
var stage:MeshInstance3D
var toys=[]
var springs=[]
var velocities=[]
var base_heights=[]
var train:Node3D
var conductor:Node3D
var arm:Node3D
var fx=[]
var time=0.0
var reward=0.0
var narrow=false
var primitive_cache={}
var faces=[]
var gestures=[]
var halos=[]
var halo_mats=[]
var note_shapes={}
var landscape_accents:MeshInstance3D
var wheels:Node3D
var art_theme=-1
var wagons=[]
var smoke_clock=0.0
const COLORS=['#f1aa4d','#f27f69','#77bba9','#a494d4']

func _ready():
	material=StandardMaterial3D.new(); material.vertex_color_use_as_albedo=true; material.roughness=.68
	material.cull_mode=BaseMaterial3D.CULL_DISABLED; material.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
	var we=WorldEnvironment.new(); env=Environment.new(); env.background_mode=Environment.BG_CLEAR_COLOR; env.background_color=Color('#a9c9db'); env.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR; env.ambient_light_color=Color('#e5efff'); env.ambient_light_energy=.5; we.environment=env; add_child(we)
	sun=DirectionalLight3D.new(); sun.rotation_degrees=Vector3(-55,-35,0); sun.light_color=Color('#fff0d9'); sun.light_energy=.9; sun.shadow_enabled=false; sun.directional_shadow_max_distance=25; add_child(sun)
	camera=Camera3D.new(); camera.projection=Camera3D.PROJECTION_ORTHOGONAL; camera.near=.1; camera.far=80; add_child(camera); camera.make_current()
	landscape_accents=MeshInstance3D.new(); landscape_accents.material_override=material; add_child(landscape_accents)
	stage=MeshInstance3D.new(); stage.material_override=material; add_child(stage)
	for i in range(8):
		var node=Node3D.new(); var body=MeshInstance3D.new(); body.material_override=material; node.add_child(body); add_child(node); toys.append(node); springs.append(0.0); velocities.append(0.0)
		var face=Node3D.new(); node.add_child(face); faces.append(face)
		var gesture=Node3D.new(); node.add_child(gesture); gestures.append(gesture)
		var halo=MeshInstance3D.new(); halo.mesh=primitive('torus'); var hm=material.duplicate(); hm.vertex_color_use_as_albedo=false; hm.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA; hm.albedo_color=Color(1,.88,.5,0); halo.material_override=hm; add_child(halo); halos.append(halo); halo_mats.append(hm)
	train=Node3D.new(); add_child(train); conductor=Node3D.new(); add_child(conductor); arm=Node3D.new(); conductor.add_child(arm)
	update_camera()

func update_camera():
	if not camera: return
	var is_narrow=game.css_size.x<600
	if narrow!=is_narrow:
		narrow=is_narrow; rebuild()
	var aspect=float(game.world.size.x)/maxf(1,game.world.size.y)
	var size=maxf(8.0,6.5/aspect) if narrow else maxf(5.9,10.6/aspect)
	camera.size=size
	camera.position=Vector3(1.2,10,15) if narrow else Vector3(3.0,8.8,13.0); camera.look_at(Vector3(0,.1,0),Vector3.UP)
	sun.shadow_enabled=false

func primitive(kind):
	if primitive_cache.has(kind): return primitive_cache[kind]
	var mesh
	match kind:
		'box': mesh=BoxMesh.new(); mesh.size=Vector3.ONE
		'sphere': mesh=SphereMesh.new(); mesh.radius=.5; mesh.height=1; mesh.radial_segments=20; mesh.rings=10
		'cylinder': mesh=CylinderMesh.new(); mesh.top_radius=.5; mesh.bottom_radius=.5; mesh.height=1; mesh.radial_segments=48
		'cone': mesh=CylinderMesh.new(); mesh.top_radius=0; mesh.bottom_radius=.5; mesh.height=1; mesh.radial_segments=16
		'torus': mesh=TorusMesh.new(); mesh.inner_radius=.475; mesh.outer_radius=.5; mesh.rings=48; mesh.ring_segments=8
	primitive_cache[kind]=mesh; return mesh
func begin(): surface=SurfaceTool.new(); surface.begin(Mesh.PRIMITIVE_TRIANGLES)
func part(kind,p,scale_value,color,rot=Vector3.ZERO):
	var a=primitive(kind).surface_get_arrays(0); var vertices=a[Mesh.ARRAY_VERTEX]; var normals=a[Mesh.ARRAY_NORMAL]; var idx=a[Mesh.ARRAY_INDEX]
	var basis=Basis.from_euler(rot); var normal_basis=basis*Basis.from_scale(scale_value).inverse().transposed()
	for i in idx:
		var normal=(normal_basis*normals[i]).normalized()
		var light=.64+maxf(0,normal.dot(Vector3(-.35,.8,.48).normalized()))*.36
		light+=pow(maxf(0,normal.dot(Vector3(-.2,.95,.2).normalized())),18)*.06
		surface.set_color(Color(color)*minf(1.0,light)); surface.set_normal(normal); surface.add_vertex(p+basis*(vertices[i]*scale_value))
func box(p,s,c,rot=Vector3.ZERO): part('box',p,s,c,rot)
func orb(p,s,c): part('sphere',p,s,c)
func cyl(p,s,c,rot=Vector3.ZERO): part('cylinder',p,s,c,rot)
func ring(p,s,c,rot=Vector3.ZERO): part('torus',p,s,c,rot)
func finish(target): target.mesh=surface.commit()
func child_mesh(parent):
	var m=MeshInstance3D.new(); m.material_override=material; parent.add_child(m); return m
func toy_position(i):
	return Vector3((i%2-.5)*2.05,.48,(int(i/2)-1.5)*1.85) if narrow else Vector3((i%4-1.5)*2.05,.48,(-.95 if i<4 else 1.05))
func footprint(v): return Vector3(v.z,v.y,v.x) if narrow else v

func rebuild():
	if not stage: return
	var bg=['#a9c9db','#b4a7ce','#e7b6b8'][game.theme]; env.background_color=Color(bg)
	begin()
	# A hand-sized oval music island, with layered wood and ceramic edges.
	cyl(Vector3(0,-.18,0),footprint(Vector3(10.3,.18,6.3)),'#83a4bb')
	cyl(Vector3(0,.03,0),footprint(Vector3(10.05,.48,6.05)),'#b76c54')
	cyl(Vector3(0,.24,0),footprint(Vector3(10.1,.1,6.1)),'#f0c694')
	cyl(Vector3(0,.32,0),footprint(Vector3(9.9,.12,5.9)),'#fff0d3')
	var deck=[['#e3cbaa','#d4d6c4','#b3ced0','#d9cfe4'],['#c7b5c6','#c5c9c7','#a9bacb','#c3bcda'],['#edceb8','#e1d2be','#bcd5ce','#e5d1e3']][game.theme][game.active]
	cyl(Vector3(0,.4,0),footprint(Vector3(9.65,.08,5.65)),deck)
	# Fine inlaid brass trim and a routed edge, all part of the wood base.
	for y in [.16,.28]: ring(Vector3(0,y,0),footprint(Vector3(10.08,.06,6.08)),'#d3a86f')
	for i in range(36):
		var a=TAU*i/36; var p=footprint(Vector3(cos(a)*4.93,.12,sin(a)*2.94))
		cyl(p,Vector3(.045,.045,.045),'#edcf9e')
	for i in range(48):
		var a=TAU*i/48; var p=footprint(Vector3(cos(a)*4.48,.46,sin(a)*2.5))
		box(p,Vector3(.18,.06,.1),'#ceaa82',Vector3(0,-a,0))
	for k in [1.0,1.035]: ring(Vector3(0,.47,0),footprint(Vector3(9.25*k,.13,5.15*k)),'#7d8b91')
	for i in range(8):
		var p=toy_position(i)
		cyl(p+Vector3(.035,-.015,.065),Vector3(1.76,.025,1.74),'#a7afa5')
		cyl(p+Vector3(0,-.005,0),Vector3(1.65,.06,1.65),'#c5bba8')
		cyl(p+Vector3(0,.02,0),Vector3(1.6,.1,1.6),'#fff7e3')
		cyl(p+Vector3(0,.075,0),Vector3(1.46,.03,1.46),COLORS[game.active])
		for j in range(6):
			var a=TAU*j/6
			orb(p+Vector3(cos(a)*.7,.12,sin(a)*.7),Vector3(.055,.03,.055),'#fff5d4')
	# Tiny flowering corners, peg feet and moulded screws.
	for x in [-3.9,3.9]:
		for z in [-1.9,1.9]:
			cyl(footprint(Vector3(x,.64,z)),Vector3(.3,.35,.3),'#dc9c74')
			for j in range(3):
				orb(footprint(Vector3(x+(j-1)*.12,.92+abs(j-1)*.04,z)),Vector3(.23,.36,.23),'#669c8a')
	for x in [-3.5,3.5]:
		cyl(footprint(Vector3(x,-.32,.4)),Vector3(.75,.5,.75),'#8a5749')
	finish(stage)
	build_garden()
	for i in range(8): rebuild_toy(i)
	for n in train.get_children(): n.queue_free()
	var trainmesh=child_mesh(train); begin()
	box(Vector3(0,.23,0),Vector3(.54,.4,.65),'#ec7962'); box(Vector3(0,.52,-.16),Vector3(.52,.22,.34),'#ffda75'); box(Vector3(0,.39,-.345),Vector3(.32,.19,.015),'#40556b')
	cyl(Vector3(0,.25,.35),Vector3(.35,.52,.35),'#e8ad51',Vector3(PI/2,0,0)); cyl(Vector3(0,.52,.36),Vector3(.13,.19,.13),'#485b68')
	ring(Vector3(0,.25,.59),Vector3(.3,.15,.3),'#fff0cd',Vector3(PI/2,0,0)); orb(Vector3(0,.25,.61),Vector3(.16,.16,.05),'#ffe7a0')
	for x in [-.24,.24]: box(Vector3(x,.49,-.17),Vector3(.025,.19,.19),'#90bdc0')
	for x in [-.3,.3]:
		for z in [-.2,.26]: cyl(Vector3(x,.05,z),Vector3(.22,.12,.22),'#42546a',Vector3(0,0,PI/2))
	finish(trainmesh)
	for n in conductor.get_children():
		if n!=arm: n.queue_free()
	var cm=child_mesh(conductor); begin()
	orb(Vector3(0,.2,0),Vector3(.65,.55,.58),'#f7c568'); orb(Vector3(-.19,.45,.04),Vector3(.2,.3,.2),'#f7c568'); orb(Vector3(.19,.45,.04),Vector3(.2,.3,.2),'#f7c568')
	for x in [-.13,.13]:
		orb(Vector3(x,.3,.27),Vector3(.15,.18,.08),'#fff6e3'); orb(Vector3(x,.29,.31),Vector3(.075,.1,.05),'#3e4559')
	orb(Vector3(0,.14,.29),Vector3(.1,.04,.045),'#ae6255')
	cyl(Vector3(0,.53,0),Vector3(.42,.12,.42),'#637da2'); cyl(Vector3(0,.61,0),Vector3(.27,.12,.27),'#637da2')
	finish(cm)
	for n in arm.get_children(): n.queue_free()
	var am=child_mesh(arm); begin(); orb(Vector3(.42,.22,.04),Vector3(.3,.13,.15),'#f7c568'); box(Vector3(.55,.37,.05),Vector3(.035,.4,.035),'#fff5de',Vector3(0,0,-.3)); finish(am)
	conductor.position=Vector3(-.2,.51,4.24 if narrow else 2.25)

func rebuild_toy(i):
	var p=int(game.patterns[game.active][i]); var body=toys[i].get_child(0)
	toys[i].position=toy_position(i)+Vector3(0,.13,0)
	begin(); var c=Color(COLORS[game.active]); var off=p==0
	var accent=c.darkened(.17) if off else c
	accent=accent.lerp(Color('#ffeac2'),float(i%3)*.045)
	var height=.4+float(p)*.13+float(i%2)*.06
	match game.active:
		0:
			cyl(Vector3(0,.22,0),Vector3(1.02,.4,1.02),accent)
			ring(Vector3(0,.04,0),Vector3(1.1,.4,1.1),'#e29543'); ring(Vector3(0,.43,0),Vector3(1.12,.36,1.12),'#faf0d5')
			cyl(Vector3(0,.445,0),Vector3(.86,.035,.86),'#f8d67e' if not off else '#cfbb94')
			for j in range(8):
				var a=TAU*j/8; box(Vector3(cos(a)*.5,.23,sin(a)*.5),Vector3(.055,.32,.055),'#fff0d2')
			for x in [-.4,.4]: box(Vector3(x,.2,-.08),Vector3(.13,.25,.12),'#b3764d')
			for j in range(12):
				var a=TAU*j/12; orb(Vector3(cos(a)*.36,.469,sin(a)*.36),Vector3(.023,.012,.023),'#c9965c')
			ring(Vector3(0,.472,0),Vector3(.62,.08,.62),'#f3c26d')
			if p>0:
				for j in range(p): orb(Vector3((j-(p-1)*.5)*.15,.49,.09),Vector3(.08,.025,.08),'#fff8e8')
		1:
			box(Vector3(0,height*.5,0),Vector3(.76,height,.68),'#d6b09d' if off else '#fff2d3')
			# Sloping roof with a ridge, overhang, moulded chimney.
			for sign_value in [-1,1]: box(Vector3(sign_value*.22,height+.12,0),Vector3(.52,.12,.87),accent,Vector3(0,0,sign_value*-.48))
			box(Vector3(.2,height+.27,-.16),Vector3(.14,.32,.16),'#deb49a')
			box(Vector3(.2,height+.45,-.16),Vector3(.19,.045,.2),'#b88a78')
			for sign_value in [-1,1]:
				for line in range(3): box(Vector3(sign_value*(.07+line*.13),height+.195-line*.065,0),Vector3(.025,.02,.88),accent.lightened(.14),Vector3(0,0,sign_value*-.48))
			box(Vector3(0,height+.25,0),Vector3(.06,.06,.93),accent.lightened(.25))
			for z in [-.3,.3]: box(Vector3(0,.09,z),Vector3(.8,.09,.05),'#dbc5a0')
			box(Vector3(0,.17,.35),Vector3(.16,.32,.025),'#638a94')
			for x in [-.24,.24]:
				box(Vector3(x,height*.58,.35),Vector3(.16,.2,.035),'#6f839b' if off else '#f2bf58'); box(Vector3(x,height*.58,.374),Vector3(.018,.2,.018),'#fff8e5')
			for z in [-.17,.17]: box(Vector3(.39,height*.6,z),Vector3(.02,.18,.16),'#7894a3')
			cyl(Vector3(0,.025,.47),Vector3(.7,.04,.23),'#d9b99f')
			for x in [-.24,.24]:
				box(Vector3(x,height*.58-.15,.4),Vector3(.23,.07,.14),'#bd856a')
				for j in range(3): flower(Vector3(x+(j-1)*.065,height*.58-.09,.43),.045,'#f8d382' if i%2==0 else '#eaa5a1')
			if i%2==0:
				box(Vector3(0,.33,.48),Vector3(.28,.035,.27),accent,Vector3(-.15,0,0))
				for x in [-.15,.15]: cyl(Vector3(x,.17,.59),Vector3(.025,.3,.025),'#d9bb91')
		2:
			cyl(Vector3(0,.025,0),Vector3(1.15,.05,1.15),'#6f9ca6'); orb(Vector3(0,.14,0),Vector3(1,.12,1),'#9bc8bd')
			orb(Vector3(0,.33,0),Vector3(.85,.47,.7),accent)
			for x in [-.24,.24]:
				orb(Vector3(x,.57,.15),Vector3(.3,.3,.28),accent); orb(Vector3(x*1.5,.17,.33),Vector3(.27,.12,.24),accent)
				orb(Vector3(x*1.25,.34,.33),Vector3(.15,.08,.035),'#dca89b')
			orb(Vector3(0,.23,.2),Vector3(.59,.19,.39),'#bcd3a7')
			for x in [-.3,.3]:
				for j in range(3): orb(Vector3(x+(j-1)*.06,.13,.38),Vector3(.07,.06,.15),accent.lightened(.08))
			for j in range(3):
				var a=j*.7; orb(Vector3(-.4+j*.17,.39,.03),Vector3(.09,.045,.09),'#c0df9f')
		3:
			cyl(Vector3(0,.06,0),Vector3(.7,.12,.7),'#8d85b0')
			for j in range(4): ring(Vector3(0,.14+j*.08,0),Vector3(.36,.18,.36),'#ddbc83')
			orb(Vector3(0,.6,0),Vector3(.68,.51,.58),accent)
			for x in [-.25,.25]: orb(Vector3(x,.55,0),Vector3(.42,.4,.45),accent)
			for x in [-.25,.25]: orb(Vector3(x,.52,.21),Vector3(.12,.07,.04),'#e8bdc8')
			for j in range(3): orb(Vector3((j-1)*.1,.75,.03),Vector3(.16,.1,.2),accent.lightened(.12))
			part('cone',Vector3(0,.96,0),Vector3(.35,.32,.35),'#ffcf74')
			orb(Vector3(0,1.15,0),Vector3(.1,.1,.1),'#fff2cb')
			ring(Vector3(0,.8,0),Vector3(.37,.2,.37),'#f4cd83')
	# Three ivory pitches make state legible without relying on colour.
	for j in range(3):
		box(Vector3((j-1)*.18,.035,.64),Vector3(.12,.045,.08),'#fff5d9' if j<p else '#b5a293')
	finish(body)
	build_expression(i,p)
func ping(i):
	velocities[i]=4.0
	if game.finale: velocities[i]=6.0
	emit_note(i)
func celebrate(): reward=2.5

func flower(p,r,color):
	for j in range(5):
		var a=TAU*j/5
		orb(p+Vector3(cos(a)*r*.55,0,sin(a)*r*.55),Vector3(r*.75,r*.3,r*.75),color)
	orb(p+Vector3(0,r*.12,0),Vector3(r*.5,r*.3,r*.5),'#f4ca72')

func star(p,r,color):
	var points=[]
	for j in range(10):
		var a=TAU*j/10-PI/2; var radius=r if j%2==0 else r*.43
		points.append(p+Vector3(cos(a)*radius,0,sin(a)*radius))
	for j in range(10):
		surface.set_color(Color(color)); surface.set_normal(Vector3.UP)
		surface.add_vertex(p); surface.add_vertex(points[j]); surface.add_vertex(points[(j+1)%10])

func build_garden():
	begin()
	for i in range(8):
		var p=toy_position(i)
		match game.active:
			0:
				# Wood marquetry and tiny daisies around the musical plinths.
				for j in range(3):
					var v=p+Vector3((j-1)*.13,.015,-.83)
					box(v,Vector3(.06,.022,.11),'#d9b986')
			1:
				for j in range(3):
					var v=p+Vector3((j-1)*.18,.01,.88)
					cyl(v,Vector3(.14,.035,.1),'#eee4c9')
				for side in [-1,1]:
					var v=p+Vector3(side*.75,.04,.48)
					orb(v,Vector3(.25,.09,.22),'#90ae87')
					flower(v+Vector3(0,.06,0),.075,'#e9b5a1')
			2:
				for j in range(2):
					var a=float(i+j)*1.6; var v=p+Vector3(cos(a)*.87,.03,sin(a)*.8)
					ring(v,Vector3(.3,.055,.3),'#d4e8dc')
				for side in [-1,1]:
					var v=p+Vector3(side*.77,.06,-.38)
					orb(v,Vector3(.27,.03,.2),'#86b49c')
					if i%3==0: flower(v+Vector3(0,.03,0),.12,'#f0d1bd')
			3:
				star(p+Vector3(.68,.01,.5),.13,'#f2d596')
				star(p+Vector3(-.62,.01,-.62),.08,'#f5e7cd')
	for side in [-1,1]:
		var p=footprint(Vector3(side*3.35,.47,-2.01))
		# Turned lamp posts frame the back, with pearly bulbs and brass collars.
		cyl(p+Vector3(0,.04,0),Vector3(.28,.08,.28),'#d0b28b')
		cyl(p+Vector3(0,.49,0),Vector3(.055,.9,.055),'#b09579')
		cyl(p+Vector3(0,.94,0),Vector3(.24,.065,.24),'#e5bf77')
		orb(p+Vector3(0,1.06,0),Vector3(.26,.27,.26),'#fff3ca')
		part('cone',p+Vector3(0,1.24,0),Vector3(.27,.1,.27),COLORS[game.active])
		if game.active==2:
			for j in range(5):
				var v=footprint(Vector3(side*(3.72+j*.07),.48,-1.22))
				cyl(v+Vector3(0,.19+j*.025,0),Vector3(.025,.4+j*.05,.025),'#719b89')
				orb(v+Vector3(0,.42+j*.05,0),Vector3(.075,.19,.075),'#b5a47d')
		elif game.active==1:
			var v=footprint(Vector3(side*3.75,.5,-1.0))
			box(v+Vector3(0,.07,0),Vector3(.45,.14,.35),'#bc9778')
			for j in range(4): flower(v+Vector3((j-1.5)*.09,.19,0),.09,'#f5c285')
		elif game.active==3:
			var v=footprint(Vector3(side*3.88,.53,-1.0))
			for j in range(3): orb(v+Vector3((j-1)*.16,.02,0),Vector3(.3,.18,.3),'#eee6e2')
		else:
			var v=footprint(Vector3(side*3.7,.51,-1.1))
			for j in range(3):
				cyl(v+Vector3((j-1)*.12,.15,0),Vector3(.02,.3,.02),'#7d9c85')
				flower(v+Vector3((j-1)*.12,.32,0),.12,'#f5dfab')
	finish(landscape_accents)
	# A pair of speaker carriages follow the same curved track as the engine.
	for n in wagons: n.queue_free()
	wagons=[]
	for j in range(2):
		var node=Node3D.new(); add_child(node); wagons.append(node); var m=child_mesh(node); begin()
		box(Vector3(0,.16,0),Vector3(.48,.24,.48),COLORS[(game.active+j)%4])
		box(Vector3(0,.34,0),Vector3(.39,.18,.32),'#f7e2b5')
		for x in [-.25,.25]:
			cyl(Vector3(x,.06,0),Vector3(.19,.08,.19),'#56677b',Vector3(0,0,PI/2))
		cyl(Vector3(0,.34,.17),Vector3(.19,.02,.19),'#67778a',Vector3(PI/2,0,0))
		orb(Vector3(0,.34,.185),Vector3(.08,.08,.025),'#f3d7a1')
		finish(m)

func build_expression(i,p):
	var face=faces[i]; var gesture=gestures[i]
	for n in face.get_children(): n.queue_free()
	for n in gesture.get_children(): n.queue_free()
	face.position=Vector3.ZERO; gesture.position=Vector3.ZERO
	if game.active!=1:
		face.position=[Vector3(0,.31,.51),Vector3.ZERO,Vector3(0,.59,.32),Vector3(0,.61,.3)][game.active]
		var m=child_mesh(face); begin()
		for side in [-1,1]:
			var x=side*(.24 if game.active==2 else (.12 if game.active==3 else .2))
			var r=.17 if game.active==2 else .13
			orb(Vector3(x,0,0),Vector3(r,r*1.08,.055),'#fff6dc')
			orb(Vector3(x+.013,-.009,.031),Vector3(r*.47,r*.58,.035),'#384b59')
			orb(Vector3(x+.002,.014,.051),Vector3(r*.15,r*.15,.012),'#fff9e8')
		finish(m)
	var m=child_mesh(gesture); begin()
	match game.active:
		0:
			gesture.position=Vector3(.28,.32,-.22)
			for j in range(2):
				box(Vector3(j*.1,.28,0),Vector3(.045,.65,.045),'#b7895f',Vector3(0,0,-.32+j*.5))
				orb(Vector3(-.11+j*.27,.59,0),Vector3(.14,.15,.14),'#fff0cc')
		1:
			var height=.4+float(p)*.13+float(i%2)*.06
			for x in [-.24,.24]:
				box(Vector3(x,height*.58,.372),Vector3(.12,.16,.01),'#f8da8a' if p>0 else '#b5c7c3')
				box(Vector3(x,height*.58,.382),Vector3(.012,.16,.012),'#f7ebc5')
		2:
			gesture.position=Vector3(0,.26,.32)
			orb(Vector3.ZERO,Vector3(.35,.13,.13),'#dce3b8')
			orb(Vector3(0,.064,.07),Vector3(.22,.025,.025),'#496e66')
		3:
			gesture.position=Vector3(.38,.61,.05)
			orb(Vector3(.07,0,0),Vector3(.24,.12,.14),'#bcaad5')
			cyl(Vector3(.2,-.1,.03),Vector3(.025,.2,.025),'#dab97b')
			part('cone',Vector3(.2,-.24,.03),Vector3(.24,.22,.24),'#f4c86f')
			orb(Vector3(.2,-.35,.03),Vector3(.08,.08,.08),'#a77f5a')
	finish(m)

func emit_note(i):
	if fx.size()>=36: return
	var key=str(game.active)
	if not note_shapes.has(key):
		var old=surface; begin()
		orb(Vector3(-.08,0,0),Vector3(.16,.1,.13),COLORS[game.active])
		box(Vector3(-.015,.18,0),Vector3(.035,.36,.035),COLORS[game.active])
		box(Vector3(.09,.32,0),Vector3(.22,.055,.035),COLORS[game.active],Vector3(0,0,-.2))
		orb(Vector3(.18,-.04,0),Vector3(.16,.1,.13),COLORS[game.active])
		box(Vector3(.245,.14,0),Vector3(.035,.36,.035),COLORS[game.active])
		note_shapes[key]=surface.commit(); surface=old
	var n=MeshInstance3D.new(); n.mesh=note_shapes[key]; n.material_override=material; n.position=toy_position(i)+Vector3(.18,1.05,0); n.rotation.y=.2; add_child(n)
	fx.append({'n':n,'v':Vector3(.12,.6,-.04),'life':1.25})

func animate(dt):
	time+=dt
	for i in range(8):
		velocities[i]+=(-springs[i]*65-velocities[i]*7)*dt
		springs[i]+=velocities[i]*dt
		var s=springs[i]
		toys[i].scale=Vector3(1-s*.3,1+s,1-s*.3)
		toys[i].rotation.z=sin(time*4+i)*s*.3
		toys[i].position=toy_position(i)+Vector3(0,.13+maxf(0,s*.25),0)
		var blink=absf(sin(time*.47+i*1.71))<.055
		faces[i].scale.y=.12 if blink else 1
		if game.active==0: gestures[i].rotation.z=-.18-maxf(0,s)*1.5
		elif game.active==1: gestures[i].scale=Vector3.ONE*(1+maxf(0,s)*.1)
		elif game.active==2: gestures[i].scale=Vector3(1,1+maxf(0,s)*3.5,1+maxf(0,s)*.8)
		else: gestures[i].rotation.z=sin(time*2+i)*.14+s*.5
		halos[i].position=toy_position(i)+Vector3(0,.14,0)
		halos[i].scale=Vector3(1.5+maxf(0,s)*1.2,.12,1.5+maxf(0,s)*1.2)
		halo_mats[i].albedo_color=Color(1,.89,.57,clampf(s*1.4,0,.7))
		halos[i].visible=s>.012
	var rate=.28 if game.playing else .06
	var a=time*rate
	for j in range(wagons.size()):
		var b=a-.23*(j+1); wagons[j].position=footprint(Vector3(cos(b)*4.48,.5,sin(b)*2.5)); wagons[j].rotation.y=atan2(cos(b)*2.5,-sin(b)*4.48) if narrow else atan2(-sin(b)*4.48,cos(b)*2.5)
	smoke_clock+=dt
	if smoke_clock>.5 and game.playing and fx.size()<36:
		smoke_clock=0
		var puff=MeshInstance3D.new(); puff.mesh=primitive('sphere'); puff.material_override=material; puff.scale=Vector3.ONE*.1; puff.position=train.position+Vector3(0,.9,0); add_child(puff); fx.append({'n':puff,'v':Vector3(-.1,.45,-.04),'life':1.2})
	train.position=footprint(Vector3(cos(a)*4.48,.5,sin(a)*2.5)); train.rotation.y=atan2(cos(a)*2.5,-sin(a)*4.48) if narrow else atan2(-sin(a)*4.48,cos(a)*2.5)
	conductor.rotation.z=sin(time*(game.bpm/60.0)*PI)*(.08 if game.playing else .02)
	arm.rotation.z=sin(time*game.bpm/60.0*TAU)*.35 if game.playing else -.3
	if reward>0:
		reward-=dt
		if fx.size()<36 and int(time*40)%2==0:
			var n=MeshInstance3D.new(); n.material_override=material; n.mesh=primitive('sphere'); n.scale=Vector3.ONE*.08; n.position=Vector3(randf_range(-3,3),2.5,randf_range(-1.5,1.5)); add_child(n); fx.append({'n':n,'v':Vector3(randf_range(-.4,.4),randf_range(.3,1.2),randf_range(-.4,.4)),'life':1.5})
	for i in range(fx.size()-1,-1,-1):
		var f=fx[i]; f.life-=dt; f.n.position+=f.v*dt; f.n.scale*=pow(.7,dt); f.n.rotation.y+=dt*1.4
		if f.life<=0: f.n.queue_free(); fx.remove_at(i)
