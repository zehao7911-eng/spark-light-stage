extends Node3D
var game
var camera:Camera3D
var sun:DirectionalLight3D
var env:Environment
var surface:SurfaceTool
var material:StandardMaterial3D
var stage:MeshInstance3D
var toys=[]
var springs=[]
var velocities=[]
var base_heights=[]
var train:Node3D
var conductor:Node3D
var arm:Node3D
var fx=[]
var time=0.0
var reward=0.0
var narrow=false
var primitive_cache={}
const COLORS=['#f1aa4d','#f27f69','#77bba9','#a494d4']

func _ready():
	material=StandardMaterial3D.new(); material.vertex_color_use_as_albedo=true; material.roughness=.68
	material.cull_mode=BaseMaterial3D.CULL_DISABLED; material.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
	var we=WorldEnvironment.new(); env=Environment.new(); env.background_mode=Environment.BG_COLOR; env.background_color=Color('#a9c9db'); env.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR; env.ambient_light_color=Color('#e5efff'); env.ambient_light_energy=.5; we.environment=env; add_child(we)
	sun=DirectionalLight3D.new(); sun.rotation_degrees=Vector3(-55,-35,0); sun.light_color=Color('#fff0d9'); sun.light_energy=.9; sun.shadow_enabled=false; sun.directional_shadow_max_distance=25; add_child(sun)
	camera=Camera3D.new(); camera.projection=Camera3D.PROJECTION_ORTHOGONAL; camera.near=.1; camera.far=80; add_child(camera); camera.make_current()
	stage=MeshInstance3D.new(); stage.material_override=material; add_child(stage)
	for i in range(8):
		var node=Node3D.new(); var body=MeshInstance3D.new(); body.material_override=material; node.add_child(body); add_child(node); toys.append(node); springs.append(0.0); velocities.append(0.0)
	train=Node3D.new(); add_child(train); conductor=Node3D.new(); add_child(conductor); arm=Node3D.new(); conductor.add_child(arm)
	update_camera()

func update_camera():
	if not camera: return
	var is_narrow=game.css_size.x<600
	if narrow!=is_narrow:
		narrow=is_narrow; rebuild()
	var aspect=float(game.world.size.x)/maxf(1,game.world.size.y)
	var size=maxf(8.0,6.5/aspect) if narrow else maxf(5.9,10.6/aspect)
	camera.size=size
	camera.position=Vector3(1.2,10,15) if narrow else Vector3(3.0,8.8,13.0); camera.look_at(Vector3(0,.1,0),Vector3.UP)
	sun.shadow_enabled=game.css_size.x>=900

func primitive(kind):
	if primitive_cache.has(kind): return primitive_cache[kind]
	var mesh
	match kind:
		'box': mesh=BoxMesh.new(); mesh.size=Vector3.ONE
		'sphere': mesh=SphereMesh.new(); mesh.radius=.5; mesh.height=1; mesh.radial_segments=16; mesh.rings=8
		'cylinder': mesh=CylinderMesh.new(); mesh.top_radius=.5; mesh.bottom_radius=.5; mesh.height=1; mesh.radial_segments=24
		'cone': mesh=CylinderMesh.new(); mesh.top_radius=0; mesh.bottom_radius=.5; mesh.height=1; mesh.radial_segments=16
		'torus': mesh=TorusMesh.new(); mesh.inner_radius=.475; mesh.outer_radius=.5; mesh.rings=24; mesh.ring_segments=8
	primitive_cache[kind]=mesh; return mesh
func begin(): surface=SurfaceTool.new(); surface.begin(Mesh.PRIMITIVE_TRIANGLES)
func part(kind,p,scale_value,color,rot=Vector3.ZERO):
	var a=primitive(kind).surface_get_arrays(0); var vertices=a[Mesh.ARRAY_VERTEX]; var normals=a[Mesh.ARRAY_NORMAL]; var idx=a[Mesh.ARRAY_INDEX]
	var basis=Basis.from_euler(rot); var normal_basis=basis*Basis.from_scale(scale_value).inverse().transposed()
	for i in idx:
		var normal=(normal_basis*normals[i]).normalized()
		var light=.76+maxf(0,normal.dot(Vector3(-.35,.8,.48).normalized()))*.24
		surface.set_color(Color(color)*light); surface.set_normal(normal); surface.add_vertex(p+basis*(vertices[i]*scale_value))
func box(p,s,c,rot=Vector3.ZERO): part('box',p,s,c,rot)
func orb(p,s,c): part('sphere',p,s,c)
func cyl(p,s,c,rot=Vector3.ZERO): part('cylinder',p,s,c,rot)
func ring(p,s,c,rot=Vector3.ZERO): part('torus',p,s,c,rot)
func finish(target): target.mesh=surface.commit()
func child_mesh(parent):
	var m=MeshInstance3D.new(); m.material_override=material; parent.add_child(m); return m
func toy_position(i):
	return Vector3((i%2-.5)*2.05,.48,(int(i/2)-1.5)*1.85) if narrow else Vector3((i%4-1.5)*2.05,.48,(-.95 if i<4 else 1.05))
func footprint(v): return Vector3(v.z,v.y,v.x) if narrow else v

func rebuild():
	if not stage: return
	var bg=['#a9c9db','#b4a7ce','#e7b6b8'][game.theme]; env.background_color=Color(bg)
	begin()
	# A hand-sized oval music island, with layered wood and ceramic edges.
	cyl(Vector3(0,-.18,0),footprint(Vector3(10.3,.18,6.3)),'#83a4bb')
	cyl(Vector3(0,.03,0),footprint(Vector3(10.05,.48,6.05)),'#b76c54')
	cyl(Vector3(0,.24,0),footprint(Vector3(10.1,.1,6.1)),'#f0c694')
	cyl(Vector3(0,.32,0),footprint(Vector3(9.9,.12,5.9)),'#fff0d3')
	cyl(Vector3(0,.4,0),footprint(Vector3(9.65,.08,5.65)),['#e8d4aa','#dcccd5','#ecd3c6'][game.theme])
	for i in range(48):
		var a=TAU*i/48; var p=footprint(Vector3(cos(a)*4.48,.46,sin(a)*2.5))
		box(p,Vector3(.18,.06,.1),'#ceaa82',Vector3(0,-a,0))
	for k in [1.0,1.035]: ring(Vector3(0,.47,0),footprint(Vector3(9.25*k,.13,5.15*k)),'#7d8b91')
	for i in range(8):
		var p=toy_position(i)
		cyl(p+Vector3(0,-.015,0),Vector3(1.65,.06,1.65),'#c5bba8')
		cyl(p+Vector3(0,.02,0),Vector3(1.6,.1,1.6),'#fff7e3')
		cyl(p+Vector3(0,.075,0),Vector3(1.46,.03,1.46),COLORS[game.active])
		for j in range(6):
			var a=TAU*j/6
			orb(p+Vector3(cos(a)*.7,.12,sin(a)*.7),Vector3(.055,.03,.055),'#fff5d4')
	# Tiny flowering corners, peg feet and moulded screws.
	for x in [-3.9,3.9]:
		for z in [-1.9,1.9]:
			cyl(footprint(Vector3(x,.64,z)),Vector3(.3,.35,.3),'#dc9c74')
			for j in range(3):
				orb(footprint(Vector3(x+(j-1)*.12,.92+abs(j-1)*.04,z)),Vector3(.23,.36,.23),'#669c8a')
	for x in [-3.5,3.5]:
		cyl(footprint(Vector3(x,-.32,.4)),Vector3(.75,.5,.75),'#8a5749')
	finish(stage)
	for i in range(8): rebuild_toy(i)
	for n in train.get_children(): n.queue_free()
	var trainmesh=child_mesh(train); begin()
	box(Vector3(0,.23,0),Vector3(.54,.4,.65),'#ec7962'); box(Vector3(0,.52,-.16),Vector3(.52,.22,.34),'#ffda75'); box(Vector3(0,.39,-.345),Vector3(.32,.19,.015),'#40556b')
	cyl(Vector3(0,.25,.35),Vector3(.35,.52,.35),'#e8ad51',Vector3(PI/2,0,0)); cyl(Vector3(0,.52,.36),Vector3(.13,.19,.13),'#485b68')
	for x in [-.3,.3]:
		for z in [-.2,.26]: cyl(Vector3(x,.05,z),Vector3(.22,.12,.22),'#42546a',Vector3(0,0,PI/2))
	finish(trainmesh)
	for n in conductor.get_children():
		if n!=arm: n.queue_free()
	var cm=child_mesh(conductor); begin()
	orb(Vector3(0,.2,0),Vector3(.65,.55,.58),'#f7c568'); orb(Vector3(-.19,.45,.04),Vector3(.2,.3,.2),'#f7c568'); orb(Vector3(.19,.45,.04),Vector3(.2,.3,.2),'#f7c568')
	for x in [-.13,.13]:
		orb(Vector3(x,.3,.27),Vector3(.15,.18,.08),'#fff6e3'); orb(Vector3(x,.29,.31),Vector3(.075,.1,.05),'#3e4559')
	orb(Vector3(0,.14,.29),Vector3(.1,.04,.045),'#ae6255')
	cyl(Vector3(0,.53,0),Vector3(.42,.12,.42),'#637da2'); cyl(Vector3(0,.61,0),Vector3(.27,.12,.27),'#637da2')
	finish(cm)
	for n in arm.get_children(): n.queue_free()
	var am=child_mesh(arm); begin(); orb(Vector3(.42,.22,.04),Vector3(.3,.13,.15),'#f7c568'); box(Vector3(.55,.37,.05),Vector3(.035,.4,.035),'#fff5de',Vector3(0,0,-.3)); finish(am)
	conductor.position=Vector3(-.2,.51,4.24 if narrow else 2.25)

func rebuild_toy(i):
	var p=int(game.patterns[game.active][i]); var body=toys[i].get_child(0)
	toys[i].position=toy_position(i)+Vector3(0,.13,0)
	begin(); var c=Color(COLORS[game.active]); var off=p==0
	var accent=c.darkened(.28) if off else c
	var height=.3+float(p)*.14
	match game.active:
		0:
			cyl(Vector3(0,.22,0),Vector3(1.02,.4,1.02),accent)
			ring(Vector3(0,.04,0),Vector3(1.1,.4,1.1),'#e29543'); ring(Vector3(0,.43,0),Vector3(1.12,.36,1.12),'#faf0d5')
			cyl(Vector3(0,.445,0),Vector3(.86,.035,.86),'#f8d67e' if not off else '#cfbb94')
			for j in range(8):
				var a=TAU*j/8; box(Vector3(cos(a)*.5,.23,sin(a)*.5),Vector3(.055,.32,.055),'#fff0d2')
			for x in [-.2,.2]:
				orb(Vector3(x,.3,.48),Vector3(.16,.16,.08),'#fff4d8'); orb(Vector3(x,.3,.522),Vector3(.075,.08,.04),'#4e4c59')
			if p>0:
				for j in range(p): orb(Vector3((j-(p-1)*.5)*.15,.49,.09),Vector3(.08,.025,.08),'#fff8e8')
		1:
			box(Vector3(0,height*.5,0),Vector3(.76,height,.68),'#d6b09d' if off else '#fff2d3')
			# Sloping roof with a ridge, overhang, moulded chimney.
			for sign_value in [-1,1]: box(Vector3(sign_value*.22,height+.12,0),Vector3(.52,.12,.87),accent,Vector3(0,0,sign_value*-.48))
			box(Vector3(.2,height+.27,-.16),Vector3(.14,.32,.16),'#deb49a')
			box(Vector3(0,.17,.35),Vector3(.16,.32,.025),'#638a94')
			for x in [-.24,.24]:
				box(Vector3(x,height*.58,.35),Vector3(.16,.2,.035),'#6f839b' if off else '#f2bf58'); box(Vector3(x,height*.58,.374),Vector3(.018,.2,.018),'#fff8e5')
			for z in [-.17,.17]: box(Vector3(.39,height*.6,z),Vector3(.02,.18,.16),'#7894a3')
			cyl(Vector3(0,.025,.47),Vector3(.7,.04,.23),'#d9b99f')
		2:
			cyl(Vector3(0,.025,0),Vector3(1.15,.05,1.15),'#6f9ca6'); orb(Vector3(0,.14,0),Vector3(1,.12,1),'#9bc8bd')
			orb(Vector3(0,.33,0),Vector3(.85,.47,.7),accent)
			for x in [-.24,.24]:
				orb(Vector3(x,.57,.15),Vector3(.3,.3,.28),accent); orb(Vector3(x,.59,.29),Vector3(.2,.2,.075),'#fff6d9'); orb(Vector3(x,.59,.332),Vector3(.09,.12,.035),'#3e4b53'); orb(Vector3(x*1.5,.17,.33),Vector3(.27,.12,.24),accent)
			orb(Vector3(0,.27,.35),Vector3(.25,.055+.035*p,.055),'#4a7470')
			for j in range(3):
				var a=j*.7; orb(Vector3(-.4+j*.17,.39,.03),Vector3(.09,.045,.09),'#c0df9f')
		3:
			cyl(Vector3(0,.06,0),Vector3(.7,.12,.7),'#8d85b0')
			for j in range(4): ring(Vector3(0,.14+j*.08,0),Vector3(.36,.18,.36),'#ddbc83')
			orb(Vector3(0,.6,0),Vector3(.68,.51,.58),accent)
			for x in [-.25,.25]: orb(Vector3(x,.55,0),Vector3(.42,.4,.45),accent)
			for x in [-.12,.12]: orb(Vector3(x,.61,.29),Vector3(.07,.1,.035),'#464761')
			orb(Vector3(0,.5,.28),Vector3(.09,.045,.04),'#f7d5cb')
			part('cone',Vector3(0,.96,0),Vector3(.35,.32,.35),'#ffcf74')
	# Three ivory pitches make state legible without relying on colour.
	for j in range(3):
		box(Vector3((j-1)*.18,.035,.64),Vector3(.12,.045,.08),'#fff5d9' if j<p else '#b5a293')
	finish(body)
func ping(i):
	velocities[i]=4.0
	if game.finale: velocities[i]=6.0
func celebrate(): reward=2.5

func animate(dt):
	time+=dt
	for i in range(8):
		velocities[i]+=(-springs[i]*65-velocities[i]*7)*dt
		springs[i]+=velocities[i]*dt
		var s=springs[i]
		toys[i].scale=Vector3(1-s*.3,1+s,1-s*.3)
		toys[i].rotation.z=sin(time*4+i)*s*.3
		toys[i].position=toy_position(i)+Vector3(0,.13+maxf(0,s*.25),0)
	var rate=.28 if game.playing else .06
	var a=time*rate
	train.position=footprint(Vector3(cos(a)*4.48,.5,sin(a)*2.5)); train.rotation.y=atan2(cos(a)*2.5,-sin(a)*4.48) if narrow else atan2(-sin(a)*4.48,cos(a)*2.5)
	conductor.rotation.z=sin(time*(game.bpm/60.0)*PI)*(.08 if game.playing else .02)
	arm.rotation.z=sin(time*game.bpm/60.0*TAU)*.35 if game.playing else -.3
	if reward>0:
		reward-=dt
		if fx.size()<36 and int(time*40)%2==0:
			var n=MeshInstance3D.new(); n.material_override=material; n.mesh=primitive('sphere'); n.scale=Vector3.ONE*.08; n.position=Vector3(randf_range(-3,3),2.5,randf_range(-1.5,1.5)); add_child(n); fx.append({'n':n,'v':Vector3(randf_range(-.4,.4),randf_range(.3,1.2),randf_range(-.4,.4)),'life':1.5})
	for i in range(fx.size()-1,-1,-1):
		var f=fx[i]; f.life-=dt; f.n.position+=f.v*dt; f.n.scale*=pow(.7,dt)
		if f.life<=0: f.n.queue_free(); fx.remove_at(i)
