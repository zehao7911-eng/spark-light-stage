extends Node2D
const LABELS=['Drum garden','Bell village','Bass pond','Cloud choir']
const PITCH=['rest','low','middle','high']
const IDEAS=[
 ['A little heartbeat','Add 3 drum beats.',0,0,[1,0,1,0,1,0,0,0]],
 ['Room to breathe','Drums on 1 & 5. Leave 2 & 6 quiet.',0,1,[1,0,0,0,2,0,0,0]],
 ['Hello, little houses','Add 3 bell notes.',1,0,[1,0,2,0,3,0,0,0]],
 ['Up the little stairs','Bells: low → middle → high on 1, 3, 5.',1,2,[1,0,2,0,3,0,0,0]],
 ['A dancing heartbeat','Drums on 1, 3, 5, 7. Quiet in between.',0,3,[1,0,2,0,1,0,3,0]],
 ['Something underneath','Add 2 bass notes.',2,0,[1,0,0,0,2,0,0,0]],
 ['A conversation','Bass low on 1, high on 5. Bells on 3 & 7.',2,4,[1,0,0,0,3,0,0,0]],
 ['A little question','Bells high on 2, middle on 4, low on 8.',1,5,[0,3,0,2,0,0,0,1]],
 ['Soft as a cloud','Add 2 choir notes.',3,0,[1,0,0,0,3,0,0,0]],
 ['Follow the moon','Choir low on 1, middle on 4, high on 7.',3,6,[1,0,0,2,0,0,3,0]],
 ['The whole neighbourhood','Every instrument needs at least 2 notes.',0,7,[1,0,2,0,1,0,2,0]],
 ['Your little finale','Use all 4 instruments. Turn on the finale!',0,8,[1,0,2,0,1,0,3,0]]
]
var patterns=[[1,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]]
var gains=[1.0,.8,.8,.6]
var muted_tracks=[false,false,false,false]
var active=0
var bpm=96
var beat=-1
var playing=false
var paused=true
var sound=true
var completed=0
var ready_claim=false
var mission_bars=0
var stable_steps=0
var theme=0
var finale=false
var edits=0
var saved_tapes=[]
var history=[]
var css_size=Vector2(1280,720)
var css_top=120.0
var css_bottom=212.0
var map_rect=Rect2()
var world:SubViewport
var island
var callback
var ticker=0.0
var local_clock=0.0
var notice='Tap the toys. Make a little noise.'
var event=0
var pulse_time=0.0

func _ready():
	world=SubViewport.new(); world.own_world_3d=true; world.size=Vector2i(1100,460); world.render_target_update_mode=SubViewport.UPDATE_ALWAYS; add_child(world)
	island=Node3D.new(); island.set_script(preload('island.gd')); island.game=self; world.add_child(island)
	restore(); island.rebuild()
	if OS.has_feature('web'):
		callback=JavaScriptBridge.create_callback(web_action); JavaScriptBridge.get_interface('window').tAction=callback
	if '--qa' in OS.get_cmdline_user_args(): verify()

func unlocked(): return 1 if completed<2 else (2 if completed<5 else (3 if completed<8 else 4))
func count_notes(track):
	var count=0
	for n in patterns[track]:
		if int(n)>0: count+=1
	return count
func fulfilled():
	if completed>=IDEAS.size(): return false
	var goal=IDEAS[completed]; var a=patterns[int(goal[2])]
	match int(goal[3]):
		0: return count_notes(int(goal[2]))>=int(3 if completed<5 else 2)
		1: return int(a[0])>0 and int(a[4])>0 and int(a[1])==0 and int(a[5])==0
		2: return int(a[0])==1 and int(a[2])==2 and int(a[4])==3
		3: return int(a[0])>0 and int(a[2])>0 and int(a[4])>0 and int(a[6])>0 and int(a[1])+int(a[3])+int(a[5])+int(a[7])==0
		4: return not muted_tracks[1] and int(a[0])==1 and int(a[4])==3 and int(patterns[1][2])>0 and int(patterns[1][6])>0
		5: return int(a[1])==3 and int(a[3])==2 and int(a[7])==1
		6: return int(a[0])==1 and int(a[3])==2 and int(a[6])==3
		7,8:
			for i in range(4):
				if count_notes(i)<2 or muted_tracks[i]: return false
			return finale if int(goal[3])==8 else true
	return false

func checkpoint(): return {'patterns':patterns.duplicate(true),'gains':gains.duplicate(),'tracks':muted_tracks.duplicate(),'bpm':bpm,'active':active,'theme':theme,'finale':finale}
func apply(s):
	patterns=s.patterns.duplicate(true)
	for row in patterns:
		for i in range(8): row[i]=int(row[i])
	gains=s.gains.duplicate(); muted_tracks=s.tracks.duplicate(); bpm=clampi(int(s.bpm),72,132); active=clampi(int(s.active),0,unlocked()-1); theme=clampi(int(s.theme),0,2); finale=bool(s.finale)
	mission_bars=0; stable_steps=0
func remember():
	history.append(checkpoint())
	if history.size()>40: history.pop_front()
func tell(s): notice=s; event+=1
func tap(step,back=false):
	if step<0 or step>=8: return false
	remember(); var n=posmod(int(patterns[active][step])+(3 if back else 1),4); patterns[active][step]=n; edits+=1
	mission_bars=0; stable_steps=0; island.rebuild_toy(step)
	if n>0:
		island.ping(step); preview(active,n)
	tell(str(step+1)+' · '+PITCH[n]); save_game(); return true
func preview(track,note):
	if OS.has_feature('web'): JavaScriptBridge.eval('window.tPreview&&window.tPreview('+str(track)+','+str(note)+')')
func pulse(n):
	if paused or not playing: return
	beat=posmod(n,8); pulse_time=1
	var can_award=fulfilled() and not muted_tracks[int(IDEAS[completed][2])]
	stable_steps=stable_steps+1 if can_award else 0
	for i in range(8):
		if i==beat and int(patterns[active][i])>0 and not muted_tracks[active]: island.ping(i)
	if beat==7:
		if fulfilled() and not muted_tracks[int(IDEAS[completed][2])]:
			mission_bars+=1
			if stable_steps>=8 and not ready_claim: ready_claim=true; tell('A lovely little loop. Stamp earned!'); island.celebrate(); save_game()
		else: mission_bars=0
func claim():
	if not ready_claim or completed>=12: return false
	completed+=1; ready_claim=false; mission_bars=0; stable_steps=0; history=[]
	if completed<12: active=int(IDEAS[completed][2])
	else: finale=false
	if completed in [2,5,8]: tell('A new instrument has arrived!')
	elif completed==12: tell('Your first album. Entirely yours.')
	else: tell('A new idea to play with.')
	island.rebuild(); save_game(); return true

func action(command):
	var p=command.split(':'); var n=int(p[1]) if p.size()>1 else 0
	match p[0]:
		'begin': paused=false; playing=true
		'view':
			if p.size()>=5: css_size=Vector2(maxi(240,n),maxi(240,int(p[2]))); css_top=float(p[3]); css_bottom=float(p[4])
		'tap': tap(n)
		'back': tap(n,true)
		'track':
			if n>=0 and n<unlocked(): active=n; island.rebuild(); save_game()
		'play': playing=not playing; save_game()
		'pulse': pulse(n)
		'pause': paused=n==1
		'tempo': remember(); bpm=clampi(bpm+n,72,132); save_game()
		'mute': sound=not sound; save_game()
		'solo': remember(); muted_tracks[active]=not muted_tracks[active]; stable_steps=0; save_game()
		'gain': remember(); gains[active]=.4 if float(gains[active])>.85 else (1.0 if float(gains[active])<.6 else .8); save_game()
		'clear': remember(); patterns[active]=[0,0,0,0,0,0,0,0]; mission_bars=0; stable_steps=0; island.rebuild(); save_game()
		'undo':
			if not history.is_empty(): apply(history.pop_back()); island.rebuild(); save_game()
		'claim': claim()
		'finale':
			if completed>=11: finale=not finale; save_game()
		'theme':
			if n>=0 and n<=2 and (n==0 or completed>=(4 if n==1 else 8)): theme=n; island.rebuild(); save_game()
		'save':
			if saved_tapes.size()<12:
				saved_tapes.append(checkpoint()); tell('Cassette '+str(saved_tapes.size())+' saved.'); save_game()
		'load':
			if n>=0 and n<saved_tapes.size(): remember(); apply(saved_tapes[n]); island.rebuild(); tell('Cassette '+str(n+1)+' is on the deck.'); save_game()
		'delete':
			if n>=0 and n<saved_tapes.size(): saved_tapes.remove_at(n); save_game()
		'variation':
			remember()
			for i in range(8): patterns[active][i]=int(patterns[active][i])%3+1 if i%2==0 else 0
			mission_bars=0; stable_steps=0; island.rebuild(); tell('A new starting point. Make it yours.'); save_game()
		'photo': photo()

func web_action(args):
	if args.size(): action(str(args[0]))
func _process(dt):
	var native=get_viewport_rect().size
	if not OS.has_feature('web'): css_size=native
	var f=native.x/css_size.x
	map_rect=Rect2(Vector2(0,css_top*f),Vector2(native.x,maxf(80,(css_size.y-css_top-css_bottom)*f)))
	world.size=Vector2i(int(minf(1280,map_rect.size.x)),int(minf(850,map_rect.size.y)))
	island.update_camera()
	if not paused:
		island.animate(dt); pulse_time=maxf(0,pulse_time-dt*2)
		if playing and not OS.has_feature('web'):
			local_clock+=dt
			if local_clock>=30.0/bpm: local_clock-=30.0/bpm; pulse(beat+1)
	ticker+=dt
	if ticker>=.12:
		ticker=0
		if OS.has_feature('web'): JavaScriptBridge.eval('window.tState&&window.tState('+JSON.stringify(snapshot())+')')
	queue_redraw()
func _draw():
	draw_rect(get_viewport_rect(),Color(['#a9c9db','#b4a7ce','#e7b6b8'][theme]))
	if world: draw_texture_rect(world.get_texture(),map_rect,false)
func snapshot():
	var spots=[]; var f=get_viewport_rect().size.x/css_size.x
	for i in range(8):
		var p=island.camera.unproject_position(island.toy_position(i)+Vector3(0,.7,0))
		p=map_rect.position+p*(map_rect.size/Vector2(world.size)); p/=f
		spots.append({'i':i,'x':p.x,'y':p.y})
	return {'patterns':patterns,'active':active,'bpm':bpm,'beat':beat,'playing':playing,'paused':paused,'sound':sound,'completed':completed,'ready':ready_claim,'fulfilled':fulfilled(),'unlocked':unlocked(),'gains':gains,'tracks':muted_tracks,'theme':theme,'finale':finale,'tapes':saved_tapes,'history':history.size(),'goal':IDEAS[mini(completed,11)],'notice':notice,'event':event,'spots':spots,'map':{'y':map_rect.position.y/f,'h':map_rect.size.y/f}}

func valid(s):
	if not s is Dictionary: return false
	for k in ['patterns','gains','tracks','bpm','active','theme','finale']:
		if not s.has(k): return false
	if not s.patterns is Array or s.patterns.size()!=4 or not s.gains is Array or s.gains.size()!=4 or not s.tracks is Array or s.tracks.size()!=4: return false
	for row in s.patterns:
		if not row is Array or row.size()!=8: return false
		for n in row:
			if not (n is float or n is int) or not is_finite(float(n)) or float(n)!=int(n) or int(n)<0 or int(n)>3: return false
	for n in s.gains:
		if not (n is float or n is int) or not is_finite(float(n)) or float(n)<0 or float(n)>1: return false
	for k in ['bpm','active','theme']:
		if not (s[k] is float or s[k] is int) or not is_finite(float(s[k])): return false
	return true
func save_game():
	var s=checkpoint(); s.completed=completed; s.ready=ready_claim; s.sound=sound; s.tapes=saved_tapes; s.edits=edits; s.history=history
	var data=JSON.stringify(s); var f=FileAccess.open('user://tiny-tape.json',FileAccess.WRITE)
	if f: f.store_string(data)
	if OS.has_feature('web'): JavaScriptBridge.eval('try{localStorage.setItem("tiny-tape.v1",'+JSON.stringify(data)+')}catch(e){}')
func restore():
	var data=''
	if OS.has_feature('web'): data=str(JavaScriptBridge.eval('(function(){try{return localStorage.getItem("tiny-tape.v1")||""}catch(e){return ""}})()'))
	elif FileAccess.file_exists('user://tiny-tape.json'): data=FileAccess.get_file_as_string('user://tiny-tape.json')
	if data.is_empty(): return false
	var s=JSON.parse_string(data)
	if not valid(s): return false
	completed=clampi(int(s.get('completed',0)),0,12); apply(s); ready_claim=bool(s.get('ready',false)) and completed<12; sound=bool(s.get('sound',true)); edits=maxi(0,int(s.get('edits',0)))
	saved_tapes=[]; history=[]
	for k in ['tapes','history']:
		var a=s.get(k,[])
		if a is Array:
			for v in a:
				if valid(v):
					if k=='tapes' and saved_tapes.size()<12: saved_tapes.append(v)
					elif k=='history' and history.size()<40: history.append(v)
	return true
func photo():
	await RenderingServer.frame_post_draw
	if OS.has_feature('web'): JavaScriptBridge.eval('window.tPhoto('+JSON.stringify(Marshalls.raw_to_base64(world.get_texture().get_image().save_png_to_buffer()))+')')
func verify():
	assert(unlocked()>=1)
	for c in range(12):
		completed=c; active=int(IDEAS[c][2]); patterns[active]=IDEAS[c][4].duplicate(); muted_tracks=[false,false,false,false]
		if c==6: patterns[1][2]=1; patterns[1][6]=2
		if c>=10:
			for i in range(4): patterns[i]=[1,0,2,0,0,0,0,0]
		if c==11: finale=true
		assert(fulfilled(),'Goal '+str(c))
		playing=true; paused=false; ready_claim=false; stable_steps=0
		for b in range(8): pulse(b)
		assert(ready_claim); assert(claim()); assert(not claim())
	assert(completed==12 and unlocked()==4)
	assert(valid(JSON.parse_string(JSON.stringify(checkpoint()))))
	print('TINY TAPE QA PASS: 12 goals, audible-loop gate, claim guard, unlocks, JSON schema')
	get_tree().quit()
