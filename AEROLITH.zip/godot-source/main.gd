extends Node2D
const Race=preload('res://race.gd')
const World=preload('res://world.gd')
const IconButton=preload('res://icon_button.gd')
const Bar=preload('res://bar.gd')
const SAVE='aerolith.v1'
const INK=Color('#eff6ed')
const GOLD=Color('#edcd92')
var g=Race.new()
var vp:SubViewport
var world
var image:TextureRect
var ui:Control
var raw=Vector2.ZERO
var view=Vector2.ZERO
var safe=Vector2.ZERO
var buttons=[]
var labels={}
var bars={}
var last_stage=''
var left=false
var right=false
var drag=false
var last_x=0.0
var hidden_=false
var hidden_stage=''
var callback
var accumulator=0.0
var snapshot_clock=0.0
var save_clock=0.0
var event_sound:AudioStreamPlayer
var motor:AudioStreamPlayer
var flash_caption=''
var caption_until=0.0
var redraw_frames=3
func _ready():
	Engine.max_fps=45;load_game()
	if g.stage in ['race','countdown']:g.pause()
	vp=SubViewport.new();vp.own_world_3d=true;vp.msaa_3d=Viewport.MSAA_2X;vp.render_target_update_mode=SubViewport.UPDATE_ALWAYS;add_child(vp);world=World.new();world.g=g;vp.add_child(world)
	image=TextureRect.new();image.expand_mode=TextureRect.EXPAND_IGNORE_SIZE;image.stretch_mode=TextureRect.STRETCH_SCALE;image.texture_filter=CanvasItem.TEXTURE_FILTER_LINEAR;image.texture=vp.get_texture();image.mouse_filter=Control.MOUSE_FILTER_IGNORE;add_child(image)
	ui=Control.new();ui.mouse_filter=Control.MOUSE_FILTER_IGNORE;add_child(ui)
	event_sound=AudioStreamPlayer.new();event_sound.stream=load('res://audio/ping.wav');event_sound.volume_db=-19;add_child(event_sound)
	motor=AudioStreamPlayer.new();motor.stream=load('res://audio/engine.wav');motor.stream.loop_mode=AudioStreamWAV.LOOP_FORWARD;motor.stream.loop_end=22050;motor.volume_db=-28;add_child(motor)
	layout();world.update(0.0)
	if OS.has_feature('web'):
		callback=JavaScriptBridge.create_callback(lifecycle);JavaScriptBridge.get_interface('window').aeroLifecycle=callback;JavaScriptBridge.eval('window.aeroReady && window.aeroReady()')
	web_snapshot()
func style(bg,border=Color('#627d86'),radius=18):
	var b=StyleBoxFlat.new();b.bg_color=bg;b.border_color=border;b.set_border_width_all(1);b.set_corner_radius_all(radius);b.content_margin_left=14;b.content_margin_right=14;return b
func panel(rect):
	var c=Panel.new();c.position=rect.position;c.size=rect.size;c.add_theme_stylebox_override('panel',style(Color(.055,.13,.18,.94),Color('#667f87'),26));c.mouse_filter=Control.MOUSE_FILTER_IGNORE;ui.add_child(c)
func label_(key,text,p,size_,font_size=16,color_=INK,align=HORIZONTAL_ALIGNMENT_LEFT):
	var l=Label.new();l.text=text;l.position=p;l.size=size_;l.add_theme_font_size_override('font_size',font_size);l.add_theme_color_override('font_color',color_);l.horizontal_alignment=align;l.vertical_alignment=VERTICAL_ALIGNMENT_CENTER;l.mouse_filter=Control.MOUSE_FILTER_IGNORE;ui.add_child(l);labels[key]=l;return l
func button(text,p,size_,action,accent=false):
	var b=IconButton.new() if text.begins_with('@') else Button.new();b.text='' if text.begins_with('@') else text
	if text.begins_with('@'):b.symbol=text.trim_prefix('@');b.tooltip_text=b.symbol
	b.position=p;b.size=size_;b.add_theme_font_size_override('font_size',16);b.add_theme_color_override('font_color',Color('#142e3b') if accent else INK);b.add_theme_stylebox_override('normal',style(GOLD if accent else Color(.08,.19,.25,.95),GOLD if accent else Color('#779599')));b.add_theme_stylebox_override('hover',style(Color('#a9dbd2'),Color('#e2f8eb')));b.add_theme_stylebox_override('pressed',style(Color('#6ba8a8'),GOLD));b.pressed.connect(action,CONNECT_DEFERRED);ui.add_child(b);buttons.append(b);return b
func progress(key,p,size_,color_):
	var b=Bar.new();b.position=p;b.size=size_;b.tint=color_;b.mouse_filter=Control.MOUSE_FILTER_IGNORE;ui.add_child(b);bars[key]=b
func layout():
	if not is_instance_valid(ui):return
	raw=get_viewport_rect().size;safe=Vector2.ZERO;view=raw
	if OS.has_feature('web'):
		var insets=JSON.parse_string(str(JavaScriptBridge.eval('JSON.stringify(window.aeroInsets ? window.aeroInsets() : [0,0,0,0])')))
		if insets is Array and insets.size()==4:safe=Vector2(insets[0],insets[1]);view=raw-safe-Vector2(insets[2],insets[3])
	var cap=960.0 if raw.y>raw.x else 1280.0;vp.size=Vector2i((raw*minf(1,cap/maxf(raw.x,raw.y))).round());world.size_=Vector2(vp.size);image.size=raw
	for c in ui.get_children():c.free()
	redraw_frames=3
	if g.stage=='paused':world.initialized=false
	ui.position=safe;buttons=[];labels={};bars={};last_stage=g.stage
	var w=view.x;var h=view.y
	label_('brand','A E R O L I T H',Vector2(20,14),Vector2(220,26),16,GOLD)
	label_('course',Race.Course.NAMES[int(g.profile.selected)],Vector2(20,40),Vector2(230,20),11,Color('#bed6d5'))
	button(('@pause' if g.stage in ['race','countdown'] else ('@play' if g.stage=='paused' else ('@sound' if not g.profile.muted else '@muted'))),Vector2(w-65,15),Vector2(46,46),toggle_pause)
	if g.stage in ['race','countdown']:
		label_('lap','01 / 02',Vector2(20,76),Vector2(130,30),22)
		label_('time','00:00.00',Vector2(w-155,74),Vector2(135,30),20,INK,HORIZONTAL_ALIGNMENT_RIGHT)
		progress('distance',Vector2(20,113),Vector2(w-40,3),GOLD)
		label_('rank','01',Vector2(20,127),Vector2(90,39),32,GOLD)
		label_('rank_tag','POSITION',Vector2(22,163),Vector2(90,17),9,Color('#c0d7d8'))
		label_('cue','',Vector2(18,maxf(170,h*.28)),Vector2(w-36,38),21,GOLD,HORIZONTAL_ALIGNMENT_CENTER)
		label_('speed','000',Vector2(20,h-172),Vector2(130,54),42)
		label_('speed_tag','KM/H',Vector2(24,h-119),Vector2(100,20),10,Color('#bfd4d7'))
		progress('shield',Vector2(24,h-91),Vector2(116,6),Color('#bde3c6'))
		var l=button('<',Vector2(20,h-72),Vector2(53,52),func():pass);var r=button('>',Vector2(81,h-72),Vector2(53,52),func():pass)
		l.button_down.connect(func():left=true);l.button_up.connect(func():left=false);r.button_down.connect(func():right=true);r.button_up.connect(func():right=false)
		button('BOOST',Vector2(w-116,h-102),Vector2(96,82),boost,true);progress('energy',Vector2(w-114,h-116),Vector2(92,6),Color('#81ecdd'))
		if g.stage=='countdown':label_('count','3',Vector2(w*.5-70,h*.43-70),Vector2(140,140),80,GOLD,HORIZONTAL_ALIGNMENT_CENTER)
	elif g.stage=='paused':
		var pw=minf(w-32,420);var x=(w-pw)*.5;var y=maxf(94,(h-260)*.5);panel(Rect2(x,y,pw,260))
		label_('pause','FLIGHT PAUSED',Vector2(x+20,y+20),Vector2(pw-40,45),25,GOLD,HORIZONTAL_ALIGNMENT_CENTER)
		button('Continue',Vector2(x+20,y+89),Vector2(pw-40,48),resume,true);button('Restart',Vector2(x+20,y+147),Vector2((pw-50)*.5,48),launch);button('Sound '+('Off' if g.profile.muted else 'On'),Vector2(x+30+(pw-50)*.5,y+147),Vector2((pw-50)*.5,48),mute)
	else:
		var result=g.stage=='result';var compact=h<560;var ph=(286.0 if result else 270.0) if compact else (346.0 if result else 304.0);var pw=minf(470,w-32);var x=(w-pw)*.5;var y=maxf(80 if compact else 93,h-ph-(12 if compact else 22))
		panel(Rect2(x,y,pw,ph));label_('title','CIRCUIT CLEAR' if result and g.won else ('SHIP RECOVERED' if result else 'TOUCH THE SKY'),Vector2(x+20,y+16),Vector2(pw-40,35),22 if compact else 26,GOLD,HORIZONTAL_ALIGNMENT_CENTER)
		var detail=(str(g.stars)+' / 3 STARS   '+time_text(g.elapsed)) if result and g.won else ('A new flight awaits.' if result else 'Slide to steer. Tap to boost.')
		label_('detail',detail,Vector2(x+14,y+54),Vector2(pw-28,30),15,INK,HORIZONTAL_ALIGNMENT_CENTER)
		label_('coins',('+'+str(g.reward)+'   CR   ' if result else 'CR   ')+str(int(g.profile.coins)),Vector2(x+20,y+90),Vector2(pw-40,26),20,GOLD,HORIZONTAL_ALIGNMENT_CENTER)
		var row=y+(109 if compact else 128);var gap=8.0;var bw=(pw-48)/3
		for i in range(3):
			var id=i;var text=['ATOLL','JADE','VIOLET'][i] if i<=g.profile.unlocked else '—';var b=button(text,Vector2(x+16+i*(bw+gap),row),Vector2(bw,44),func():choose(id),i==g.profile.selected);b.add_theme_font_size_override('font_size',13);b.reset_size();b.size=Vector2(bw,44);b.disabled=i>g.profile.unlocked
		var start_y=row+(50 if compact else 54)
		if result and g.won and g.profile.selected<2:button('Next circuit',Vector2(x+16,start_y),Vector2(pw-32,49),next_course,true)
		else:button('Launch' if not result else 'Fly again',Vector2(x+16,start_y),Vector2(pw-32,49),launch,true)
		var cost=35+int(g.profile.engine)*30;var small=(pw-40)/2
		button('ENGINE '+('MAX' if g.profile.engine>=3 else str(cost)),Vector2(x+16,start_y+(56 if compact else 59)),Vector2(small,44),upgrade);button('PAINT '+('FREE' if g.profile.owned[(int(g.profile.paint)+1)%3] else '20'),Vector2(x+24+small,start_y+(56 if compact else 59)),Vector2(small,44),repaint)
		if result:label_('summary',str(g.gates)+' GATES   ·   '+str(g.hits)+' HITS   ·   #'+str(g.rank_()),Vector2(x+16,start_y+(103 if compact else 111)),Vector2(pw-32,23),11,Color('#b5cecf'),HORIZONTAL_ALIGNMENT_CENTER)
	update_hud()
func time_text(t):return '%02d:%05.2f'%[int(t/60),fposmod(t,60)]
func sound(kind):
	if g.profile.muted or hidden_:return
	event_sound.pitch_scale={'gate':1.25,'boost':.70,'hit':.30,'go':1.0,'finish':1.5,'wreck':.38}.get(kind,1.0);event_sound.play()
func launch():
	g.launch();clear_input();world.initialized=false;flash_caption='';sound('go');motor.play();save_game();layout()
func boost():
	if g.boost():sound('boost');flash_caption='OVERDRIVE';caption_until=g.clock+1.1
func choose(which):
	if g.select(which):world.build();save_game();layout()
func next_course():
	if g.select(mini(2,int(g.profile.selected)+1)):launch()
func upgrade():
	if g.upgrade():sound('gate');save_game();layout()
func repaint():
	if g.repaint():sound('gate');world.build();save_game();layout()
func mute():g.profile.muted=not g.profile.muted;save_game();layout();update_audio()
func toggle_pause():
	if g.stage=='paused':resume()
	elif g.stage in ['race','countdown']:g.pause();clear_input();save_game();layout();update_audio()
	else:mute()
func resume():g.resume();clear_input();if not g.profile.muted:motor.play()
func clear_input():left=false;right=false;drag=false
func update_audio():
	var active_=g.stage=='race' and not g.profile.muted and not hidden_
	motor.volume_db=-30+minf(1,g.speed/60)*5;motor.pitch_scale=.7+g.speed/60*.65
	if not active_:motor.stream_paused=true;event_sound.stream_paused=g.stage=='paused' or hidden_ or g.profile.muted
	else:motor.stream_paused=false;event_sound.stream_paused=false
func update_hud():
	if labels.has('lap'):
		labels.lap.text=('%02d / 02'%[mini(2,int(g.distance/g.course.total)+1)]);labels.time.text=time_text(g.elapsed);labels.rank.text='%02d'%g.rank_();labels.speed.text='%03d'%int(g.speed*5.6);bars.distance.value=g.distance/(g.course.total*2);bars.shield.value=g.shield/100;bars.energy.value=g.energy
		labels.cue.text=flash_caption if g.clock<caption_until else ('CHAIN ×'+str(g.combo) if g.combo>1 else '')
	if labels.has('count'):labels.count.text=str(maxi(1,int(ceil(g.countdown))))
func _process(dt):
	if get_viewport_rect().size!=raw:layout()
	if not hidden_:
		accumulator+=minf(dt,.1)
		while accumulator>=1.0/90.0:
			g.update(1.0/90.0,(1.0 if right else 0.0)-(1.0 if left else 0.0));accumulator-=1.0/90.0
			for e in g.events:
				sound(e)
				if e=='gate':flash_caption='GATE + ENERGY';caption_until=g.clock+.8;world.gate_flash=.6
				if e=='hit':flash_caption='SHIELD HIT';caption_until=g.clock+.9
		if g.stage!=last_stage:save_game();layout()
		if g.stage!='paused':world.update(minf(dt,.05));vp.render_target_update_mode=SubViewport.UPDATE_ALWAYS
		elif redraw_frames>0:world.update(0.0);vp.render_target_update_mode=SubViewport.UPDATE_ONCE;redraw_frames-=1
		else:vp.render_target_update_mode=SubViewport.UPDATE_DISABLED
	update_hud();update_audio();snapshot_clock+=dt;save_clock+=dt
	if snapshot_clock>.4:snapshot_clock=0;web_snapshot()
	if save_clock>4:save_clock=0;save_game()
func _input(e):
	if e is InputEventKey and not e.echo:
		if e.keycode in [KEY_LEFT,KEY_A]:left=e.pressed
		if e.keycode in [KEY_RIGHT,KEY_D]:right=e.pressed
		if e.pressed and e.keycode==KEY_SPACE:
			if g.stage in ['ready','result']:launch()
			elif g.stage=='paused':resume()
			else:boost()
		if e.pressed and e.keycode==KEY_ESCAPE:toggle_pause()
func _unhandled_input(e):
	if g.stage not in ['race','countdown'] or hidden_:return
	if e is InputEventMouseButton and e.button_index==MOUSE_BUTTON_LEFT:
		drag=e.pressed;last_x=e.position.x
	if e is InputEventMouseMotion and drag:g.target=clampf(g.target+(e.position.x-last_x)*9.0/maxf(250,view.x),-4.65,4.65);last_x=e.position.x
func lifecycle(args):
	var s=str(args[0]) if args.size()>0 else 'save';clear_input()
	if s=='away':hidden_=true;g.pause();layout();vp.render_target_update_mode=SubViewport.UPDATE_DISABLED
	if s=='back':hidden_=false
	save_game();update_audio()
func save_game():
	var text=JSON.stringify(g.snapshot())
	if OS.has_feature('web'):JavaScriptBridge.eval('(()=>{try{localStorage.setItem('+JSON.stringify(SAVE)+','+JSON.stringify(text)+')}catch(e){}})()')
	else:var f=FileAccess.open('user://aerolith.json',FileAccess.WRITE);if f:f.store_string(text)
func load_game():
	var text=''
	if OS.has_feature('web'):text=str(JavaScriptBridge.eval('(()=>{try{return localStorage.getItem('+JSON.stringify(SAVE)+') || ""}catch(e){return ""}})()'))
	elif FileAccess.file_exists('user://aerolith.json'):text=FileAccess.get_file_as_string('user://aerolith.json')
	if text!='':g.restore(JSON.parse_string(text))
func web_snapshot():
	if not OS.has_feature('web'):return
	var s=g.snapshot();s['view']=[raw.x,raw.y];s['render']=[vp.size.x,vp.size.y];s['revision']='aerolith-1';s['buttons']=[];s['diagnostics']={'fps':Engine.get_frames_per_second(),'cpu_ms':Performance.get_monitor(Performance.TIME_PROCESS)*1000,'draw_calls':Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME),'primitives':Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME)}
	for b in buttons:s.buttons.append([b.text if b.text!='' else b.tooltip_text,b.position.x+safe.x,b.position.y+safe.y,b.size.x,b.size.y,b.disabled])
	JavaScriptBridge.eval('window.aeroSnapshot && window.aeroSnapshot('+JSON.stringify(s)+')')
