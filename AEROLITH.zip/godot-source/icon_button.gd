extends Button
var symbol='pause'
func _draw():
	var c=size*.5;var ink=Color('#f0d299');var w=2.0
	if symbol=='pause':
		for x in [-4,4]:draw_line(c+Vector2(x,-7),c+Vector2(x,7),ink,3,true)
	elif symbol=='play':draw_colored_polygon(PackedVector2Array([c+Vector2(-5,-8),c+Vector2(8,0),c+Vector2(-5,8)]),ink)
	elif symbol=='sound':
		draw_colored_polygon(PackedVector2Array([c+Vector2(-9,-3),c+Vector2(-4,-3),c+Vector2(1,-8),c+Vector2(1,8),c+Vector2(-4,3),c+Vector2(-9,3)]),ink);draw_arc(c+Vector2(0,0),7,-.8,.8,12,ink,w,true)
	elif symbol=='muted':
		draw_line(c+Vector2(-6,-6),c+Vector2(6,6),ink,w,true);draw_line(c+Vector2(-6,6),c+Vector2(6,-6),ink,w,true)
