extends RefCounted
const Course=preload('res://course.gd')
var profile={'v':1,'coins':0,'engine':0,'paint':0,'owned':[true,false,false],'unlocked':0,'selected':0,'bests':[0.0,0.0,0.0],'stars':[0,0,0],'muted':false}
var course=Course.new(0)
var stage='ready'
var previous_stage='ready'
var clock=0.0
var elapsed=0.0
var distance=0.0
var lane=0.0
var target=0.0
var speed=0.0
var shield=100.0
var energy=1.0
var burst=0.0
var invulnerable=0.0
var flash=0.0
var countdown=2.4
var hits=0
var gates=0
var combo=0
var best_combo=0
var paid=false
var reward=0
var won=false
var stars=0
var collected=[]
var passed=[]
var rivals=[6.0,12.0,18.0]
var events=[]
func select(which):
	if which<0 or which>profile.unlocked or stage not in ['ready','result']:return false
	profile.selected=which;course=Course.new(which);stage='ready';return true
func launch():
	course=Course.new(profile.selected);stage='countdown';countdown=2.4;elapsed=0;distance=0;lane=0;target=0;speed=0;shield=100;energy=1;burst=0;invulnerable=0;flash=0;hits=0;gates=0;combo=0;best_combo=0;paid=false;reward=0;won=false;stars=0;collected=[];passed=[];rivals=[6.0,12.0,18.0];events=[]
func boost():
	if stage!='race' or energy<.26 or burst>.12:return false
	energy-=.26;burst=1.35;events.append('boost');return true
func damage():
	if invulnerable>0 or stage!='race':return
	shield=maxf(0,shield-14);hits+=1;combo=0;speed*=.69;invulnerable=.75;flash=.5;events.append('hit')
	if shield<=0:finish(false)
func rank_():
	var rank=1
	for d in rivals:
		if d>distance:rank+=1
	return rank
func finish(success):
	if stage!='race':return
	stage='result';won=success;burst=0;stars=(1+(1 if rank_()==1 else 0)+(1 if hits<=3 else 0)) if won else 0
	if not paid:
		reward=12+gates*2+(8 if rank_()==1 else 0) if won else maxi(3,gates)
		profile.coins+=reward;paid=true
		if won:
			profile.unlocked=mini(2,maxi(profile.unlocked,profile.selected+1));profile.stars[profile.selected]=maxi(profile.stars[profile.selected],stars)
			if profile.bests[profile.selected]<=0 or elapsed<profile.bests[profile.selected]:profile.bests[profile.selected]=elapsed
	events.append('finish' if won else 'wreck')
func upgrade():
	var cost=35+profile.engine*30
	if stage not in ['ready','result'] or profile.engine>=3 or profile.coins<cost:return false
	profile.coins-=cost;profile.engine+=1;return true
func repaint():
	if stage not in ['ready','result']:return false
	var next=(int(profile.paint)+1)%3;var cost=0 if profile.owned[next] else 20
	if profile.coins<cost:return false
	profile.coins-=cost;profile.owned[next]=true;profile.paint=next;return true
func update(dt,steer=0.0):
	events.clear()
	if stage=='paused':return
	clock+=dt
	if stage=='countdown':
		countdown-=dt
		if countdown<=0:stage='race';events.append('go')
		return
	if stage!='race':return
	elapsed+=dt;burst=maxf(0,burst-dt);flash=maxf(0,flash-dt);invulnerable=maxf(0,invulnerable-dt)
	energy=minf(1,energy+dt*.045);target=clampf(target+steer*7.5*dt,-4.65,4.65);lane=lerpf(lane,target,1-exp(-dt*8.0))
	var wanted=38.0+profile.engine*1.8+(21.0 if burst>0 else 0);speed=move_toward(speed,wanted,dt*(15 if burst>0 else 10))
	if absf(lane)>4.05:damage()
	if stage!='race':return
	var old=distance;distance=minf(course.total*2,distance+speed*dt)
	for i in range(3):rivals[i]+=dt*(36.5+i*.8+profile.selected*.25)*(1.0+.028*sin(clock*.35+i))
	for lap in range(2):
		for i in range(course.gates.size()):
			var gate=course.gates[i];var at=gate[0]+lap*course.total;var key=lap*16+i
			if old<at and distance>=at:
				passed.append(key)
				if absf(lane-gate[1])<1.42:collected.append(key);gates+=1;combo+=1;best_combo=maxi(best_combo,combo);energy=minf(1,energy+.18);events.append('gate')
				else:combo=0
		for i in range(course.barriers.size()):
			var barrier=course.barriers[i];var at=barrier[0]+lap*course.total
			if old<at and distance>=at and absf(lane-barrier[1])<1.12:damage()
	if stage=='race' and distance>=course.total*2:finish(true)
func pause():
	if stage in ['race','countdown']:previous_stage=stage;stage='paused'
func resume():
	if stage=='paused':stage=previous_stage
func snapshot():
	return {'profile':profile.duplicate(true),'stage':stage,'previous':previous_stage,'clock':clock,'elapsed':elapsed,'distance':distance,'lane':lane,'target':target,'speed':speed,'shield':shield,'energy':energy,'burst':burst,'invulnerable':invulnerable,'flash':flash,'countdown':countdown,'hits':hits,'gates':gates,'combo':combo,'best_combo':best_combo,'paid':paid,'reward':reward,'won':won,'stars':stars,'collected':collected.duplicate(),'passed':passed.duplicate(),'rivals':rivals.duplicate()}
func restore(s):
	if not s is Dictionary or not s.get('profile') is Dictionary:return false
	var p=s.profile
	for key in ['coins','engine','paint','unlocked','selected']:
		if not (p.get(key) is float or p.get(key) is int) or not is_finite(float(p[key])) or p[key]<0 or p[key]>100000000 or p[key]!=int(p[key]):return false
	if p.get('v')!=1 or p.engine>3 or p.paint>2 or p.unlocked>2 or p.selected>p.unlocked:return false
	for key in ['bests','stars']:
		if not p.get(key) is Array or p[key].size()!=3:return false
		for v in p[key]:
			if not (v is int or v is float) or not is_finite(float(v)) or v<0:return false
	if not p.get('muted') is bool or s.get('stage') not in ['ready','countdown','race','paused','result']:return false
	for key in ['clock','elapsed','distance','lane','target','speed','shield','energy','burst','invulnerable','flash','countdown','hits','gates','combo','best_combo','reward','stars']:
		if not (s.get(key) is float or s.get(key) is int) or not is_finite(float(s[key])):return false
	var c=Course.new(int(p.selected))
	if s.distance<0 or s.distance>c.total*2+.01 or absf(s.lane)>5 or absf(s.target)>5 or s.speed<0 or s.speed>100 or s.shield<0 or s.shield>100 or s.energy<0 or s.energy>1:return false
	for key in ['collected','passed','rivals']:
		if not s.get(key) is Array or s[key].size()>(3 if key=='rivals' else 32):return false
	if s.rivals.size()!=3:return false
	for key in ['collected','passed']:
		for value in s[key]:
			if not (value is int or value is float) or value<0 or value>=32 or value!=int(value):return false
	for value in s.rivals:
		if not (value is int or value is float) or not is_finite(float(value)) or value<0:return false
	if not s.get('paid') is bool or not s.get('won') is bool or s.get('previous') not in ['ready','race','countdown']:return false
	var owned=p.get('owned',[true,false,false])
	if not owned is Array or owned.size()!=3:return false
	for value in owned:
		if not value is bool:return false
	profile=p.duplicate(true);profile['owned']=owned.duplicate();profile.owned[0]=true;profile.owned[int(profile.paint)]=true;course=c
	for key in ['stage','clock','elapsed','distance','lane','target','speed','shield','energy','burst','invulnerable','flash','countdown','hits','gates','combo','best_combo','paid','reward','won','stars','collected','passed','rivals']:set(key,s[key])
	previous_stage=s.previous
	for key in ['coins','engine','paint','unlocked','selected']:profile[key]=int(profile[key])
	for key in ['hits','gates','combo','best_combo','reward','stars']:set(key,int(s[key]))
	for i in range(profile.stars.size()):profile.stars[i]=int(profile.stars[i])
	collected=collected.map(func(v):return int(v));passed=passed.map(func(v):return int(v));return true
