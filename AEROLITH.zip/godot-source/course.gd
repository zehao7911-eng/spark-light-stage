extends RefCounted
const N=480
const NAMES=['SUNLIT ATOLL','JADE TEMPEST','VIOLET HOUR']
var points=[]
var lengths=[]
var total=0.0
var gates=[]
var barriers=[]
var id=0
func _init(which=0):
	id=which
	for i in range(N+1):
		var a=i*TAU/N;var r=94+sin(a*(3+which)+.5*which)*(16+which*3)+cos(a*2)*7
		var p=Vector3(sin(a)*r,22+sin(a*2+which)*5+cos(a*3)*2,cos(a)*r)
		if i>0:total+=p.distance_to(points[-1])
		points.append(p);lengths.append(total)
	for i in range(16):gates.append([total*(i+.42)/16,[-2.65,0.0,2.65,0.0][(i+which)%4]])
	for i in range(8):barriers.append([total*(i+.77)/8,[-2.65,2.65,0.0,2.65,-2.65,0.0,2.65,-2.65][(i+which)%8]])
func sample(s):
	var d=fposmod(s,total);var lo=0;var hi=N
	while hi-lo>1:
		var mid=int((lo+hi)/2)
		if lengths[mid]<=d:lo=mid
		else:hi=mid
	var u=(d-lengths[lo])/maxf(.001,lengths[hi]-lengths[lo]);var p=points[lo].lerp(points[hi],u)
	var forward=(points[hi]-points[lo]).normalized();var right=forward.cross(Vector3.UP).normalized();var up=right.cross(forward).normalized()
	return [p,Basis(right,up,-forward)]
