extends SceneTree
const Race=preload('res://race.gd')
var count_=0
var failures=0
func check(v,msg):
	count_+=1
	if not v:failures+=1;push_error(msg)
func _initialize():call_deferred('test')
func drive(g):
	var target=0.0;var best=INF
	for lap in range(2):
		for gate in g.course.gates:
			var gap=gate[0]+lap*g.course.total-g.distance
			if gap>3 and gap<best:best=gap;target=gate[1]
		for obstacle in g.course.barriers:
			var gap=obstacle[0]+lap*g.course.total-g.distance
			if gap>0 and gap<19 and absf(target-obstacle[1])<1.25:target=-2.65 if obstacle[1]>=0 else 2.65
	g.target=target
	if g.energy>.30:g.boost()
	g.update(1.0/90.0)
func test():
	for which in range(3):
		var g=Race.new();g.profile.unlocked=2;check(g.select(which),'Unlocked route can be selected');g.launch()
		check(not g.boost(),'No boost during countdown')
		var at_start=g.course.sample(0);var at_end=g.course.sample(g.course.total-.00001);check(at_start[0].distance_to(at_end[0])<.001,'Track closes without a seam')
		for j in range(60):
			var p=g.course.sample(g.course.total*j/60.0);check(p[0].is_finite() and p[1].is_finite() and absf(p[1].determinant()-1)<.001,'Finite orthonormal course frame')
		for step in range(10000):
			drive(g)
			if g.stage=='result':break
		check(g.stage=='result' and g.won,'Full two-lap course is playable: '+str(which));check(g.gates>=20,'Gate collection rewards steering');check(g.profile.coins==g.reward and g.reward>20,'Single finish payout')
		var coins=g.profile.coins;g.finish(true);g.update(1);check(g.profile.coins==coins,'Results cannot pay twice')
		check(g.passed.size()==32 and g.collected.size()<=32,'Every gate crossed exactly once per lap')
		check(g.profile.stars[which]>=1 and g.profile.bests[which]>0,'Medals and best time recorded')
		print('Route ',which,' finish ',g.elapsed,' gates ',g.gates,' hits ',g.hits,' stars ',g.stars)
	var g=Race.new();check(not g.select(1),'Locked route cannot be selected');g.launch()
	for i in range(500):drive(g)
	var clone=Race.new();check(clone.restore(JSON.parse_string(JSON.stringify(g.snapshot()))),'JSON race/profile restore')
	for i in range(400):drive(g);drive(clone)
	check(absf(g.distance-clone.distance)<.00001 and absf(g.energy-clone.energy)<.000001 and g.hits==clone.hits and g.collected==clone.collected,'Restored race continues deterministically')
	g.pause();var state=g.snapshot();g.update(10);check(g.snapshot()==state,'Pause freezes simulation and rivals');g.resume();check(g.stage=='race','Resume returns to race')
	var old=g.hits;g.invulnerable=0;g.damage();g.damage();check(g.hits==old+1,'Collision cooldown prevents repeated frame damage')
	for key in ['distance','energy','profile','rivals']:
		var bad=g.snapshot();bad[key]=null;check(not Race.new().restore(bad),'Malformed save rejected: '+key)
	var empty=Race.new();check(not empty.upgrade() and not empty.repaint(),'Unaffordable purchases rejected');empty.profile.coins=500;check(empty.upgrade() and empty.profile.engine==1 and empty.profile.coins==465,'Engine purchase pays once');check(empty.repaint() and empty.profile.paint==1 and empty.profile.coins==445,'Paint purchase persists')
	check(empty.repaint() and empty.repaint() and empty.profile.coins==425,'Owned liveries can be re-equipped free')
	var game=load('res://main.tscn').instantiate();root.add_child(game);await process_frame
	for dim in [Vector2i(320,568),Vector2i(390,844),Vector2i(844,390),Vector2i(1280,720)]:
		root.size=dim;await process_frame
		for stage_ in ['ready','race','paused','result']:
			game.g.stage=stage_;game.layout();var bounds=[]
			for child in game.ui.get_children():
				if child is Panel:check(child.position.y>=0 and child.get_rect().end.y<=game.view.y,'Card fits short landscape screens')
			for b in game.buttons:
				var rect=Rect2(b.position,b.size);check(Rect2(Vector2.ZERO,game.view).encloses(rect),'Button fits '+str(dim)+' '+stage_);check(b.size.x>=44 and b.size.y>=44,'44px touch target')
				for other in bounds:check(not rect.intersects(other),'Buttons do not overlap')
				bounds.append(rect)
	game.g.stage='race';game.g.previous_stage='race';game.lifecycle(['away']);check(game.g.stage=='paused' and game.hidden_,'Background pauses active race');game.lifecycle(['back']);check(game.g.stage=='paused' and not game.hidden_,'Foreground waits for deliberate resume')
	game.g.stage='result';game.g.profile.coins=100;game.g.profile.engine=0;game.layout()
	for b in game.buttons:
		if b.text.begins_with('ENGINE'):
			b.pressed.emit();check(game.g.profile.coins==100,'Button purchase waits for safe event boundary');break
	await process_frame;await process_frame
	check(game.g.profile.engine==1 and game.g.profile.coins==65,'Deferred UI purchase pays once and rebuilds safely')
	game.event_sound.stop();game.motor.stop();await create_timer(.15).timeout;game.free();await process_frame;await process_frame
	print('AEROLITH QA: ',count_,' checks, ',failures,' failures');quit(1 if failures else 0)
