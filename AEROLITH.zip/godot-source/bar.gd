extends Control
var tint=Color('#8fe6da')
var value=0.0:
	set(v):value=clampf(v,0,1);queue_redraw()
func _draw():
	var bg=StyleBoxFlat.new();bg.bg_color=Color(.035,.10,.15,.8);bg.set_corner_radius_all(3);draw_style_box(bg,Rect2(Vector2.ZERO,size))
	if value>0:
		var fg=StyleBoxFlat.new();fg.bg_color=tint;fg.set_corner_radius_all(3);draw_style_box(fg,Rect2(Vector2.ZERO,Vector2(size.x*value,size.y)))
