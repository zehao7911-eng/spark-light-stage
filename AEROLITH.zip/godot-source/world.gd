extends Node3D
const B=preload('res://mesh.gd')
var g
var arena:Node3D
var camera:Camera3D
var craft:Node3D
var rivals=[]
var flame:Node3D
var gates:MultiMeshInstance3D
var trail:MultiMeshInstance3D
var clouds:MultiMeshInstance3D
var airships:MultiMeshInstance3D
var halo:Node3D
var finish:ShaderMaterial
var sea:ShaderMaterial
var light:ShaderMaterial
var surface:ShaderMaterial
var post:ColorRect
var initialized=false
var size_=Vector2(1280,720)
var last_course=-1
var last_paint=-1
var stats={}
var gate_flash=0.0
var sparks:MultiMeshInstance3D
const HAZES=[Color('#c0d7d6'),Color('#aeced0'),Color('#9c9dc2')]
const SEAS=[Color('#407f89'),Color('#286f7b'),Color('#383f70')]
func mat(path):
	var m=ShaderMaterial.new();m.shader=load(path);return m
func mesh(b,parent,m):
	var n=MeshInstance3D.new();n.mesh=b.mesh(m);parent.add_child(n);return n
func instances(m,count_,parent,custom=false):
	var node=MultiMeshInstance3D.new();node.multimesh=MultiMesh.new();node.multimesh.transform_format=MultiMesh.TRANSFORM_3D;node.multimesh.use_custom_data=custom;node.multimesh.mesh=m;node.multimesh.instance_count=count_;parent.add_child(node);return node
func _ready():
	camera=Camera3D.new();camera.near=.15;camera.far=900;camera.current=true;add_child(camera)
	var env=WorldEnvironment.new();var e=Environment.new();e.background_mode=Environment.BG_SKY;e.sky=Sky.new();e.sky.sky_material=mat('res://sky.gdshader');e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;e.ambient_light_color=Color('#b5d0dc');e.ambient_light_energy=.8;env.environment=e;add_child(env)
	var layer=CanvasLayer.new();layer.layer=1;add_child(layer);post=ColorRect.new();post.mouse_filter=Control.MOUSE_FILTER_IGNORE;finish=mat('res://finish.gdshader');post.material=finish;layer.add_child(post)
	build()
func build():
	if is_instance_valid(arena):arena.free()
	arena=Node3D.new();add_child(arena);rivals=[];last_course=int(g.profile.selected);last_paint=int(g.profile.paint);initialized=false
	surface=mat('res://surface.gdshader');surface.set_shader_parameter('haze',HAZES[last_course]);surface.set_shader_parameter('metal',.6);light=mat('res://light.gdshader')
	var env=get_child(1).environment;var sky=env.sky.sky_material
	sky.set_shader_parameter('horizon',HAZES[last_course]);sky.set_shader_parameter('zenith',[Color('#427e9a'),Color('#2d6b86'),Color('#464d80')][last_course]);sky.set_shader_parameter('glow',Color('#ffd2a0') if last_course<2 else Color('#edbedf'))
	var road=B.new();var edge=B.new();var marks=B.new();var supports=B.new();var c=g.course
	for i in range(c.N):
		var a=c.sample(c.lengths[i]);var b=c.sample(c.lengths[i+1]-.0001);var p=a[0];var q=b[0];var r=a[1].x;var s=b[1].x
		road.quad(p-r*4.8,q-s*4.8,q+s*4.8,p+r*4.8,Color('#233e50').lightened(.018*(i%2)))
		for side in [-1,1]:
			road.quad(p+r*side*4.8,q+s*side*4.8,q+s*side*4.8-Vector3.UP*.6,p+r*side*4.8-Vector3.UP*.6,Color('#e5dcc7'))
			edge.tube(p+r*side*4.60+Vector3.UP*.05,q+s*side*4.60+Vector3.UP*.05,.055,Color('#d8bd84'),5)
			if i%2==0:marks.quad(p+r*side*4.35+Vector3.UP*.017,q+s*side*4.35+Vector3.UP*.017,q+s*side*4.20+Vector3.UP*.017,p+r*side*4.20+Vector3.UP*.017,Color('#6adacf'))
		if i%3==0:
			for x in [-1.6,1.6]:marks.quad(p+r*(x-.035)+Vector3.UP*.02,q+s*(x-.035)+Vector3.UP*.02,q+s*(x+.035)+Vector3.UP*.02,p+r*(x+.035)+Vector3.UP*.02,Color('#668691'))
		if i%20==0:
			supports.box(p-Vector3.UP*1.1,Vector3(1.4,1.0,1.4),Color('#c2d1c9'));supports.tube(p-Vector3.UP*.6,p-Vector3.UP*13,.23,Color('#99b9b9'),7)
			for side in [-1,1]:supports.tube(p-Vector3.UP*4,p+r*side*4.7-Vector3.UP*.3,.13,Color('#b9cfc8'),5)
	# Tall ceremonial arches are clear of the road and camera corridor.
	for at_distance in [c.total*.24,c.total*.68]:
		var frame=c.sample(at_distance);var anchor=frame[0];var basis=frame[1]
		for side in [-1,1]:
			for y in [0,4.5]:supports.tube(anchor+basis*Vector3(side*5.55,y,0),anchor+basis*Vector3(side*5.55,y+4.5,0),.32,Color('#e0dccc'),8)
			supports.box(anchor+basis*Vector3(side*5.55,.3,0),Vector3(1.1,.6,1.3),Color('#b7c3bd'))
		for i in range(24):
			var a=i*PI/24;var b=(i+1)*PI/24;var p=anchor+basis*Vector3(cos(a)*5.55,9+sin(a)*3.2,0);var q=anchor+basis*Vector3(cos(b)*5.55,9+sin(b)*3.2,0);supports.tube(p,q,.34,Color('#ddd6be'),8);edge.tube(p+basis.z*.4,q+basis.z*.4,.06,Color('#d1ac68'),5)
	mesh(road,arena,surface);mesh(edge,arena,surface);mesh(marks,arena,light);mesh(supports,arena,surface)
	var gate=B.new()
	for i in range(16):
		var a=i*PI/16;var b=(i+1)*PI/16;gate.tube(Vector3(cos(a)*1.47,sin(a)*2.5,.0),Vector3(cos(b)*1.47,sin(b)*2.5,0),.075,Color('#8df3d9'),6)
	for side in [-1,1]:gate.box(Vector3(side*1.52,.15,0),Vector3(.22,.3,.36),Color('#e1c394'))
	for i in range(3):
		var z=.4+i*.65;gate.triangle(Vector3(-.65,.025,z),Vector3(0,.025,z-.42),Vector3(0,.025,z-.17),Color('#7cddd3'));gate.triangle(Vector3(.65,.025,z),Vector3(0,.025,z-.17),Vector3(0,.025,z-.42),Color('#7cddd3'))
	gates=instances(gate.mesh(light),16,arena)
	for i in range(16):
		var at=c.sample(c.gates[i][0]);gates.multimesh.set_instance_transform(i,Transform3D(at[1],at[0]+at[1].x*c.gates[i][1]))
	var crystal=B.new();crystal.box(Vector3(0,.16,0),Vector3(1.65,.32,1.5),Color('#284355'))
	for i in range(3):
		var x=(i-1)*.38;var h=1.2+(1-absf(x))*1.1;var top=Vector3(x+.1,h,0)
		for j in range(5):
			var a=j*TAU/5;var b=(j+1)*TAU/5;crystal.triangle(Vector3(x+cos(a)*.42,.25,sin(a)*.42),top,Vector3(x+cos(b)*.42,.25,sin(b)*.42),Color('#d78897').lightened(j*.025))
	var obstacles=instances(crystal.mesh(surface),8,arena)
	for i in range(8):
		var at=c.sample(c.barriers[i][0]);obstacles.multimesh.set_instance_transform(i,Transform3D(at[1],at[0]+at[1].x*c.barriers[i][1]))
	build_scenery();craft=make_ship(arena,int(g.profile.paint),true)
	for i in range(3):rivals.append(make_ship(arena,(i+1)%3,false))
	var strip=B.new();strip.quad(Vector3(-.08,0,0),Vector3(.08,0,0),Vector3(.035,0,1.4),Vector3(-.035,0,1.4),Color.WHITE);trail=instances(strip.mesh(mat('res://trail.gdshader')),32,arena,true)
	var sparkle=B.new();sparkle.ellipsoid(Vector3.ZERO,Vector3(.035,.035,.10),Color.WHITE,6,4);sparks=instances(sparkle.mesh(mat('res://trail.gdshader')),24,arena,true)
	stats={'road_segments':c.N,'gates':16,'barriers':8,'clouds':32}
func make_ship(parent,paint,player):
	var root=Node3D.new();parent.add_child(root);var b=B.new();var col=[Color('#e8e5d8'),Color('#dcae93'),Color('#88c6c6')][paint];var gold=Color('#d4b06f')
	var nose=Vector3(0,0,-1.9);var top=Vector3(0,.36,-.1);var rear=Vector3(0,.05,1.20)
	b.triangle(nose,Vector3(.55,.05,.65),top,col);b.triangle(nose,top,Vector3(-.55,.05,.65),col);b.triangle(Vector3(-.55,.05,.65),top,rear,col.darkened(.08));b.triangle(top,Vector3(.55,.05,.65),rear,col)
	b.triangle(nose,Vector3(-.55,.05,.65),Vector3(0,-.18,.55),col.darkened(.18));b.triangle(nose,Vector3(0,-.18,.55),Vector3(.55,.05,.65),col.darkened(.18))
	for side in [-1,1]:
		b.triangle(Vector3(side*.36,0,-.65),Vector3(side*1.35,-.08,.9),Vector3(side*.43,.10,.68),col);b.triangle(Vector3(side*1.35,-.08,.9),Vector3(side*.86,.0,1.08),Vector3(side*.43,.10,.68),gold)
		b.box(Vector3(side*.44,.05,1.03),Vector3(.28,.22,.60),Color('#607781'));b.box(Vector3(side*.44,.05,1.34),Vector3(.22,.16,.035),Color('#91f5ee'))
		b.triangle(Vector3(side*.75,.03,.95),Vector3(side*.68,.58,1.03),Vector3(side*.40,.03,.44),col)
	b.ellipsoid(Vector3(0,.28,-.12),Vector3(.26,.15,.64),Color('#2c6379'),16,8);b.tube(Vector3(0,.40,-.62),Vector3(0,.40,.24),.018,gold,5);mesh(b,root,surface)
	var lights=B.new()
	for side in [-1,1]:lights.tube(Vector3(side*.2,.04,-1.35),Vector3(side*.50,.12,.35),.025,Color('#7ff0df'),5)
	mesh(lights,root,light)
	if player:
		flame=Node3D.new();root.add_child(flame);var f=B.new()
		for side in [-1,1]:f.ellipsoid(Vector3(side*.44,.05,1.8),Vector3(.10,.08,.48),Color('#72dfef'),9,6)
		mesh(f,flame,light)
	return root
func build_scenery():
	var rng=RandomNumberGenerator.new();rng.seed=51843+last_course*981;var islands=B.new();var architecture=B.new();var luminous=B.new()
	for i in range(25):
		var a=i*2.4;var r=155+rng.randf()*100;var p=Vector3(cos(a)*r,-6+rng.randf()*8,sin(a)*r);var size_=rng.randf_range(9,21)
		for j in range(9):
			var a0=j*TAU/9;var a1=(j+1)*TAU/9;var v0=p+Vector3(cos(a0)*size_,0,sin(a0)*size_*.8);var v1=p+Vector3(cos(a1)*size_,0,sin(a1)*size_*.8)
			islands.triangle(v0,p-Vector3(0,size_*1.7,0),v1,Color('#7d9eac').lightened(j*.015));islands.triangle(p+Vector3(0,.5,0),v0,v1,Color('#a7c5bb'))
		# Terraced landing platform, balcony rails and copper roof details.
		architecture.ellipsoid(p+Vector3(0,.35,0),Vector3(size_*.62,.35,size_*.48),Color('#c0cec4'),14,5)
		for j in range(12):
			var ang=j*TAU/12;var q=p+Vector3(cos(ang)*size_*.62,.8,sin(ang)*size_*.48);architecture.tube(q,q+Vector3(0,1.0,0),.07,Color('#ccbc96'),5)
		for j in range(3):
			var q=p+Vector3(sin(j*2.4)*size_*.35,0,cos(j*2.4)*size_*.35);var h=rng.randf_range(8,20)
			architecture.box(q+Vector3(0,h*.5,0),Vector3(2.0,h,2.2),Color('#d9ded0'));architecture.roof(q+Vector3(0,h,0),Vector3(2.7,3.0,2.8),Color('#bdaf90'))
			for y in range(3,int(h),3):luminous.box(q+Vector3(0,y,1.12),Vector3(1.25,.20,.03),Color('#f2cf8b'))
	# The monumental lighthouse is always separated from the playable circuit.
	architecture.tube(Vector3(0,-14,0),Vector3(0,62,0),3.4,Color('#b2c5c6'),12)
	for k in range(3):
		var y=32+k*12
		for i in range(48):
			var a=i*TAU/48;var b=(i+1)*TAU/48;architecture.tube(Vector3(cos(a)*13,y,sin(a)*13),Vector3(cos(b)*13,y,sin(b)*13),.45,Color('#d4c5a1'),6)
		luminous.ellipsoid(Vector3(0,y,0),Vector3(4.0,.4,4.0),Color('#9bf0e5'),16,5)
	mesh(islands,arena,surface);mesh(architecture,arena,surface);mesh(luminous,arena,light)
	var ocean=B.new();ocean.quad(Vector3(-1000,-28,-1000),Vector3(1000,-28,-1000),Vector3(1000,-28,1000),Vector3(-1000,-28,1000),Color.WHITE);sea=mat('res://sea.gdshader');sea.set_shader_parameter('base',SEAS[last_course]);sea.set_shader_parameter('haze',HAZES[last_course]);mesh(ocean,arena,sea)
	var cloud=B.new()
	for j in range(4):cloud.ellipsoid(Vector3((j-1.5)*4,sin(j)*1.2,cos(j)*1.5),Vector3(6,1.8,4.0),Color.WHITE,12,7)
	clouds=instances(cloud.mesh(mat('res://cloud.gdshader')),32,arena)
	var air=B.new();air.ellipsoid(Vector3.ZERO,Vector3(3.1,2.3,9.0),Color('#dfdfcc'),22,11)
	air.ellipsoid(Vector3(0,-2.2,1),Vector3(1.2,.7,3.8),Color('#6d9eaa'),16,7)
	for side in [-1,1]:
		air.triangle(Vector3(side*1.4,0,4),Vector3(side*5.0,.15,7.3),Vector3(side*1.8,0,7.5),Color('#c3aa7e'));air.tube(Vector3(side*2.3,-1.1,-5),Vector3(side*2.3,-1.1,4),.07,Color('#d6b471'),5)
		for z in range(-2,5,2):air.box(Vector3(side*1.12,-2.0,z),Vector3(.035,.32,.55),Color('#f1d7a1'))
	air.triangle(Vector3(0,1,5),Vector3(0,5,8),Vector3(0,0,8),Color('#cfbd93'));airships=instances(air.mesh(surface),3,arena)
func update(dt):
	if last_course!=int(g.profile.selected) or last_paint!=int(g.profile.paint):build()
	gate_flash=maxf(0,gate_flash-dt)
	var t=g.clock;var demo=g.stage=='ready';var d=55+t*9 if demo else g.distance;var lane=sin(t*.22)*.5 if demo else g.lane
	var sample=g.course.sample(d);var pos=sample[0]+sample[1].x*lane+sample[1].y*(.57+sin(t*6)*.025)
	craft.transform=Transform3D(sample[1],pos);craft.rotate_object_local(Vector3.BACK,clampf((g.target-g.lane)*-.10,-.30,.30));flame.scale.z=2.1 if g.burst>0 else .9+sin(t*33)*.08
	for i in range(3):
		var at=g.course.sample(g.rivals[i] if not demo else d+25+i*20);rivals[i].transform=Transform3D(at[1],at[0]+at[1].x*sin(t*.23+i*2)*2.7+at[1].y*.65)
	for i in range(32):
		var back=(i/2.0)*.74;var at=g.course.sample(d-back);var p=at[0]+at[1].x*(lane+(-.44 if i%2==0 else .44))+at[1].y*.60
		trail.multimesh.set_instance_transform(i,Transform3D(at[1].scaled(Vector3(1.6 if g.burst>0 else .75,1,1)),p));trail.multimesh.set_instance_custom_data(i,Color((1-i/32.0)*(.9 if g.burst>0 else .35),0,0,0))
	var forward=-sample[1].z;var portrait=size_.y>size_.x;var desired=pos-forward*(11.7 if portrait else 10.5)+Vector3.UP*(5.8 if portrait else 4.3);var aim=g.course.sample(d+16)[0]+Vector3.UP*1.0
	desired+=sample[1].x*sin(t*65)*g.flash*.18
	if not initialized:camera.position=desired;camera.fov=62 if portrait else 65;initialized=true
	else:camera.position=camera.position.lerp(desired,1-exp(-dt*9));camera.fov=lerpf(camera.fov,(67 if g.burst>0 else 60) if portrait else (73 if g.burst>0 else 64),1-exp(-dt*5))
	for i in range(24):
		var age=1-gate_flash/.6;var a=i*2.4;var local=Vector3(sin(a)*(1+age*2),cos(a)*(.3+age),age*3+cos(a)*.7);sparks.multimesh.set_instance_transform(i,Transform3D(sample[1],pos+sample[1]*local));sparks.multimesh.set_instance_custom_data(i,Color(gate_flash*.9,0,0,0))
	camera.keep_aspect=Camera3D.KEEP_WIDTH if portrait else Camera3D.KEEP_HEIGHT;camera.look_at(aim)
	for i in range(32):
		var a=i*2.4+t*.0015;var r=130+i%5*25;clouds.multimesh.set_instance_transform(i,Transform3D(Basis(Vector3.UP,a),Vector3(cos(a)*r,-7+i%3*3,sin(a)*r)))
	for i in range(3):
		var a=t*.007+i*TAU/3;var r=205+i*22;var p=Vector3(cos(a)*r,48+i*8+sin(t*.12+i),sin(a)*r);airships.multimesh.set_instance_transform(i,Transform3D(Basis(Vector3.UP,-a),p))
	light.set_shader_parameter('clock',t);sea.set_shader_parameter('clock',t);finish.set_shader_parameter('rush',minf(1,g.burst));finish.set_shader_parameter('hit',g.flash*2);finish.set_shader_parameter('gate',gate_flash);post.size=size_
