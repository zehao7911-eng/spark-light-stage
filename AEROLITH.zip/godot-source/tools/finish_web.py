"""Restore the small loading/lifecycle wrapper around a normal native Godot Web export."""
from pathlib import Path
import sys,re,json,shutil,hashlib
target=Path(sys.argv[1] if len(sys.argv)>1 else 'index.html').resolve()
source=Path(__file__).resolve().parent.parent
text=target.read_text(encoding='utf-8')
match=re.search(r'const GODOT_CONFIG = (\{.*?\});',text)
if not match:raise SystemExit('Run a normal Godot Web export first; its generated config was not found.')
config=json.loads(match[1]);config['ensureCrossOriginIsolationHeaders']=False
pack=target.parent/(config['executable']+'.pck')
versioned='flight-'+hashlib.sha256(pack.read_bytes()).hexdigest()[:12]+'.pck'
for prior in target.parent.glob('flight-*.pck'):
 if prior.name!=versioned:prior.unlink()
shutil.copyfile(pack,target.parent/versioned)
config['mainPack']=versioned
config['fileSizes'][versioned]=pack.stat().st_size
target.write_text((source/'web/shell.html').read_text(encoding='utf-8').replace('__CONFIG__',json.dumps(config)),encoding='utf-8')
shutil.copyfile(source/'icon.svg',target.parent/'icon.svg')
print('Native Godot Web export wrapper restored:',target)
