# Source adaptation details

Source: https://github.com/nmoroze/swap
Revision: a3cfb7d2d59d37dd3778d5de685a206cca4f1206
Authors: @nmoroze and @themichaelyang, as credited in upstream README.
License: CC BY-SA4.0, original full text in LICENSE-SWAP.txt and upstream/LICENSE.

source-engine.js is reproducibly built from upstream ai.js,player.js,tile.js,world.js by work/build-rooftop-engine.py in the development workspace. Unmodified originals and their SHA256 manifest are distributed in upstream/.

Retained actual runtime systems: Player inertia/acceleration and trail state; world map parsing; all six AI factories and their update/collision methods; Floor/Wall/Victory/Lava/Switched/Switch/PlayerWall tile classes and factory; tile collision callbacks; world update iteration; cyclePlayer handoff. Original tile IDs stay compatible.

Corrections/adaptations: renderer/input are original touch-capable implementations; deterministic fixed30Hz loop replaces setInterval; player collision resolves axes before callbacks to replace unreliable trail rollback; bounds queries return a solid border; empty floor under a bot gets its real grid coordinates; pad visual down flag resets each update; gates and entity lists reset on level change; uncontrolled body wall contact restores prior coordinates; changing control clears old movement velocity; release has an explicit braking hook; snapshot/restore preserve live bodies, selected identity, velocity and tile states; bounded gameplay callbacks replace old modal/death progression. Original multiplayer/network features do not exist in this source; none are implied.

Twelve new maps, collectible batteries, stars, sequential unlocks, three paints, click-route planning, undo, local saves, sound synthesis and artwork are new. Original keypress library, old music, thumbnails, font-icons and renderer are not executed or reused. The preserved original levels.js contains25 levels but is not loaded by the rooftop campaign.

The lift requires the currently controlled robot. Upstream allowed any AI to trigger victory; the active-only condition prevents an unattended courier from automatically completing a new rooftop before the player acts.
