/* ROOFTOP RELAY adaptation of Swap by Noah Moroze and Michael Yang. CC BY-SA4.0. See LICENSE-SWAP.txt and SOURCE.md. */
var AI = {
	x:0,
	y:0,
	vx:0,
	vy:0,
	color: "rgb(125,167,217)",//"rgba(0, 10, 200, 0.4)",
	init: function(x, y) {
		this.x = x;
		this.y = y;
	},
	update: function(gridSize) {
		if(!this.hitWall) {
			if(this.vx!=0)
				this.x += gridSize / this.vx;
			if(this.vy!=0)
				this.y += gridSize / this.vy;
		}
		this.hitWall = false;
	}, 
	onCollide: function(tile) {
		if(tile.blocksMovement)
			this.hitWall = true;
	},
};

// STATIONARY AI 
var StationaryAI = function(x, y) {
	this.init(x, y);
}
StationaryAI.prototype = Object.create(AI);

// RIGHT AI
var RightAI = function(x, y) {
	this.init(x, y);
	this.vx = 7;
	this.hitWall = false;
}
RightAI.prototype = Object.create(AI);

// BOUNCE AI (RIGHT) (starts right, reverses direction on walls)
var RightBounceAI = function(x, y) {
	this.init(x, y);
	this.vx = 7;
	this.hitWall = false;
}
RightBounceAI.prototype = Object.create(AI);
RightBounceAI.prototype.onCollide = function(tile) {
	if(tile.blocksMovement && !this.hitWall) {
		this.vx *= -1;
		this.hitWall = true;
	}
}
RightBounceAI.prototype.update = function(gridSize) {
	this.hitWall = false;

	if(this.vx!=0)
		this.x += gridSize/this.vx;
	if(this.vy!=0)
		this.y += gridSize/this.vy; 
}

// FOLLOW AI (follows player movements)
var FollowAI = function(x, y) {
	this.init(x, y);
}
FollowAI.prototype = Object.create(AI);
FollowAI.prototype.update = function(gridSize) {
	if (!this.hitWall) {
		this.prevX = this.x;
		this.prevY = this.y;
		this.x += player.getVelocity().x;
		this.y += player.getVelocity().y;
	}
	this.hitWall = false;
}
FollowAI.prototype.onCollide = function(tile) {
	if(tile.blocksMovement) {
		this.hitWall = true;
		this.x = this.prevX; 
		this.y = this.prevY;
	}
}

// LEFT TURN AI (RIGHT) (starts right, turns left on walls)
var LeftTurnRightAI = function(x, y) {
	this.init(x, y);
	this.vx = 7;
}
LeftTurnRightAI.prototype = Object.create(AI);
LeftTurnRightAI.prototype.update = function(gridSize) {
	this.prevX = this.x;
	this.prevY = this.y;
	if(this.vx!=0)
		this.x += gridSize/this.vx;
	if(this.vy!=0)
		this.y += gridSize/this.vy; 
	this.hitWall = false;
}
LeftTurnRightAI.prototype.onCollide = function(tile) {
	if(tile.blocksMovement && !this.hitWall) {
		this.x = this.prevX;
		this.y = this.prevY;
		this.vxo = this.vx;
		this.vyo = this.vy;
		this.vx = 0;
		this.vy = 0;
		if (this.vxo > 0) this.vy = -7;
		else if (this.vxo < 0) this.vy = 7; 
		else if (this.vyo > 0) this.vx = 7;
		else if (this.vyo < 0) this.vx = -7;
		this.hitWall = true;
	}
}

// UP AI
var UpAI = function(x, y) {
	this.init(x, y);
	this.vy = -7;
	this.hitWall = false;
}
UpAI.prototype = Object.create(AI);


var getAI = function(x, y, id) {
	switch(id) {
		case -1:
			return new StationaryAI(x, y);
		case -2:
			return new RightAI(x, y);
		case -3:
			return new RightBounceAI(x, y);
		case -4: 
			return new FollowAI(x, y);
		case -5:
			return new LeftTurnRightAI(x, y);
		case -6:
			return new UpAI(x, y);
	}
}

var player = function() {
	var x,y;
	var prevX, prevY;
	var vx = 0, vy = 0;
	var currentAI;
	var friction = 1.6;
	var trail = [];
	var gridSize;
	// var hitRight = false;
	// var hitLeft = false;
	// var hitUp = false;
	// var hitDown = false;

	var init = function(gSize) {
		gridSize = gSize;
		vx = 0;
		vy = 0;
		this.trail.length = 0;
	}

	var setAI = function(ai){
		this.trail.length = 0;
		this.x = ai.x;
		this.y = ai.y;
		this.currentAI = ai; vx=0;vy=0;
	}

	var getAI = function() {
		this.currentAI.x = this.x;
		this.currentAI.y = this.y;
		return this.currentAI;
	}
	var update = function(gridSize) {
		prevX = x;
		prevY = y;
		this.trail.push([this.x, this.y]);
		if (this.trail.length >= 5) this.trail.shift();

		if(input.right) {
            if (vx <= gridSize / 10) vx += (Math.abs(vx) + 1) / friction;
		}
        else if(input.left) {
            if (vx >= -gridSize / 10) vx -= (Math.abs(vx) + 1) / friction;
        }

        if(input.up){
            if (vy >= -gridSize / 10) vy -= (Math.abs(vy) + 1) / friction;
        }
        else if(input.down) {
            if (vy <= gridSize / 10) vy += (Math.abs(vy) + 1) / friction;
        }
        if(!input.right && !input.left) {
        	vx = vx / friction;
        }
        if(!input.up && !input.down) {
        	vy = vy / friction;
        }
        if(vx>8)
        	vx=8;
        else if(vx<-8)
        	vx=-8;
        if(vy>8)
        	vy=8;
        else if(vy<-8)
        	vy=-8;
		this.x += vx;
		this.y += vy;
	}

	var hitWall = function(x, y) {
		if(this.trail[1]) {
			if (x>this.trail[1][0]) {
				if (x-this.trail[1][0] > gridSize) {
					this.y = this.trail[1][1];
				}
			}
			else {
				if (this.trail[1][0]-x < gridSize) {
					this.y = this.trail[1][1];
				}
			}

			if (y>this.trail[1][1]) {
				if (y-this.trail[1][1] > gridSize) {
					this.x = this.trail[1][0];
				}
			}
			else {
				if (this.trail[1][1]-y < gridSize) {
					this.x = this.trail[1][0];
				}
			}
		}
		// justHit = true;
		// if(vx*vx>vy*vy) {
		// 	vx=0;
		// 	hitSide = true;
		// }
		// if(vy*vy>vx*vx) {
		// 	vy=0;
		// 	hitUp = true;
		// }

		// if(vx*vx>vy*vy) {
		// 	vx = 0;
		// 	if(this.x>x)
		// 		hitLeft = true;
		// 	else if(this.x<x+gridSize)
		// 		hitRight = true;
		// }
		// if(vy*vy>vx*vx) {
		// 	vy = 0;
		// 	if(this.y>y)
		// 		hitUp = true;
		// 	else if(this.y<y+gridSize)
		// 		hitDown = true;
		// }
		// vx = vx / friction;
		// vy = vy / friction;

		// vx *= -0.3;
		// vy *= -0.3;
	}

	var getVelocity = function() {
		return {
			x:vx,
			y:vy,
		}
	}

	return {
		x: x,
		y: y,
		color: "rgb(125,167,217)",//"rgba(0, 10, 200, 0.4)",
		trail: trail,
		getVelocity: getVelocity,
		stop:function(){vx=0;vy=0;}, serialize:function(){return {x:this.x,y:this.y,vx:vx,vy:vy,trail:this.trail.slice()};}, restore:function(s){this.x=s.x;this.y=s.y;vx=s.vx;vy=s.vy;this.trail=s.trail.slice();}, init: init,
		setAI: setAI,
		getAI: getAI, 
		update: update,
		hitWall: hitWall,
	}
}();

var switchedTiles = new Array(10);
var anyDown = [];

var Tile = {
	init: function(x, y){
		this.x = x;
		this.y = y;
	},
	update: function() {},
	onCollide: function(ai) {},
	blocksMovement: false,
	blocksOnlyPlayer: false,
	color:"white",
};

// FLOOR TILE
var FloorTile = function(x, y){
	this.init(x, y);
};
FloorTile.prototype = Object.create(Tile);

// WALL TILE
var WallTile = function(x, y){
	this.init(x, y);
	this.blocksMovement = true;
	this.color = "grey";
};
WallTile.prototype = Object.create(Tile);

// VICTORY TILE
var VictoryTile = function(x, y){
	this.init(x, y);
	this.color = "rgb(163, 211, 156)"; //"rgba(95, 255, 80, 1.0)";	
};
VictoryTile.prototype = Object.create(Tile);
VictoryTile.prototype.onCollide = function(ai) {
	if(ai===player) world.victory();
};

// LAVA TILE (kills player)
var LavaTile = function(x, y){
	this.init(x, y);
	this.color = "red";
};
LavaTile.prototype = Object.create(Tile);
LavaTile.prototype.onCollide = function(ai) {
	world.death();
};

// SWITCHED TILE (wall that can be on/off)
var SwitchedTile = function(x, y){
	this.init(x, y);
	this.blocksMovement = true;
	this.color = "rgb(253, 198, 137)";
};
SwitchedTile.prototype = Object.create(Tile);
SwitchedTile.prototype.onCollide = function(ai) {
	this.touchingAI = true;
	// console.log(ai);
	this.justTouching = true;
}
SwitchedTile.prototype.update = function() {
	if(!this.justTouching)
		this.touchingAI = false;
	this.justTouching = false;
}

// SWITCH TILE (toggles wall)
var SwitchTile = function(x, y, id){
	this.init(x, y);
	this.switchingId = id;
	this.color = "rgb(255, 247, 153)";
}
SwitchTile.prototype = Object.create(Tile);
SwitchTile.prototype.onCollide = function(ai) {
	this.down = true;
	anyDown[this.switchingId] = true;
	switchedTiles[this.switchingId].blocksMovement = false;
	switchedTiles[this.switchingId].color = "rgb(235, 235, 235)";
}
SwitchTile.prototype.update = function() { this.down=false;
	if(!anyDown[this.switchingId]) {
		if(!switchedTiles[this.switchingId].touchingAI) {
			switchedTiles[this.switchingId].blocksMovement = true;
			switchedTiles[this.switchingId].color = "rgb(253, 198, 137)";
		}
	}
	anyDown[this.switchingId] = false;
}

// PLAYER WALL TILE (blocks only player)
var PlayerWallTile = function(x, y){
	this.init(x, y);
	this.blocksOnlyPlayer = true;
	this.color = "rgb(155,197,247)";
};
PlayerWallTile.prototype = Object.create(Tile);


var getTile = function(x, y, id) {
	if(19<id && id<30) {
		t = new SwitchedTile(x, y)
		switchedTiles[id-20] = t;
		anyDown.push(false);
		return t;
	}
	else if(9<id && id<20) {
		return new SwitchTile(x, y, id-10);
	}
	else {
		switch(id) {
			case 1:
				return new WallTile(x, y);
			case 2:
				return new VictoryTile(x, y);
			case 3:
				return new LavaTile(x, y);
			case 4: 
				return new PlayerWallTile(x, y);
			default:
				return new FloorTile(x, y);
		}
	}
}


var world = function() {
	var aiEntities = [];
	var floor = [];
	var gridSize;
	var curLevel;
	var deaths = 0;
	var intervalId;
	var fps = 30;
	var hitSpace = false;
	var dialogue = "";
	var hasDied = false;
	var prevTime;
	var hasWon = false;

	var init = function(level, canvasId, hudId, tipId) {
		renderer.init(canvasId, hudId, tipId);
		initLevel(level);
		
		prevTime = Date.now();
	}

	var initLevel = function(level) {
		hasDied = false;
		hasWon = false; dialogue=""; switchedTiles=new Array(10);anyDown=[]; rooftopUid=0;
		if(intervalId)
			clearInterval(intervalId); //makes sure we don't run dual loops

		curLevel = level;
		if(level==levels.length) {
			// alert("That's all folks!");
			createDialogue("That's all folks");
			return;
		}

		renderer.initLevel(levels[level]);
		gridSize = renderer.gridSize;

		player.init(gridSize);
		input.gameMode();
		input.reset();
				
		loadLevel(level);
		renderer.renderText(deaths, curLevel, levels[curLevel].tip);

		// Loop supplied by new fixed-step presentation controller.
		run();
	}

	var victory=function(){if(!hasWon&&!hasDied){hasWon=true;input.reset();bridge.win(curLevel);}};
 var death=function(){if(!hasDied&&!hasWon){hasDied=true;deaths++;input.reset();bridge.fail(curLevel);}};

	var loadLevel = function(index) {
		// loads level from level file
		var currentLevel = levels[index];
		floor.length = 0;
		aiEntities.length = 0;
		for (var y = 0; y < currentLevel.sizeY; y++) {
			floor.push([]);
			for (var x = 0; x < currentLevel.sizeX; x++) {
				if (currentLevel.tiles[y][x] >= 0) {
					floor[y].push(getTile(x*gridSize, y*gridSize, currentLevel.tiles[y][x]));
				}
				else {
					floor[y].push(getTile(x*gridSize,y*gridSize,0));	
					if(x==currentLevel.startX && y==currentLevel.startY)
						player.setAI(getAI(x*gridSize+gridSize/2, y*gridSize+gridSize/2, currentLevel.tiles[y][x]));
					else {
						aiEntities.push(getAI(x*gridSize+gridSize/2, y*gridSize+gridSize/2, currentLevel.tiles[y][x]));
					}
				}
			}
		}
	}

	var run = function() {
		// var deltaTime = (Date.now() - prevTime);
		// prevTime = Date.now();
		// console.log(deltaTime);
		if (!dialogue&&!hasWon&&!hasDied) update();
		renderer.draw(aiEntities, floor);
		if (dialogue) {
			input.dialogueMode();
			renderer.showDialogue(dialogue);
		}
	}	

	var update = function() {
		for(var y=0; y<floor.length; y++) {
			for(var x=0; x<floor[y].length; x++) {
				floor[y][x].update();
			}
		}

		//update player and player collision
		var oldX=player.x,oldY=player.y; player.update(gridSize);
 var newX=player.x,newY=player.y;
 player.x=blocked(newX,oldY,true)?oldX:newX;
 player.y=blocked(player.x,newY,true)?oldY:newY;
		var touchingTiles = collide(player).tiles;
		for(var i=0; i<touchingTiles.length; i++) {
			if(touchingTiles[i].blocksMovement || touchingTiles[i].blocksOnlyPlayer) {
				// Axis collision already resolved above.
			}
			touchingTiles[i].onCollide(player);
		}

		//update AIs and AI collisions
		for(var i=0; i<aiEntities.length; i++) {
			var prevX=aiEntities[i].x,prevY=aiEntities[i].y; aiEntities[i].update(gridSize);
			var touchingTiles = collide(aiEntities[i]).tiles;
			for(var j=0; j<touchingTiles.length; j++) {
				aiEntities[i].onCollide(touchingTiles[j]); if(touchingTiles[j].blocksMovement){aiEntities[i].x=prevX;aiEntities[i].y=prevY;}
				touchingTiles[j].onCollide(aiEntities[i])
			}
		}

	}

	var collide = function(ai) {
		var touching = {
			tiles: [],
		}
		var x = (ai.x - gridSize/2) + 5;
		var y = (ai.y - gridSize/2) + 5;
		addToArray(touching.tiles, tileAt(x,y));
		addToArray(touching.tiles, tileAt(x+gridSize-10,y));
		addToArray(touching.tiles, tileAt(x,y+gridSize-10));
		addToArray(touching.tiles, tileAt(x+gridSize-10,y+gridSize-10));
		return touching;
	}	

var tileAt=function(x,y){var q=coordToGrid(x,y);return floor[q.y]&&floor[q.y][q.x]||{blocksMovement:true,onCollide:function(){}};};
 var blocked=function(x,y,active){var r=gridSize/2-5;return [[-r,-r],[r,-r],[-r,r],[r,r]].some(function(d){var t=tileAt(x+d[0],y+d[1]);return t.blocksMovement||(active&&t.blocksOnlyPlayer);});};
	var coordToGrid = function(x, y) {
		var grid = {};
		grid.x = Math.round((x-gridSize/2)/gridSize);
		grid.y = Math.round((y-gridSize/2)/gridSize);
		return grid;
	}

	var addToArray = function(array, obj) {
		if(array.indexOf(obj)==-1) 
			array.push(obj);
	}

	var cyclePlayer = function() {
		aiEntities.push(player.getAI());		
		player.setAI(aiEntities.shift());
	}

	var createDialogue = function(info) {
		input.dialogueMode();
		dialogue = info;
	}

	var closeDialogue = function() {
		input.gameMode();
		dialogue = "";
		initLevel(curLevel);
	}

	var resetLevel = function() {
		createDialogue("Level Reset!");
		initLevel(curLevel);
	}

	return {
step:run, start:initLevel, state:function(){return {floor:floor,ais:aiEntities,level:curLevel,won:hasWon,failed:hasDied};},
 snapshot:function(){player.getAI();return {level:curLevel,selected:player.currentAI.uid,bots:[player.currentAI].concat(aiEntities).map(function(a){var q={};Object.keys(a).forEach(function(k){if(typeof a[k]!=='function')q[k]=a[k];});return q;}),player:player.serialize(),tiles:floor.map(function(row){return row.map(function(t){return {blocksMovement:t.blocksMovement,touchingAI:t.touchingAI,justTouching:t.justTouching,down:t.down};});})};},
 restore:function(s){initLevel(s.level);var all=[player.currentAI].concat(aiEntities);s.bots.forEach(function(b){var a=all.find(function(a){return a.uid===b.uid;});if(a)Object.assign(a,b);});var chosen=all.find(function(a){return a.uid===s.selected;});if(chosen){aiEntities=all.filter(function(a){return a!==chosen;});player.setAI(chosen);player.restore(s.player);}s.tiles.forEach(function(row,y){row.forEach(function(t,x){Object.assign(floor[y][x],t);});});},
 init: init,
		victory: victory,
		cyclePlayer: cyclePlayer,
		death: death,
		closeDialogue: closeDialogue,
		resetLevel: resetLevel,
	}
}();
var rooftopUid=0, sourceGetAI=getAI;getAI=function(x,y,id){var a=sourceGetAI(x,y,id);a.kind=id;a.uid=rooftopUid++;return a;};
