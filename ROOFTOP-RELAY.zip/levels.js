/* Original rooftop layouts. Tile IDs follow the adapted Swap engine. */
var roofPlans=[
['Across the Gap','Switch to the robot on the other roof.',['#########','#..c...E#','#b.c.c..#','#.......#','#xxxxxxx#','#.......#','#.......#','#a......#','#########']],
['Hold the Door','Park one robot on ◇. Switch and use the gate.',['#########','#...#..E#','#.p.#.c.#','#.b.#...#','#...#.c.#','#..cG...#','#...#...#','#a..#...#','#########']],
['Round the Corner','One partner. One switch. A different route.',['#########','#....c.E#','#.###...#','#...#c..#','#####G###','#.......#','#p.c..b.#','#a......#','#########']],
['The Long Way','Take the upper robot through the open passage.',['#########','#E.c#...#','#.#c#b..#','#.#.#...#','#.#.###.#','#c......#','#######.#','#a......#','#########']],
['Autopilot','The striped vent stops you, not an autopilot.',['#########','#B..M.cE#','#########','#.......#','#...c...#','#.......#','#..c....#','#a......#','#########']],
['Sunroom Circuit','Hold the brass pad. Find the balcony route.',['#########','#E.c#...#','#...#b..#','#.c.#.p.#','#...#...#','#...G.c.#','#...#...#','#...#..a#','#########']],
['Narrow Escape','The second robot has a better starting point.',['#########','#c..#..E#','#.#.#.#c#','#b#...#.#','#.#####.#','#c......#','#######.#','#a......#','#########']],
['Eastbound','Let the courier cross the vent before switching.',['#########','#B.cM..E#','#########','#....c..#','#.......#','#..c....#','#.......#','#a......#','#########']],
['Moving Together','The echo robot follows your movement.',['#########','#....c.E#','#F..c...#','#.......#','#########','#.......#','#a......#','#..c....#','#########']],
['Terrace Gate','A partner opens the gate. The exit is on the left.',['#########','#E.c#..p#','#...#.b.#','#...#...#','#.c.G.c.#','#...#...#','#...#...#','#...#a..#','#########']],
['The Switchback','Trace the balcony, then change partners.',['#########','#E..c...#','#######.#','#b.c....#','#.#######','#......c#','#######.#','#a......#','#########']],
['Last Lift','A final relay across the sunlit rooftops.',['#########','#p..#..E#','#.b.#.c.#','#...#...#','#..cG...#','#...#.c.#','#...#...#','#a..#...#','#########']]
];
var levels=roofPlans.map(function(p){var map=p[2],startX=0,startY=0,collectibles=[];var tiles=map.map(function(row,y){return row.split('').map(function(c,x){if(c==='a'){startX=x;startY=y;}if(c==='c')collectibles.push([x,y]);return {'#':1,'.':0,'c':0,'E':2,'x':3,'p':10,'G':20,'M':4,'a':-1,'b':-1,'B':-3,'F':-4}[c];});});return {name:p[0],tip:p[1],sizeX:map[0].length,sizeY:map.length,startX:startX,startY:startY,tiles:tiles,cells:collectibles};});
