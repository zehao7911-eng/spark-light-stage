LANTERN LANE
A little trail of light.

PLAY
Draw one continuous trail from the fox to the house. Light every lantern.
Use the stepping-stone paths; a stone cannot be visited twice in the same trail.
The three golden stars are optional detours. Bring as many home as you can.
When all lanterns are lit and the trail reaches home, the fox follows your route.

CONTROLS
Drag along the stones, or tap consecutive stones. Drag backward to retrace.
Tap an earlier stone to shorten your trail to that point. UNDO removes one step.
RESET starts the trail again. HINT highlights a step on a route with all stars.
If the current trail is stuck, HINT first retraces enough steps to find a route.
Keyboard: focus the board and use arrow keys, or focus a stone and press Enter.
There are no timers, lives or purchases. Sound starts after a player interaction.

REWARDS
Each completed night earns 1-3 stars. Every six stars add a decoration to the
actual village: a firefly jar, pond, mushrooms, tent, owl, bakery, balloons and
shooting stars. Open YOUR LITTLE VILLAGE to view the collection.
Progress, rewards and sound preferences save locally. Reloading after a claimed
night continues to the next one without claiming the same reward twice.

PUZZLES
140 generated layouts, each verified with a route that lights all lanterns and
collects all three stars. Early nights introduce 3x3 boards with two lanterns.
The route choices grow through 4x4 and 5x5 to 6x6 with five lanterns.
After the initial set, advanced mirrored layouts keep the nights going.

RUN
Extract the ZIP and open index.html, or host the folder on any static web server.
For HTML5 game platforms, upload the ZIP with index.html at the archive root.
All art and audio are generated in code. No external libraries, fonts or CDN.

MOBILE
Responsive portrait and landscape layouts, safe-area spacing, touch dragging,
pixel ratio capped at 2, optional vibration, reduced motion support and paused
animation while the tab is hidden.

VALIDATION
Verified 1,200 level selections and 24,588 valid steps, including all-lantern,
all-star routes and backtracking. Browser tests cover real drag input, undo,
hints, completion, reward unlocks, persistence and layouts at 320x568,
390x844, 844x390 and 1440x900, with no script errors or layout overflow.
Mobile tests use browser device-size simulations rather than physical devices.
