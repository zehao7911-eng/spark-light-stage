extends Node2D

const SAVE = "user://neon_tether.json"
const TITLES = ["Rainline", "Signal chase", "Furnace heart", "Molten relay", "Wild antenna", "Sky garden", "Moonrise", "The last signal"]
var city = preload("res://assets/city.png")
var sheet = preload("res://assets/sprites.png")
var room = 0
var lap = 0
var bank = 0
var upgrades = {"armor":0,"reach":0,"magnet":0}
var medals = []
var mode = "title"
var p = Vector2(100,410)
var vel = Vector2.ZERO
var camera = Vector2.ZERO
var target = Vector2.ZERO
var zip = false
var zip_origin = Vector2.ZERO
var health = 3
var nodes = []
var drones = []
var gems = []
var platforms = []
var effects = []
var trail = []
var t = 0.0
var elapsed = 0.0
var combo = 0
var best_combo = 0
var combo_time = 0.0
var earned = 0
var collected = 0
var total = 0
var deaths = 0
var invincible = 0.0
var shake = 0.0
var freeze = 0.0
var ui_clock = 0.0
var checkpoint = Vector2(100,410)
var portal = Vector2.ZERO
var notice = "Tap a cyan anchor to fly."
var notice_time = 4.0
var muted = false
var reduced = false
var callback
var players = []
var music_player: AudioStreamPlayer
var music_clock = 0.0
var grade = 0
var screen = Vector2(1100,760)
var scale_world = 1.0
var world_top = 88.0
var world_height = 500.0

func _ready():
	Engine.max_fps = 60
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	load_progress()
	generate_room()
	if OS.has_feature("web"):
		callback = JavaScriptBridge.create_callback(_web_action)
		JavaScriptBridge.get_interface("window").ntAction = callback
	set_process_unhandled_input(true)
	if "--qa" in OS.get_cmdline_user_args():
		self_test()

func max_health():
	return 3 + int(upgrades.armor)

func save_progress():
	var payload=JSON.stringify({"room":room,"lap":lap,"bank":bank,"upgrades":upgrades,"medals":medals,"muted":muted,"reduced":reduced})
	if OS.has_feature("web"):
		JavaScriptBridge.eval("try { localStorage.setItem('neon-tether-v1', "+JSON.stringify(payload)+"); } catch(e) {}")
	var f = FileAccess.open(SAVE, FileAccess.WRITE)
	if f:
		f.store_string(payload)
		f.close()

func load_progress():
	var raw=""
	if OS.has_feature("web"):
		var saved=JavaScriptBridge.eval("(function(){try{return localStorage.getItem('neon-tether-v1')}catch(e){return null}})()",true)
		if saved is String: raw=saved
	if raw=="" and FileAccess.file_exists(SAVE): raw=FileAccess.get_file_as_string(SAVE)
	var d = JSON.parse_string(raw) if raw!="" else null
	if not d is Dictionary: return
	room = clampi(int(d.get("room",0)),0,7)
	lap = clampi(int(d.get("lap",0)),0,99)
	bank = clampi(int(d.get("bank",0)),0,999999)
	medals = d.get("medals",[])
	muted = d.get("muted",false)
	reduced = d.get("reduced",false)
	for k in upgrades:
		upgrades[k] = clampi(int(d.get("upgrades",{}).get(k,0)),0,3)

func generate_room():
	nodes.clear(); drones.clear(); gems.clear(); platforms.clear(); effects.clear(); trail.clear()
	zip = false; vel = Vector2.ZERO; p = Vector2(100,410); checkpoint = p
	camera = Vector2.ZERO
	health = max_health(); elapsed = 0; earned = 0; collected = 0; deaths = 0; combo = 0; best_combo = 0
	platforms.append(Rect2(25,410,220,90))
	var heights = [[295,220,310,170,270,210,310],[245,335,205,300,180,285,230],[310,190,280,165,290,210,300],[220,310,170,270,200,320,220],[270,160,280,220,145,245,320],[330,250,155,250,335,220,160],[200,300,210,135,235,330,240],[310,205,135,235,310,190,270]]
	for i in range(7):
		var x = 300.0 + i * 205
		var y = float(heights[room][i])
		nodes.append({"base":Vector2(x,y),"p":Vector2(x,y),"moving":room>0 and i%3==1,"phase":i*1.2,"used":false})
		platforms.append(Rect2(x-65,y+70,130,65))
		gems.append({"p":Vector2(x,y+20),"got":false})
		gems.append({"p":Vector2(x-50,y+35),"got":false})
		if i>0 and (i%2==0 or room>2):
			drones.append({"base":Vector2(x-75,y+55),"p":Vector2(x-75,y+55),"hp":1,"phase":i*0.9,"timer":1.2+i*.33,"shot":0.0,"boss":false})
	# Optional upper route: two bonus anchors and high-value cache.
	for i in range(2):
		var a = Vector2(650+i*400,85)
		nodes.append({"base":a,"p":a,"moving":false,"phase":0.0,"used":false})
		gems.append({"p":a+Vector2(15,5),"got":false})
	portal = Vector2(1800,320)
	platforms.append(Rect2(1670,410,260,90))
	nodes.append({"base":Vector2(1760,275),"p":Vector2(1760,275),"moving":false,"phase":0.0,"used":false})
	if room == 3 or room == 7:
		drones.append({"base":Vector2(1710,320),"p":Vector2(1710,320),"hp":3+lap,"phase":0.0,"timer":2.0,"shot":0.0,"boss":true})
	total = gems.size()
	notice = "Tap cyan anchors. Tap drones to strike." if room==0 else TITLES[room]
	notice_time = 5

func _web_action(args):
	if args.size()>0: action(str(args[0]))

func action(a):
	if a=="sound":
		muted = not muted
		for ap in players: ap.volume_db = -80 if muted else -12
		save_progress(); sync_ui(); return
	if a=="motion": reduced = not reduced; save_progress(); sync_ui(); return
	if a=="pause" and mode=="play": mode="pause"; sync_ui(); return
	if a=="resume" and mode=="pause": mode="play"; sync_ui(); return
	if a=="begin" and mode=="title": mode="play"; tone(0); sync_ui(); return
	if a=="retry" and mode=="fallen": generate_room(); mode="play"; sync_ui(); return
	if a.begins_with("buy_") and mode=="reward":
		var k = a.trim_prefix("buy_")
		if upgrades.has(k) and upgrades[k]<3:
			var price = 25*(upgrades[k]+1)
			if bank>=price:
				bank-=price; upgrades[k]+=1; tone(2); save_progress()
		sync_ui(); return
	if a=="next" and mode=="reward":
		if room==7: mode="ending"
		else: room+=1; generate_room(); mode="play"
		save_progress(); sync_ui(); return
	if a=="lap" and mode=="ending":
		lap+=1; room=0; generate_room(); mode="play"; save_progress(); sync_ui(); return
	if a=="jump" and mode=="play":
		if zip: zip=false
		vel = Vector2(180,-340); tone(0); return
	if a=="hook" and mode=="play":
		var best = -1
		var distance = 99999.0
		for i in range(nodes.size()):
			var v = nodes[i].p-p
			if v.x>30 and v.length()<reach() and v.length()<distance:
				best=i; distance=v.length()
		if best>=0: hook_node(best)
		return

func reach(): return 440.0 + upgrades.reach*55

func hook_node(i):
	if mode!="play" or p.distance_to(nodes[i].p)>reach(): return
	target = nodes[i].p+Vector2(0,35)
	zip_origin = p
	zip = true
	if not nodes[i].used:
		nodes[i].used=true; add_combo(); earned+=1
	tone(0)
	burst(p,Color("62e5ef"),8)

func hook_enemy(i):
	if mode!="play" or drones[i].hp<=0 or p.distance_to(drones[i].p)>reach(): return
	target = drones[i].p
	zip_origin = p; zip=true; tone(0)

func _unhandled_input(event):
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode==KEY_ENTER:
			action({"title":"begin","reward":"next","ending":"lap","fallen":"retry","pause":"resume"}.get(mode,"hook")); return
		if mode=="reward" and event.keycode in [KEY_1,KEY_2,KEY_3]:
			action("buy_"+["armor","reach","magnet"][event.keycode-KEY_1]); return
	if mode!="play": return
	if event is InputEventMouseButton and event.pressed and event.button_index==MOUSE_BUTTON_LEFT:
		tap_world(event.position)
	elif event is InputEventKey and event.pressed and not event.echo:
		if event.keycode==KEY_SPACE: action("hook")
		if event.keycode==KEY_W or event.keycode==KEY_UP: action("jump")
		if event.keycode==KEY_ESCAPE: action("pause")

func tap_world(pos):
	if pos.y<world_top or pos.y>world_top+world_height: return
	var hit = maxf(34.0,30.0/scale_world)
	var q = (pos-Vector2(screen.x/2,world_top+world_height/2))/scale_world + camera
	var closest = hit
	var picked = -1
	for i in range(drones.size()):
		if drones[i].hp<=0: continue
		var d = q.distance_to(drones[i].p)
		if d<closest and p.distance_to(drones[i].p)<reach(): closest=d; picked=i
	if picked>=0: hook_enemy(picked); return
	closest=hit; picked=-1
	for i in range(nodes.size()):
		var d=q.distance_to(nodes[i].p)
		if d<closest and p.distance_to(nodes[i].p)<reach(): closest=d; picked=i
	if picked>=0: hook_node(picked)
	else:
		notice="Choose a glowing anchor in reach."; notice_time=1.5

func add_combo():
	combo = combo+1 if combo_time>0 else 1
	combo_time=4.0
	best_combo=maxi(best_combo,combo)

func _physics_process(dt):
	if mode!="play": return
	if freeze>0: freeze-=dt; return
	elapsed+=dt
	invincible=maxf(0,invincible-dt)
	combo_time=maxf(0,combo_time-dt)
	if combo_time<=0: combo=0
	for n in nodes:
		if n.moving: n.p=n.base+Vector2(0,sin(elapsed*1.8+n.phase)*32)
	for d in drones:
		if d.hp<=0: continue
		d.p=d.base+Vector2(sin(elapsed*1.4+d.phase)*38,cos(elapsed*1.8+d.phase)*12)
		d.timer-=dt
		d.shot=maxf(0,d.shot-dt)
		if d.timer<=0:
			d.timer=3.8-maxf(0,minf(lap,5))*.2; d.shot=.25
			if absf(p.y-d.p.y)<21 and absf(p.x-d.p.x)<450 and not zip: hurt()
	if zip:
		var old = p
		p=p.move_toward(target,dt*920)
		trail.append({"p":old,"life":.22})
		for d in drones:
			if d.hp>0 and Geometry2D.get_closest_point_to_segment(d.p,old,p).distance_to(d.p)<34:
				d.hp-=1; d.timer=3.5
				add_combo(); earned+=6+mini(combo,10)
				burst(d.p,Color("ffb869"),22); tone(1); freeze=.065; shake=5
				if d.hp>0:
					zip=false; vel=Vector2(100,-180); invincible=1.0
				else: invincible=.35
		if p.distance_to(target)<1:
			zip=false; vel=Vector2(110,-100)
	else:
		var axis = float(Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT))-float(Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT))
		if axis!=0: vel.x=axis*190
		else: vel.x=move_toward(vel.x,0,dt*210)
		vel.y+=650*dt
		var previous=p
		p+=vel*dt
		for r in platforms:
			if vel.y>=0 and p.x>r.position.x-8 and p.x<r.end.x+8 and previous.y<=r.position.y+5 and p.y>=r.position.y:
				p.y=r.position.y; vel.y=0
		for d in drones:
			if d.hp>0 and p.distance_to(d.p)<28: hurt()
	for gem in gems:
		if not gem.got and p.distance_to(gem.p)<42+upgrades.magnet*15:
			gem.got=true; collected+=1; earned+=3; burst(gem.p,Color("ffd489"),9); tone(2)
	if p.x>900 and checkpoint.x<800:
		checkpoint=Vector2(1120,platforms[5].position.y)
		notice="CHECKPOINT"; notice_time=2; burst(p,Color("5ce5ec"),14)
	if p.y>620 or p.x<0:
		deaths+=1; health-=1; respawn()
	if p.distance_to(portal)<85:
		var blocked=false
		for d in drones:
			if d.boss and d.hp>0: blocked=true
		if blocked: notice="Break the guardian's armor."; notice_time=1
		else: finish_room()

func hurt():
	if invincible>0: return
	health-=1; deaths+=1; invincible=1.5; shake=7
	burst(p,Color("ff727b"),15); tone(3)
	if health<=0: mode="fallen"; zip=false; sync_ui()

func respawn():
	zip=false; vel=Vector2.ZERO; p=checkpoint; invincible=2; combo=0
	if health<=0: mode="fallen"
	sync_ui()

func finish_room():
	if mode!="play": return
	grade=1+int(collected>=total*.7)+int(collected==total and deaths==0 and elapsed<35)
	var bounty=earned+20+grade*8
	bank+=bounty
	while medals.size()<8: medals.append(0)
	medals[room]=maxi(int(medals[room]),grade)
	mode="reward"; zip=false; tone(4); save_progress(); sync_ui()

func burst(at,color,count):
	for i in range(count):
		if effects.size()>160: break
		effects.append({"p":at,"v":Vector2(randf_range(-160,160),randf_range(-180,60)),"life":randf_range(.25,.7),"color":color})

func _process(dt):
	t+=dt
	screen=get_viewport_rect().size
	world_top=62.0 if screen.y<500 else 88.0
	world_height=maxf(160,screen.y-(152 if screen.y<500 else 210))
	scale_world=maxf(screen.x/1050,world_height/570)
	if mode=="play":
		var cam_goal=Vector2(clampf(p.x+(60 if screen.x<600 else 110),200 if screen.x<600 else 260,1720 if screen.x<600 else 1620),265)
		camera=camera.lerp(cam_goal,1-exp(-dt*6))
		for e in effects:
			e.life-=dt; e.p+=e.v*dt; e.v.y+=200*dt
		effects=effects.filter(func(e): return e.life>0)
		for e in trail: e.life-=dt
		trail=trail.filter(func(e): return e.life>0)
		shake=move_toward(shake,0,dt*22)
		notice_time=maxf(0,notice_time-dt)
		music_clock+=dt
		if music_clock>1.0: music_clock=0; tone(5)
	elif mode=="title": camera=Vector2(200 if screen.x<600 else 330,265)
	ui_clock+=dt
	if ui_clock>.15: ui_clock=0; sync_ui()
	queue_redraw()

func to_screen(v):
	return (v-camera)*scale_world+Vector2(screen.x/2,world_top+world_height/2)

func atlas(rect,at,size,flip=false,color=Color.WHITE):
	var r=Rect2(rect[0],rect[1],rect[2],rect[3])
	var f=sheet.get_width()/1280.0
	r.position*=f; r.size*=f
	var wh=Vector2(size*rect[2]/rect[3],size)*scale_world
	var xy=to_screen(at)-Vector2(wh.x/2,wh.y)
	if flip: xy.x+=wh.x; wh.x=-wh.x
	draw_texture_rect_region(sheet,Rect2(xy,wh),r,color)

func _draw():
	draw_rect(Rect2(Vector2.ZERO,screen),Color("080d20"))
	var district=room/2
	var src=Rect2((district%2)*768,(district/2)*512,768,512)
	var bg_scale=maxf(screen.x/768,world_height/512)
	var bg_size=Vector2(768,512)*bg_scale
	var offset=fmod(camera.x*.06,40)
	draw_texture_rect_region(city,Rect2(Vector2((screen.x-bg_size.x)/2-offset,world_top),bg_size+Vector2(40,0)),src)
	# Playable scenery is a separate atlas layer; platform top exactly matches collision.
	for r in platforms:
		var segments=int(ceil(r.size.x/95))
		for j in range(segments):
			var rr=[0,970,320,260] if j==0 else [320,970,320,260]
			if j==segments-1: rr=[640,970,320,260]
			atlas(rr,Vector2(r.position.x+(j+.5)*r.size.x/segments,r.position.y+49),70)
		var a=to_screen(r.position)
		draw_line(a,to_screen(r.position+Vector2(r.size.x,0)),Color("65b7be"),2)
	for gem in gems:
		if not gem.got: atlas([320,660,320,300],gem.p+Vector2(0,18+sin(t*3+gem.p.x)*3),30)
	for n in nodes:
		var v=to_screen(n.p)
		var valid=p.distance_to(n.p)<reach()
		var col=Color("63ebef") if valid else Color("456c80")
		if valid:
			draw_circle(v,23*scale_world,Color(col,.08))
			draw_arc(v,(17+sin(t*4+n.phase)*2)*scale_world,0,TAU,24,Color(col,.5),1.5)
		atlas([0,660,320,300],n.p+Vector2(0,17),39,false,Color.WHITE if valid else Color(.4,.5,.6))
		if n.used: draw_circle(v+Vector2(14,-12)*scale_world,2,Color("ffcb78"))
	atlas([960,660,320,300],checkpoint+Vector2(0,0),55)
	atlas([640,660,320,300],portal+Vector2(0,75),120)
	for d in drones:
		if d.hp<=0: continue
		var frame=2 if d.timer<.7 else int(t*3)%2
		atlas([frame*320,390,320,260],d.p+Vector2(0,30),85 if d.boss else 57)
		if d.boss:
			var a=to_screen(d.p+Vector2(-35,-55))
			draw_rect(Rect2(a,Vector2(70*scale_world,5)),Color("301938"))
			draw_rect(Rect2(a,Vector2(70*scale_world*d.hp/(3.0+lap),5)),Color("ff828d"))
		if d.timer<.7 or d.shot>0:
			var a=to_screen(d.p+Vector2(-380,0)); var b=to_screen(d.p+Vector2(380,0))
			draw_line(a,b,Color("ff5678") if d.shot>0 else Color(1,.3,.5,.35),3 if d.shot>0 else 1)
	if zip:
		draw_line(to_screen(p+Vector2(0,-24)),to_screen(target),Color("163f5b"),5*scale_world)
		draw_line(to_screen(p+Vector2(0,-24)),to_screen(target),Color("abf8ed"),2*scale_world)
	for e in trail:
		atlas([960,0,320,390],e.p,66,false,Color(.3,.9,1,e.life*.55))
	var pose=3 if zip else 2 if absf(vel.y)>30 else 1 if absf(vel.x)>10 else 0
	var player_pos=p+Vector2(randf_range(-shake,shake),0) if not reduced else p
	if invincible<=0 or int(t*12)%2==0:
		atlas([pose*320,0,320,390],player_pos,72,vel.x<0 and not zip)
	for e in effects:
		draw_rect(Rect2(to_screen(e.p),Vector2(3,3)*scale_world),Color(e.color,e.life*1.5))
	if not reduced:
		for i in range(38):
			var a=Vector2(fposmod(i*83.5-t*70,screen.x),world_top+fposmod(i*51+t*230,world_height))
			draw_line(a,a+Vector2(-3,10),Color(.4,.7,.9,.14),1)
	# UI uses DOM controls in web; canvas remains playable and resize responsive.
	if not OS.has_feature("web"):
		var font=ThemeDB.fallback_font
		draw_string(font,Vector2(24,40),"NEON TETHER  /  "+TITLES[room]+"   HP "+str(health)+"   CREDITS "+str(bank),HORIZONTAL_ALIGNMENT_LEFT,-1,20)
		draw_string(font,Vector2(24,screen.y-50),"A/D: move   W: leap   SPACE: grapple   ESC: pause",HORIZONTAL_ALIGNMENT_LEFT,-1,18)
		if mode!="play":
			draw_rect(Rect2(Vector2(screen.x/2-235,screen.y/2-60),Vector2(470,120)),Color(.03,.08,.16,.95))
			draw_string(font,Vector2(screen.x/2-210,screen.y/2-15),mode.to_upper()+" — ENTER TO CONTINUE",HORIZONTAL_ALIGNMENT_LEFT,-1,20)
			draw_string(font,Vector2(screen.x/2-210,screen.y/2+20),"Upgrades: 1 Armor / 2 Cable / 3 Magnet",HORIZONTAL_ALIGNMENT_LEFT,-1,17)

func tone(kind):
	if muted or DisplayServer.get_name()=="headless": return
	var freq=[620.0,150.0,1046.0,90.0,784.0,220.0][kind]
	if kind==5: freq=[220,277,330,440,330,277,247,330][int(t)%8]
	var length=.15 if kind!=5 else .55
	var rate=22050
	var bytes=PackedByteArray()
	bytes.resize(int(rate*length)*2)
	for i in range(int(rate*length)):
		var phase=i/float(rate)
		var envelope=pow(1-phase/length,2)*minf(1,phase*200)
		var sample=sin(phase*freq*TAU)*envelope*(.07 if kind==5 else .24)
		bytes.encode_s16(i*2,int(sample*32767))
	var stream=AudioStreamWAV.new(); stream.format=AudioStreamWAV.FORMAT_16_BITS; stream.mix_rate=rate; stream.data=bytes
	var ap=AudioStreamPlayer.new(); add_child(ap); ap.stream=stream; players.append(ap)
	ap.finished.connect(func(): players.erase(ap); ap.queue_free())
	ap.play()

func snapshot():
	return {"mode":mode,"room":room,"title":TITLES[room],"lap":lap,"health":health,"maxHealth":max_health(),"bank":bank,"earned":earned,"collected":collected,"total":total,"combo":combo,"bestCombo":best_combo,"time":int(elapsed),"grade":grade,"deaths":deaths,"upgrades":upgrades,"medals":medals,"muted":muted,"reduced":reduced,"notice":notice if notice_time>0 else "","player":[snappedf(p.x,.1),snappedf(p.y,.1)],"zip":zip,"viewport":[screen.x,screen.y],"anchors":nodes.map(func(n): var s=to_screen(n.p); return [snappedf(s.x,1),snappedf(s.y,1),p.distance_to(n.p)<reach()]),"drones":drones.map(func(d): var s=to_screen(d.p); return [snappedf(s.x,1),snappedf(s.y,1),d.hp])}

func sync_ui():
	if OS.has_feature("web"):
		JavaScriptBridge.eval("window.ntState && window.ntState("+JSON.stringify(snapshot())+");")

func self_test():
	for r in range(8):
		room=r; generate_room()
		assert(nodes.size()==10)
		assert(gems.size()==16)
		var last=Vector2(100,410)
		for i in range(7):
			assert(last.distance_to(nodes[i].p)<reach())
			last=nodes[i].p+Vector2(0,35)
		assert(last.distance_to(nodes[9].p)<reach())
		mode="play"; collected=total; elapsed=20; deaths=0; finish_room()
		assert(mode=="reward" and grade==3)
		var prev=upgrades.armor
		bank=999; action("buy_armor")
		assert(upgrades.armor==mini(3,prev+1))
	for r in range(8):
		room=r; generate_room(); mode="play"
		upgrades.magnet=3
		for idx in [0,1,7,2,3,8,4,5,6,9]:
			hook_node(idx)
			for step in range(45): _physics_process(1.0/60)
		for attempt in range(5):
			if mode!="play": break
			if drones[-1].boss and drones[-1].hp>0: hook_enemy(drones.size()-1)
			else: hook_node(9)
			for step in range(45): _physics_process(1.0/60)
		assert(mode=="reward", "Physics route did not finish: "+str(r))
		assert(collected==total, "Upper route missed data: "+str(r)+" "+str(collected))
		assert(health>0)
	room=3; generate_room(); mode="play"; checkpoint=Vector2(1120,platforms[5].position.y)
	health=3; respawn()
	for step in range(120): _physics_process(1.0/60)
	assert(health==3 and p.y<500, "Checkpoint must remain on platform")
	mode="ending"; var old_lap=lap; action("lap")
	assert(lap==old_lap+1 and room==0 and mode=="play")
	print("NEON TETHER QA: 8 physics-complete routes, all 16 data crystals each, guardians, safe checkpoint, grades, upgrades, new loop passed")
	get_tree().quit()



