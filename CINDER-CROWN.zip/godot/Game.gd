extends Node2D

const SAVE_PATH = "user://cinder_crown.json"
const TYPES = ["Pawn", "Knight", "Bishop", "Rook", "Queen", "King"]
const HP = [2, 4, 4, 5, 6, 8]
const SPEED = [2, 3, 3, 4, 4, 3]
const UPGRADES = [
 ["Iron rain", "+2 pellets", "pellets"], ["Long barrel", "+1 range", "range"],
 ["Bandolier", "+1 shell capacity", "capacity"], ["Royal heart", "+1 max heart and heal", "heart"],
 ["Hot lead", "+1 pellet damage", "damage"], ["Ghost shot", "Pellets pierce one piece", "pierce"],
 ["Cold powder", "Hits delay enemies", "frost"], ["Marching fire", "Moving empowers next shot", "march"],
 ["Second wind", "Heal one heart", "heal"], ["Royal guard", "+1 safety seal", "guard"],
 ["Wide decree", "Wider shot cone", "spread"], ["Blood tithe", "Heal after 4 kills", "vampire"]
]
const CURSES = [["White recruits", "+2 pawns", "pawns"], ["Iron masks", "+1 enemy armor", "armor"], ["Royal escort", "+1 knight", "knights"], ["Thick marble", "+1 enemy health", "health"], ["Quick court", "Enemies act sooner", "speed"]]
var rng = RandomNumberGenerator.new()
var s: Dictionary = {}
var meta: Dictionary = {"best":0, "crowns":0, "runs":0,"forge":0}
var mode = "title"
var return_mode = "play"
var board = Rect2()
var cell = 48.0
var buttons: Array = []
var particles: Array = []
var numbers: Array = []
var trails: Array = []
var t = 0.0
var enemy_delay = 0.0
var shake = 0.0
var flash = 0.0
var aim_cell = Vector2i(-1,-1)
var note = ""
var note_time = 0.0
var muted = false
var help_page = 0
var effects: Array = []
var font: Font
var sounds: Dictionary = {}
var players: Array = []
var art: Dictionary = {}
var bridge_timer = 0.0
var hero_visual=Vector2.ZERO
var choice_rects: Array = []
var portrait = true

func _ready():
 Engine.max_fps=30
 rng.randomize()
 font = load("res://art/VT323-Regular.ttf")
 for i in 12:art["card"+str(i)]=load("res://art/card"+str(i)+".png")
 for color_name in ["black","white"]:
  for k in 6:art[color_name+str(k)]=load("res://art/"+color_name+str(k)+".png")
 for n in ["shot", "move", "hit", "coin", "hurt"]:
  sounds[n] = load("res://audio/"+n+".wav")
 for i in 5:
  var p = AudioStreamPlayer.new()
  add_child(p)
  p.volume_db = -12
  players.append(p)
 load_game()
 get_viewport().size_changed.connect(layout)
 layout()
 set_process(true)

func layout():
 var actual=DisplayServer.window_get_size()
 var wanted=Vector2i(480,800) if actual.x<actual.y*1.15 else Vector2i(900,450)
 if get_viewport().content_scale_size!=wanted:
  get_viewport().content_scale_size=wanted
 var v = get_viewport_rect().size
 portrait = v.x < v.y * 1.15
 cell = minf((v.x-48)/8.0, (v.y-285)/8.0) if portrait else minf((v.x-340)/8.0,(v.y-112)/8.0)
 cell=floor(cell/2)*2
 cell = maxf(24,cell)
 var side = cell * 8
 board = Rect2(Vector2((v.x-side)/2,145 if portrait else (v.y-side)/2),Vector2(side,side))
 if not portrait:
  board.position.x = (v.x-side)/2
 if not s.is_empty():hero_visual=center(pp())
 queue_redraw()

func play_sound(n: String):
 if muted:return
 for p in players:
  if not p.playing:
   p.stream=sounds[n]
   p.play()
   return

func new_run():
 s={"floor":1,"turn":0,"hp":3,"maxhp":3,"ammo":2,"capacity":2,"pellets":6,"range":5,"damage":1,"pierce":false,"frost":false,"march":false,"spread":0.28,"vampire":false,"guards":2,"kills":0,"gold":0,"player":[4,7],"enemies":[],"upgrades":[],"curses":[],"pawns":0,"knights":0,"armor":0,"health":0,"speed":0,"boost":0,"reward":[],"paid":false}
 s.pellets+=int(meta.get("forge",0))
 meta.runs+=1
 start_floor()
 mode="help"
 help_page=0
 save_game()

func start_floor():
 s.player=[4,7]
 s.ammo=s.capacity
 s.boost=0
 s.enemies=[]
 s.turn=0
 enemy_delay=0
 var f=int(s.floor)
 var slots:Array=[]
 for y in 3:
  for x in 8:slots.append(Vector2i(x,y))
 for i in range(slots.size()-1,0,-1):
  var j=rng.randi_range(0,i)
  var tmp=slots[i];slots[i]=slots[j];slots[j]=tmp
 add_enemy(5,Vector2i(4,0))
 slots.erase(Vector2i(4,0))
 var kinds:Array=[0,0,0]
 if f>=2:kinds.append(2)
 if f>=3:kinds.append(1)
 if f>=4:kinds.append(3)
 if f>=6:kinds.append(4)
 for i in mini(5,int(f/3)+int(s.pawns)):kinds.append(0)
 for i in mini(3,int(s.knights)):kinds.append(1)
 for i in kinds.size():add_enemy(kinds[i],slots[i])
 mode="play"
 note="TAP A NEARBY TILE TO MOVE"
 note_time=3
 aim_cell=Vector2i(-1,-1)
 hero_visual=center(pp())
 particles.clear()
 trails.clear()
 save_game()

func add_enemy(kind:int,pos:Vector2i):
 var hp=HP[kind]+int(s.health)+int((int(s.floor)-1)/8)
 if kind==5:hp+=int(s.floor)*2
 s.enemies.append({"k":kind,"x":pos.x,"y":pos.y,"hp":hp,"max":hp,"timer":SPEED[kind],"armor":int(s.armor),"flash":0.0})

func pp()->Vector2i:return Vector2i(int(s.player[0]),int(s.player[1]))
func ep(e:Dictionary)->Vector2i:return Vector2i(int(e.x),int(e.y))
func center(p:Vector2i)->Vector2:return board.position+(Vector2(p)+Vector2(.5,.5))*cell
func inside(p:Vector2i)->bool:return p.x>=0 and p.y>=0 and p.x<8 and p.y<8
func enemy_at(p:Vector2i)->int:
 for i in s.enemies.size():
  if ep(s.enemies[i])==p:return i
 return -1
func clear_line(a:Vector2i,b:Vector2i)->bool:
 var d=Vector2i(signi(b.x-a.x),signi(b.y-a.y))
 var p=a+d
 for i in 8:
  if p==b:return true
  if enemy_at(p)>=0:return false
  p+=d
 return false

func attacks(e:Dictionary,p:Vector2i)->bool:
 var a=ep(e);var d=p-a;var x=absi(d.x);var y=absi(d.y)
 if p==a:return false
 match int(e.k):
  0:return y==1 and x==1 and d.y>0
  1:return (x==1 and y==2) or (x==2 and y==1)
  2:return x==y and clear_line(a,p)
  3:return (x==0 or y==0) and clear_line(a,p)
  4:return (x==y or x==0 or y==0) and clear_line(a,p)
  5:return maxi(x,y)==1
 return false

func dangerous(p:Vector2i)->bool:
 for e in s.enemies:
  if int(e.timer)<=1 and attacks(e,p):return true
 return false

func enemy_moves(e:Dictionary)->Array:
 var result:Array=[];var a=ep(e)
 if int(e.k)==0:
  var b=a+Vector2i(0,1)
  if inside(b) and enemy_at(b)<0 and b!=pp():result.append(b)
 elif int(e.k)==1:
  for d in [Vector2i(1,2),Vector2i(2,1),Vector2i(-1,2),Vector2i(-2,1),Vector2i(1,-2),Vector2i(2,-1),Vector2i(-1,-2),Vector2i(-2,-1)]:
   var b=a+d
   if inside(b) and enemy_at(b)<0 and b!=pp():result.append(b)
 else:
  for d in [Vector2i(1,0),Vector2i(-1,0),Vector2i(0,1),Vector2i(0,-1),Vector2i(1,1),Vector2i(-1,1),Vector2i(1,-1),Vector2i(-1,-1)]:
   if int(e.k)==2 and (d.x==0 or d.y==0):continue
   if int(e.k)==3 and d.x!=0 and d.y!=0:continue
   for n in range(1,2 if int(e.k)==5 else 8):
    var b=a+d*n
    if not inside(b) or enemy_at(b)>=0 or b==pp():break
    result.append(b)
 return result

func move_player(p:Vector2i):
 if enemy_delay>0:return
 if maxi(absi(p.x-pp().x),absi(p.y-pp().y))!=1 or enemy_at(p)>=0:return
 if dangerous(p) and int(s.guards)>0:
  s.guards-=1
  message("SAFETY SEAL · DANGER BLOCKED")
  play_sound("hurt")
  save_game()
  return
 var a=center(pp())
 hero_visual=center(pp())
 s.player=[p.x,p.y]
 s.ammo=mini(int(s.capacity),int(s.ammo)+1)
 if s.march:s.boost=2
 burst(a,Color("9a8bba"),6)
 play_sound("move")
 message("SHELL LOADED")
 end_action()

func shoot(p:Vector2i):
 if enemy_delay>0:return
 if int(s.ammo)<=0:
  message("MOVE TO RELOAD")
  play_sound("move")
  return
 var d=Vector2(p-pp());var dist=d.length()
 if dist>float(s.range)+.5:
  message("OUT OF RANGE")
  return
 s.ammo-=1
 var angle=d.angle()
 var hit_count=0
 var damage_by:Dictionary={}
 var count=int(s.pellets)+int(s.boost)
 s.boost=0
 for i in count:
  var ray=angle+(float(i)/maxf(1,count-1)-.5)*float(s.spread)*2
  var dir=Vector2.from_angle(ray)
  var hits:Array=[]
  for e in s.enemies:
   var rel=Vector2(ep(e)-pp());var proj=rel.dot(dir)
   if proj>0 and proj<float(s.range)+.55 and absf(rel.cross(dir))<.43:
    hits.append({"e":e,"distance":proj})
  hits.sort_custom(func(a,b):return a.distance<b.distance)
  var stop=float(s.range)
  for h in hits.slice(0,2 if s.pierce else 1):
   var e:Dictionary=h.e
   var id=str(e.x)+":"+str(e.y)
   damage_by[id]=int(damage_by.get(id,0))+int(s.damage)
   stop=float(h.distance)
   if s.frost:e.timer=mini(7,int(e.timer)+1)
   e.flash=.35
   hit_count+=1
  trails.append({"a":center(pp()),"b":center(pp())+dir*stop*cell,"life":.17})
 if damage_by.is_empty() and enemy_at(p)>=0:
  var e:Dictionary=s.enemies[enemy_at(p)]
  damage_by[str(e.x)+":"+str(e.y)]=int(s.damage)
  hit_count=1
 for e in s.enemies.duplicate():
  var id=str(e.x)+":"+str(e.y)
  if damage_by.has(id):
   var damage=maxi(1,int(damage_by[id])-int(e.armor))
   e.hp-=damage
   numbers.append({"p":center(ep(e)),"text":"-"+str(damage),"life":.8,"color":Color("ffcf91")})
   burst(center(ep(e)),Color("ffbd73"),12)
   if int(e.hp)<=0:
    s.enemies.erase(e)
    s.kills+=1;s.gold+=1
    if s.vampire and int(s.kills)%4==0:s.hp=mini(int(s.maxhp),int(s.hp)+1)
    burst(center(ep(e)),Color("e9e3d3"),20)
    if int(e.k)==5:
     win_floor()
     break
 burst(center(pp()),Color("ffd58a"),8)
 shake=8
 flash=.12
 play_sound("shot")
 if mode=="play":
  if hit_count==0:message("SCATTER SHOT · MISSED")
  end_action()

func end_action():
 s.turn+=1
 enemy_delay=.42
 aim_cell=Vector2i(-1,-1)
 save_game()

func enemy_turn():
 if mode!="play":return
 var hurt=false
 for e in s.enemies:
  e.timer=int(e.timer)-1
  if int(e.timer)>0:continue
  if attacks(e,pp()):
   if not hurt:
    s.hp-=1;hurt=true
    burst(center(pp()),Color("d05a64"),20)
    shake=9
    message("ROYAL HEART LOST")
    play_sound("hurt")
  else:
   var moves=enemy_moves(e)
   var best=ep(e);var best_score=10000.0
   for p in moves:
    var score=Vector2(p-pp()).length()
    if int(e.k)==0:score-=float(p.y)*.4
    var future=e.duplicate();future.x=p.x;future.y=p.y
    if attacks(future,pp()):score-=2
    if score<best_score:best_score=score;best=p
   e.prev=[int(e.x),int(e.y)];e.anim=.18
   e.x=best.x;e.y=best.y
   if int(e.k)==0 and int(e.y)==7:
    e.k=4;e.hp=maxi(4,int(e.hp));e.max=maxi(4,int(e.max))
    message("PAWN PROMOTED")
  e.timer=maxi(1,SPEED[int(e.k)]-int(s.speed))
 if int(s.hp)<=0:
  mode="lost"
  cash_out()
 save_game()

func win_floor():
 enemy_delay=0
 s.gold+=3+int(s.floor)
 s.hp=mini(int(s.maxhp),int(s.hp)+1)
 meta.best=maxi(int(meta.best),int(s.floor))
 var offers:Array=[]
 for i in 2:
  var u=rng.randi_range(0,UPGRADES.size()-1)
  if i==1 and u==int(offers[0][0]):u=(u+1)%UPGRADES.size()
  var c=rng.randi_range(0,CURSES.size()-1)
  offers.append([u,c])
 s.reward=offers
 mode="reward"
 note="KING DOWN!"
 note_time=3
 play_sound("coin")
 if int(s.floor)==10:
  mode="won"
  cash_out()
 save_game()

func choose_reward(i:int):
 var offer=s.reward[i]
 var u=UPGRADES[int(offer[0])]
 var c=CURSES[int(offer[1])]
 s.upgrades.append(int(offer[0]));s.curses.append(int(offer[1]))
 match str(u[2]):
  "pellets":s.pellets=mini(20,int(s.pellets)+2)
  "range":s.range=mini(9,int(s.range)+1)
  "capacity":s.capacity=mini(5,int(s.capacity)+1)
  "heart":s.maxhp=mini(8,int(s.maxhp)+1);s.hp=mini(int(s.maxhp),int(s.hp)+1)
  "damage":s.damage=mini(5,int(s.damage)+1)
  "pierce":s.pierce=true
  "frost":s.frost=true
  "march":s.march=true
  "heal":s.hp=mini(int(s.maxhp),int(s.hp)+1)
  "guard":s.guards=mini(6,int(s.guards)+1)
  "spread":s.spread=minf(.6,float(s.spread)+.06)
  "vampire":s.vampire=true
 match str(c[2]):
  "pawns":s.pawns=mini(5,int(s.pawns)+2)
  "armor":s.armor=mini(3,int(s.armor)+1)
  "knights":s.knights=mini(3,int(s.knights)+1)
  "health":s.health=mini(8,int(s.health)+1)
  "speed":s.speed=mini(1,int(s.speed)+1)
 s.floor+=1
 start_floor()
 play_sound("coin")

func cash_out():
 if not s.paid:
  meta.crowns+=int(s.gold)
  s.paid=true
func message(text:String):note=text;note_time=2.2
func burst(p:Vector2,c:Color,n:int):
 for i in n:
  if particles.size()>150:break
  particles.append({"p":p,"v":Vector2.from_angle(rng.randf()*TAU)*rng.randf_range(40,150),"life":rng.randf_range(.2,.6),"c":c})

func save_game():
 if s.is_empty():return
 var data={"state":s,"meta":meta,"mode":mode,"muted":muted}
 if enemy_delay>0:data.mode="pending"
 var file=FileAccess.open(SAVE_PATH,FileAccess.WRITE)
 if file:file.store_string(JSON.stringify(data))
func load_game():
 if not FileAccess.file_exists(SAVE_PATH):return
 var file=FileAccess.open(SAVE_PATH,FileAccess.READ)
 var data=JSON.parse_string(file.get_as_text())
 if data is Dictionary and data.has("meta"):
  meta=data.meta;muted=data.get("muted",false)
  if data.has("state") and not data.state.is_empty():
   s=data.state
   return_mode=data.get("mode","play")
   if return_mode=="pending":return_mode="play";mode="play";enemy_turn();return_mode=mode
 mode="title"
func _notification(what):
 if what==NOTIFICATION_APPLICATION_FOCUS_OUT:save_game()

func _process(dt):
 t+=dt
 bridge_timer+=dt
 if OS.has_feature("web") and bridge_timer>.25:
  bridge_timer=0
  var payload={"mode":mode,"state":s,"meta":meta,"board":[board.position.x,board.position.y,cell],"viewport":[get_viewport_rect().size.x,get_viewport_rect().size.y]}
  JavaScriptBridge.eval("window.CinderSnapshot="+JSON.stringify(payload),true)
 if mode=="play" and enemy_delay>0:
  enemy_delay-=dt
  if enemy_delay<=0:enemy_turn()
 shake=maxf(0,shake-dt*40);flash=maxf(0,flash-dt)
 note_time=maxf(0,note_time-dt)
 for p in particles:
  p.life-=dt;p.p+=p.v*dt;p.v.y+=dt*100
 particles=particles.filter(func(p):return p.life>0)
 for n in numbers:n.life-=dt;n.p.y-=dt*35
 numbers=numbers.filter(func(n):return n.life>0)
 for r in trails:r.life-=dt
 trails=trails.filter(func(r):return r.life>0)
 if not s.is_empty():
  hero_visual=hero_visual.lerp(center(pp()),minf(1,dt*16))
  for e in s.enemies:
   e.flash=maxf(0,float(e.get("flash",0))-dt)
   e.anim=maxf(0,float(e.get("anim",0))-dt)
 queue_redraw()

func _unhandled_input(ev):
 var pressed=false
 var pos=Vector2.ZERO
 if ev is InputEventScreenTouch:
  pressed=ev.pressed;pos=ev.position
 elif ev is InputEventMouseButton and ev.button_index==MOUSE_BUTTON_LEFT:
  pressed=ev.pressed;pos=ev.position
 elif ev is InputEventMouseMotion:
  aim_cell=Vector2i((ev.position-board.position)/cell) if board.has_point(ev.position) else Vector2i(-1,-1)
 if ev is InputEventKey and ev.pressed and ev.keycode==KEY_ESCAPE:
  if mode=="play":mode="pause";save_game()
  elif mode=="pause":mode="play"
 if not pressed:return
 for b in buttons:
  if b.rect.has_point(pos):
   action(b.id)
   get_viewport().set_input_as_handled()
   return
 if mode=="play" and board.has_point(pos):
  var p=Vector2i((pos-board.position)/cell)
  aim_cell=p
  if enemy_at(p)>=0:shoot(p)
  else:move_player(p)

func action(id:String):
 match id:
  "forge":
   var level=int(meta.get("forge",0));var cost=15*(level+1)
   if level<3 and int(meta.crowns)>=cost:
    meta.crowns-=cost;meta.forge=level+1;play_sound("coin");save_game()
  "start":new_run()
  "resume":mode=return_mode if return_mode not in ["title","pause","help"] else "play"
  "pause":
   if enemy_delay>0:return
   mode="pause";save_game()
  "continue":mode="play"
  "help":help_page=0;mode="help"
  "next_help":
   help_page+=1
   if help_page>1:mode="play";save_game()
  "retry":new_run()
  "title":return_mode="play";mode="title";save_game()
  "sound":muted=not muted;save_game()
  "choice0":choose_reward(0)
  "choice1":choose_reward(1)
  "endless":mode="reward";s.paid=false;s.gold=0;save_game()

func text_at(text:String,p:Vector2,size:int=18,color:Color=Color("e8dfca"),centered:bool=false):
 if size<=20:size=int(size*1.35)
 var x=p.x-font.get_string_size(text,HORIZONTAL_ALIGNMENT_LEFT,-1,size).x/2 if centered else p.x
 draw_string(font,Vector2(x,p.y),text,HORIZONTAL_ALIGNMENT_LEFT,-1,size,color)
func panel(r:Rect2,c:Color=Color("192135"),border:Color=Color("6f658c")):
 draw_rect(Rect2(r.position+Vector2(0,5),r.size),Color("080e19"))
 draw_rect(r,c)
 draw_rect(r,border,false,2)
 draw_line(r.position+Vector2(2,2),r.position+Vector2(r.size.x-2,2),border.lightened(.15),2)
func button(id:String,label:String,r:Rect2,hot:bool=false):
 panel(r,Color("a63251") if hot else Color("20243d"),Color("fff0be") if hot else Color("74678f"))
 text_at(label,r.position+Vector2(r.size.x/2,r.size.y/2+7),18,Color("fff2c4") if hot else Color("d4c8ba"),true)
 buttons.append({"id":id,"rect":r})

func draw_piece(p:Vector2,kind:int,black:bool=false,scale_factor:float=1.0,highlight:bool=false):
 var tex=art[("black" if black else "white")+str(kind)]
 var size=Vector2(floor(cell*.76/2)*2,floor(cell*.95/2)*2)*scale_factor
 draw_ellipse_shadow(p,cell*.33*scale_factor)
 if highlight:draw_circle(p-Vector2(0,cell*.2),cell*.4,Color(1,.7,.3,.16))
 draw_texture_rect(tex,Rect2((p-Vector2(size.x/2,size.y*.77)).round(),size),false,Color(1.6,1.3,1.1) if highlight else Color.WHITE)
func draw_ellipse_shadow(p:Vector2,r:float):
 draw_set_transform(p+Vector2(0,cell*.17),0,Vector2(1,.3))
 draw_circle(Vector2.ZERO,r,Color(0,0,0,.45))
 draw_set_transform(Vector2.ZERO)

func _draw():
 buttons.clear()
 var v=get_viewport_rect().size
 draw_rect(Rect2(Vector2.ZERO,v),Color("111827"))
 for i in 80:
  var x=fmod(i*137.0,v.x);var y=fmod(i*71.0,v.y)
  draw_rect(Rect2(x,y,34,2),Color("192035"))
 for yy in range(0,int(v.y),4):draw_line(Vector2(0,yy),Vector2(v.x,yy),Color(0,0,0,.09))
 if mode=="title":draw_title(v);return
 draw_game(v)
 for yy in range(0,int(v.y),4):draw_line(Vector2(0,yy),Vector2(v.x,yy),Color(.02,.03,.06,.065))
 if mode in ["pause","help","reward","lost","won"]:
  draw_rect(Rect2(Vector2.ZERO,v),Color(0.04,.03,.06,.88))
  match mode:
   "help":draw_help(v)
   "pause":draw_pause(v)
   "reward":draw_reward(v)
   "lost","won":draw_end(v)

func draw_game(v:Vector2):
 var bx=board.position.x;var by=board.position.y;var side=board.size.x
 var offset=Vector2(sin(t*90),cos(t*103))*shake
 draw_set_transform(offset)
 var r=Rect2(board.position-Vector2(9,9),board.size+Vector2(18,26))
 panel(r,Color("181b2d"),Color("c0afad"))
 for y in 8:
  for x in 8:
   var pos=Vector2i(x,y);var tile=Rect2(board.position+Vector2(x,y)*cell,Vector2.ONE*cell)
   var c=Color("e5d5b5") if (x+y)%2==0 else Color("80738f")
   draw_rect(tile,c)
   draw_line(tile.position,tile.position+Vector2(cell,0),c.lightened(.12))
   draw_line(tile.position+Vector2(0,cell-1),tile.end-Vector2(0,1),c.darkened(.2))
   draw_rect(Rect2(tile.position+Vector2(2,2),Vector2(3,2)),c.lightened(.18))
   if dangerous(pos):
    draw_rect(tile,Color(.8,.25,.28,.18+sin(t*3)*.04))
    draw_line(tile.position+Vector2(5,5),tile.end-Vector2(5,5),Color(.9,.38,.36,.25),1)
   if maxi(absi(x-pp().x),absi(y-pp().y))==1 and enemy_at(pos)<0:
    draw_circle(center(pos),3,Color("e8c586") if not dangerous(pos) else Color("cb5966"))
   if pos==aim_cell:
    draw_rect(tile,Color("fff1bb"),false,2)
 for e in s.enemies:
  var p=center(ep(e))
  if float(e.get("anim",0))>0:
   p=center(Vector2i(int(e.prev[0]),int(e.prev[1]))).lerp(p,1-float(e.anim)/.18)
  draw_piece(p,int(e.k),false,1,float(e.flash)>0)
  var hpw=cell*.55
  draw_rect(Rect2(p.x-hpw/2,p.y+cell*.24,hpw,3),Color("262332"))
  draw_rect(Rect2(p.x-hpw/2,p.y+cell*.24,hpw*maxf(0,float(e.hp)/float(e.max)),3),Color("f1d8b7"))
  text_at(str(int(e.hp)),p+Vector2(-cell*.36,cell*.3),11,Color("f3e6ca"))
  var ready=int(e.timer)<=1
  draw_rect(Rect2(p.x+cell*.2,p.y-cell*.37,cell*.22,cell*.23),Color("ee355c") if ready else Color("172037"))
  text_at("!" if ready else str(int(e.timer)),p+Vector2(cell*.31,-cell*.2),11,Color("f5dcc1"),true)
 draw_piece(hero_visual,5,true)
 for r2 in trails:draw_line(r2.a,r2.b,Color(1,.85,.55,float(r2.life)/.17),2)
 for p in particles:draw_rect(Rect2(p.p,Vector2(3,3)),Color(p.c,float(p.life)*2))
 for n in numbers:text_at(n.text,n.p,22,Color(n.color,float(n.life)*1.4),true)
 if flash>0:draw_rect(board,Color(1,.83,.5,flash*.5))
 draw_set_transform(Vector2.ZERO)
 if portrait:
  text_at("CINDER CROWN",Vector2(v.x/2,35),32,Color("fff0c0"),true)
  text_at("FLOOR "+str(int(s.floor))+" / "+("10" if int(s.floor)<=10 else "ENDLESS"),Vector2(v.x/2,59),18,Color("bcacc4"),true)
  button("pause","II",Rect2(v.x-62,16,46,46))
  draw_stats(Vector2(28,106),v.x-56)
  shotgun(Vector2(v.x/2-28,86),1.3)
  var bot=by+side+34
  text_at(note if note_time>0 else "MOVE: RELOAD   •   TARGET: FIRE",Vector2(v.x/2,bot),18,Color("eee0c6"),true)
  draw_loadout(Rect2(24,bot+16,v.x-48,64))
  for i in 5:
   var rr=Rect2(24+i*(v.x-48)/5,bot+96,(v.x-48)/5-6,65)
   mini_card(rr,int(s.upgrades[i]) if i<s.upgrades.size() else -1,false)
  button("sound","MUTE" if not muted else "SOUND",Rect2(24,v.y-56,100,44))
  text_at("TURN "+str(int(s.turn))+"  SEALS "+str(int(s.guards)),Vector2(v.x-215,v.y-28),18,Color("b4a2c3"))
 else:
  draw_stats(Vector2(bx,by-18),side*.62)
  shotgun(Vector2(bx+side*.64,by-46),1.7)
  text_at("FLOOR "+str(int(s.floor)),Vector2(bx+side/2,by-36),22,Color("fff0c0"),true)
  var cw=minf(115,bx-36)
  for i in 6:
   var yy=24+i*(v.y-48)/6
   mini_card(Rect2(24,yy,cw,(v.y-48)/6-7),int(s.upgrades[i]) if i<s.upgrades.size() else -1,false)
   mini_card(Rect2(v.x-cw-24,yy,cw,(v.y-48)/6-7),i%5 if i<int(s.floor)-1 else -1,true)
  text_at("POWER",Vector2(bx-25,v.y*.42),17,Color("8b7b9e"),true)
  text_at(str(int(s.pellets)*int(s.damage)),Vector2(bx-25,v.y*.42+22),24,Color("fff0c0"),true)
  text_at("RANGE",Vector2(bx-25,v.y*.42+57),17,Color("8b7b9e"),true)
  text_at(str(int(s.range)),Vector2(bx-25,v.y*.42+79),24,Color("fff0c0"),true)
  text_at("SEALS",Vector2(bx+side+31,v.y*.42),17,Color("8b7b9e"),true)
  text_at(str(int(s.guards)),Vector2(bx+side+31,v.y*.42+22),24,Color("fff0c0"),true)
  button("pause","II",Rect2(bx,by+side+17,44,38))
  button("sound","MUTE" if not muted else "SOUND",Rect2(bx+side-92,by+side+17,92,38))
  text_at(note if note_time>0 else "YOUR TURN",Vector2(bx+side/2,by+side+42),18,Color("aa99b6"),true)

func shotgun(p:Vector2,k:float):
 var c=Color("fff0c0");var points=PackedVector2Array([Vector2(0,16),Vector2(8,8),Vector2(19,9),Vector2(23,4),Vector2(54,4),Vector2(54,10),Vector2(25,12),Vector2(19,17),Vector2(11,14),Vector2(5,21)])
 for i in points.size():points[i]=p+points[i]*k
 draw_polygon(points,PackedColorArray([c]));draw_line(p+Vector2(26,7)*k,p+Vector2(50,7)*k,Color("111827"),2*k)
func mini_card(r:Rect2,id:int,enemy:bool):
 panel(r,Color("161e30"),Color("6a5a83") if id>=0 else Color("34304e"))
 if id<0:
  draw_line(r.position+Vector2(6,5),r.position+Vector2(r.size.x-6,5),Color("37344f"),2);return
 var tex=art["white"+str(id%6)] if enemy else art["card"+str(id%12)]
 var z=minf(r.size.y-13,r.size.x-14)
 draw_texture_rect(tex,Rect2(r.position+Vector2((r.size.x-z)/2,6),Vector2(z,z*.8)),false,Color("ed88a1") if enemy else Color.WHITE)
 draw_rect(Rect2(r.position+Vector2(3,r.size.y-4),Vector2(r.size.x-6,2)),Color("d13d67") if enemy else Color("d4bba1"))

func draw_stats(p:Vector2,w:float):
 for i in int(s.maxhp):
  var x=p.x+i*22
  var c=Color("ee375d") if i<int(s.hp) else Color("4a4264")
  draw_polygon(PackedVector2Array([Vector2(x,p.y-13),Vector2(x+6,p.y-17),Vector2(x+11,p.y-13),Vector2(x+16,p.y-17),Vector2(x+21,p.y-13),Vector2(x+11,p.y-1)]),PackedColorArray([c]))
 for i in int(s.capacity):
  var x=p.x+w-20-i*19
  draw_rect(Rect2(x,p.y-17,9,18),Color("ef375d") if i<int(s.ammo) else Color("30324e"))
  draw_rect(Rect2(x-1,p.y-2,11,3),Color("fff0c0"))
func draw_loadout(r:Rect2):
 panel(r,Color("182033"),Color("5c5779"))
 text_at(str(int(s.pellets))+" PELLETS  ·  "+str(int(s.damage))+" DMG  ·  "+str(int(s.range))+" RANGE",r.position+Vector2(12,24),12)
 var names:Array=[]
 for u in s.upgrades.slice(maxi(0,s.upgrades.size()-2)):names.append(UPGRADES[int(u)][0])
 text_at(" · ".join(names) if not names.is_empty() else "THE LAST KING · THE FIRST SHOT",r.position+Vector2(12,47),11,Color("bdabc5"))

func draw_title(v:Vector2):
 var cx=v.x/2
 var cy=v.y/2
 text_at("CINDER",Vector2(cx,cy-200),54,Color("fff0c0"),true)
 text_at("CROWN",Vector2(cx,cy-148),54,Color("fff0c0"),true)
 text_at("ONE KING. ONE SHOTGUN.",Vector2(cx,cy-108),13,Color("9f8baa"),true)
 var old=cell;cell=100
 draw_piece(Vector2(cx,cy+22),5,true,1.15)
 cell=old
 button("start","NEW EXPEDITION",Rect2(cx-135,cy+68,270,52),true)
 if not s.is_empty():button("resume","CONTINUE",Rect2(cx-135,cy+132,270,48))
 button("forge","FORGE MAXED" if int(meta.get("forge",0))>=3 else "FORGE +1 PELLET · "+str(15*(int(meta.get("forge",0))+1))+" CROWNS",Rect2(cx-160,cy+190,320,40))
 text_at("BEST FLOOR "+str(int(meta.best))+" · CROWNS "+str(int(meta.crowns)),Vector2(cx,cy+250),13,Color("b9a3bb"),true)
 text_at("A GODOT CHESS ROGUELITE",Vector2(cx,v.y-30),12,Color("6d658d"),true)

func draw_help(v:Vector2):
 var cx=v.x/2;var cy=v.y/2
 text_at("THE ROYAL DECREE",Vector2(cx,cy-175),27,Color("fff0c0"),true)
 var lines=["Tap a neighboring tile to move.","Moving reloads one shell.","Tap an enemy to fire the shotgun.","Red tiles are dangerous this turn."] if help_page==0 else ["Enemy numbers count down to action.","A ! means it acts after your next move.","Kill the white king to clear the floor.","Pick a boon AND its enemy curse."]
 for i in lines.size():text_at(lines[i],Vector2(cx,cy-105+i*35),16,Color("ded0c0"),true)
 text_at("Safety seals stop risky MOVES.",Vector2(cx,cy+63),14,Color("c48690"),true)
 text_at("Shots do not receive this protection.",Vector2(cx,cy+87),14,Color("c48690"),true)
 button("next_help","NEXT" if help_page==0 else "TAKE THE THRONE",Rect2(cx-130,cy+130,260,50),true)

func draw_pause(v:Vector2):
 var cx=v.x/2;var cy=v.y/2
 text_at("THE COURT WAITS",Vector2(cx,cy-125),29,Color("fff0c0"),true)
 button("continue","CONTINUE",Rect2(cx-130,cy-75,260,48),true)
 button("help","HOW TO PLAY",Rect2(cx-130,cy-12,260,48))
 button("retry","NEW EXPEDITION",Rect2(cx-130,cy+51,260,48))
 text_at("Progress saved locally",Vector2(cx,cy+140),14,Color("938296"),true)

func draw_reward(v:Vector2):
 var cx=v.x/2;var cy=v.y/2
 text_at("THE KING HAS FALLEN",Vector2(cx,cy-230 if portrait else 45),26,Color("fff0c0"),true)
 text_at("ONE BOON. ONE BURDEN.",Vector2(cx,cy-202 if portrait else 70),13,Color("a796aa"),true)
 for i in 2:
  var r=Rect2(20,cy-165+i*190,v.x-40,172) if portrait else Rect2(cx-310+i*320,100,300,v.y-145)
  var offer=s.reward[i];var u=UPGRADES[int(offer[0])];var c=CURSES[int(offer[1])]
  panel(r,Color("2c2532"),Color("ae8d63"))
  draw_texture_rect(art["card"+str(int(offer[0]))],Rect2(r.position+Vector2(12,8),Vector2(46,36)),false)
  text_at(u[0].to_upper(),r.position+Vector2(r.size.x/2+14,35),23,Color("fff0c0"),true)
  text_at(u[1],r.position+Vector2(r.size.x/2,62),16,Color("d5ccb9"),true)
  draw_line(r.position+Vector2(16,79),r.position+Vector2(r.size.x-16,79),Color("6a505b"))
  text_at(c[0]+" · "+c[1],r.position+Vector2(r.size.x/2,104),12,Color("cf8b96"),true)
  button("choice"+str(i),"CLAIM",Rect2(r.position+Vector2(18,r.size.y-54),Vector2(r.size.x-36,40)),true)

func draw_end(v:Vector2):
 var cx=v.x/2;var cy=v.y/2
 var won=mode=="won"
 text_at("CROWN RESTORED" if won else "THE KING IS DEAD",Vector2(cx,cy-130),30,Color("fff0c0"),true)
 text_at("FLOOR "+str(int(s.floor))+" · "+str(int(s.kills))+" PIECES DEFEATED",Vector2(cx,cy-83),15,Color("b7a5b3"),true)
 text_at("CROWNS EARNED "+str(int(s.gold)),Vector2(cx,cy-48),18,Color("d6b278"),true)
 if won:button("endless","ENTER ENDLESS",Rect2(cx-130,cy+10,260,48),true)
 button("retry","NEW EXPEDITION",Rect2(cx-130,cy+75,260,48),not won)
 text_at("Best floor "+str(int(meta.best)),Vector2(cx,cy+170),14,Color("9b879f"),true)

