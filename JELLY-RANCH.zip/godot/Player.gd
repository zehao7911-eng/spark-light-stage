extends CharacterBody3D
var world
var camera:Camera3D
var gun:Node3D
var yaw=0.0
var pitch=-.08
var kick=0.0
func _ready():
 collision_layer=2;collision_mask=1
 var col=CollisionShape3D.new();var shape=CapsuleShape3D.new();shape.radius=.34;shape.height=1.8;col.shape=shape;col.position.y=.9;add_child(col)
 camera=Camera3D.new();camera.position.y=1.45;camera.near=.05;camera.far=180;camera.fov=72;add_child(camera);camera.current=true
 gun=RanchArt.vacpack();camera.add_child(gun);gun.scale=Vector3.ONE*.65;gun.position=Vector3(.46,-.4,-1.0);gun.rotation.y=.3
func look(v):yaw-=v.x*.004;pitch=clampf(pitch-v.y*.004,-.95,.70)
func _physics_process(dt):
 if world.mode!="play":return
 var input=world.move_vec
 var key=Vector2(float(Input.is_physical_key_pressed(KEY_D))-float(Input.is_physical_key_pressed(KEY_A)),float(Input.is_physical_key_pressed(KEY_S))-float(Input.is_physical_key_pressed(KEY_W)))
 if key.length()>.1:input=key.normalized()
 var d=Basis(Vector3.UP,yaw)*Vector3(input.x,0,input.y);var speed=4.2+int(world.s.boots)*.8
 velocity.x=move_toward(velocity.x,d.x*speed,dt*20);velocity.z=move_toward(velocity.z,d.z*speed,dt*20);velocity.y-=dt*15
 move_and_slide();position.x=clampf(position.x,-38,38);position.z=clampf(position.z,-54 if world.s.gate>0 else -24.8,24)
 rotation.y=yaw;camera.rotation.x=pitch;camera.position.y=1.45+sin(world.clock*10)*.025*input.length()
 kick=move_toward(kick,0,dt*2)
 var portrait=get_viewport().get_visible_rect().size.x<get_viewport().get_visible_rect().size.y
 gun.position=Vector3(.36,-1.02,-1.0) if portrait else Vector3(.46,-.4,-1.0);gun.position.z+=kick*.16;gun.rotation.z=sin(world.clock*6)*(.012 if world.sucking else .003)
