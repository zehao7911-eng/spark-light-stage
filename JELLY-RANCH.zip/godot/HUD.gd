extends Control
var world
var font=ThemeDB.fallback_font
var buttons=[]
var joystick=-1
var look_pointer=-1
var suck_pointer=-1
var stick=Vector2.ZERO
var flash=0.0
var bump=0.0
var slots_rect=[]
var cream=Color("fff3d9")
var ink=Color("395563")
func _ready():set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);mouse_filter=Control.MOUSE_FILTER_IGNORE
func _process(dt):flash=maxf(0,flash-dt);bump=move_toward(bump,0,dt*3);queue_redraw()
func text(t,p,size=17,c=Color("fff3d9")):draw_string(font,p,str(t),HORIZONTAL_ALIGNMENT_LEFT,-1,size,c)
func center(t,y,size=22,c=Color("fff3d9")):
 var w=font.get_string_size(str(t),HORIZONTAL_ALIGNMENT_LEFT,-1,size).x;text(t,Vector2((get_viewport_rect().size.x-w)/2,y),size,c)
func rounded(r,c,border=Color.TRANSPARENT):
 var b=StyleBoxFlat.new();b.bg_color=c;b.set_corner_radius_all(12);b.border_color=border;b.set_border_width_all(2 if border.a>0 else 0);draw_style_box(b,r)
func panel(r):rounded(Rect2(r.position+Vector2(0,5),r.size),Color("263f5855"));rounded(r,Color("fff0d9f5"),Color("ceaa89"))
func button(id,label,r,active=true,sub=""):
 rounded(r,Color("a7d59f") if active else Color("e7d5bf"),Color("6c9982") if active else Color("bda489"))
 var size=17 if label.length()<20 else 14;var width=font.get_string_size(label,HORIZONTAL_ALIGNMENT_LEFT,-1,size).x;var y=r.position.y+r.size.y/2+size*.32-(8 if not sub.is_empty() else 0);text(label,Vector2(r.position.x+(r.size.x-width)/2,y),size,ink)
 if not sub.is_empty():var w=font.get_string_size(sub,HORIZONTAL_ALIGNMENT_LEFT,-1,12).x;text(sub,Vector2(r.position.x+(r.size.x-w)/2,r.end.y-10),12,Color("67737b"))
 buttons.append({"id":id,"r":r})
func icon(k,p,r):
 if k<0:return
 if k<5:
  var c=Color(RanchArt.COLORS[k]);draw_circle(p+Vector2(0,2),r,c.darkened(.18));draw_circle(p-Vector2(0,r*.13),r*.92,c);draw_circle(p+Vector2(-r*.25,-r*.37),r*.17,c.lightened(.35))
  for side in [-1,1]:draw_circle(p+Vector2(side*r*.31,-r*.02),r*.095,ink)
  draw_arc(p+Vector2(0,r*.10),r*.17,.20,PI-.20,8,ink,1.3)
  if k==1:
   for i in 3:draw_colored_polygon(PackedVector2Array([p+Vector2(-r*.7+i*r*.7,-r*.65),p+Vector2(-r*.35+i*r*.7,-r*1.15),p+Vector2(i*r*.7,-r*.65)]),c.lightened(.2))
  if k==2:
   for side in [-1,1]:draw_colored_polygon(PackedVector2Array([p+Vector2(side*r*.25,-r*.68),p+Vector2(side*r*.65,-r*1.12),p+Vector2(side*r*.87,-r*.5)]),c)
  if k==4:draw_arc(p-Vector2(0,r*.90),r*.45,0,TAU,20,Color("b6a4dd"),2)
 elif k==5:draw_circle(p,r*.72,Color("e77d6f"));draw_circle(p+Vector2(-r*.2,-r*.22),r*.17,cream);draw_line(p-Vector2(0,r*.7),p-Vector2(-r*.2,r*1.0),Color("7f9a61"),3)
 elif k==6:draw_colored_polygon(PackedVector2Array([p+Vector2(-r*.45,-r*.55),p+Vector2(r*.45,-r*.55),p+Vector2(0,r*.8)]),Color("e8a357"));draw_line(p-Vector2(0,r*.5),p-Vector2(0,r),Color("7f9a61"),4)
 else:
  var c=Color(RanchArt.COLORS[k-10]);draw_colored_polygon(PackedVector2Array([p+Vector2(0,-r),p+Vector2(r,0),p+Vector2(0,r),p+Vector2(-r,0)]),c);draw_line(p+Vector2(-r,0),p+Vector2(r,0),cream,1.5);draw_line(p+Vector2(0,-r),p+Vector2(0,r),cream,1.5)
func joy_center():
 var v=get_viewport_rect().size;return Vector2(84,v.y-239 if v.x<v.y else v.y-115)
func _draw():
 if not world or not world.player:return
 buttons=[];slots_rect=[];var v=get_viewport_rect().size;var w=v.x;var h=v.y;var s=world.s;var m=world.mode
 if m!="title":
  rounded(Rect2(12,12,125,57),Color("395665d9"));text("DAY %d"%int(s.day),Vector2(26,34),13,Color("d6e9d6"));text("%02d:%02d"%[int(s.hour),int((float(s.hour)-int(s.hour))*60)],Vector2(26,56),19)
  rounded(Rect2(w-150,12,138,57),Color("395665d9"));text("$%d"%int(s.coins),Vector2(w-131,50),28,Color("f2dfa9"))
 if m=="play":
  button("pause","II",Rect2(w-70,80,56,54),false)
  var c=Vector2(w/2,h/2);draw_arc(c,7,0,TAU,24,cream,1.4);draw_circle(c,1.8,cream)
  if world.target:
   var label=world.item_name(world.target.k);var tw=font.get_string_size(label,HORIZONTAL_ALIGNMENT_LEFT,-1,15).x;rounded(Rect2(w/2-tw/2-13,h/2-49,tw+26,29),Color("395665dd"));center(label,h/2-29,15)
  var joy=joy_center();draw_circle(joy,61,Color("39566577"));draw_arc(joy,61,0,TAU,40,Color("ecedceaa"),2);draw_circle(joy+stick*36,24,Color("eee1bdbb"))
  button("suck","SUCK",Rect2(w-112,h-294 if w<h else h-180,96,74),world.sucking);button("shoot","SHOOT",Rect2(w-112,h-208 if w<h else h-94,96,70))
  var station=world.near_station()
  if not station.is_empty():button("interact","SELL ALL" if station=="market" else "UPGRADES" if station=="shop" else "OPEN · $150",Rect2(w/2-79,h-183,158,57))
  var sw=minf(80,(w-48)/4);var left=w/2-sw*2
  for i in 4:
   var r=Rect2(left+i*sw+3,h-116,sw-6,80);slots_rect.append(r);rounded(r,Color("f4e2c7"),Color("76bfd0") if s.selected==i else Color("b5a083"));var k=int(s.slots[i].k);icon(k,r.position+Vector2(r.size.x/2,31),18*(1+bump*.06));text(str(s.slots[i].n) if s.slots[i].n>0 else "–",r.position+Vector2(12,67),17,ink)
  var k=int(s.slots[int(s.selected)].k);center(world.item_name(k) if k>=0 else "Empty slot",h-14,13)
  if s.sold==0:
   var tip="Hold SUCK to collect. Drag the world to look."
   for slot in s.slots:
    if slot.k<5 and slot.n>0:tip="Shoot into a corral, then feed with berries."
    if slot.k in [5,6] and slot.n>0:tip="Shoot food toward a hungry jelly."
    if slot.k>=10 and slot.n>0:tip="Bring crystals to the market."
   center(tip,98,14)
 elif m=="title":
  draw_rect(Rect2(Vector2.ZERO,v),Color("33546735"));var r=Rect2(w/2-minf(w*.44,290),h*.23,minf(w*.88,580),minf(h*.55,320));panel(r)
  center("JELLY",r.position.y+67,52,Color("aa657d"));center("RANCH",r.position.y+115,46,ink);center("Collect · Feed · Grow",r.position.y+158,17,Color("698276"))
  button("begin","START RANCHING",Rect2(w/2-140,r.end.y-80,280,62));center("Drag to look · WASD / touch to move",h-23,14)
 elif m=="shop":draw_shop(v)
 elif m=="pause":
  var r=Rect2(w/2-180,h/2-195,360,390);panel(r);center("TAKE A BREATHER",r.position.y+45,26,ink)
  button("mute","SOUND · OFF" if s.muted else "SOUND · ON",Rect2(w/2-150,r.position.y+66,300,55),false)
  button("quality","SHADOWS · OFF" if s.low else "SHADOWS · ON",Rect2(w/2-150,r.position.y+132,300,55),false)
  button("map","MAP",Rect2(w/2-150,r.position.y+199,144,55),false);button("help","HOW TO PLAY",Rect2(w/2+6,r.position.y+199,144,55),false)
  button("close","RESUME",Rect2(w/2-150,r.end.y-90,300,64))
 elif m=="help":
  var r=Rect2(w/2-minf(w*.45,290),80,minf(w*.9,580),h-110);panel(r);center("A HAPPY LITTLE LOOP",118,24,ink)
  var rows=[[0,"Vacuum jellies and food."],[5,"Shoot jellies into a corral."],[10,"Feed them. Vacuum the crystals."],[3,"Sell. Upgrade. Explore the canyon."]]
  for i in 4:var p=r.position+Vector2(36,75+i*66);icon(rows[i][0],p,19);text(rows[i][1],p+Vector2(31,6),15,ink)
  button("close","GOT IT",Rect2(w/2-130,r.end.y-77,260,62))
 elif m=="map":
  var side=minf(minf(w-48,h-168),440);var r=Rect2(w/2-side/2-12,77,side+24,side+83);panel(r);center("YOUR LITTLE RANGE",112,23,ink)
  var area=Rect2(w/2-side/2,131,side,side-35);rounded(area,Color("e3c397"));var to_map=func(p):return area.position+Vector2((p.x+40)/80,(p.z+55)/82)*area.size
  draw_line(to_map.call(Vector3(-40,0,-26)),to_map.call(Vector3(40,0,-26)),Color("bc986e"),3)
  for i in 4:var p=to_map.call(world.PENS[i]);draw_rect(Rect2(p-Vector2(8,8),Vector2(16,16)),Color("95b6a3") if i<s.pens else Color("b39b87"))
  for data in [[world.MARKET,"MARKET"],[world.SHOP,"SHOP"],[world.GATE,"CANYON"]]:var p=to_map.call(data[0]);draw_circle(p,5,ink);text(data[1],p+Vector2(9,4),12,ink)
  var p=to_map.call(world.player.position);draw_circle(p,6,Color("be6f8d"));draw_line(p,p+Vector2(-sin(world.player.yaw),-cos(world.player.yaw))*17,Color("be6f8d"),2)
  button("close","CLOSE",Rect2(w/2-110,r.end.y-73,220,61))
 elif m=="ending":
  var r=Rect2(w/2-190,h/2-180,380,360);panel(r);center("A THRIVING RANCH",r.position.y+48,26,ink)
  for i in 5:icon(i,Vector2(w/2-128+i*64,r.position.y+134),25)
  center("Five species. A whole lot of happy jellies.",r.position.y+201,15,ink);center("New orders keep the ranch growing.",r.position.y+231,14,Color("698276"))
  button("close","KEEP RANCHING",Rect2(w/2-145,r.end.y-80,290,62))
 if world.notice_time>0:
  var tw=font.get_string_size(world.notice,HORIZONTAL_ALIGNMENT_LEFT,-1,14).x;rounded(Rect2(w/2-tw/2-15,h-353,tw+30,34),Color("395665e5"));center(world.notice,h-330,14)
 if flash>0:draw_rect(Rect2(Vector2.ZERO,v),Color(1,.94,.74,flash*.3))
func draw_shop(v):
 var w=v.x;var h=v.y;var s=world.s;var r=Rect2(w/2-minf(w*.46,330),77,minf(w*.92,660),h-98);panel(r);center("RANCH WORKSHOP",115,25,ink)
 var cols=2 if w<700 else 3;var cw=(r.size.x-36)/cols;var kinds=["tank","boots","range","garden","walls","gate","pens","rest","help"];var labels=["TANK","BOOTS","VACPACK","GARDEN","WALLS","CANYON","CORRAL","REST","GUIDE"];var subs=["Carry more","Move faster","Pull farther","Grow berries","Largos + space","New species","More pens","Fresh morning","A simple loop"];var costs=[70,90,80,60,80,150,120]
 for i in 9:
  var kind=kinds[i];var enabled=true;var caption=labels[i]
  if i<7:
   var level=int(s[kind]);var cap=4 if kind=="pens" else 1 if kind=="gate" else 2 if kind in ["garden","walls"] else 3;var cost=costs[i]*(level if kind=="pens" else level+1);caption+=(" · MAX" if level>=cap else " · $%d"%cost);enabled=level<cap and s.coins>=cost
  button(kind,caption,Rect2(r.position.x+12+(i%cols)*cw,r.position.y+63+int(i/cols)*70,cw-9,62),enabled,subs[i])
 var wanted=int(s.orders)%5;var progress=int(s.delivery[wanted])-int(s.spent[wanted]);var need=6 if s.orders<5 else 6+int(s.orders/5)*2
 if wanted==4:center("Moon jellies appear after sunset in the canyon.",r.end.y-121,12,ink)
 center("ORDER · %s CRYSTALS %d / %d"%[world.NAMES[wanted].replace(" Jelly","").to_upper(),progress,need],r.end.y-99,14,ink)
 button("close","BACK TO THE RANCH",Rect2(w/2-145,r.end.y-80,290,64))
func audio_unlock():
 if world.music and not world.music.playing and not world.s.muted:world.music.play()
func act(id):
 audio_unlock()
 match id:
  "begin","close":world.set_mode("play");world.save_game()
  "shoot":world.shoot()
  "interact":world.interact()
  "pause":world.set_mode("pause");world.save_game()
  "map","help":world.set_mode(id)
  "mute":world.s.muted=not world.s.muted;world.music.stream_paused=world.s.muted;world.save_game()
  "quality":world.s.low=not world.s.low;world.sun.shadow_enabled=not world.s.low;world.save_game()
  "rest":world.rest()
  "tank","boots","range","garden","walls","gate","pens":world.buy(id)
func pointer(p,pressed,id):
 if not pressed:
  if id==joystick:joystick=-1;stick=Vector2.ZERO;world.move_vec=Vector2.ZERO
  if id==look_pointer:look_pointer=-1
  if id==suck_pointer:suck_pointer=-1;world.sucking=false
  return
 audio_unlock()
 for b in buttons:
  if b.r.has_point(p):
   if b.id=="suck":suck_pointer=id;world.sucking=true
   else:act(b.id)
   return
 for i in slots_rect.size():
  if slots_rect[i].has_point(p):world.s.selected=i;world.sound("move");return
 if world.mode=="play":
  if p.distance_to(joy_center())<77:joystick=id;move_stick(p)
  else:look_pointer=id
func move_stick(p):stick=((p-joy_center())/44).limit_length(1);world.move_vec=stick
func _input(e):
 if e is InputEventScreenTouch:pointer(e.position,e.pressed,e.index)
 elif e is InputEventScreenDrag:
  if e.index==joystick:move_stick(e.position)
  elif e.index==look_pointer:world.player.look(e.relative)
 elif e is InputEventMouseButton:
  if e.button_index==MOUSE_BUTTON_LEFT:pointer(e.position,e.pressed,99)
  elif e.button_index==MOUSE_BUTTON_RIGHT and e.pressed and world.mode=="play":act("shoot")
 elif e is InputEventMouseMotion:
  if joystick==99:move_stick(e.position)
  elif look_pointer==99:world.player.look(e.relative)
 elif e is InputEventKey and not e.echo:
  if e.keycode==KEY_SPACE and world.mode=="play":audio_unlock();world.sucking=e.pressed
  elif e.pressed:
   if e.keycode==KEY_ENTER:act("begin" if world.mode=="title" else "close" if world.mode!="play" else "shoot")
   elif e.keycode==KEY_E and world.mode=="play":act("interact")
   elif e.keycode==KEY_ESCAPE:act("pause" if world.mode=="play" else "close")
   elif e.keycode==KEY_M and world.mode=="play":act("map")
   elif e.keycode>=KEY_1 and e.keycode<=KEY_4:world.s.selected=e.keycode-KEY_1
   elif e.keycode==KEY_TAB:world.s.selected=(int(world.s.selected)+1)%4
