class_name RanchArt
extends RefCounted
static var mats={}
const COLORS=["f979a8","659ee9","baa0cb","ecc36a","baaaed"]
static func mat(c,glow=false):
 var k=str(c)+str(glow)
 if mats.has(k):return mats[k]
 var m=StandardMaterial3D.new();m.albedo_color=Color(c);m.roughness=.75
 if glow:m.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
 if m.albedo_color.a<1:m.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA;m.cull_mode=BaseMaterial3D.CULL_DISABLED
 mats[k]=m;return m
static func mesh(p,m,pos,c,glow=false):
 var n=MeshInstance3D.new();n.mesh=m;n.position=pos;n.material_override=mat(c,glow);p.add_child(n);return n
static func box(p,pos,size,c):var q=BoxMesh.new();q.size=size;return mesh(p,q,pos,c)
static func ball(p,pos,size,c):
 var q=SphereMesh.new();q.radial_segments=20;q.rings=10;var n=mesh(p,q,pos,c);n.scale=size;return n
static func cylinder(p,pos,r,h,c,top=-1):
 var q=CylinderMesh.new();q.bottom_radius=r;q.top_radius=r if top<0 else top;q.height=h;q.radial_segments=12;return mesh(p,q,pos,c)
static func ring(p,pos,r,c):var q=TorusMesh.new();q.inner_radius=r-.035;q.outer_radius=r+.035;q.rings=24;q.ring_segments=6;return mesh(p,q,pos,c,true)
static func rod(p,a,b,r,c):var n=cylinder(p,(a+b)/2,r,a.distance_to(b),c);n.quaternion=Quaternion(Vector3.UP,(b-a).normalized());return n
static func slime(k,second=-1):
 var n=Node3D.new();var body=ball(n,Vector3.ZERO,Vector3(1.45,1.1,1.4),COLORS[k]);body.name="Body"
 var m=ShaderMaterial.new();m.shader=load("res://Jelly.gdshader");m.set_shader_parameter("tint",Color(COLORS[k]).lerp(Color(COLORS[second]),.45) if second>=0 else Color(COLORS[k]));body.material_override=m
 for side in [-1,1]:
  var eye=ball(n,Vector3(side*.22,.10,-.68),Vector3(.115,.14,.065),"352348");eye.name="EyeL" if side==-1 else "EyeR"
  ball(n,Vector3(side*.22-.022,.125,-.715),Vector3(.026,.029,.020),"fff9ea").material_override=mat("fff9ea",true)
 var line=ImmediateMesh.new();line.surface_begin(Mesh.PRIMITIVE_LINE_STRIP)
 for i in 9:line.surface_add_vertex(Vector3(-.105+i*.026,-.13-pow(sin(i*PI/8),1)*.035,-.714))
 line.surface_end();var mouth=MeshInstance3D.new();mouth.mesh=line;mouth.material_override=mat("673349",true);n.add_child(mouth)
 if k==1 or second==1:
  for i in 4:var p=Vector3(cos(i*TAU/4)*.38,.45,sin(i*TAU/4)*.35);var spike=cylinder(n,p,.17,.5,"a7d2ef",0);spike.rotation.z=cos(i*TAU/4)*-.5
 if k==2 or second==2:
  for side in [-1,1]:var ear=cylinder(n,Vector3(side*.41,.50,-.05),.19,.49,"9c7bac",0);ear.rotation.z=side*-.25;ball(n,Vector3(side*.24,.30,-.56),Vector3(.10,.035,.026),"806294")
 if k==3 or second==3:
  for i in 3:ball(n,Vector3(-.14+i*.14,.50,-.10),Vector3(.13,.16,.12),"f5d98b")
 if k==4 or second==4:
  for side in [-1,1]:var wing=ball(n,Vector3(side*.70,.24,.12),Vector3(.50,.10,.37),"d1cff5bb");wing.rotation.z=side*.3;wing.material_override=mat("d1cff5bb",true)
  ring(n,Vector3(0,.58,0),.26,"eadffb")
 return n
static func fruit(k):
 var n=Node3D.new()
 if k==5:
  ball(n,Vector3.ZERO,Vector3(.65,.57,.65),"e95b57");rod(n,Vector3(0,.21,0),Vector3(.03,.4,0),.035,"685547");var leaf=ball(n,Vector3(.10,.32,0),Vector3(.26,.045,.12),"83b45a");leaf.rotation.z=-.35
 elif k==6:
  var carrot=cylinder(n,Vector3.ZERO,.04,.52,"ed9950",.19);carrot.rotation.z=.15
  for i in 3:rod(n,Vector3(0,.22,0),Vector3(-.16+i*.16,.56,.05),.035,"73a65b")
 else:
  var a=BoxMesh.new();a.size=Vector3(.36,.36,.36);var gem=mesh(n,a,Vector3.ZERO,COLORS[k-10]);gem.rotation=Vector3(.35,.5,.35);gem.material_override=mat(COLORS[k-10],true);ring(n,Vector3(0,-.17,0),.25,COLORS[k-10]+"88")
 return n
static func vacpack():
 var n=Node3D.new();box(n,Vector3(0,-.03,.22),Vector3(.36,.40,.50),"df944d");box(n,Vector3(.07,-.25,.32),Vector3(.16,.30,.19),"4b5569")
 for z in [-.37,-.28,-.08,.16]:var a=cylinder(n,Vector3(0,0,z),.22,.14,"405365");a.rotation.x=PI/2
 for z in [-.22,-.04,.14]:var a=ring(n,Vector3(0,0,z),.235,"c9eb91");a.rotation.x=PI/2
 var barrel=cylinder(n,Vector3(0,0,-.47),.21,.10,"283e51");barrel.rotation.x=PI/2;var lip=ring(n,Vector3(0,0,-.54),.22,"eed2a0");lip.rotation.x=PI/2
 var gauge=cylinder(n,Vector3(.18,.08,.24),.115,.035,"cbebb0");gauge.rotation.z=PI/2
 var back=cylinder(n,Vector3(.02,.04,.49),.15,.025,"344957");back.rotation.x=PI/2;var dial=ring(n,Vector3(.02,.04,.51),.125,"c9eb91");dial.rotation.x=PI/2;rod(n,Vector3(.02,.04,.53),Vector3(-.045,.10,.53),.013,"e5f4c0")
 for side in [-1,1]:rod(n,Vector3(side*.13,.19,-.15),Vector3(side*.13,.19,.21),.028,"ede3c3")
 return n
static func solid_box(p,pos,size,c):
 var n=box(p,pos,size,c);var b=StaticBody3D.new();var a=CollisionShape3D.new();var shape=BoxShape3D.new();shape.size=size;a.shape=shape;b.add_child(a);n.add_child(b);return n
static func tree(p,pos,c="dd91a3"):
 var n=Node3D.new();n.position=pos;p.add_child(n);cylinder(n,Vector3(0,1.4,0),.22,2.8,"9a7758",.12)
 ball(n,Vector3(0,3.4,0),Vector3(3.4,2.1,3.1),c);ball(n,Vector3(-.9,2.8,.3),Vector3(2.2,1.8,2.0),c);ball(n,Vector3(.95,3.0,-.3),Vector3(2.1,1.8,1.9),c)
static func corral(p,pos,built,height):
 var n=Node3D.new();n.position=pos;p.add_child(n);cylinder(n,Vector3(0,.01,0),3.9,.08,"c89462" if built else "bb9b73")
 for x in [-3.2,3.2]:
  for z in [-3.2,3.2]:
   cylinder(n,Vector3(x,height/2,z),.20,height,"e4a85b");ball(n,Vector3(x,height+.02,z),Vector3(.52,.32,.52),"e9c08a");cylinder(n,Vector3(x,height*.58,z),.205,.13,"cceda9").material_override=mat("cceda9",true)
 if built:
  for i in 2:
   box(n,Vector3(0,height/2,-3.2 if i==0 else 3.2),Vector3(6.4,height,.03),"9adeb82b");box(n,Vector3(-3.2 if i==0 else 3.2,height/2,0),Vector3(.03,height,6.4),"9adeb82b")
   for y in [.18,height-.12]:rod(n,Vector3(-3.2,y,-3.2 if i==0 else 3.2),Vector3(3.2,y,-3.2 if i==0 else 3.2),.05,"e2c18d");rod(n,Vector3(-3.2 if i==0 else 3.2,y,-3.2),Vector3(-3.2 if i==0 else 3.2,y,3.2),.05,"e2c18d")
 return n
static func label(p,pos,title,color="f5ebcd",size=40):
 var n=Label3D.new();n.text=title;n.font_size=size;n.pixel_size=.014;n.modulate=Color(color);n.outline_modulate=Color("4e5355");n.outline_size=5;n.position=pos;n.billboard=BaseMaterial3D.BILLBOARD_ENABLED;p.add_child(n);return n
static func building(p,pos):
 var n=Node3D.new();n.position=pos;p.add_child(n);solid_box(n,Vector3(0,1.6,0),Vector3(6,3.2,5),"edcca5");box(n,Vector3(0,3.3,0),Vector3(7,.35,5.7),"c96f69");cylinder(n,Vector3(0,3.8,0),3.5,1.1,"ce7e70",2.3)
 for x in [-1.8,1.8]:box(n,Vector3(x,1.8,2.55),Vector3(1,.8,.05),"79c7ce");box(n,Vector3(x,1.8,2.6),Vector3(.08,.9,.04),"f4ddad")
 box(n,Vector3(0,.9,2.56),Vector3(1.1,1.8,.08),"708f91");cylinder(n,Vector3(0,.05,3.5),2,.1,"c79f74")
 return n
static func cliffs(p,positions):
 for layer in 3:
  var mm=MultiMesh.new();mm.transform_format=MultiMesh.TRANSFORM_3D;mm.use_colors=true;var m=CylinderMesh.new();m.radial_segments=7;m.bottom_radius=1;m.top_radius=.8;m.height=1;mm.mesh=m;mm.instance_count=positions.size()
  var node=MultiMeshInstance3D.new();node.multimesh=mm;node.material_override=mat("ffffff").duplicate();node.material_override.vertex_color_use_as_albedo=true;p.add_child(node)
  for i in positions.size():
   var a=positions[i];var r=a[1]*(1-layer*.12);var h=a[2]/3;var basis=Basis(Vector3.UP,i*.43).scaled(Vector3(r,h,r*.85));mm.set_instance_transform(i,Transform3D(basis,a[0]+Vector3(0,h*(layer+.5),0)));mm.set_instance_color(i,Color(["a27664","bb8e6a","d6b184"][layer]).darkened((i%3)*.03).srgb_to_linear())
   if layer==0:
    var b=StaticBody3D.new();b.position=a[0]+Vector3(0,a[2]/2,0);var col=CollisionShape3D.new();var shape=CylinderShape3D.new();shape.radius=a[1]*.9;shape.height=a[2];col.shape=shape;b.add_child(col);p.add_child(b)
