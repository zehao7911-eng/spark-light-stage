extends SceneTree
func _initialize():call_deferred("run")
func own(n,r):
 for c in n.get_children():c.owner=r;own(c,r)
func run():
 var w=load("res://World.tscn").instantiate();root.add_child(w);await process_frame
 var scene=Node3D.new();scene.name="JellyRanch";scene.set_script(load("res://World.gd"));var preview=Node3D.new();preview.name="EditorPreview";scene.add_child(preview)
 preview.add_child(w.map_root.duplicate());preview.add_child(w.sun.duplicate())
 for c in w.get_children():
  if c is WorldEnvironment:preview.add_child(c.duplicate())
 var camera=w.player.camera.duplicate();preview.add_child(camera);camera.transform=w.player.camera.global_transform
 for e in w.entities:var actor=e.node.duplicate();preview.add_child(actor)
 own(scene,scene);var packed=PackedScene.new();packed.pack(scene);ResourceSaver.save(packed,"res://World.tscn");scene.free();w.queue_free();await process_frame;print("Editable 3D ranch baked");quit()
