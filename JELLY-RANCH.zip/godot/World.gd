extends Node3D
const PLAYER=preload("res://Player.gd")
const HUD=preload("res://HUD.gd")
const SAVE="user://jelly_ranch.json"
const PENS=[Vector3(-8,0,5),Vector3(8,0,5),Vector3(-8,0,-6),Vector3(8,0,-6)]
const MARKET=Vector3(16,0,-16)
const SHOP=Vector3(-15,0,10)
const GARDEN=Vector3(0,0,9)
const GATE=Vector3(0,0,-26)
const NAMES=["Pink Jelly","Rock Jelly","Tabby Jelly","Honey Jelly","Moon Jelly","Berry","Carrot"]
const PRICES=[9,18,22,26,32]
var s={"coins":0,"day":1,"hour":9.0,"tank":0,"boots":0,"range":0,"garden":0,"walls":0,"gate":0,"pens":1,"orders":0,"sold":0,"selected":0,"slots":[{"k":-1,"n":0},{"k":-1,"n":0},{"k":-1,"n":0},{"k":-1,"n":0}],"delivery":[0,0,0,0,0],"spent":[0,0,0,0,0],"discovered":[0],"pos":[0,0,16],"yaw":0.0,"pitch":-.08,"entities":[],"bank":{},"won":false,"low":false,"muted":false}
var player
var hud
var mode="title"
var move_vec=Vector2.ZERO
var sucking=false
var clock=0.0
var autosave=0.0
var bridge=0.0
var notice=""
var notice_time=0.0
var entities:Array=[]
var particles:Array=[]
var pen_nodes:Array=[]
var gate_node
var garden_node
var map_root:Node3D
var env:Environment
var sky_mat:ProceduralSkyMaterial
var sun:DirectionalLight3D
var rng=RandomNumberGenerator.new()
var target=null
var intake=0.0
var spawn_timer=0.0
var garden_timer=0.0
var audio=[]
var vacuum:AudioStreamPlayer
var music:AudioStreamPlayer
var sounds={}
var preview=false
var swirl:Array=[]
func _ready():
 if has_node("EditorPreview"):get_node("EditorPreview").queue_free()
 rng.randomize();Engine.max_fps=30;load_save()
 var we=WorldEnvironment.new();env=Environment.new();env.background_mode=Environment.BG_SKY;var sky=Sky.new();sky_mat=ProceduralSkyMaterial.new();sky_mat.sky_top_color=Color("459fb2");sky_mat.sky_horizon_color=Color("c6e7d7");sky_mat.ground_horizon_color=Color("c6e7d7");sky_mat.ground_bottom_color=Color("accbbc");sky.sky_material=sky_mat;env.sky=sky;env.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;env.ambient_light_color=Color("c2dbea");env.ambient_light_energy=.60;env.fog_enabled=true;env.fog_density=.0028;env.fog_sky_affect=.05;env.fog_light_color=Color("bce1d7");we.environment=env;add_child(we)
 sun=DirectionalLight3D.new();sun.rotation_degrees=Vector3(-42,-30,0);sun.light_color=Color("ffdfb9");sun.light_energy=1.1;sun.shadow_enabled=not s.low;sun.directional_shadow_max_distance=45;add_child(sun)
 map_root=Node3D.new();map_root.name="TheRanch";add_child(map_root);make_world()
 player=PLAYER.new();player.world=self;add_child(player);player.position=Vector3(float(s.pos[0]),float(s.pos[1]),float(s.pos[2]));player.yaw=float(s.yaw);player.pitch=float(s.pitch);player.rotation.y=player.yaw;player.camera.rotation.x=player.pitch
 hud=HUD.new();hud.world=self;add_child(hud)
 for n in ["shot","move","hit","coin","hurt"]:sounds[n]=load("res://audio/"+n+".wav")
 for i in 6:var a=AudioStreamPlayer.new();a.volume_db=-20;add_child(a);audio.append(a)
 music=AudioStreamPlayer.new();music.stream=load("res://audio/ambient.wav");music.stream.loop_mode=AudioStreamWAV.LOOP_FORWARD;music.stream.loop_end=int(music.stream.get_length()*22050);music.volume_db=-28;add_child(music)
 vacuum=AudioStreamPlayer.new();vacuum.stream=load("res://audio/vacuum.wav");vacuum.stream.loop_mode=AudioStreamWAV.LOOP_FORWARD;vacuum.stream.loop_end=22050;vacuum.volume_db=-25;add_child(vacuum)
 for i in 6:var a=RanchArt.ring(self,Vector3.ZERO,.2,"d3f2df99");a.visible=false;swirl.append(a)
 if s.entities.is_empty():populate()
 else:
  for e in s.entities:
   var a=spawn(int(e.k),Vector3(e.p[0],e.p[1],e.p[2]),int(e.get("pen",-1)),int(e.get("second",-1)))
   if a:a.hunger=float(e.get("hunger",0));a.flight=0
 get_viewport().size_changed.connect(resize);resize()
func resize():
 var v=DisplayServer.window_get_size();var q=Vector2i(480,800) if v.x<v.y else Vector2i(960,540)
 if get_viewport().content_scale_size!=q:get_viewport().content_scale_size=q
 if player:player.camera.keep_aspect=Camera3D.KEEP_WIDTH if v.x<v.y else Camera3D.KEEP_HEIGHT;player.camera.fov=72
func make_world():
 var ground=RanchArt.solid_box(map_root,Vector3(0,-.22,-15),Vector3(120,.4,140),"dab383")
 var gm=ShaderMaterial.new();gm.shader=load("res://Ground.gdshader");ground.material_override=gm
 for p in [Vector3(-8,.001,5),Vector3(8,.001,5),Vector3(-8,.001,-6),Vector3(8,.001,-6)]:pen_nodes.append(RanchArt.corral(map_root,p,pen_nodes.size()<int(s.pens),1.5+int(s.walls)*.45))
 RanchArt.building(map_root,Vector3(-17,0,17));RanchArt.label(map_root,SHOP+Vector3(0,2.3,0),"WORKSHOP","fff0c8",38)
 var shop=Node3D.new();shop.position=SHOP;map_root.add_child(shop);RanchArt.box(shop,Vector3(0,.75,0),Vector3(2.1,1.5,.9),"bb755c");RanchArt.box(shop,Vector3(0,1.53,0),Vector3(2.4,.13,1.1),"f5d99f");var terminal=RanchArt.box(shop,Vector3(0,1.15,.5),Vector3(1.2,.65,.04),"b9eac5");terminal.material_override=RanchArt.mat("b9eac5",true)
 var market=Node3D.new();market.position=MARKET;map_root.add_child(market);RanchArt.building(market,Vector3.ZERO);RanchArt.label(market,Vector3(0,4.8,1),"CRYSTAL MARKET","eeffd3",38)
 var funnel=RanchArt.cylinder(market,Vector3(0,1.2,3.0),1.0,.6,"3c6473",.60);funnel.rotation.x=PI/2;var lip=RanchArt.ring(market,Vector3(0,1.2,3.34),1,"cdf19e");lip.rotation.x=PI/2;RanchArt.box(market,Vector3(0,1.0,3.1),Vector3(2.5,.15,.5),"e1b27e")
 garden_node=Node3D.new();garden_node.position=GARDEN;map_root.add_child(garden_node);RanchArt.box(garden_node,Vector3(0,.02,0),Vector3(3.5,.1,3),"957157")
 for x in [-1.8,1.8]:RanchArt.box(garden_node,Vector3(x,.17,0),Vector3(.18,.3,3.5),"cca17b")
 for z in [-1.6,1.6]:RanchArt.box(garden_node,Vector3(0,.17,z),Vector3(3.8,.3,.18),"cca17b")
 for i in 8:var sprout=RanchArt.ball(garden_node,Vector3(-1.2+(i%4)*.8,.23,-.8+int(i/4)*1.5),Vector3(.5,.12,.5),"8ab66a");sprout.visible=s.garden>0
 gate_node=Node3D.new();gate_node.position=GATE;map_root.add_child(gate_node)
 for side in [-1,1]:RanchArt.solid_box(map_root,Vector3(side*4.5,2,-26),Vector3(1.8,4,2),"9ea0b1");RanchArt.box(map_root,Vector3(side*4.5,4.2,-26),Vector3(2.2,.4,2.2),"dec3a0")
 RanchArt.box(map_root,Vector3(0,4.5,-26),Vector3(10,.6,2),"c2b398");RanchArt.label(map_root,Vector3(0,5.3,-25),"SUNBEAM CANYON","f4e3b2",34)
 var barrier=RanchArt.solid_box(gate_node,Vector3(0,1.6,0),Vector3(7.2,3.2,.20),"a0c9cd99");barrier.name="Barrier";barrier.visible=s.gate==0;barrier.get_child(0).collision_layer=1 if s.gate==0 else 0
 var rocks=[]
 for i in 30:
  var a=i*TAU/30;var pos=Vector3(cos(a)*38,0,sin(a)*38-15);rocks.append([pos,4.0+fmod(i*1.8,3),7+fmod(i*2.3,7)])
 for x in [-32,-24,-16,16,24,32]:rocks.append([Vector3(x,0,-27),4.5,7.5])
 for p in [Vector3(-22,0,1),Vector3(22,0,4),Vector3(-23,0,-43),Vector3(23,0,-42)]:rocks.append([p,3.5,4.2])
 RanchArt.cliffs(map_root,rocks)
 for i in 13:var a=i*2.41;var pos=Vector3(cos(a)*25,0,sin(a)*24-14);RanchArt.tree(map_root,pos,"e0a3b0" if i%3==0 else "94b391")
 RanchArt.tree(map_root,Vector3(-4,0,12),"c5cc91");RanchArt.tree(map_root,Vector3(17,0,12),"c5cc91")
 for i in 7:RanchArt.ball(map_root,Vector3(-65+i*21,30+sin(i)*7,-90),Vector3(18,4,8),"edf8e5")
 var grass=MultiMesh.new();grass.transform_format=MultiMesh.TRANSFORM_3D;grass.use_colors=true;var blade=CylinderMesh.new();blade.radial_segments=3;blade.top_radius=0;blade.bottom_radius=.25;blade.height=.6;grass.mesh=blade;grass.instance_count=230
 var g=MultiMeshInstance3D.new();g.multimesh=grass;g.material_override=RanchArt.mat("ffffff").duplicate();g.material_override.vertex_color_use_as_albedo=true;map_root.add_child(g)
 for i in 230:
  var p=Vector3(rng.randf_range(-30,30),.17,rng.randf_range(-48,23));grass.set_instance_transform(i,Transform3D(Basis.from_scale(Vector3(.65,rng.randf_range(.5,1),.65)),p));grass.set_instance_color(i,Color("adaf70") if i%3 else Color("d6a696"))
func populate():
 spawn(0,PENS[0]+Vector3(-.8,.6,0),0);spawn(0,PENS[0]+Vector3(.8,.6,0),0)
 spawn(0,Vector3(2,.6,12));spawn(0,Vector3(-1,.6,9))
 for i in 8:spawn(0,Vector3(rng.randf_range(-15,15),.6,rng.randf_range(-16,18)))
 for k in [1,2,3]:
  for i in 4:spawn(k,Vector3(rng.randf_range(-25,25),.6,rng.randf_range(-48,-32)))
 grow_food()
func grow_food():
 for p in [Vector3(-4,.4,12),Vector3(17,.4,12),Vector3(-15,.4,-16),Vector3(12,.4,-40)]:
  for i in 4:spawn(5 if i%3 else 6,p+Vector3(rng.randf_range(-1.6,1.6),0,rng.randf_range(-1.6,1.6)))
func spawn(k,p,pen=-1,second=-1):
 var slimes=0;var items=0
 for e in entities:
  if e.k<5:slimes+=1
  else:items+=1
 if (k<5 and slimes>=36) or (k>=5 and items>=64):return null
 var node=RanchArt.slime(k,second) if k<5 else RanchArt.fruit(k);add_child(node);node.position=p
 var e={"k":k,"p":p,"node":node,"pen":pen,"second":second,"hunger":0.0,"phase":rng.randf()*TAU,"timer":rng.randf()*3,"dir":Vector3.ZERO,"flight":0.0,"vel":Vector3.ZERO,"pull":0.0,"north":p.z<-26};entities.append(e);return e
func erase_entity(e):e.node.queue_free();entities.erase(e)
func item_name(k):return NAMES[k] if k<7 else NAMES[k-10].replace(" Jelly","")+" Crystal"
func capacity():return 20+int(s.tank)*10
func can_add(k):
 for slot in s.slots:if slot.k==k and slot.n<capacity():return true
 for slot in s.slots:if slot.n==0:return true
 return false
func add_item(k):
 if not can_add(k):return false
 var id=-1
 for i in 4:if int(s.slots[i].k)==k and int(s.slots[i].n)<capacity():id=i;break
 if id<0:
  for i in 4:if s.slots[i].n==0:id=i;break
 s.slots[id].k=k;s.slots[id].n+=1
 if k<5 and k not in s.discovered:s.discovered.append(k);toast("NEW · "+item_name(k))
 hud.bump=1.0;sound("move");return true
func remove_item(id):
 if s.slots[id].n<=0:return -1
 var k=int(s.slots[id].k);s.slots[id].n-=1
 if s.slots[id].n==0:s.slots[id].k=-1
 return k
func aim_entity():
 var best=null;var score=-INF;var cam=player.camera;var forward=-cam.global_basis.z;var range_limit=8+int(s.range)*2
 for e in entities:
  if e.k<5 and e.second>=0:continue
  var d=e.node.global_position-cam.global_position;var distance=d.length()
  if distance>range_limit or distance<.1:continue
  var dot=forward.dot(d.normalized())
  if dot<.68:continue
  var ray=PhysicsRayQueryParameters3D.create(cam.global_position,e.node.global_position,1);var hit=get_world_3d().direct_space_state.intersect_ray(ray)
  if not hit.is_empty() and cam.global_position.distance_to(hit.position)<distance-.5:continue
  var a=dot*4-distance*.17+(.5 if e.k>=10 else .2 if e.k>=5 else 0)
  if a>score:score=a;best=e
 return best
func near_station():
 var d=player.position
 if d.distance_to(MARKET+Vector3(0,0,3))<5:return "market"
 if d.distance_to(SHOP)<4:return "shop"
 if d.distance_to(GATE)<5 and s.gate==0:return "gate"
 return ""
func interact():
 var station=near_station()
 if station=="market":sell()
 elif station=="shop":set_mode("shop")
 elif station=="gate":buy("gate")
 else:toast("FIND THE MARKET OR WORKSHOP")
func aimed_pen():
 var best=-1;var score=.4;var forward=-player.camera.global_basis.z
 for i in int(s.pens):
  var d=PENS[i]+Vector3(0,.8,0)-player.camera.global_position
  if d.length()<10 and forward.dot(d.normalized())>score:best=i;score=forward.dot(d.normalized())
 return best
func shoot():
 if mode!="play":return
 var id=int(s.selected);var k=int(s.slots[id].k)
 if s.slots[id].n<=0:toast("EMPTY SLOT");return
 var pen=aimed_pen() if k<5 else -1
 if pen>=0:
  var count=0
  for e in entities:if e.pen==pen and e.k<5:count+=1
  if count>=4+int(s.walls)*2:toast("CORRAL FULL · UPGRADE WALLS");return
 if k>=10 and near_station()=="market":remove_item(id);sale_one(k,1);finish_orders();sound("coin");save_game();return
 var p=player.camera.global_position-player.camera.global_basis.z*1.0;var e=spawn(k,p,pen)
 if not e:toast("THE RANCH IS BUSY");return
 remove_item(id);e.flight=.8;e.vel=-player.camera.global_basis.z*9+Vector3.UP*1.5
 if pen>=0:e.vel=(PENS[pen]+Vector3(0,.8,0)-p).normalized()*9+Vector3.UP*2
 if k in [5,6]:
  var friend=closest_hungry(p,8)
  if friend:e.vel=(friend.p+Vector3(0,.2,0)-p).normalized()*9+Vector3.UP*1.2
 player.kick=1;hud.flash=.1;sound("shot");save_game()
func closest_hungry(p,range_limit):
 var best=null;var dist=range_limit
 for e in entities:
  if e.k>=5 or e.hunger>0:continue
  if (-player.camera.global_basis.z).dot((e.p-p).normalized())<.4:continue
  var q=e.p.distance_to(p)
  if q<dist:dist=q;best=e
 return best
func feed(e,food):
 if e.hunger>0 or food.k not in [5,6]:return false
 var favorite=food.k==(6 if e.k in [1,2] else 5);var count=3 if favorite else 2;erase_entity(food);e.hunger=12;e.phase=0;sound("coin");hud.bump=.4
 var kinds=[e.k] if e.second<0 else [e.k,e.second]
 for kind in kinds:
  for i in count:
   var a=spawn(10+kind,e.p+Vector3(rng.randf_range(-.55,.55),.2,rng.randf_range(-.55,.55)))
   if a:a.flight=.4;a.vel=Vector3(rng.randf_range(-1,1),2,rng.randf_range(-1,1))
   else:s.bank[str(10+kind)]=int(s.bank.get(str(10+kind),0))+1
 burst(e.p,"+%d"%(count*kinds.size()),"fff2d3");toast("HAPPY JELLY · +%d CRYSTALS"%(count*kinds.size()));return true
func breed(e,crystal):
 var other=crystal.k-10
 if s.walls<1 or e.second>=0 or other==e.k:return false
 erase_entity(crystal);e.second=other;var old=e.node;e.node=RanchArt.slime(e.k,other);add_child(e.node);e.node.position=e.p;old.queue_free();e.hunger=0;burst(e.p,"LARGO!","f5cc9c");toast("A NEW LARGO!");sound("coin");save_game();return true
func sale_one(k,n):
 var value=PRICES[k-10];s.coins+=value*n;s.sold+=n;s.delivery[k-10]+=n
func sell():
 var before=int(s.coins);var orders_before=int(s.orders)
 for i in 4:
  var slot=s.slots[i]
  if slot.k>=10 and slot.n>0:sale_one(int(slot.k),int(slot.n));slot.n=0;slot.k=-1
 for key in s.bank:sale_one(int(key),int(s.bank[key]))
 s.bank={};finish_orders();sound("coin");burst(MARKET+Vector3(0,2,3),"+$%d"%(int(s.coins)-before),"def2a7");toast(("ORDER FILLED · +$%d" if s.orders>orders_before else "SOLD · +$%d")%(int(s.coins)-before));save_game()
func finish_orders():
 for i in 12:
  var wanted=int(s.orders)%5;var need=6 if int(s.orders)<5 else 6+int(s.orders/5)*2
  if int(s.delivery[wanted])-int(s.spent[wanted])<need:break
  s.spent[wanted]+=need;s.coins+=60+int(s.orders)*15;s.orders+=1
  if s.orders>=5 and not s.won:s.won=true;set_mode("ending")
func buy(kind):
 var costs={"tank":70,"boots":90,"range":80,"garden":60,"walls":80,"gate":150,"pens":120};var level=int(s[kind]);var cap=4 if kind=="pens" else 1 if kind=="gate" else 2 if kind in ["garden","walls"] else 3
 if level>=cap:toast("FULLY UPGRADED");return false
 var cost=costs[kind]*(level if kind=="pens" else level+1)
 if s.coins<cost:toast("NEED $%d"%cost);return false
 s.coins-=cost;s[kind]+=1
 if kind=="pens" or kind=="walls":
  for n in pen_nodes:n.queue_free()
  pen_nodes=[]
  for i in 4:pen_nodes.append(RanchArt.corral(map_root,PENS[i],i<int(s.pens),1.5+int(s.walls)*.45))
 if kind=="gate":gate_node.get_node("Barrier").visible=false;gate_node.get_node("Barrier").get_child(0).collision_layer=0
 if kind=="garden":
  for a in garden_node.get_children():a.visible=true
  for i in 5:spawn(5,GARDEN+Vector3(rng.randf_range(-1,1),.4,rng.randf_range(-1,1)))
 sound("coin");toast("UPGRADED · "+kind.to_upper());save_game();return true
func rest():
 s.day+=1;s.hour=8;grow_food();garden_timer=30;set_mode("play");save_game();toast("A FRESH MORNING")
func set_mode(m):mode=m;sucking=false;move_vec=Vector2.ZERO;player.velocity=Vector3.ZERO
func sound(n):
 if s.muted:return
 for a in audio:if not a.playing:a.stream=sounds[n];a.play();return
func toast(t):notice=t;notice_time=2.8
func burst(p,t,c):
 if particles.size()>16:return
 var node=RanchArt.label(self,p+Vector3.UP*.5,t,c,48);particles.append({"n":node,"life":1.6})
func _physics_process(dt):
 if mode!="play":return
 s.hour+=dt*.05
 if s.hour>=24:s.hour-=24;s.day+=1
 target=aim_entity();intake=maxf(0,intake-dt)
 for e in entities.duplicate():
  e.hunger=maxf(0,e.hunger-dt);e.timer-=dt;e.pull=move_toward(e.pull,0,dt*3)
  if e.flight>0:
   e.flight-=dt;e.vel.y-=dt*10;var next=e.p+e.vel*dt;var ray=PhysicsRayQueryParameters3D.create(e.p,next,1);var hit=get_world_3d().direct_space_state.intersect_ray(ray)
   if not hit.is_empty():next=hit.position+hit.normal*.28;e.flight=0
   e.p=next
   if e.p.y<.25:e.p.y=.25;e.flight=0
  elif sucking and target==e:
   e.pull=1;e.p=e.p.move_toward(player.camera.global_position-player.camera.global_basis.z*.55,dt*(6+int(s.range)*1.5))
   if e.p.distance_to(player.camera.global_position)<1.6 and intake<=0:
    if add_item(e.k):erase_entity(e);intake=.15;target=null;continue
    else:toast("TANK FULL · SELL OR RELEASE");sucking=false
  elif e.k<5:
   if e.timer<=0:e.timer=rng.randf_range(1.5,4);var a=rng.randf()*TAU;e.dir=Vector3(sin(a),0,cos(a))*.6
   var food=null;var distance=4.0
   if e.hunger<=0:
    for f in entities:
     if f.k in [5,6] and f.flight<=0:
      var d=Vector2(f.p.x,f.p.z).distance_to(Vector2(e.p.x,e.p.z))
      if d<distance:distance=d;food=f
    if food:e.dir=(food.p-e.p).normalized()*1.2
   e.p+=e.dir*dt;e.p.y=.57+absf(sin(clock*2.6+e.phase))*.30
   if e.pen>=0:
    var center=PENS[e.pen];e.p.x=clampf(e.p.x,center.x-2.55,center.x+2.55);e.p.z=clampf(e.p.z,center.z-2.55,center.z+2.55)
   else:
    e.p.x=clampf(e.p.x,-28,28);var north=e.north;e.p.z=clampf(e.p.z,-49 if north else -20,-31 if north else 21)
    for center in PENS:
     var d=Vector2(e.p.x-center.x,e.p.z-center.z)
     if absf(d.x)<3.5 and absf(d.y)<3.5:e.p.x=center.x+3.7*(1 if d.x>=0 else -1);e.dir.x*=-1
   if food and food in entities and Vector2(food.p.x,food.p.z).distance_to(Vector2(e.p.x,e.p.z))<1.0:feed(e,food)
   if s.walls>0 and e.second<0:
    for f in entities.duplicate():
     if f.k>=10 and f.flight<=0 and e.p.distance_to(f.p)<1:if breed(e,f):break
  e.node.position=e.p
  if e.k<5:
   if Vector2(e.p.x,e.p.z).distance_to(Vector2(player.position.x,player.position.z))>.01:e.node.look_at(Vector3(player.position.x,e.p.y,player.position.z))
   e.node.scale=Vector3(1-e.pull*.15,1-e.pull*.15,1+e.pull*.5)*(1.3 if e.second>=0 else 1);var squash=sin(clock*2.6+e.phase)*.09;e.node.get_node("Body").scale=Vector3(1.45*(1+squash),1.1*(1-squash),1.4*(1+squash));var blink=.08 if fmod(clock+e.phase,5)<.13 else 1.0;e.node.get_node("EyeL").scale.y=.14*blink;e.node.get_node("EyeR").scale.y=.14*blink
  elif e.flight<=0:e.node.position.y=.28+sin(clock*2+e.phase)*.045;e.node.rotation.y+=dt*.30
 garden_timer+=dt
 if s.garden>0 and garden_timer>28: garden_timer=0;for i in int(s.garden)*3:spawn(5,GARDEN+Vector3(rng.randf_range(-1,1),.4,rng.randf_range(-1,1)))
 spawn_timer+=dt
 if spawn_timer>30:
  spawn_timer=0;var count=0
  for e in entities:if e.k<5 and e.pen<0:count+=1
  if count<24:spawn(rng.randi_range(0,3) if s.gate>0 else 0,Vector3(rng.randf_range(-22,22),.6,rng.randf_range(-47,-32) if s.gate>0 else rng.randf_range(-18,18)))
  var food_count=0
  for e in entities:if e.k in [5,6]:food_count+=1
  if food_count<8:
   for i in 3:spawn(5,Vector3(-4+rng.randf_range(-1,1),.4,12+rng.randf_range(-1,1)))
  if s.hour>19 or s.hour<5:
   var moons=0
   for e in entities:if e.k==4:moons+=1
   if moons<4:spawn(4,Vector3(rng.randf_range(-22,22),.6,rng.randf_range(-47,-32)))
func _process(dt):
 clock+=dt;autosave+=dt;bridge+=dt;notice_time=maxf(0,notice_time-dt)
 if vacuum:
  if sucking and mode=="play" and not s.muted:
   if not vacuum.playing:vacuum.play()
   vacuum.pitch_scale=1.15 if target else .95
  elif vacuum.playing:vacuum.stop()
 for a in particles.duplicate():
  a.life-=dt;a.n.position.y+=dt*.7;a.n.modulate.a=minf(1,a.life*2)
  if a.life<=0:a.n.queue_free();particles.erase(a)
 var night=s.hour>=19 or s.hour<6;sun.light_energy=.35 if night else .85;env.ambient_light_energy=.42;sky_mat.sky_top_color=Color("443f78") if night else Color("459fb2");sky_mat.sky_horizon_color=Color("9c94b6") if night else Color("c6e7d7");sky_mat.ground_horizon_color=sky_mat.sky_horizon_color;env.fog_light_color=sky_mat.sky_horizon_color
 for i in swirl.size():
  var a=swirl[i];a.visible=sucking and mode=="play"
  if a.visible:
   var origin=player.camera.global_position;var end=target.node.global_position if target else origin-player.camera.global_basis.z*5;var t=fmod(clock*1.2+i/6.0,1);a.position=origin.lerp(end,t);a.scale=Vector3.ONE*(.2+t*2);a.quaternion=Quaternion(Vector3.UP,(end-origin).normalized())
 if autosave>8:autosave=0;save_game()
 if OS.has_feature("web") and bridge>.25:
  bridge=0;var actors=[];var controls=[]
  for e in entities:
   var p=player.camera.unproject_position(e.node.global_position);actors.append({"k":e.k,"second":e.second,"pen":e.pen,"p":[e.p.x,e.p.y,e.p.z],"screen":[p.x,p.y]})
  for b in hud.buttons:controls.append({"id":b.id,"r":[b.r.position.x,b.r.position.y,b.r.size.x,b.r.size.y]})
  JavaScriptBridge.eval("window.RanchSnapshot="+JSON.stringify({"mode":mode,"s":s,"player":[player.position.x,player.position.y,player.position.z],"yaw":player.yaw,"pitch":player.pitch,"target":target.k if target else -1,"station":near_station(),"entities":actors,"controls":controls,"sucking":sucking,"viewport":[get_viewport().get_visible_rect().size.x,get_viewport().get_visible_rect().size.y]}),true)
func save_game():
 if not player:return
 s.pos=[player.position.x,player.position.y,player.position.z];s.yaw=player.yaw;s.pitch=player.pitch;s.entities=[]
 for e in entities:s.entities.append({"k":e.k,"p":[e.p.x,e.p.y,e.p.z],"second":e.second,"pen":e.pen,"hunger":e.hunger})
 var raw=JSON.stringify(s);var f=FileAccess.open(SAVE,FileAccess.WRITE)
 if f:f.store_string(raw);f.close()
 if OS.has_feature("web"):JavaScriptBridge.eval("try{localStorage.setItem('jelly_ranch_v1',"+JSON.stringify(raw)+")}catch(e){}",true)
func load_save():
 var d=null
 if OS.has_feature("web"):
  var raw=JavaScriptBridge.eval("(()=>{try{return localStorage.getItem('jelly_ranch_v1')||''}catch(e){return ''}})()",true)
  if raw is String and not raw.is_empty():d=JSON.parse_string(raw)
 if not d is Dictionary and FileAccess.file_exists(SAVE):d=JSON.parse_string(FileAccess.get_file_as_string(SAVE))
 if d is Dictionary:s.merge(d,true)
func _notification(n):
 if n==NOTIFICATION_APPLICATION_FOCUS_OUT and mode=="play":set_mode("pause");save_game()
