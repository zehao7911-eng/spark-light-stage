extends SceneTree
var w
var failures=[]
var checks=0
var backup=""
func check(ok,label):
 checks+=1
 if not ok:failures.append(label);printerr("FAIL "+label)
func _initialize():call_deferred("run")
func clear():
 for e in w.entities.duplicate():w.erase_entity(e)
func slots():w.s.slots=[{"k":-1,"n":0},{"k":-1,"n":0},{"k":-1,"n":0},{"k":-1,"n":0}]
func run():
 if FileAccess.file_exists("user://jelly_ranch.json"):backup=FileAccess.get_file_as_string("user://jelly_ranch.json")
 w=load("res://World.tscn").instantiate();root.add_child(w);await process_frame
 w.s.muted=true;w.set_process(false);w.set_physics_process(false);w.player.set_physics_process(false);w.mode="play";clear();slots();w.s.tank=0;w.s.walls=0;w.s.coins=0;w.s.orders=0;w.s.sold=0;w.s.delivery=[0,0,0,0,0];w.s.spent=[0,0,0,0,0];w.s.bank={};w.s.won=false
 for i in 20:w.add_item(5)
 check(w.s.slots[0].n==20,"inventory stack capacity")
 w.add_item(5);check(w.s.slots[1].n==1,"full stack spills into free slot")
 w.add_item(0);w.add_item(1);check(not w.can_add(2),"four distinct occupied slots block fifth")
 check(w.remove_item(3)==1 and w.s.slots[3].k==-1,"last item clears slot")
 slots();var e=w.spawn(0,Vector3(0,.6,0));var food=w.spawn(5,Vector3(0,.3,0));check(w.feed(e,food),"favorite food accepted")
 check(w.entities.size()==4 and e.hunger==12,"favorite food produces three crystals")
 food=w.spawn(6,Vector3(0,.3,0));check(not w.feed(e,food) and food in w.entities,"hunger cooldown prevents repeated production")
 e.hunger=0;check(w.feed(e,food),"other food accepted");check(w.entities.size()==6,"other food produces two crystals")
 var crystal=w.spawn(11,Vector3.ZERO);check(not w.breed(e,crystal),"hybrid requires wall upgrade")
 w.s.walls=1;check(w.breed(e,crystal) and e.second==1,"different crystal creates hybrid")
 check(crystal not in w.entities,"breeding consumes crystal once")
 var n=w.entities.size();e.hunger=0;food=w.spawn(5,Vector3.ZERO);w.feed(e,food);check(w.entities.size()==n+6,"hybrid yields both crystal types")
 clear();slots();w.s.bank={};w.s.slots[0]={"k":10,"n":6};w.sell();check(w.s.coins==114 and w.s.orders==1 and w.s.sold==6,"sale plus first order bonus")
 var gold=w.s.coins;w.sell();check(w.s.coins==gold,"empty sale cannot repeat rewards")
 for k in range(1,5):w.s.slots[0]={"k":10+k,"n":6};w.sell()
 check(w.s.orders==5 and w.s.won and w.mode=="ending","five species complete initial orders")
 w.s.slots[0]={"k":10,"n":8};w.sell();check(w.s.orders==6 and w.s.spent[0]==14,"continuing orders require new delivery")
 w.s.coins=0;w.s.garden=0;check(not w.buy("garden") and w.s.garden==0,"unaffordable purchase blocked")
 w.s.coins=1000;w.s.tank=0;check(w.buy("tank") and w.capacity()==30 and w.s.coins==930,"tank upgrade cost and capacity")
 w.s.gate=0;w.buy("gate");check(w.s.gate==1 and w.gate_node.get_node("Barrier").get_child(0).collision_layer==0,"canyon unlock removes collision")
 w.s.garden=0;var before=w.entities.size();w.buy("garden");check(w.s.garden==1 and w.entities.size()==before+5,"garden starts with five berries")
 w.s.tank=3;gold=w.s.coins;check(not w.buy("tank") and w.s.coins==gold,"capped upgrade does not charge")
 clear();slots();w.s.walls=0;w.s.pens=1;w.mode="play";w.player.position=Vector3(-8,0,12);w.player.yaw=0;w.player.rotation.y=0;w.player.pitch=-.08;w.player.camera.rotation.x=-.08
 for i in 4:w.spawn(0,w.PENS[0]+Vector3(i*.2,.6,0),0)
 w.add_item(0);w.s.selected=0;w.shoot();check(w.s.slots[0].n==1 and w.entities.size()==4,"full corral blocks release without losing cargo")
 clear();slots();w.player.position=Vector3(0,0,16);w.player.rotation.y=0;w.player.yaw=0;w.player.camera.rotation.x=-.08;var a=w.spawn(5,Vector3(0,.5,12));await physics_frame
 check(w.aim_entity()==a,"vacuum acquires visible fruit")
 w.sucking=true
 for i in 90:w._physics_process(1.0/60)
 check(a not in w.entities and w.s.slots[0].k==5,"physics vacuum transfers fruit into inventory")
 w.sucking=false;clear();slots();w.player.position=Vector3(0,0,16);var jelly=w.spawn(0,Vector3(0,.6,12));jelly.timer=100;jelly.dir=Vector3.ZERO;w.add_item(5);w.s.selected=0;w.shoot()
 for i in 100:w._physics_process(1.0/60)
 check(jelly.hunger>0,"shot food reaches and feeds jelly through physics")
 var crystals=0
 for item in w.entities:if item.k==10:crystals+=1
 check(crystals==3,"shot favorite food creates collectible crystals")
 w.player.position=Vector3(0,0,16);clear();var hidden=w.spawn(5,Vector3(0,.6,11));var wall=RanchArt.solid_box(w,Vector3(0,1,13),Vector3(3,3,.2),"888888");await physics_frame;await physics_frame
 check(w.aim_entity()==null,"solid scenery blocks vacuum line of sight")
 wall.queue_free();clear();w.s.hour=23;w.s.day=1;w.rest();check(w.s.day==2 and w.s.hour==8 and w.mode=="play","rest advances day and restores morning food")
 w.s.slots[0]={"k":5,"n":7};w.s.coins=321;w.save_game();w.s.coins=0;w.s.slots=[];w.load_save();check(w.s.coins==321 and w.s.slots[0].n==7,"save restores money and inventory")
 w.queue_free();await process_frame
 if not backup.is_empty():var f=FileAccess.open("user://jelly_ranch.json",FileAccess.WRITE);f.store_string(backup);f.close()
 else:DirAccess.remove_absolute("user://jelly_ranch.json")
 print(JSON.stringify({"checks":checks,"failures":failures}));quit(0 if failures.is_empty() else 1)

