# Jelly Ranch

A first-person, touch-ready 3D ranching game built in Godot 4.7.2, with original procedural meshes and synthesized audio. Inspired by the vacuum / feed / sell / explore loop of Slime Rancher; this is a smaller independent browser game, not the commercial game or its assets.

## Play
- Desktop: WASD to move, drag the world to look, hold Space to vacuum, right-click or Enter to shoot, 1–4 to select cargo, E to use nearby stations. M opens the map; Escape pauses.
- Touch: left stick moves, drag an empty area to look, hold SUCK to collect, tap a cargo slot and SHOOT to release. Nearby stations show a contextual button. Movement and vacuum support simultaneous touches.
- Vacuum food and jellies, release jellies toward a corral, shoot food near hungry jellies, vacuum the resulting crystals, and bring them to the market.
- Berries are favorites of Pink, Honey and Moon jellies. Rock and Tabby prefer carrots. Favorite meals produce three crystals; other meals produce two. Hungry creatures chase food; meals have a cooldown.
- Buy gardens, larger tanks, boots, range, taller walls and more corrals. Open Sunbeam Canyon for more species. Moon jellies appear after sunset. Rest at the workshop to reach the next morning.
- Taller walls enable feeding a jelly another species' crystal to create a larger hybrid. Hybrids produce both species' crystals and cannot be vacuumed. Initial five orders lead to an achievement, followed by larger repeat orders.

## Package
`web/` is the complete HTML5 build. Serve this directory over HTTP; do not open index.html as a file URL. It needs WebGL 2. No CDN, cross-origin isolation, SharedArrayBuffer or external assets are required.
`godot/` contains project.godot, an editable baked World.tscn preview, source scripts, shaders, audio and export preset. Open project.godot in Godot 4.7.2 and press F6 or F5. Install matching export templates to re-export Web. Compatibility renderer and a single-thread Web export are used.

The local development layout is `jelly-ranch/` and its sibling `jelly-ranch-web/`; adapt export_path if using the package layout. The runtime generates the world from Art.gd and World.gd; the baked EditorPreview is removed at startup.

## Performance and storage
The game caps actors at 36 jellies and 64 loose objects, uses batched grass/cliffs, low-poly meshes and a 30 FPS cap. Pause settings can disable shadows or sound. Canvas/UI adapts to portrait and landscape. Save data is stored in browser localStorage plus Godot storage on that browser and origin. Browser storage deletion clears the save.

## Validation
30 headless logic checks cover inventory, food, hunger, hybrid outputs, sales, unique order rewards, upgrades, projectile feeding, occlusion, corral capacity and save restoration. Browser checks at 1280×800, 390×844, 844×390 and 768×1024 cover collection, touch movement plus vacuum, release, map/help, control bounds and reload persistence. Tested in Chromium/Edge and in the local Godot editor. Physical iPhone/Android hardware performance has not been measured.

## Assets and licenses
All ranch and creature meshes are constructed locally in code. Audio is synthesized locally. No Steam reference screenshots or commercial game assets are bundled. Godot license is included in GODOT-LICENSE.txt. The optional bundled Cinzel font has its accompanying OFL license.
