MINION: BANANA BALL
Original unofficial fan mini-game, not affiliated with Illumination or Universal.

Drag anywhere to roll. Lift to brake. Collect all three bananas, then enter the golden gate. Checkpoint flags save your return position; falls keep your bananas. Springs launch you, striped bumpers bounce you, paired purple portals transport you.

Eight authored routes introduce the mechanics, followed by mirrored routes and a small capped bumper speed increase. Course numbers continue to 999, reusing these eight layouts. Three stars: finish / no falls / beat the route's generous target time. Your highest stars on each numbered course save locally. Six total stars unlock gold goggles; twelve unlock a party hat. Replay cannot repeatedly farm the same stars.

Keyboard: arrows or WASD. Hold Space to brake. Escape pauses. The note button mutes synthesized sound. Progress restores paused; no account or network required. If browser storage is blocked, session play still works.

Open index.html in a current WebGL browser. The standalone index includes all dependencies. The editable JS/CSS files are included separately. For web hosting upload the folder, or upload banana-ball.html. All character geometry, environment, visual effects and synthesized audio were authored for this fan game. No commercial assets, voices or game code were extracted. Three.js r147 MIT license: THREE-LICENSE.txt.

Portrait and landscape touch sizes are tested through browser automation. DPR capped at 1.5, particles at 100, simultaneous audio voices at 12. Pause/background stops simulation, rendering and sound. WebGL context loss offers Retry. Real handset performance depends on device.
