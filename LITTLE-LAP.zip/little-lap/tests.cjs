const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const folder=path.resolve(process.argv[2]||'outputs/little-lap');
const THREE=require(path.join(folder,'three.min.js'));let ctx={module:{exports:{}},console};vm.createContext(ctx);vm.runInContext(fs.readFileSync(path.join(folder,'racer-util.js'),'utf8'),ctx);vm.runInContext(fs.readFileSync(path.join(folder,'rules.js'),'utf8'),ctx);const R=ctx.module.exports.LapRules;
const w=fs.readFileSync(path.join(folder,'world.js'),'utf8'),points=vm.runInNewContext(w.match(/const points=(\[\[.*?\]\]);/)[1]);
const curve=new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p)),true,'catmullrom',.28);curve.arcLengthDivisions=1400;
const samples=[];let last,total=0;for(let i=0;i<=900;i++){let p=curve.getPointAt(i/900),t=curve.getTangentAt(i/900);if(last)total+=p.distanceTo(last);samples.push({x:p.x,y:p.y,z:p.z,s:total,tx:t.x,tz:t.z,curve:0});last=p;}
for(let i=0;i<samples.length;i++){let a=samples[(i-2+900)%900],b=samples[(i+2)%900];samples[i].curve=Math.atan2(a.tx*b.tz-a.tz*b.tx,a.tx*b.tx+a.tz*b.tz)/(total/900*4);}
R.setup(samples);assert(total>100&&total<180);let checks=0;
function run(assist,mode){let r=R.newRace(mode,assist);for(let i=0;i<18000&&!r.finished;i++){let input={gas:true};if(!assist&&r.p.yaw!==undefined){let target=R.at(r.p.s+1.3),angle=Math.atan2(target.x-r.p.x,target.z-r.p.z),diff=Math.atan2(Math.sin(angle-r.p.yaw),Math.cos(angle-r.p.yaw)),speed=Math.abs(diff)>.3?2.6:Math.abs(diff)>.1?4:6;input={gas:r.p.v<speed,brake:r.p.v>speed+.3,right:diff>.025,left:diff<-.025};}R.tick(r,input,1/60);assert(Number.isFinite(r.p.s)&&Number.isFinite(r.p.d));checks++;}assert(r.finished,'controlled race must finish');assert.equal(r.lapTimes.length,3);assert(r.finishRank>=1&&r.finishRank<=4);return r;}
for(let assist of [true,false])for(let mode of ['race','trial']){let r=run(assist,mode);console.log(mode,assist,'finish',r.finishRank,'time',r.time.toFixed(2),'edge hits',r.hits);}
let r=R.newRace();for(let i=0;i<400;i++)R.tick(r,{gas:true},1/60);for(let i=0;i<140;i++)R.tick(r,{gas:true,drift:true,left:true},1/60);let q=r.p.charge;R.tick(r,{gas:true},1/60);assert(q>.23);assert(r.boosts>0&&r.p.boost>0);checks++;
for(let i=0;i<900;i++)R.tick(r,{gas:true,right:true},1/60);assert(r.hits>0);assert(Math.abs(r.p.d)<=1.61);let s=r.p.s;R.reset(r);assert.equal(r.p.s,s);assert.equal(r.p.d,0);assert.equal(r.resetCount,1);checks++;
r.state='paused';let t=r.time;for(let i=0;i<100;i++)R.tick(r,{gas:true},1/60);assert.equal(r.time,t);checks++;
const end=R.at(total-.00001),start=R.at(0);assert(Math.hypot(end.x-start.x,end.z-start.z)<.01);checks++;
console.log('PASS',checks,'simulation assertions; track length',total.toFixed(2));
