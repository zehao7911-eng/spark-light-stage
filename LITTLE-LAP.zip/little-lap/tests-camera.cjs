const assert=require('assert'),{world,R,THREE:T}=require('./audit-lap-scene.cjs');let count=0,maxLift=0;
let race=R.newRace('trial');for(const sample of world.samples){race.p.s=sample.s;race.p.d=0;race.p.v=6;world.render(race,1/30,false);let p=world.camera.position;
for(const b of world.staticBounds)assert(!(p.x>b.minX-.07&&p.x<b.maxX+.07&&p.y>b.minY-.07&&p.y<b.maxY+.07&&p.z>b.minZ-.07&&p.z<b.maxZ+.07),'interpolated camera near plane clips');
maxLift=Math.max(maxLift,world.cars[0].g.position.y);assert(world.cars[0].g.position.y<.15,'suspension must not float car over track');count++;}
// The actual rendered position follows the reset car instead of a stale manual coordinate.
race.p.s=50;world.render(race,1/30);R.reset(race);world.render(race,1/30);let initial=world.cars[0].root.position.clone();race.state='race';for(let i=0;i<100;i++)R.tick(race,{gas:true},1/60);world.render(race,1/30);assert(world.cars[0].root.position.distanceTo(initial)>.5);count++;
for(let i=0;i<3;i++){let p=world.parkingPose(i);for(const b of world.staticBounds)assert(!R.solidContact(p,b),'finished car parking must clear scenery');for(let j=0;j<i;j++)assert(!R.contact(R.body(p),R.body(world.parkingPose(j))),'finished cars must not stack');count++;}
for(const a of world.samples){assert(Math.abs(a.curve)*1.55<.94,'inner ribbon folds around overly tight bend');count++;}
console.log('PASS',count,'render-pose/camera/parking/road-radius checks. Maximum axle lift',maxLift.toFixed(4));
