/* Original procedural room, toy cars and circuit. Three.js r147. */
window.LapWorld=function(canvas){
const T=THREE;T.ColorManagement.legacyMode=false;const V=T.Vector3,scene=new T.Scene();scene.background=new T.Color('#efe6d5');scene.fog=new T.Fog('#e9ddc6',34,78);
const renderer=new T.WebGLRenderer({canvas,antialias:true,alpha:false,powerPreference:'high-performance'});renderer.outputEncoding=T.sRGBEncoding;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=.85;renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;
const camera=new T.PerspectiveCamera(58,1,.07,110);const hemi=new T.HemisphereLight('#fff4d4','#92734e',.72);scene.add(hemi);scene.add(new T.AmbientLight('#fff0d2',.08));
const sun=new T.DirectionalLight('#fff1ca',1.5);sun.position.set(-13,24,12);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);Object.assign(sun.shadow.camera,{left:-24,right:24,top:22,bottom:-22,near:1,far:60});sun.shadow.bias=-.0004;sun.shadow.normalBias=.025;scene.add(sun);
const fill=new T.DirectionalLight('#c8e4e3',.3);fill.position.set(15,10,-5);scene.add(fill);
const mats={},geo={};
function mat(c,rough=.7,metal=0){let key=c+':'+rough+':'+metal;return mats[key]||(mats[key]=new T.MeshStandardMaterial({color:c,roughness:rough,metalness:metal}));}
function mesh(g,m,p,x=0,y=0,z=0){let o=new T.Mesh(g,m);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;p.add(o);return o;}
function box(p,x,y,z,w,h,d,c){const k=w+','+h+','+d;return mesh(geo[k]||(geo[k]=new T.BoxGeometry(w,h,d)),typeof c==='string'?mat(c):c,p,x,y,z);}
function roundGeo(w,h,d,r=.12){r=Math.min(r,w*.45,h*.45,d*.45);let key='r'+[w,h,d,r];if(geo[key])return geo[key];const s=new T.Shape(),x=-w/2,y=-h/2;s.moveTo(x+r,y);s.lineTo(x+w-r,y);s.quadraticCurveTo(x+w,y,x+w,y+r);s.lineTo(x+w,y+h-r);s.quadraticCurveTo(x+w,y+h,x+w-r,y+h);s.lineTo(x+r,y+h);s.quadraticCurveTo(x,y+h,x,y+h-r);s.lineTo(x,y+r);s.quadraticCurveTo(x,y,x+r,y);const g=new T.ExtrudeGeometry(s,{depth:d-2*r,bevelEnabled:true,bevelSegments:2,steps:1,bevelSize:r*.45,bevelThickness:r,curveSegments:4});g.translate(0,0,-d/2+r);geo[key]=g;return g;}
function rounded(p,x,y,z,w,h,d,c,r=.12){return mesh(roundGeo(w,h,d,r),typeof c==='string'?mat(c):c,p,x,y,z);}
function ball(p,x,y,z,sx,sy,sz,c){let o=mesh(geo.sphere||(geo.sphere=new T.SphereGeometry(1,20,12)),typeof c==='string'?mat(c,.48):c,p,x,y,z);o.scale.set(sx,sy,sz);return o;}
function cyl(p,x,y,z,r1,r2,h,c,seg=20){return mesh(new T.CylinderGeometry(r1,r2,h,seg),typeof c==='string'?mat(c):c,p,x,y,z);}
function group(x,y,z){let g=new T.Group();g.position.set(x,y,z);scene.add(g);return g;}
function texture(w,h,draw){let c=document.createElement('canvas');c.width=w;c.height=h;draw(c.getContext('2d'),w,h);let t=new T.CanvasTexture(c);t.encoding=T.sRGBEncoding;t.anisotropy=Math.min(4,renderer.capabilities.getMaxAnisotropy());return t;}
let seed=19;function rnd(){seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;}
const wood=texture(1024,1024,(c,w,h)=>{c.fillStyle='#a97645';c.fillRect(0,0,w,h);const u=32,l=128;for(let yy=-512;yy<1536;yy+=u)for(let xx=-512;xx<1536;xx+=l+u){let x=xx+(Math.floor(yy/u)%5)*u,y=yy;c.save();c.translate(x,y);c.rotate(-Math.PI/4);for(let k=0;k<2;k++){c.save();if(k){c.translate(l,u);c.rotate(Math.PI/2);}let shade=156+Math.floor(rnd()*40);c.fillStyle=`rgb(${shade+30},${shade-2},${shade-48})`;c.fillRect(0,0,l-2,u-2);c.strokeStyle='#f3d69a80';c.lineWidth=2;c.strokeRect(2,2,l-5,u-5);for(let i=0;i<6;i++){let py=4+rnd()*(u-9);c.strokeStyle=rnd()>.5?'#70442020':'#fff1c730';c.lineWidth=.5+rnd();c.beginPath();c.moveTo(3,py);c.bezierCurveTo(30,py-2,77,py+2,l-5,py);c.stroke();}c.restore();}c.restore();}});wood.wrapS=wood.wrapT=T.RepeatWrapping;wood.repeat.set(8,7);
const floorMat=new T.MeshStandardMaterial({map:wood,color:'#ceaa7b',roughness:.64});box(scene,0,-.15,0,44,.3,36,floorMat);
const wall='#ede4cf',trim='#d6c8aa';box(scene,0,7,-17,44,14,.35,wall);box(scene,-22,7,0,.35,14,36,wall);box(scene,22,7,0,.35,14,36,wall);box(scene,0,.28,-16.75,44,.55,.22,trim);box(scene,-21.75,.28,0,.22,.55,36,trim);box(scene,21.75,.28,0,.22,.55,36,trim);
// Pale wall panelling and a sunlit window.
for(let x=-20;x<22;x+=4)box(scene,x,3,-16.79,.035,5.4,.04,'#d9cfbb');box(scene,0,5.9,-16.78,44,.055,.04,'#d4c8b1');
const win=group(-21.68,7,-1);box(win,0,0,0,.07,7,10,'#fff7e4');box(win,.06,0,0,.08,6.5,9.4,'#a7c8c8');for(let z=-4.6;z<=4.6;z+=4.6)box(win,.13,0,z,.18,6.6,.14,'#fff9e7');box(win,.13,0,0,.18,.15,9.3,'#fff9e7');
const sunpatch=new T.Mesh(new T.PlaneGeometry(13,8),new T.MeshBasicMaterial({color:'#fff1bd',transparent:true,opacity:.14,depthWrite:false}));sunpatch.rotation.x=-Math.PI/2;sunpatch.rotation.z=.45;sunpatch.position.set(-12,.015,2);scene.add(sunpatch);
// Sofa: rounded fabric, piping and gently tilted cushions.
const sofa=group(19,0,6);sofa.rotation.y=-Math.PI/2;rounded(sofa,0,1.15,0,15,1.45,3.9,'#cf8a61',.28);rounded(sofa,0,2.9,-1.45,14.8,3.3,.95,'#d7956e',.25);for(let i=-1;i<=1;i++){rounded(sofa,i*4.25,1.95,.23,4.07,.55,2.65,'#e5ab81',.2);rounded(sofa,i*4.25,3,-.88,4.05,2.3,.5,'#e8b28a',.25);}for(const x of [-7,7]){rounded(sofa,x,2.4,0,1.15,2.8,4.05,'#dd9e77',.38);cyl(sofa,x,.4,0,.15,.16,.8,'#7d5039');}
for(const [x,z,col,rot] of [[-4,-.5,'#7daea2',-.35],[4,-.55,'#c8a14f',.26],[2,-.4,'#768f9c',-.27]]){let o=rounded(sofa,x,3.5,z,1.7,1.5,.5,col,.2);o.rotation.z=rot;o.rotation.x=-.3;}
// A coffee table carries the raised section of the cardboard circuit.
const table=group(1.8,0,-.7);table.name='Coffee table';rounded(table,0,2.55,0,8.2,.4,5.6,'#99603b',.16);rounded(table,0,2.77,0,8.05,.08,5.45,'#b47c48',.07);for(const x of [-3.5,3.5])for(const z of [-2.1,2.1])box(table,x,1.25,z,.45,2.5,.45,'#815137');
// Cabinet, TV, picture frames and soft rug.
const tv=group(16.7,0,-11.8);rounded(tv,0,1.2,0,6.3,2.2,2.3,'#886748',.15);for(let x=-2;x<3;x+=2){box(tv,x,1.28,1.19,1.8,1.5,.05,'#ad8b62');cyl(tv,x,1.25,1.25,.08,.08,.09,'#d7b67d');}let screen=rounded(tv,0,4.7,0,6.1,3.5,.22,'#292f2e',.1);box(tv,0,4.75,.14,5.65,3.03,.025,'#334544');box(tv,0,2.83,0,.24,.5,.25,'#4b4d47');rounded(tv,0,2.58,.2,2,.08,.7,'#3d423e',.05);
function frame(x,y,w,h,col){box(scene,x,y,-16.48,w+.22,h+.22,.25,'#9b7352');box(scene,x,y,-16.32,w,h,.03,'#fff2ce');box(scene,x,y,-16.28,w*.72,h*.65,.025,col);ball(scene,x+.2,y+.1,-16.24,w*.16,h*.18,.02,'#e6bb63');}frame(-10,7.7,3.6,4.5,'#7ea29a');frame(-5.5,8.2,2.4,2.9,'#d29379');frame(10,8.6,4,2.8,'#879fac');
const rug=mesh(new T.CircleGeometry(4.7,64),mat('#b4cbc0'),scene,-12,.024,-6);rug.rotation.x=-Math.PI/2;rug.scale.y=.7;for(let i=0;i<3;i++){let ring=new T.Mesh(new T.RingGeometry(3.2+i*.4,3.25+i*.4,64),mat('#e1debc'));ring.rotation.x=-Math.PI/2;ring.scale.y=.7;ring.position.set(-12,.028+i*.001,-6);scene.add(ring);}
function book(x,z,w,d,h,col,angle=0,y=0){let g=group(x,y,z);g.rotation.y=angle;box(g,0,h/2,0,w,h,d,'#f7e6c6');box(g,0,.035,0,w+.08,.07,d+.08,col);box(g,0,h-.035,0,w+.08,.07,d+.08,col);box(g,-w/2,h/2,0,.09,h,d+.08,col);for(let i=1;i<4;i++)box(g,w/2+.004,h*i/4,0,.006,.009,d,'#c7b598');return g;}
book(-13,-1,2.8,3.6,.55,'#658d9b',-.4);book(-13,-1,2.5,3.3,.4,'#da9264',-.1,.55);book(4,-2.85,1.8,.8,.25,'#6e8c89',.12,2.83);
function plant(x,z,size=1){let g=group(x,0,z);g.scale.setScalar(size);cyl(g,0,.68,0,1,.78,1.36,'#c77f54');cyl(g,0,1.38,0,1.05,1.02,.18,'#dd996c');cyl(g,0,1.48,0,.92,.92,.05,'#715c3e');for(let i=0;i<11;i++){let a=i*2.4,leaf=ball(g,Math.cos(a)*.55,2.3+(i%3)*.2,Math.sin(a)*.55,.22,1.3,.13,i%2?'#658b67':'#7b9d74');leaf.rotation.z=Math.sin(a)*.6;leaf.rotation.x=Math.cos(a)*.6;}return g;}
plant(-16,0,1.7);plant(19,-5,1.5);plant(-7,-13,1);
function duck(x,z,s,ang){let g=group(x,0,z);g.scale.setScalar(s);g.rotation.y=ang;ball(g,0,.75,0,1,.78,1.25,'#f5cf57');ball(g,0,1.68,.5,.68,.68,.68,'#f5d55e');let b=ball(g,0,1.56,1.12,.4,.12,.4,'#e89a4f');for(let x of [-.4,.4])ball(g,x,1.84,.93,.065,.085,.05,'#333c33');ball(g,-.85,.8,-.12,.2,.4,.7,'#e9b94a');ball(g,.85,.8,-.12,.2,.4,.7,'#e9b94a');return g;}
const duckie=duck(9.5,-12.3,1.15,-.7);
const frog=group(-2,0,12.7);ball(frog,0,1,0,1.4,.9,1,'#83a37a');for(let x of [-.8,.8]){ball(frog,x,1.8,.35,.42,.5,.42,'#91ad7e');ball(frog,x,1.91,.7,.17,.22,.1,'#f8edd2');ball(frog,x,1.93,.79,.08,.12,.035,'#3c4f3c');ball(frog,x,.3,.3,.4,.3,.8,'#739469');}
const drum=group(4,0,12);cyl(drum,0,1.1,0,1,1,2.2,'#faf0d9');cyl(drum,0,1.95,0,1.02,1.02,.45,'#cf795e');cyl(drum,0,2.2,0,1.05,1.05,.07,'#f3dbb2');for(let i=0;i<8;i++){let a=i*Math.PI/4;ball(drum,Math.cos(a)*1.01,1.05,Math.sin(a)*1.01,.075,.12,.075,'#597e99');}
for(const [x,z,c]of [[-3,-11.8,'#6fa6a1'],[-.8,-11.8,'#e6aa5d'],[1.5,-11.8,'#db866b']]){let g=group(x,.01,z);rounded(g,0,.5,0,1,.9,1,c,.08);let a=cyl(g,0,1.15,0,.56,.72,.45,c,4);a.rotation.y=Math.PI/4;}
// Loose sheets, a toy train and a glass mug: readable scale cues near the road.
function paper(x,z,angle){let p=box(scene,x,.05,z,1.4,.018,1.9,'#fff6df');p.rotation.y=angle;return p;}paper(-8,12,-.2);paper(-6.5,12.5,.2);paper(-5.2,12,.5);
const train=group(10,0,12.9);train.name="Toy train";rounded(train,0,.48,0,2.2,.8,1,'#65a09b',.1);box(train,.6,1.12,0,.75,.7,1,'#d78062');cyl(train,-.6,1.1,0,.14,.14,.7,'#5c6460');for(const x of [-.65,.65])for(const z of [-.57,.57]){let w=cyl(train,x,.27,z,.27,.27,.16,'#3e4d46');w.rotation.x=Math.PI/2;}
const mug=group(-1.5,-.02,-2.95);mug.name="Coffee mug";cyl(mug,0,3.36,0,.55,.45,1.02,'#f4e7ce');cyl(mug,0,3.88,0,.49,.49,.035,'#70523a');let handle=new T.Mesh(new T.TorusGeometry(.32,.09,8,20),mat('#f0dec0'));handle.position.set(.57,3.4,0);mug.add(handle);
// Static solid bounds are extracted from the actual scene, not a separate decorative map.
const staticBounds=[];scene.updateMatrixWorld(true);
scene.traverse(o=>{if(!o.isMesh||o.material.transparent)return;const b=new T.Box3().setFromObject(o);if(b.max.y<.09)return;staticBounds.push({minX:b.min.x,maxX:b.max.x,minY:b.min.y,maxY:b.max.y,minZ:b.min.z,maxZ:b.max.z,name:o.parent.name||'scenery'});});
// Closed cardboard ribbon, elevated over the table. Original spline geometry.
const points=[[-8,0.055,9],[2,0.055,9],[11,0.055,7.8],[14,0.055,5],[15,0.055,1],[14,0.055,-3],[11,0.055,-6],[6,0.055,-8],[-2,0.055,-8],[-5.5,0.055,-7],[-7,0.055,-5.3],[-7,0.8,-3.5],[-5.5,2.25,-1.8],[-3,2.9,-0.5],[2,2.9,0],[6,2.9,-0.1],[8.5,2.55,0.5],[10,1.5,2.3],[9.5,0.5,4.1],[7,0.055,5],[-1,0.055,4.5],[-9,0.055,3],[-12.5,0.055,3],[-14.6,0.055,3.9],[-15.5,0.055,6],[-14.6,0.055,8.1],[-12.5,0.055,9],[-10.5,0.055,9]];
const curve=new T.CatmullRomCurve3(points.map(p=>new V(...p)),true,'catmullrom',.5);curve.arcLengthDivisions=1400;const samples=[];let last=null,total=0;for(let i=0;i<=900;i++){let u=i/900,p=curve.getPointAt(u),t=curve.getTangentAt(u);p.y=Math.max(.055,Math.min(2.9,p.y));if(last)total+=p.distanceTo(last);samples.push({x:p.x,y:p.y,z:p.z,tx:t.x,tz:t.z,s:total,curve:0});last=p;}
for(let i=0;i<samples.length;i++){const a=samples[(i-2+900)%900],b=samples[(i+2)%900];let angle=Math.atan2(a.tx*b.tz-a.tz*b.tx,a.tx*b.tx+a.tz*b.tz);samples[i].curve=angle/(total/900*4);}LapRules.setup(samples,staticBounds);
function ribbon(offset,width,y,color){let pos=[],uv=[],idx=[];for(let i=0;i<samples.length;i++){let p=samples[i],l=Math.hypot(p.tx,p.tz),nx=p.tz/l,nz=-p.tx/l;for(let side of [-1,1]){let d=offset+side*width/2;pos.push(p.x+nx*d,p.y+y,p.z+nz*d);uv.push((side+1)/2,i/900*50);}}for(let i=0;i<900;i++){let a=i*2;idx.push(a,a+1,a+2,a+1,a+3,a+2);}let g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(pos,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.setIndex(idx);g.computeVertexNormals();let m=typeof color==='string'?mat(color):color;m.side=T.DoubleSide;let o=mesh(g,m,scene);o.receiveShadow=true;return o;}
ribbon(0,3.1,-.035,'#bba37c');ribbon(0,2.94,0,'#f1e6ca');ribbon(-1.48,.065,.015,'#cf8056');ribbon(1.48,.065,.015,'#cf8056');
function roadPoint(s,d=0,dy=0){let p=LapRules.at(s);return new V(p.x+p.tz*d,p.y+dy,p.z-p.tx*d);}
function roadBox(s,d,w,l,dy,col){let p=roadPoint(s,d,dy),t=LapRules.at(s);let o=box(scene,p.x,p.y,p.z,w,.018,l,col);o.rotation.y=Math.atan2(t.tx,t.tz);return o;}
for(let s=0;s<total;s+=2.1)roadBox(s,0,.055,.64,.027,'#cbb779');
// Start line and tape holding the cardboard down.
for(let row=0;row<2;row++)for(let c=0;c<10;c++)roadBox(2.9+row*.25,-1.35+c*.3,.3,.25,.038,(c+row)%2?'#fdf7e5':'#353a35');
for(let i=0;i<samples.length;i+=70){let p=samples[i];if(p.y<.4){roadBox(p.s,-1.49,.4,.85,.009,'#d8bb85');roadBox(p.s,1.49,.4,.85,.009,'#d1b381');}}
for(let s=total*.50;s<total*.68;s+=2.3){let p=LapRules.at(s);if(p.y>1)for(let d of [-1.24,1.24]){let q=roadPoint(s,d);box(scene,q.x,q.y/2-.06,q.z,.18,q.y-.1,.3,'#b09b79');}}
// Direction chevrons on straights; emissive boost arrows.
const boosts=[];for(const f of [.17,.42,.69,.87]){let s=total*f,g=new T.Group();scene.add(g);let p=roadPoint(s,0,.055);g.position.copy(p);let t=LapRules.at(s);g.rotation.y=Math.atan2(t.tx,t.tz);for(let i=0;i<3;i++){const sh=new T.Shape();sh.moveTo(-.75,-.25);sh.lineTo(0,.12);sh.lineTo(.75,-.25);sh.lineTo(.75,.05);sh.lineTo(0,.43);sh.lineTo(-.75,.05);sh.closePath();let a=new T.Mesh(new T.ShapeGeometry(sh),new T.MeshStandardMaterial({color:'#f4c857',emissive:'#e89d2a',emissiveIntensity:.23,side:T.DoubleSide}));a.rotation.x=Math.PI/2;a.position.z=i*.38-.4;g.add(a);}boosts.push(g);}
const gate=group(0,0,0);let gp=roadPoint(3.2);gate.position.copy(gp);let gt=LapRules.at(3.2);gate.rotation.y=Math.atan2(gt.tx,gt.tz);for(let x of [-1.95,1.95])cyl(gate,x,1.1,0,.065,.09,2.2,'#d79d48');box(gate,0,2.25,0,4.1,.38,.11,'#e4a444');for(let i=0;i<12;i++)box(gate,-1.86+i*.34,2.25,.065,.14,.39,.015,'#fff0cb');
// Car bodies: tiny die-cast racers, sidewall tyres, hubs, glass and coach lines.
const carColors=['#df9c35','#de6e58','#65a79d','#9478b1'];
function car(color,num){let root=new T.Group(),g=new T.Group();root.add(g);scene.add(root);const bodyMat=mat(color,.25,.24),ivory=mat('#fff0ce',.37,.1),glass=mat('#567775',.18,.32),chrome=mat('#b6b9aa',.24,.65);let body=rounded(g,0,.32,0,.7,.24,1.42,bodyMat,.13);rounded(g,0,.48,-.12,.61,.21,.78,bodyMat,.09);let cabin=rounded(g,0,.62,-.12,.48,.21,.49,glass,.07);for(let x of [-.27,.27])for(let z of [-.43,.45])ball(g,x,.38,z,.18,.11,.29,bodyMat);rounded(g,0,.745,-.13,.48,.035,.39,bodyMat,.025);box(g,0,.553,.45,.14,.015,.39,ivory);box(g,0,.564,-.61,.14,.016,.23,ivory);box(g,0,.766,-.13,.12,.016,.38,ivory);box(g,0,.31,.71,.43,.07,.025,chrome);box(g,0,.3,-.73,.48,.045,.03,chrome);rounded(g,0,.27,.731,.23,.06,.012,'#394b44',.009);
for(let x of [-.24,.24]){ball(g,x,.4,.654,.09,.055,.04,'#fff7c2');ball(g,x,.39,-.71,.09,.045,.023,'#a74232');}
let wheels=[];for(let x of [-.37,.37])for(let z of [-.44,.46]){let w=new T.Group();w.position.set(x,.205,z);g.add(w);let tire=cyl(w,0,0,0,.205,.205,.16,mat('#313935',.94),16);tire.rotation.z=Math.PI/2;let hub=cyl(w,x>0?.09:-.09,0,0,.122,.122,.012,chrome,12);hub.rotation.z=Math.PI/2;let hub2=cyl(w,x>0?.1:-.1,0,0,.048,.048,.016,'#5f6d65',10);hub2.rotation.z=Math.PI/2;for(let i=0;i<5;i++){let spoke=box(w,x>0?.102:-.102,Math.sin(i*TAU/5)*.06,Math.cos(i*TAU/5)*.06,.012,.025,.095,chrome);spoke.rotation.x=-i*TAU/5;}wheels.push(w);}
let badge=texture(64,64,(c)=>{c.fillStyle='#faf0d2';c.beginPath();c.arc(32,32,27,0,TAU);c.fill();c.fillStyle='#3f4e46';c.font='bold 36px Arial';c.textAlign='center';c.fillText(num,32,45);});let bm=new T.MeshBasicMaterial({map:badge,transparent:true});let bo=new T.Mesh(new T.PlaneGeometry(.24,.24),bm);bo.rotation.x=-Math.PI/2;bo.position.set(0,.572,.45);g.add(bo);
const shadow=texture(64,64,(c)=>{let gr=c.createRadialGradient(32,32,2,32,32,32);gr.addColorStop(0,'#30220b66');gr.addColorStop(1,'#30220b00');c.fillStyle=gr;c.fillRect(0,0,64,64);});let sh=new T.Mesh(new T.PlaneGeometry(1.4,1.9),new T.MeshBasicMaterial({map:shadow,transparent:true,depthWrite:false}));sh.rotation.x=-Math.PI/2;sh.position.y=.025;root.add(sh);
return{root,g,wheels,bodyMat,color,shadow:sh};}
const TAU=Math.PI*2;const cars=carColors.map((c,i)=>car(c,i+1));
const sparks=[],sparkGeo=new T.SphereGeometry(.045,4,3),sparkMat=[mat('#f6c55d'),mat('#76e7d2'),mat('#fff0b8')];for(let i=0;i<80;i++){let o=new T.Mesh(sparkGeo,sparkMat[i%3]);o.visible=false;scene.add(o);sparks.push({o,life:0,v:new V()});}
function burst(pos,amount=12,color=0){for(let i=0;i<amount;i++){let s=sparks.find(s=>s.life<=0);if(!s)break;s.o.material=sparkMat[color%3];s.o.position.copy(pos);s.o.visible=true;s.life=.35+Math.random()*.4;s.v.set((Math.random()-.5)*3,1+Math.random()*2,(Math.random()-.5)*3);}}
let trailCount=0;const trailGeo=new T.PlaneGeometry(.055,.25),trailMat=new T.MeshBasicMaterial({color:'#655e4b',transparent:true,opacity:.24,depthWrite:false}),trails=[];for(let i=0;i<100;i++){let t=new T.Mesh(trailGeo,trailMat);t.rotation.x=-Math.PI/2;t.visible=false;scene.add(t);trails.push(t);}
function pose(c,p,dt){const q=LapRules.body(p);c.root.position.set(q.x,q.y+.018,q.z);c.root.rotation.y=q.yaw;
const a=LapRules.at(p.s-.35),b=LapRules.at(p.s+.35),forward=LapRules.at(p.s),alignment=Math.cos(q.yaw-Math.atan2(forward.tx,forward.tz));
const pitch=-(p.offAge>0?0:Math.atan2(b.y-a.y,.7)*alignment);c.g.rotation.x=pitch;c.g.rotation.z=0;c.g.position.y=0;
// Raise the chassis by the minimum needed to keep both axles above the ribbon at crests.
if(!p.offAge){let lift=0;for(let z of [-.44,.46]){const offset=(z*Math.cos(pitch)+.205*Math.sin(pitch))*alignment,ground=LapRules.at(p.s+offset).y,slope=(LapRules.at(p.s+offset+.08).y-LapRules.at(p.s+offset-.08).y)/.16*alignment,center=.205*Math.cos(pitch)-z*Math.sin(pitch);lift=Math.max(lift,ground+.205*Math.sqrt(1+slope*slope)-q.y-center);}c.g.position.y=Math.max(0,lift);}
for(let w of c.wheels)w.rotation.x+=p.v*dt*4;
}
// Capture the complete room once for die-cast paint reflections.
const envTarget=new T.WebGLCubeRenderTarget(64,{generateMipmaps:true,minFilter:T.LinearMipmapLinearFilter});
const envCamera=new T.CubeCamera(.1,70,envTarget);envCamera.position.set(1,4,1);cars.forEach(c=>c.root.visible=false);envCamera.update(renderer,scene);cars.forEach(c=>c.root.visible=true);
const pmrem=new T.PMREMGenerator(renderer),env=pmrem.fromCubemap(envTarget.texture);scene.environment=env.texture;Object.values(mats).forEach(m=>m.envMapIntensity=.12);cars.forEach(c=>c.bodyMat.envMapIntensity=.65);envTarget.dispose();pmrem.dispose();
function cameraSafe(origin,desired){
const out=desired.clone(),dir=new V(),radius=.23;let length=out.distanceTo(origin),limit=length;
if(length<.001)return out;dir.copy(out).sub(origin).divideScalar(length);
for(const b of staticBounds){let enter=0,leave=limit;for(const [key,lo,hi]of [['x',b.minX-radius,b.maxX+radius],['y',b.minY-radius,b.maxY+radius],['z',b.minZ-radius,b.maxZ+radius]]){let v=dir[key],p=origin[key];if(Math.abs(v)<1e-8){if(p<lo||p>hi){enter=Infinity;break;}}else{let a=(lo-p)/v,c=(hi-p)/v;if(a>c)[a,c]=[c,a];enter=Math.max(enter,a);leave=Math.min(leave,c);if(enter>leave)break;}}if(enter<=leave&&enter>=0&&enter<limit)limit=Math.max(.05,enter-.08);}
out.copy(origin).addScaledVector(dir,limit);out.y=Math.max(.35,out.y);return out;
}
function cameraArm(anchor,desired){let best=cameraSafe(anchor,desired);if(best.distanceTo(anchor)<2.2){for(const candidate of [desired.clone().add(new V(0,2.5,0)),new V(anchor.x,anchor.y+3,anchor.z)]){const safe=cameraSafe(anchor,candidate);if(safe.distanceTo(anchor)>best.distanceTo(anchor)+.15)best=safe;}}return best;}
let follow=new V(),look=new V(),lastTime=0,low=false,camMode='follow',introTime=0;
function parkingPose(i){return{s:7+i*2,d:-6,v:0};}
function render(r,dt,menu=false){introTime+=dt;for(let i=0;i<4;i++){let p=i===0?r.p:r.ai[i-1];cars[i].root.visible=i===0||r.mode==='race';if(i&&p.finished)p=parkingPose(i-1);pose(cars[i],p,r.finished?0:dt);}
const pp=cars[0].root.position;let a=LapRules.at(r.p.s);if(r.p.yaw!==undefined){a.tx=Math.sin(r.p.yaw);a.tz=Math.cos(r.p.yaw);}let portrait=innerHeight>innerWidth;
let desired,target;
if(menu){const s=LapRules.length*.56+Math.sin(introTime*.07)*4;let q=roadPoint(s);desired=new V(q.x+9+Math.sin(introTime*.11)*2,8.9,q.z+13);target=new V(q.x*.42,1.3,q.z*.35);}
else{const distance=portrait?4.5:4.35;desired=new V(pp.x-a.tx*distance,pp.y+(portrait?2.6:1.85)+r.p.v*.015,pp.z-a.tz*distance);target=new V(pp.x+a.tx*2.8,pp.y+.5,pp.z+a.tz*2.8);}
if(!menu)desired=cameraArm(new V(pp.x,pp.y+.65,pp.z),desired);
const k=1-Math.exp(-dt*(menu?2:7));if(!lastTime){follow.copy(desired);look.copy(target);}else{follow.lerp(desired,k);look.lerp(target,k);}if(!menu){const anchor=new V(pp.x,pp.y+.65,pp.z);follow.copy(cameraSafe(anchor,follow));}camera.position.copy(follow);camera.lookAt(look);const fov=menu?48:portrait?68:58+(r.p.boost>0?5:0);camera.fov=Util.interpolate(camera.fov,fov,1-Math.exp(-dt*4));camera.updateProjectionMatrix();lastTime=1;
if(!menu&&r.state==='race'&&r.p.lastDrift&&Math.abs(r.p.slip)>.12&&r.p.v>3){let t=trails[(trailCount++)%trails.length];t.position.copy(roadPoint(r.p.s-.45,r.p.d+.28,.042));t.rotation.z=-Math.atan2(a.tx,a.tz);t.visible=true;if(trailCount%3===0)burst(roadPoint(r.p.s-.5,r.p.d,.12),1,r.p.charge>.7?0:1);}
for(let s of sparks)if(s.life>0){s.life-=dt;s.v.y-=6*dt;s.o.position.addScaledVector(s.v,dt);s.o.scale.setScalar(Math.max(.1,s.life*1.7));if(s.life<=0)s.o.visible=false;}
duckie.rotation.z=Math.sin(introTime*.8)*.012;
for(let i=0;i<boosts.length;i++){let available=r.pickups[i].cool<=0;boosts[i].visible=available;boosts[i].children.forEach((m,j)=>{m.material.emissiveIntensity=.17+Math.sin(introTime*5-j)*.1;});}
renderer.render(scene,camera);
}
function resize(quality){low=quality==='low'||(quality==='auto'&&(innerWidth<700||matchMedia('(pointer:coarse)').matches));renderer.setPixelRatio(low?1:Math.min(devicePixelRatio,1.65));renderer.setSize(innerWidth,innerHeight,false);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();sun.castShadow=!low;}
function color(hex){cars[0].bodyMat.color.set(hex);}
return{scene,renderer,camera,samples,staticBounds,cameraSafe,parkingPose,cars,resize,render,color,burst,roadPoint,resetCamera(){lastTime=0;},clearTrails(){trails.forEach(t=>t.visible=false);},get low(){return low;}};
};
