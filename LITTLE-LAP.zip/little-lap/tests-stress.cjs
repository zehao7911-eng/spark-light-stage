const assert=require('assert'),{world,R}=require('./audit-lap-scene.cjs');let checks=0;
for(let scenario=0;scenario<10;scenario++){let r=R.newRace('trial',false);r.state='race';r.p.s=R.length*scenario/10;
for(let i=0;i<600;i++){let cycle=i%180;R.tick(r,{gas:true,left:scenario%2===0&&cycle<100,right:scenario%2===1&&cycle<100,drift:cycle>40&&cycle<110},1/30);
for(const b of world.staticBounds){let hit=R.solidContact(r.p,b);assert(!hit||hit.depth<.02,`manual solid penetration in ${scenario} at ${i}: ${hit?.depth}`);}checks++;}
R.reset(r);const before=R.body(r.p);for(let i=0;i<60;i++)R.tick(r,{gas:true},1/60);assert(Math.hypot(R.body(r.p).x-before.x,R.body(r.p).z-before.z)>.15,'manual reset must resume');}
console.log('PASS',checks,'manual off-road/drift/static-collision stress frames');
