/* Little Lap simulation. Jake Gordon's MIT Util is used for racing math. */
(function(root){'use strict';
const clamp=Util.limit,HW=.47,HL=.82,finishS=3;
let path=[],length=1,obstacles=[];
function setup(samples,solids=[]){path=samples;length=samples[samples.length-1].s;obstacles=solids;}
function at(s){s=Util.increase(s,0,length);let lo=0,hi=path.length-1;while(hi-lo>1){let m=(lo+hi)>>1;if(path[m].s>s)hi=m;else lo=m;}const a=path[lo],b=path[hi],f=(s-a.s)/(b.s-a.s||1),tx=Util.interpolate(a.tx,b.tx,f),tz=Util.interpolate(a.tz,b.tz,f),n=Math.hypot(tx,tz);return{x:Util.interpolate(a.x,b.x,f),y:Util.interpolate(a.y,b.y,f),z:Util.interpolate(a.z,b.z,f),tx:tx/n,tz:tz/n,curve:Util.interpolate(a.curve,b.curve,f)};}
function body(p){let a=at(p.s),manual=p.x!==undefined;return{x:manual?p.x:a.x+a.tz*p.d,y:manual?p.y:a.y,z:manual?p.z:a.z-a.tx*p.d,yaw:(manual?p.yaw:Math.atan2(a.tx,a.tz))+(p.slip||0),hw:HW,hl:HL};}
function boxBody(b){return{x:(b.minX+b.maxX)/2,z:(b.minZ+b.maxZ)/2,yaw:0,hw:(b.maxX-b.minX)/2,hl:(b.maxZ-b.minZ)/2};}
// Separating-axis test for actual oriented car footprints. Returns a minimum separation vector.
function contact(a,b){if(Math.abs(a.x-b.x)>a.hw+a.hl+b.hw+b.hl||Math.abs(a.z-b.z)>a.hw+a.hl+b.hw+b.hl)return null;
const ar=[Math.cos(a.yaw),-Math.sin(a.yaw)],af=[Math.sin(a.yaw),Math.cos(a.yaw)],br=[Math.cos(b.yaw),-Math.sin(b.yaw)],bf=[Math.sin(b.yaw),Math.cos(b.yaw)];let depth=Infinity,nx=0,nz=0;
for(const axis of [ar,af,br,bf]){let d=(a.x-b.x)*axis[0]+(a.z-b.z)*axis[1],ra=a.hw*Math.abs(ar[0]*axis[0]+ar[1]*axis[1])+a.hl*Math.abs(af[0]*axis[0]+af[1]*axis[1]),rb=b.hw*Math.abs(br[0]*axis[0]+br[1]*axis[1])+b.hl*Math.abs(bf[0]*axis[0]+bf[1]*axis[1]),overlap=ra+rb-Math.abs(d);if(overlap<=.00001)return null;if(overlap<depth){depth=overlap;const sign=d<0?-1:1;nx=axis[0]*sign;nz=axis[1]*sign;}}
return{depth,nx,nz};}
function solidContact(p,b){const a=body(p);if(b.maxY<=a.y+.025||b.minY>=a.y+.88)return null;if(a.x+1.05<b.minX||a.x-1.05>b.maxX||a.z+1.05<b.minZ||a.z-1.05>b.maxZ)return null;return contact(a,boxBody(b));}
function emit(r,type,value){r.events.push({type,value});if(r.events.length>40)r.events.shift();}
function newRace(mode='race',assist=true){const r={state:'countdown',countdown:3.8,time:0,completedLaps:0,lapStart:0,lapTimes:[],finished:false,mode,assist,events:[],drifts:0,boosts:0,hits:0,finishRank:0,resetCount:0,p:{s:0,d:-.62,v:0,dv:0,slip:0,charge:0,boost:0,bump:0,lastDrift:false},ai:[{s:2.2,d:.63,v:0,skill:6.85},{s:2.2,d:-.63,v:0,skill:7.15},{s:0,d:.63,v:0,skill:6.55}],pickups:[.17,.42,.69,.87].map(f=>({s:length*f,d:0,cool:0})),rank:4};collide(r);return r;}
function shift(p,dx,dz,manual){if(manual){p.x+=dx;p.z+=dz;}else{const a=at(p.s);p.s=Math.max(0,p.s+dx*a.tx+dz*a.tz);p.d+=dx*a.tz-dz*a.tx;}}
function lane(p){const a=at(p.s),slip=p.slip||0,limit=Math.max(.5,1.47-HW*Math.abs(Math.cos(slip))-HL*Math.abs(Math.sin(slip))-.04-Math.abs(a.curve)*.24);return limit;}
function reset(r){const p=r.p,base=p.safeS===undefined?p.s:p.safeS;let chosen={s:Math.max(0,base-1.5),d:0};
search:for(const ds of [0,-1.9,-3.8,-5.7])for(const d of [0,-.65,.65]){const candidate={s:Math.max(0,base+ds),d};if(obstacles.some(b=>solidContact(candidate,b)))continue;const cb=body(candidate);if(r.mode==='race'&&r.ai.some(a=>!a.finished&&Math.abs(body(a).y-cb.y)<.9&&contact(cb,body(a))))continue;chosen=candidate;break search;}
Object.assign(p,chosen,{dv:0,v:0,charge:0,slip:0,boost:0,bump:.5,lastDrift:false,offAge:0});delete p.x;delete p.y;delete p.z;delete p.yaw;
if(!r.assist){const a=at(p.s);p.x=a.x+a.tz*p.d;p.z=a.z-a.tx*p.d;p.y=a.y;p.yaw=Math.atan2(a.tx,a.tz);}p.safeS=p.s;r.resetCount++;emit(r,'reset',0);}
function reproject(p){let nearest=path[0],distance=Infinity;for(const a of path){const d=(a.x-p.x)**2+(a.z-p.z)**2;if(d<distance){distance=d;nearest=a;}}
let diff=nearest.s-Util.increase(p.s,0,length);if(diff>length/2)diff-=length;if(diff<-length/2)diff+=length;if(Math.abs(diff)<2.5)p.s=Math.max(0,p.s+diff);const a=at(p.s);p.d=(p.x-a.x)*a.tz-(p.z-a.z)*a.tx;return{a,distance};}
function collide(r){const list=[r.p,...(r.mode==='race'?r.ai.filter(a=>!a.finished):[])];
// Alternating edge/static/car constraints prevents a side impact from pushing another car into scenery.
for(let pass=0;pass<12;pass++){let changed=false;
for(const p of list){const manual=p===r.p&&!r.assist;if(!manual){const bound=lane(p);if(Math.abs(p.d)>bound){p.d=Math.sign(p.d)*bound;p.dv=0;changed=true;if(p===r.p&&p.bump<=0){p.v*=.82;p.bump=.5;r.hits++;emit(r,'hit',0);}}}
for(const b of obstacles){const hit=solidContact(p,b);if(!hit)continue;shift(p,hit.nx*(hit.depth+.001),hit.nz*(hit.depth+.001),manual);changed=true;if(p.bump<=0){p.v*=.5;p.bump=.5;if(p===r.p){r.hits++;emit(r,'hit',0);}}}}
for(let i=0;i<list.length;i++)for(let j=i+1;j<list.length;j++){const p=list[i],q=list[j],a=body(p),b=body(q);if(Math.abs(a.y-b.y)>.9)continue;const hit=contact(a,b);if(!hit)continue;const delta=(hit.depth+.001)*.5;shift(p,hit.nx*delta,hit.nz*delta,p===r.p&&!r.assist);shift(q,-hit.nx*delta,-hit.nz*delta,q===r.p&&!r.assist);changed=true;
if(pass===0){const v=(p.v+q.v)*.5;p.v=Math.min(p.v,v+.1);q.v=Math.min(q.v,v+.1);if((p===r.p||q===r.p)&&r.p.bump<=0){r.p.bump=.35;emit(r,'bump',0);}}}
if(!changed)break;}
if(!r.assist&&r.p.x!==undefined)reproject(r.p);
// Compound prop corners can trap an iterative solver. Recover to an inspected clear pose,
// never leave a car embedded in a solid at the end of a frame.
for(const p of list){if(!obstacles.some(b=>{const h=solidContact(p,b);return h&&h.depth>.006;}))continue;
if(p===r.p){reset(r);emit(r,'offroad',0);}else{
let found=false;for(const ds of [-1.8,-3.6,-5.4,-7.2]){for(const d of [0,-.65,.65]){const c={s:Math.max(0,p.s+ds),d};if(obstacles.some(b=>solidContact(c,b)))continue;if(list.some(q=>q!==p&&Math.abs(body(q).y-body(c).y)<.9&&contact(body(c),body(q))))continue;Object.assign(p,c,{v:0});found=true;break;}if(found)break;}
}}
}
function tick(r,input,dt){dt=clamp(dt,0,.04);if(r.state==='paused'||r.finished)return;
for(const o of r.pickups)o.cool=Math.max(0,o.cool-dt);
if(r.state==='countdown'){const was=Math.ceil(r.countdown);r.countdown-=dt;if(Math.ceil(r.countdown)!==was)emit(r,'count',Math.ceil(r.countdown));if(r.countdown<=0){r.state='race';emit(r,'go',0);}return;}
const p=r.p,prevS=p.s,geo=at(p.s);r.time+=dt;const steer=(input.right?1:0)-(input.left?1:0),drift=!!input.drift&&p.v>2.3;
if(!drift&&p.lastDrift){if(p.charge>.23){p.boost=Math.max(p.boost,p.charge>.78?1.65:p.charge>.43?1.05:.6);r.boosts++;emit(r,'boost',p.charge);}p.charge=0;}
p.lastDrift=drift;if(drift&&steer)p.charge=clamp(p.charge+dt*.43,0,1);else if(drift)p.charge=Math.max(0,p.charge-dt*.05);
p.slip=Util.interpolate(p.slip,drift?steer*.36:steer*.08,1-Math.exp(-dt*7));const spring=r.assist&&!steer?-.9*p.d:0,centrifugal=clamp(-geo.curve*p.v*p.v*.11,-1.7,1.7);
p.dv=Util.interpolate(p.dv,steer*(drift?2.5:3.6)+spring+centrifugal,1-Math.exp(-dt*(drift?3.2:8)));if(r.assist)p.d+=p.dv*dt*Math.min(1,Math.abs(p.v)/2+.05);
let accel=input.gas?(p.boost>0?8.2:4.5):-2.1;if(input.brake)accel=p.v>0?-10:-3;if(Math.abs(p.d)>1.3&&p.v>3)accel-=5;
p.v=clamp(Util.accelerate(p.v,accel,dt),input.brake?-2:0,p.boost>0?11.2:8.5);if(drift)p.v=Math.max(0,p.v-.45*dt);p.boost=Math.max(0,p.boost-dt);p.bump=Math.max(0,p.bump-dt);
if(r.assist)p.s=Math.max(0,p.s+p.v*dt);else{
if(p.x===undefined){p.x=geo.x+geo.tz*p.d;p.z=geo.z-geo.tx*p.d;p.y=geo.y;p.yaw=Math.atan2(geo.tx,geo.tz);}
p.yaw+=steer*dt*(drift?1.8:1.34)*Math.min(1,Math.abs(p.v)/3)*(p.v<0?-1:1);p.x+=Math.sin(p.yaw-p.slip*.35)*p.v*dt;p.z+=Math.cos(p.yaw-p.slip*.35)*p.v*dt;
const projected=reproject(p),a=projected.a;if(Math.abs(p.d)<1.48&&projected.distance<3&&Math.abs(p.y-a.y)<.36){p.y=a.y;p.offAge=0;}else{
const oldY=p.y;p.offAge=(p.offAge||0)+dt;p.y=Math.max(.055,oldY-dt*3);for(const b of obstacles)if(p.x>b.minX-.25&&p.x<b.maxX+.25&&p.z>b.minZ-.25&&p.z<b.maxZ+.25&&oldY>=b.maxY-.025&&p.y<=b.maxY)p.y=Math.max(p.y,b.maxY+.015);
if(p.offAge>2.4){reset(r);emit(r,'offroad',0);}}
}
if(r.mode==='race')for(let i=0;i<r.ai.length;i++){const a=r.ai[i];if(a.finished)continue;const old=a.s,base=a.skill+(r.assist?0:.3);let desired=base+Math.sin(r.time*.6+i)*.26;
// Observe same-level traffic ahead. Brake instead of driving through a stopped rival.
for(const q of [p,...r.ai]){if(q===a||q.finished)continue;let diff=Util.increase(q.s-a.s,0,length);if(diff>0&&diff<2.6&&Math.abs(q.d-a.d)<.95&&Math.abs(body(q).y-body(a).y)<.9){desired=Math.min(desired,Math.max(0,q.v)+(diff>1.9?.2:-.4));}}
a.v=Util.interpolate(a.v,Math.max(0,desired),1-Math.exp(-dt*2.4));a.s+=a.v*dt;a.d=Util.interpolate(a.d,Math.sin(a.s*.12+i*2)*.64,dt*1.5);a.bump=Math.max(0,(a.bump||0)-dt);
if(a.s>=length*3+finishS){a.finishTime=r.time-dt*(a.s-length*3-finishS)/Math.max(.001,a.s-old);a.s=length*3+finishS;a.v=0;a.finished=true;}}
collide(r);
if(!p.offAge&&Math.abs(p.d)<1.1&&!obstacles.some(b=>solidContact(p,b)))p.safeS=p.s;
for(const o of r.pickups){const d=Util.increase(p.s-o.s,0,length);if(d<.85&&Math.abs(p.d)<1.05&&o.cool<=0){o.cool=8;p.boost=Math.max(p.boost,.65);emit(r,'pickup',o);}}
const lap=Math.max(0,Math.floor((p.s-finishS)/length));if(lap>r.completedLaps&&!p.offAge&&Math.abs(p.d)<1.47){r.lapTimes.push(r.time-r.lapStart);r.lapStart=r.time;r.completedLaps=lap;emit(r,'lap',lap);}
r.rank=r.mode==='race'?1+r.ai.filter(a=>a.finished||a.s>p.s).length:1;
if(r.completedLaps>=3){p.v=0;r.finished=true;r.state='finish';r.finishRank=r.rank;emit(r,'finish',r.rank);}
}
root.LapRules={setup,at,body,contact,solidContact,lane,newRace,tick,reset,finishS,get length(){return length;},get obstacles(){return obstacles;}};
})(typeof module!=='undefined'?module.exports:window);
