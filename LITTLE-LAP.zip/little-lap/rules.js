/* Little Lap simulation. Uses Jake Gordon's MIT-licensed Util at runtime. */
(function(root){
'use strict';
const clamp=Util.limit, TAU=Math.PI*2;
let path=[], length=1;
function setup(samples){path=samples;length=samples[samples.length-1].s;}
function at(s){s=Util.increase(s,0,length);let low=0,high=path.length-1;while(high-low>1){let m=(low+high)>>1;if(path[m].s>s)high=m;else low=m;}let a=path[low],b=path[high],f=(s-a.s)/(b.s-a.s||1);let tx=Util.interpolate(a.tx,b.tx,f),tz=Util.interpolate(a.tz,b.tz,f),l=Math.hypot(tx,tz);return{x:Util.interpolate(a.x,b.x,f),y:Util.interpolate(a.y,b.y,f),z:Util.interpolate(a.z,b.z,f),tx:tx/l,tz:tz/l,curve:Util.interpolate(a.curve,b.curve,f)};}
function newRace(mode='race',assist=true){return{state:'countdown',countdown:3.8,time:0,lapStart:0,lapTimes:[],finished:false,mode,assist,events:[],drifts:0,boosts:0,hits:0,finishRank:0,resetCount:0,p:{s:0,d:-.62,v:0,dv:0,slip:0,charge:0,boost:0,bump:0,lastDrift:false},ai:[{s:1.75,d:.63,v:0,skill:6.85},{s:1.75,d:-.63,v:0,skill:7.15},{s:0,d:.63,v:0,skill:6.55}],pickups:[{s:length*.17,d:-.65,cool:0},{s:length*.42,d:.65,cool:0},{s:length*.69,d:0,cool:0},{s:length*.87,d:-.65,cool:0}],rank:4};}
function emit(r,type,value){r.events.push({type,value});if(r.events.length>30)r.events.shift();}
function reset(r){const p=r.p;if(p.safeS!==undefined)p.s=p.safeS;const a=at(p.s);p.x=a.x;p.z=a.z;p.y=a.y;p.yaw=Math.atan2(a.tx,a.tz);p.offAge=0;p.d=0;p.dv=0;p.v=1;p.charge=0;p.slip=0;p.boost=0;r.resetCount++;emit(r,'reset',0);}
function tick(r,input,dt){dt=clamp(dt,0,.04);if(r.state==='paused'||r.finished)return;
for(const o of r.pickups)o.cool=Math.max(0,o.cool-dt);
if(r.state==='countdown'){const was=Math.ceil(r.countdown);r.countdown-=dt;if(Math.ceil(r.countdown)!==was)emit(r,'count',Math.ceil(r.countdown));if(r.countdown<=0){r.state='race';emit(r,'go',0);}return;}
const p=r.p,prevS=p.s;const geo=at(p.s);r.time+=dt;
const steer=clamp((input.right?1:0)-(input.left?1:0),-1,1),drift=!!input.drift&&p.v>2.3;
if(!drift&&p.lastDrift){if(p.charge>.23){const amount=p.charge>.78?1.65:p.charge>.43?1.05:.6;p.boost=Math.max(p.boost,amount);r.boosts++;emit(r,'boost',p.charge);}p.charge=0;}
p.lastDrift=drift;
if(drift&&steer){p.charge=clamp(p.charge+dt*.43,0,1);}else if(drift)p.charge=Math.max(0,p.charge-dt*.05);
const targetSlip=drift?steer*.42:steer*.1;p.slip=Util.interpolate(p.slip,targetSlip,1-Math.exp(-dt*7));
const spring=r.assist&&!steer?-.9*p.d:0;
const centrifugal=clamp(-geo.curve*p.v*p.v*.11,-1.7,1.7);
p.dv=Util.interpolate(p.dv,steer*(drift?2.7:3.8)+spring+centrifugal,1-Math.exp(-dt*(drift?3.2:8)));
if(r.assist)p.d+=p.dv*dt*Math.min(1,Math.abs(p.v)/2+.05);
const off=Math.abs(p.d)>1.22;
let accel=input.gas?(p.boost>0?8.2:4.5):-2.1;
if(input.brake)accel=p.v>0?-10:-3;
if(off&&p.v>3)accel-=5;
const max=p.boost>0?11.2:8.5;
p.v=clamp(Util.accelerate(p.v,accel,dt),input.brake?-2:0,max);
if(drift)p.v=Math.max(0,p.v-.45*dt);
p.boost=Math.max(0,p.boost-dt);p.bump=Math.max(0,p.bump-dt);
if(r.assist&&Math.abs(p.d)>1.6){p.d=Math.sign(p.d)*1.6;p.dv*=-.45;if(p.bump<=0){p.v*=.72;p.bump=.65;r.hits++;emit(r,'hit',0);}}
if(r.assist){p.s=Math.max(0,p.s+p.v*dt);}else{
if(p.x===undefined){p.x=geo.x+geo.tz*p.d;p.z=geo.z-geo.tx*p.d;p.y=geo.y;p.yaw=Math.atan2(geo.tx,geo.tz);}
p.yaw+=steer*dt*(drift?1.8:1.34)*Math.min(1,Math.abs(p.v)/3)*(p.v<0?-1:1);
p.x+=Math.sin(p.yaw-p.slip*.35)*p.v*dt;p.z+=Math.cos(p.yaw-p.slip*.35)*p.v*dt;
let nearest=path[0],distance=Infinity;for(let sample of path){let d=(sample.x-p.x)**2+(sample.z-p.z)**2;if(d<distance){distance=d;nearest=sample;}}
let diff=nearest.s-Util.increase(p.s,0,length);if(diff>length/2)diff-=length;if(diff<-length/2)diff+=length;
if(Math.abs(diff)<2.5)p.s=Math.max(0,p.s+diff);
p.d=(p.x-nearest.x)*nearest.tz-(p.z-nearest.z)*nearest.tx;
if(Math.abs(p.d)<1.5&&distance<3){p.y=nearest.y;p.offAge=0;p.safeS=p.s;}
else{p.offAge=(p.offAge||0)+dt;p.y=Math.max(.02,(p.y||0)-dt*3);if(p.offAge>2.4){reset(r);emit(r,'offroad',0);}}
}

if(r.mode==='race')for(let i=0;i<r.ai.length;i++){const a=r.ai[i];if(a.finished)continue;const base=a.skill+(r.assist?0:.3);const aim=base+Math.sin(r.time*.6+i)*.26;a.v=Util.interpolate(a.v,aim,1-Math.exp(-dt*1.7));a.s+=a.v*dt;if(a.s>=length*3){a.s=length*3;a.v=0;a.finished=true;a.finishTime=r.time;}a.d=Util.interpolate(a.d,Math.sin(a.s*.12+i*2)*.7,dt*1.5);
 if(Math.abs(a.s-p.s)<1.1&&Util.overlap(a.d,.61,p.d,.61,.9)&&p.bump<=0){const side=p.d>a.d?1:-1;p.dv+=side*2.2;p.v=Math.max(1,p.v-.8);p.bump=.55;a.d-=side*.22;emit(r,'bump',0);}}
for(const o of r.pickups){let d=Util.increase(p.s-o.s,0,length);if(d<.85&&Math.abs(p.d-o.d)<.6&&o.cool<=0){o.cool=8;p.boost=Math.max(p.boost,.65);emit(r,'pickup',o);}}
const oldLap=Math.floor(prevS/length),lap=Math.floor(p.s/length);
if(lap>oldLap){let elapsed=r.time-r.lapStart;r.lapTimes.push(elapsed);r.lapStart=r.time;emit(r,'lap',lap);}
r.rank=r.mode==='race'?1+r.ai.filter(a=>a.finished||a.s>p.s).length:1;
if(lap>=3){r.finished=true;r.state='finish';r.finishRank=r.rank;emit(r,'finish',r.rank);}
}
root.LapRules={setup,at,newRace,tick,reset,get length(){return length;}};
})(typeof module!=='undefined'?module.exports:window);
