GODZILLA: TINY TANTRUM
Unofficial fan mini-game. Godzilla belongs to TOHO CO., LTD.
Original procedural toy-city/monster models, code, animation and synthesized sound.
No extracted commercial game assets or music.

Drag anywhere on the city to move. Walking into buildings breaks them.
Tap a destination for an automatic stomp on arrival, or press STOMP to stomp now.
Orange fuel tanks cause nearby chain explosions. Blue power stations charge extra energy.
Six energy pips automatically trigger an aimed atomic breath. Clear every building to advance.
Build a chain by destroying more buildings within 2.5 seconds. No timer or lives.
Cities rotate layouts, building colours and sky palettes. Building count caps at 16.
Keyboard: arrows/WASD to move, Space to stomp, Escape to pause.
Pause/hidden tab/pointer cancellation stop movement safely without losing progress.
Completed-city progression, best chain and mute preference save locally when storage is available.
Blocked storage falls back to the current session. SAVE THE DAMAGE exports a PNG.

Open index.html directly or host the folder on any static HTML5 host.
All resources bundled. No network dependencies, build step, account or installation.
Three.js r147 is bundled under the accompanying MIT license.
Design reference: the short destruction/chain-reaction satisfaction of Instruments of Destruction.
This is an original compact fan mini-game, not a port or simulation of that game's full physics.
