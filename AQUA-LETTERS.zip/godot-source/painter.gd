extends Node2D
var game

func box(x,y,w,h,c): draw_rect(Rect2(floor(x),floor(y),w,h),Color('#'+c))
func line(a,b,c,w=1): draw_line(a,b,Color('#'+c),w)

func _process(_dt): queue_redraw()

func plant(x,y,height,kind):
	box(x-8,y,16,5,'415a51')
	for k in range(4):
		var stem=x-7+k*5
		var tip=y-height+(k%2)*12
		var sway=sin(game.time*1.3+x+k)*3
		line(Vector2(stem,y),Vector2(stem+sway,tip),'649b7e',2)
		for j in range(4):
			var yy=y-j*height/5.0-5
			var xx=stem+sway*j/4
			var c=['71a882','8bb79b','4c8977'][kind]
			box(xx-8,yy-4,8,3,c); box(xx-5,yy-7,5,4,c)
			box(xx+1,yy-10,7,3,c); box(xx+4,yy-13,4,4,c)

func rock(x,y,w,h):
	box(x-w/2,y-h+4,w,h-4,'456a70'); box(x-w/2+5,y-h,w-10,h,'5f8384')
	box(x-w/2+7,y-h+3,w-14,3,'91a39a'); box(x+w/2-6,y-h+9,5,h-9,'365a63')
	box(x-w/2-3,y,w+6,4,'b6ad88')
	for k in range(5):
		var xx=x-w/3+k*w/8
		var yy=y-h+8+(k%3)*4
		line(Vector2(xx,yy),Vector2(xx+4,yy+6),'769490',1)
		box(xx+2,yy+8,4,2,'496e75')

func draw_fish(f,index):
	var id=int(f.id)
	var scale_f=0.55+f.age*.8
	var color=game.COLORS[id]
	if f.variant==1: color='f4ce78'
	if f.variant==2: color='c4b9e8'
	draw_set_transform(Vector2(floor(f.x),floor(f.y*game.vertical)),0,Vector2(f.dir*scale_f,scale_f))
	var tail=sin(game.time*9+f.phase)*2
	# Species silhouettes: slim neon, high gourami, armored cory, disc reef fish,
	# translucent jelly and broad diamond ray; pixel details stay on the native grid.
	if id==10:
		box(-10,-10,20,8,'827fa2'); box(-13,-7,26,7,color); box(-10,0,20,4,'e1d2e5')
		for k in range(5):
			var xx=-8+k*4
			line(Vector2(xx,3),Vector2(xx+sin(game.time*3+k)*3,16+k%2*5),color,1)
		box(-5,-7,3,2,'f5edda'); box(4,-7,3,2,'f5edda')
	elif id==11:
		for y in range(-10,11): box(-14+abs(y),y,28-abs(y)*2,1,color)
		line(Vector2(-12,0),Vector2(-30,tail*3),'9db8c7',2)
		box(6,-4,2,2,'193b4a'); box(6,3,2,2,'193b4a'); box(-3,-2,4,4,'d8e4d9')
	elif id==16:
		box(0,-14,8,7,color); box(7,-11,7,3,color); box(-3,-7,8,15,color)
		box(-6,2,8,10,color); box(-4,12,7,3,color); box(2,9,3,5,color)
		box(-7,-5,3,5,'aa876b'); box(4,-12,2,2,'233c4a')
		for k in range(5): box(-2,-6+k*4,5,1,'f2dfae')
		box(-2,-18,3,4,color)
	else:
		var high=10 if id in [4,7,8] else (5 if id==2 else 7)
		if id in [14,15]: high=12
		var outline='294654'
		# Contoured row silhouette with a consistent dark, one-pixel edge.
		for row in range(-high,high+1):
			var inset=int(pow(absf(float(row)/high),2)*6)
			box(-14+inset,row,28-inset*2,1,outline)
			if abs(row)<high: box(-13+inset,row,26-inset*2,1,color)
		box(-8,-high+1,14,2,'f3dcc0'); box(-10,high-3,17,2,'ac7974' if id in [0,1,5,6,12] else '537991')
		for k in range(12):
			var sx=-8+(k%4)*4; var sy=-3+int(k/4)*3
			box(sx,sy,2,1,'edd3ac' if id in [0,5,12,17] else '9dc4c3')
		box(-19,-5+tail,5,10,color); box(-15,-3,4,6,color)
		box(-3,-high-5,7,5,color); box(-2,high,7,3,color)
		if id in [0,5]:
			box(-22,-7+tail,4,14,'d88e74'); box(-19,-5+tail,3,10,'e8bf7a')
		if id==1: box(-7,-5,3,10,'8a4c60'); box(0,-5,2,10,'8a4c60')
		if id==2: box(-11,-2,19,2,'96ece0'); box(-9,2,13,2,'dc6776')
		if id==3: box(-4,-6,5,11,'48606a'); box(6,-4,4,5,'48606a'); line(Vector2(11,4),Vector2(15,6),'dbcdb2')
		if id==4:
			box(-3,-4,3,3,'827b9d'); box(3,2,2,2,'827b9d'); line(Vector2(1,9),Vector2(-4,20+tail),'d4c9df')
		if id==6:
			for x in [-8,0,6]: box(x,-6,3,12,'f3e1c8'); box(x-1,-6,1,12,'72596c')
		if id==7: box(-8,-5,12,4,'3f5679'); box(-19,-5+tail,6,10,'e1c35e')
		if id==8: box(2,-8,3,16,'56656d'); box(-8,-3,3,3,'56656d')
		if id==9:
			for k in range(4): box(-10+k*4,-5+(k%2)*3,2,7,'de9565'); box(-8+k*4,-5,2,4,'7898ca')
		if id==12:
			box(5,-10,7,5,'d8866e'); box(8,-8,5,5,'dc9676')
			for k in range(3): line(Vector2(-13,k*3-3),Vector2(-26,tail*2+k*5-5),'e6b88e',2)
		if id==13:
			for k in range(7):
				line(Vector2(-10,k-3),Vector2(-27,tail+k*3-9),'9a8ec4',2)
			box(-7,-14,18,4,'a6a4d5'); box(-6,9,18,5,'c4a6d5')
		if id==14:
			box(-8,5,17,5,'e5dbb5')
			for k in range(8): box(-9+(k%4)*5,-6+int(k/4)*6,2,2,'6c7c72')
			for k in range(4): box(-10+k*6,-14,1,3,'ded6a3')
		if id==15:
			for k in range(5): line(Vector2(-9+k*4,-8),Vector2(-9+k*4,8),'5f8ca9',1)
			box(-5,-10,12,2,'c2d7cf')
		if id==17:
			box(-10,-5,7,5,'d78973'); box(1,0,8,4,'d78973'); box(0,-6,4,3,'546b78')
			line(Vector2(12,4),Vector2(17,7+tail),'e3cbb0',1)
		box(7,-4,3,3,'233c4a'); box(8,-4,1,1,'f5e6c4')
		box(10,1,2,2,'e6c9aa'); box(-2,1+sin(game.time*8+index),5,2,'ead3ae')
	if f.favorite: box(-1,-22,3,3,'e8afad'); box(-3,-20,7,2,'e8afad')
	if f.variant==2:
		var sx=sin(game.time*2+f.phase)*22
		var sy=cos(game.time*2+f.phase)*16
		box(sx-2,sy,5,1,'e8e0f4'); box(sx,sy-2,1,5,'e8e0f4')
	if index==game.selected:
		draw_rect(Rect2(-26,-26,52,52),Color('#e4dac0'),false,1)
		box(-20,23,40,2,'314c58'); box(-20,23,40*f.age,2,'edcb81')
	draw_set_transform(Vector2.ZERO,0,Vector2(1,game.vertical))

func _draw():
	var t=game.time
	draw_set_transform(Vector2.ZERO,0,Vector2(1,game.vertical))
	box(0,0,480,300,'19323b')
	box(0,0,480,31,'24414b'); box(0,29,480,2,'50646a')
	for i in range(12): box(i*43,0,1,28,'2d4b54')
	# Timber enclosure and brass corner hardware.
	box(17,32,446,226,'182f38'); box(21,35,438,218,'a18b72'); box(25,39,430,210,'d0b698')
	box(30,43,420,202,'385f6a')
	for y in range(44,243,4):
		var top=['#5d9b9c','#638fad','#807da7'][game.tank]
		var bottom=['#254856','#294768','#373b60'][game.tank]
		var c=Color(top).lerp(Color(bottom),float(y-44)/200)
		if game.night: c=c.darkened(.23)
		draw_rect(Rect2(31,y,418,4),c)
	for i in range(7):
		var x=48+i*61+sin(t*.2+i)*10
		draw_colored_polygon(PackedVector2Array([Vector2(x,45),Vector2(x+12,45),Vector2(x+65,229),Vector2(x+30,229)]),Color(0.72,0.89,0.80,.045 if game.night else .08))
	# Parallax reed silhouettes and algae, behind all fish.
	for i in range(24):
		var x=35+i*18
		line(Vector2(x,232),Vector2(x+sin(t*.6+i)*4,155+sin(i*9)*24),'406d72',3)
	if game.tank==1:
		for i in range(6):
			var x=74+i*61
			line(Vector2(x,233),Vector2(x-5,208),'bd8e89',4)
			line(Vector2(x-4,221),Vector2(x-14,211),'ca9b92',3)
			line(Vector2(x-3,218),Vector2(x+9,203),'ca9b92',3)
	elif game.tank==2:
		for i in range(9):
			var x=45+i*47
			box(x,224,3,10,'90a9bd'); box(x-3,220,8,5,'b7b8db'); box(x,217,3,3,'d4c9df')
	box(31,233,418,11,'c2b38f'); box(31,232,418,2,'ded0a6'); box(31,243,418,2,'827e6d')
	for i in range(150):
		var x=33+(i*47)%412; var y=235+(i*13)%8
		box(x,y,2 if i%3 else 3,1,['a4967c','d5c4a0','938f7b'][i%3])
	plant(63,233,108,0); plant(86,234,72,2); plant(409,233,117,1); plant(383,233,78,0)
	rock(114,234,48,26); rock(370,234,38,18)
	if game.decor==0:
		rock(293,233,64,40); rock(325,233,32,23)
		plant(318,233,67,2)
	elif game.decor==1:
		box(267,192,52,42,'9caa9b'); box(273,189,40,4,'c6c1a2'); box(276,199,34,35,'526e71'); box(281,205,24,29,'30545f')
		box(263,232,60,4,'c9b48e'); plant(315,233,62,0)
	else:
		box(261,224,75,10,'856d64'); box(270,215,57,10,'b68d72'); box(280,210,7,18,'cfaa83'); box(302,209,7,19,'cfaa83')
		box(276,204,37,6,'ddbc91'); plant(338,233,72,1)
	# Driftwood, shells and tiny snail.
	line(Vector2(155,232),Vector2(205,205),'7b7467',6); line(Vector2(182,217),Vector2(171,200),'7b7467',3)
	line(Vector2(157,230),Vector2(203,204),'b09d7f',2)
	for i in range(7): box(142+i*21,237+(i%2)*2,5,2,'e8cdb0')
	box(218+sin(t*.02)*20,237,6,3,'caa47c'); box(220+sin(t*.02)*20,234,4,4,'a7816e')
	for i in range(game.fish.size()):
		if int(game.fish[i].tank)==game.tank: draw_fish(game.fish[i],i)
	for pellet in game.food: box(pellet.x,pellet.y,2,2,'e8bc80')
	for p in game.fx: box(p.x,p.y,2,2,p.c)
	for i in range(22):
		var x=37+(i*73)%406+sin(t+i)*3
		var y=237-fmod(t*(5+i%5)+i*19,187)
		draw_rect(Rect2(floor(x),floor(y),2,3),Color('#8bb9ba'),false,1)
	# Glass highlights and surface shimmer.
	box(32,46,2,178,'9fbdb2'); box(35,47,1,56,'c4d7c5'); box(445,48,2,190,'779a9a')
	for i in range(16): box(37+i*26+sin(t+i)*3,46,14,1,'a2c7b9')
	for x in [23,451]:
		for y in [37,249]: box(x,y,4,3,'e6c994'); box(x+1,y+1,2,1,'806e59')
	box(20,258,440,7,'7c6c5f'); box(26,265,428,11,'b99a7c'); box(32,276,416,3,'4a4140')
	box(45,280,18,20,'826f61'); box(417,280,18,20,'826f61')
	box(209,260,62,5,'e5c69c'); box(226,261,28,1,'9b836b')
	# Feeder grows visibly with upgrades.
	if game.feeder>0:
		box(355,27,26,15,'dfcfb0'); box(358,29,20,9,'637d80'); box(365,39,6,9,'b6a28b')
		for i in range(game.feeder): box(360+i*5,32,3,3,'e6bf75')
	if game.night:
		box(193,33,94,3,'e7d0a2'); box(206,36,68,2,'b8bfaf')
