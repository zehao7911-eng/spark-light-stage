extends Node2D

const NAMES = ['Honey Guppy','Cherry Barb','Blue Neon','Panda Cory','Pearl Gourami','Sunset Platy','Clownfish','Royal Tang','Butterflyfish','Mandarin','Moon Jelly','Ribbon Ray','Oranda Goldfish','Silk Betta','Spotted Puffer','Blue Discus','Golden Seahorse','Celestial Koi']
const COLORS = ['e9b960','d87974','66c9c9','e6debc','c3b2d7','e89c6c','ec975a','7795d0','e4d584','74b7ae','c7b8e1','a6c4d4','e2a269','8e99ca','c5bf7b','89b5ce','e4c98e','ddd2b2']
var fish = []
var discovered = []
var coins = 65.0
var earned = 0.0
var sold = 0
var level = 0
var feeder = 0
var decor = 0
var night = false
var muted = false
var selected = -1
var food = []
var fx = []
var time = 0.0
var ticker = 0.0
var auto_clock = 0.0
var save_clock = 0.0
var feed_cooldown = 0.0
var event = 0
var notice = 'Tap the water to feed your fish.'
var recent = []
var packs_opened = 0
var tank = 0
var claims = []
var paused = true
var world: SubViewport
var origin = Vector2.ZERO
var zoom = 1.0
var callback
var holding_feed = false
var feed_position = Vector2(240,70)
var away_coins = 0.0
var away_seconds = 0.0
var vertical = 1.0

func _ready():
	world = SubViewport.new()
	world.size = Vector2i(480,300)
	world.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(world)
	var painter = Node2D.new()
	painter.set_script(preload('res://painter.gd'))
	painter.game = self
	world.add_child(painter)
	if not load_game():
		for id in [0,1,2,3,0,1]: add_fish(id,0,0.3)
	if OS.has_feature('web'):
		callback = JavaScriptBridge.create_callback(web_action)
		JavaScriptBridge.get_interface('window').aAction = callback
	if '--qa' in OS.get_cmdline_user_args(): verify()

func capacity(): return 12 + level*4
func tank_count(): return fish.filter(func(f):return int(f.tank)==tank).size()
func growth_time(id): return 35.0+id*6.0
func value(f): return int((16+int(f.id)*7)*(1+int(f.variant)*2))
func income():
	var result = 0.0
	for f in fish:
		if f.age>=1: result += (0.12+int(f.id)*0.025)*(1+int(f.variant))
	return result

func add_fish(id,variant=0,age=0.0):
	var f = {'id':id,'variant':variant,'age':age,'x':randf_range(90,390),'y':randf_range(80,220),'tx':randf_range(70,410),'ty':randf_range(65,230),'dir':1.0,'phase':randf()*6.28,'favorite':false,'tank':tank}
	fish.append(f)
	var key = str(id)+':'+str(variant)
	if not key in discovered: discovered.append(key)
	return f

func tell(message):
	notice=message
	event+=1

func pack(tier):
	var costs=[25,85,180]
	if tier<0 or tier>2: return
	if tier>level: tell('Expand your aquarium first.'); return
	if tank_count()+3>capacity(): tell('Make room for three little arrivals.'); return
	if coins<costs[tier]: tell('Grow fish, or collect viewing income.'); return
	coins-=costs[tier]
	recent=[]
	packs_opened+=1
	for i in range(3):
		var species_roll=randi_range(1,100)
		var species=0
		var cumulative=0
		for j in range(6):
			cumulative+=[30,24,18,14,9,5][j]
			if species_roll<=cumulative: species=j; break
		var id = tier*6+species
		var roll=randf()
		var variant = 2 if roll<0.025 else (1 if roll<0.175 else 0)
		# Every fifth pack guarantees the next missing species in this biome.
		if packs_opened%5==0:
			for j in range(tier*6,tier*6+6):
				if not str(j)+':0' in discovered: id=j; variant=0; break
		add_fish(id,variant)
		recent.append({'id':id,'variant':variant,'name':NAMES[id]})
		burst(Vector2(180+i*60,90),COLORS[id],12)
	tell('Three new lives. Welcome home!')
	save_game()

func feed_at(p):
	if feed_cooldown>0: return
	feed_cooldown=0.3
	for i in range(5):
		if food.size()<35: food.append({'x':clampf(p.x+randf_range(-18,18),36,444),'y':clampf(p.y,48,236),'life':9.0})
	burst(p,'d6f0df',6)

func burst(p,c,n):
	for i in range(n):
		if fx.size()<150: fx.append({'x':p.x,'y':p.y,'vx':randf_range(-30,30),'vy':randf_range(-35,-7),'life':randf_range(.4,1.1),'c':c})

func sell_fish(index):
	if index<0 or index>=fish.size(): return
	var f=fish[index]
	if f.age<1: tell('Still growing. Feed this little one.'); return
	if f.favorite: tell('A favourite stays with you. Unpin to sell.'); return
	var payout=value(f)
	coins+=payout
	earned+=payout
	sold+=1
	burst(Vector2(f.x,f.y),'f1d58f',18)
	fish.remove_at(index)
	selected=-1
	tell('A lovely new home. +'+str(payout))
	save_game()

func web_action(args):
	if args.size(): action(str(args[0]))

func action(cmd):
	var parts=cmd.split(':')
	var n=int(parts[1]) if parts.size()>1 else 0
	match parts[0]:
		'pack': pack(n)
		'tank': tank=(tank+1)%(level+1); selected=-1; food=[]; tell(['The freshwater room.','The reef room.','The moon room.'][tank]); save_game()
		'move':
			if selected>=0 and selected<fish.size() and level>0:
				var destination=(tank+1)%(level+1)
				if fish.filter(func(f):return int(f.tank)==destination).size()<capacity(): fish[selected].tank=destination; selected=-1; tell('Settled into the next room.'); save_game()
				else: tell('The next room is full. Rehome a grown fish first.')
		'feed': feed_at(Vector2(randf_range(100,380),70))
		'feedstart': holding_feed=true; feed_at(Vector2(randf_range(100,380),70))
		'feedstop': holding_feed=false
		'rescue':
			if fish.is_empty() and coins<25: add_fish(0); tell('A little rescue guppy. Food is free.'); save_game()
		'select': selected=n if n>=0 and n<fish.size() else -1
		'sell': sell_fish(selected)
		'favorite':
			if selected>=0 and selected<fish.size(): fish[selected].favorite=not fish[selected].favorite; save_game()
		'expand':
			if level<2:
				var cost=[140,420][level]
				if coins>=cost: coins-=cost; level+=1; tell('More room. A new fish pack is ready.'); save_game()
		'feeder':
			if feeder<3:
				var cost=60*(feeder+1)
				if coins>=cost: coins-=cost; feeder+=1; tell('A little help at feeding time.'); save_game()
		'decor': decor=(decor+1)%3; save_game()
		'light': night=not night; save_game()
		'sound': muted=not muted; save_game()
		'pause': paused=n==1; holding_feed=false
		'claim':
			var conditions=[discovered.size()>=4,sold>=5,level>=1,discovered.size()>=12,sold>=20,level>=2]
			if n>=0 and n<6 and conditions[n] and not n in claims:
				claims.append(n); coins+=[40,65,90,160,220,300][n]; tell('A new page in your aquarium story.'); save_game()
		'photo': photograph()
		'begin':
			paused=false
			if away_seconds>=60: tell('Welcome back. Your aquarium earned '+str(int(away_coins))+'.')

func _process(dt):
	var size=get_viewport_rect().size
	vertical=1.7 if size.x<600 and size.y>650 else 1.0
	var canvas_size=Vector2(480,300*vertical)
	if world.size!=Vector2i(canvas_size): world.size=Vector2i(canvas_size)
	var area_height=maxf(100,size.y-(245 if size.x<600 else 220))
	zoom=minf(size.x/480.0,area_height/canvas_size.y)
	origin=Vector2((size.x-480*zoom)/2,72+(area_height-canvas_size.y*zoom)/2)
	if not paused:
		time+=dt
		feed_cooldown=maxf(0,feed_cooldown-dt)
		if holding_feed: feed_at(feed_position)
		var cash=income()*dt
		coins+=cash
		earned+=cash
		for f in fish:
			var before=f.age
			f.age=minf(1,f.age+dt/growth_time(int(f.id)))
			if before<1 and f.age>=1: burst(Vector2(f.x,f.y),'f1d58f',14); tell(NAMES[int(f.id)]+' is all grown up!')
			var pos=Vector2(f.x,f.y)
			var target=Vector2(f.tx,f.ty)
			var nearest=-1
			var distance=9999.0
			for i in range(food.size() if int(f.tank)==tank else 0):
				var d=pos.distance_to(Vector2(food[i].x,food[i].y))
				if d<distance: distance=d; nearest=i
			if nearest>=0:
				target=Vector2(food[nearest].x,food[nearest].y)
				if distance<8:
					food.remove_at(nearest)
					var age_before_food=f.age
					f.age=minf(1,f.age+.055)
					burst(pos,'f3c78a',3)
					if age_before_food<1 and f.age>=1: burst(pos,'f1d58f',14); tell(NAMES[int(f.id)]+' is all grown up!')
			elif pos.distance_to(target)<6: f.tx=randf_range(55,425); f.ty=randf_range(65,224)
			var velocity=pos.direction_to(target)*(25+int(f.id)*1.6)*(1.7 if nearest>=0 else 1.0)
			pos+=velocity*dt
			f.x=clampf(pos.x,38,442); f.y=clampf(pos.y,50,239)
			if absf(velocity.x)>1: f.dir=1.0 if velocity.x>0 else -1.0
		for pellet in food: pellet.y=minf(238,pellet.y+dt*5); pellet.life-=dt
		food=food.filter(func(p):return p.life>0)
		for p in fx: p.x+=p.vx*dt; p.y+=p.vy*dt; p.life-=dt
		fx=fx.filter(func(p):return p.life>0)
		auto_clock+=dt
		if feeder>0 and auto_clock>9.0/feeder: auto_clock=0; feed_at(Vector2(randf_range(100,380),60))
		save_clock+=dt
		if save_clock>4: save_clock=0; save_game()
	ticker+=dt
	if ticker>.2:
		ticker=0
		if OS.has_feature('web'): JavaScriptBridge.eval('window.aState && window.aState('+JSON.stringify(snapshot())+');')
	queue_redraw()

func _draw():
	draw_rect(get_viewport_rect(),Color('#102c36'))
	if world: draw_texture_rect(world.get_texture(),Rect2(origin,Vector2(world.size)*zoom),false)

func _unhandled_input(e):
	if paused: return
	if e is InputEventMouseButton and e.button_index==MOUSE_BUTTON_LEFT and not e.pressed: holding_feed=false
	if e is InputEventMouseButton and e.button_index==MOUSE_BUTTON_LEFT and e.pressed:
		var p=(e.position-origin)/zoom
		p.y/=vertical
		if p.x<30 or p.x>450 or p.y<40 or p.y>245: return
		var best=18.0
		var hit=-1
		for i in range(fish.size()):
			if int(fish[i].tank)!=tank: continue
			var d=p.distance_to(Vector2(fish[i].x,fish[i].y))
			if d<best: best=d; hit=i
		if hit>=0: selected=hit
		else: feed_position=p; holding_feed=true; feed_at(p)
	if e is InputEventMouseMotion and holding_feed:
		var p=(e.position-origin)/zoom
		p.y/=vertical
		feed_position=Vector2(clampf(p.x,36,444),clampf(p.y,48,236))

func snapshot():
	var list=[]
	for f in fish: list.append({'name':NAMES[int(f.id)],'id':f.id,'age':f.age,'variant':f.variant,'favorite':f.favorite,'value':value(f),'tank':f.tank,'index':list.size()})
	return {'coins':int(coins),'income':income(),'count':tank_count(),'total':fish.size(),'tank':tank,'packs':packs_opened,'capacity':capacity(),'level':level,'feeder':feeder,'decor':decor,'night':night,'muted':muted,'selected':selected,'fish':list,'discovered':discovered,'sold':sold,'claims':claims,'event':event,'notice':notice,'recent':recent,'view':{'x':origin.x,'y':origin.y,'zoom':zoom},'paused':paused}

func save_game():
	var data=JSON.stringify({'saved_at':Time.get_unix_time_from_system(),'tank':tank,'packs_opened':packs_opened,'coins':coins,'earned':earned,'sold':sold,'level':level,'feeder':feeder,'decor':decor,'night':night,'muted':muted,'fish':fish,'discovered':discovered,'claims':claims})
	var file=FileAccess.open('user://aqua-letters.json',FileAccess.WRITE)
	if file: file.store_string(data)
	if OS.has_feature('web'): JavaScriptBridge.eval('try{localStorage.setItem("aqua-letters.v1",'+JSON.stringify(data)+')}catch(e){}')

func load_game():
	var data=''
	if OS.has_feature('web'): data=str(JavaScriptBridge.eval('(function(){try{return localStorage.getItem("aqua-letters.v1") || ""}catch(e){return ""}})()'))
	elif FileAccess.file_exists('user://aqua-letters.json'): data=FileAccess.get_file_as_string('user://aqua-letters.json')
	if data.is_empty(): return false
	var s=JSON.parse_string(data)
	if not s is Dictionary or not s.get('fish') is Array: return false
	coins=clampf(float(s.get('coins',65)),0,99999999)
	earned=maxf(0,float(s.get('earned',0))); sold=clampi(int(s.get('sold',0)),0,999999)
	level=clampi(int(s.get('level',0)),0,2); feeder=clampi(int(s.get('feeder',0)),0,3); decor=clampi(int(s.get('decor',0)),0,2)
	tank=clampi(int(s.get('tank',0)),0,level); packs_opened=maxi(0,int(s.get('packs_opened',0)))
	night=bool(s.get('night',false)); muted=bool(s.get('muted',false))
	discovered=s.get('discovered',[]) if s.get('discovered',[]) is Array else []
	claims=s.get('claims',[]) if s.get('claims',[]) is Array else []
	for f in s.fish:
		if not f is Dictionary or fish.size()>=capacity()*(level+1): continue
		var id=clampi(int(f.get('id',0)),0,17)
		var added=add_fish(id,clampi(int(f.get('variant',0)),0,2),clampf(float(f.get('age',0)),0,1))
		added.favorite=bool(f.get('favorite',false)); added.tank=clampi(int(f.get('tank',0)),0,level)
		for key in ['x','y','tx','ty','dir','phase']:
			if f.get(key) is float or f.get(key) is int: added[key]=float(f[key])
		added.x=clampf(added.x,38,442); added.y=clampf(added.y,50,239)
		added.tx=clampf(added.tx,55,425); added.ty=clampf(added.ty,65,230)
	away_seconds=clampf(Time.get_unix_time_from_system()-float(s.get('saved_at',Time.get_unix_time_from_system())),0,28800)
	away_coins=0
	if away_seconds>=5:
		for f in fish:
			var grow_seconds=(1.0-float(f.age))*growth_time(int(f.id))
			var paid_seconds=maxf(0,away_seconds-grow_seconds)
			away_coins+=paid_seconds*(.12+int(f.id)*.025)*(1+int(f.variant))
			f.age=minf(1,f.age+away_seconds/growth_time(int(f.id)))
		coins+=away_coins; earned+=away_coins
		# Commit the catch-up timestamp, so refreshing cannot collect it twice.
		save_game()
	return true

func photograph():
	await RenderingServer.frame_post_draw
	var data=Marshalls.raw_to_base64(world.get_texture().get_image().save_png_to_buffer())
	if OS.has_feature('web'): JavaScriptBridge.eval('window.aPhoto('+JSON.stringify(data)+')')

func verify():
	fish=[]; discovered=[]; coins=2000; level=2; claims=[]; sold=0
	pack(0); assert(fish.size()==3 and coins==1975)
	var f=fish[0]; f.age=1; f.favorite=true
	sell_fish(0); assert(fish.size()==3)
	f.favorite=false; var old=coins; var payout=value(f); sell_fish(0)
	assert(fish.size()==2 and coins==old+payout and sold==1)
	for i in range(12): add_fish(i,0,1)
	assert(income()>2 and discovered.size()>=12)
	action('claim:3'); old=coins; action('claim:3'); assert(coins==old)
	while tank_count()<capacity(): add_fish(0)
	old=coins; pack(0); assert(coins==old and fish.size()==capacity())
	fish=[]; coins=0; pack(0); assert(fish.is_empty())
	print('AQUA QA PASS: economy, packs, favourites, capacity, collection, income, reward-once')
	get_tree().quit()
