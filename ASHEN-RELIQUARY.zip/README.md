# Ashen Reliquary

A Godot 4.7.2 single-player 2.5D horde-survival game inspired by Halls of Torment's movement-first combat, build choices and persistent relic recovery. It uses original locally constructed 3D meshes, original stone and icon artwork, synthesized audio, and a smaller independently implemented scope. No commercial game screenshots or game assets are packaged.

## Play
Move with WASD/arrows or the touch stick. Weapons attack automatically. Space/DASH gives a brief invulnerable dash; E/BURST damages and knocks back a nearby crowd. Pick up blue souls to level up, then choose one of three powers. Tap cards or use 1/2/3 to select. Pause with Escape or II. Sound unlocks after interaction.

The Knight starts with an arc-shaped sword attack. The Ranger starts with piercing arrow volleys. Recover a relic to unlock the Warlock, who starts with fire nova and chain lightning. You can add and upgrade five weapon types plus five support traits, up to rank six. Damage, haste, vitality, pickup reach and regeneration change the build.

Lords arrive at 1:05, 2:20 and 3:45. Their circles warn before ground attacks. Defeated Lords drop purple relics: pick one up and carry it to the well before you fall. R/SECURE RELIC retrieves it. Retrieved relics permanently grant regeneration, damage, arrow piercing, pickup range, shorter burst cooldown or health. Bosses progress through the six relic rewards during continued descents. Gold is banked when you die, retire or defeat the third Lord; spend it at the Shrine on capped permanent Might, Health and Fortune blessings. Banking is idempotent. Endless continuation resets unbanked gold and resumes the current build, with another Lord every 80 seconds. A character can be changed between descents.

## Package and editing
`web/` contains the real single-thread Godot HTML5/WebGL 2 export. Serve the entire folder over HTTP/HTTPS. Opening index.html as a file URL is unsupported. There are no CDN dependencies, shared-memory requirements, accounts or external asset servers.
`godot/` contains project.godot, editable World.tscn preview, GDScript sources, shaders, individual PNG artwork and audio. Open project.godot in Godot 4.7.2 and press F5/F6. Install matching export templates to re-export. In this archive, set the Web export path to ../web/index.html; the local development layout uses ../ashen-reliquary-web/index.html.

World.gd generates the gameplay scene and Art.gd creates cached merged character meshes. World.tscn includes an editable EditorPreview removed at runtime. Bake.gd rebuilds that preview. Grade.gdshader supplies a restrained pixel filter and vignette before the responsive HUD. Actor.gdshader shades the original character meshes. Artwork generation source is included in art/create_art.py.

## Performance and persistence
30 FPS cap; at most 80 ordinary enemies (84 with reserved boss slots), 130 loose drops, 48 projectiles, 10 telegraphed hazards and 100 short effects. Characters share four cached pose meshes per type. Touch supports moving and activating a skill simultaneously. Portrait and landscape are supported; shadows and sound can be disabled from pause. Backgrounding pauses the descent. Local browser storage preserves the active build, foes, loot, pending choices, gold and permanent profile. Clearing browser storage clears the save.

## Validation
37 headless logic checks passed, including weapon collisions, dash immunity, cooldowns, damage immunity, relic retrieval, purchases, pool limits, timed Lords, victory, endless continuation and duplicate bank protection. Browser runs at 1280×800, 390×844, 844×390 and 768×1024 verified simultaneous touch movement/dash, burst, control bounds, help, shrine and save reload without page errors. A normal fresh browser run reached level four through 55 kills, chose lightning/nova/orbs, restored its save, and banked 17 gold. Physical phone GPU performance has not been measured. WebGL 2 and WebAssembly are required.

Godot's license is included in GODOT-LICENSE.txt. Cinzel's OFL license is included in art/CINZEL-OFL.txt.
