from PIL import Image,ImageDraw,ImageFilter
from pathlib import Path
import random,math
random.seed(23);out=Path(__file__).resolve().parent
im=Image.new('RGB',(128,128));pix=im.load()
for y in range(128):
 for x in range(128):
  n=random.randrange(-7,8);pix[x,y]=(max(0,34+n),max(0,38+n),max(0,46+n))
d=ImageDraw.Draw(im);d.rectangle((1,1,126,126),outline='#aa8a57',width=3);d.rectangle((6,6,121,121),outline='#4c4240',width=2);d.rectangle((10,10,117,117),outline='#756044',width=1)
for cornerx,cornery in [(15,15),(113,15),(15,113),(113,113)]:
 d.ellipse((cornerx-5,cornery-5,cornerx+5,cornery+5),fill='#5a4934',outline='#cead70');d.line((cornerx-3,cornery,cornerx+3,cornery),fill='#231d1a',width=1)
im.save(out/'icon_frame.png')
for key in ['blade','power','dash','bow','nova','pulse','bolt','orbs','vitality','heart','regen','magnet','fortune','relic']:
 a=Image.new('RGBA',(128,128));g=ImageDraw.Draw(a)
 if key in ['blade','power','dash']:
  g.polygon([(30,104),(24,98),(78,28),(101,18),(91,40)],fill='#3b485b',outline='#172332');g.polygon([(33,98),(78,34),(98,20),(88,41)],fill='#b3c4d0');g.polygon([(35,96),(95,24),(76,37)],fill='#edf0d5');g.line((38,89,74,42),fill='#718b9b',width=3);g.polygon([(24,79),(30,74),(57,96),(52,104)],fill='#b48a4f',outline='#e7bd74');g.line((29,94,19,110),fill='#6f4136',width=8);g.ellipse((12,107,25,119),fill='#aa874c',outline='#edce8a')
 elif key=='bow':
  g.arc((23,12,108,118),-90,90,fill='#674536',width=13);g.arc((26,12,108,118),-88,88,fill='#caac71',width=5);g.line((66,13,66,117),fill='#d2c7a9',width=2);g.line((24,67,111,67),fill='#a3b3bd',width=4);g.polygon([(112,67),(101,58),(101,76)],fill='#dedcc7');g.line((27,60,42,67,27,75),fill='#cfab68',width=4)
 elif key in ['nova','pulse']:
  g.polygon([(24,98),(17,61),(42,69),(49,16),(70,48),(83,28),(108,79),(99,108),(46,114)],fill='#7e3d36');g.polygon([(34,99),(32,75),(48,84),(56,33),(70,65),(87,52),(94,88),(79,106)],fill='#dc8650');g.polygon([(48,103),(54,78),(62,52),(69,86),(80,81),(77,104)],fill='#ffdea0')
 elif key=='bolt':
  g.polygon([(77,13),(31,72),(61,71),(45,118),(101,53),(72,54),(99,13)],fill='#344e73',outline='#73a4b7');g.polygon([(75,17),(38,67),(70,62),(52,106),(91,58),(65,60),(90,17)],fill='#d4edef')
 elif key=='orbs':
  g.ellipse((25,25,103,103),outline='#556976',width=4);g.ellipse((28,28,100,100),outline='#c1cfd2',width=1)
  for i in range(3):
   x=64+math.sin(i*math.tau/3)*39;y=64+math.cos(i*math.tau/3)*39;g.polygon([(x-14,y+12),(x+13,y-19),(x+7,y+8)],fill='#bfcbcc',outline='#f2e6c5');g.ellipse((x-5,y-5,x+5,y+5),fill='#a48555')
 elif key in ['vitality','heart','regen']:
  g.polygon([(19,48),(25,31),(46,24),(64,38),(81,24),(105,30),(115,50),(100,75),(64,111),(29,76)],fill='#833b43',outline='#d79683');g.polygon([(30,41),(47,32),(60,46),(70,44),(84,31),(104,42),(98,55),(64,95),(36,66)],fill='#b36264');g.line((33,41,42,36,50,37),fill='#e2b5a0',width=4)
 else:
  g.polygon([(64,13),(105,65),(64,115),(22,65)],fill='#655783',outline='#c9b299');g.polygon([(64,20),(96,65),(64,105),(30,65)],fill='#ac8abb');g.polygon([(64,20),(64,69),(30,65)],fill='#d9bfd2');g.polygon([(64,69),(96,65),(64,105)],fill='#584f86');g.line((41,49,64,32,82,53),fill='#e9d8d0',width=2)
 a.save(out/(key+'.png'))
# Original stone pattern, generated locally rather than downloaded.
tile=Image.new('RGB',(256,256));px=tile.load()
for y in range(256):
 for x in range(256):
  n=random.randint(-7,7);v=49+n+int(3*math.sin(x*.11)*math.sin(y*.17));px[x,y]=(v,v+1,v+4)
g=ImageDraw.Draw(tile)
for y in range(0,256,64):
 for x in range(-64,256,64):
  a=x+(32 if y//64%2 else 0);g.rectangle((a,y,a+63,y+63),outline='#22252b',width=2);g.line((a+3,y+3,a+60,y+3),fill='#46484d');g.line((a+3,y+3,a+3,y+60),fill='#414449')
for i in range(14):
 x=random.randrange(256);y=random.randrange(256);g.line((x,y,x+random.randrange(-8,8),y+random.randrange(5,16),x+random.randrange(-16,16),y+random.randrange(18,30)),fill='#292c31',width=1)
tile.save(out/'stone.png')

