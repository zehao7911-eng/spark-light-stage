extends RefCounted
class_name ReliquaryArt
static var materials={}
static var frames={}
static func mat(hex,glow=false):
 var key=str(hex)+str(glow)
 if materials.has(key):return materials[key]
 var m=StandardMaterial3D.new();m.albedo_color=Color(hex);m.roughness=.72
 if glow:m.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
 if m.albedo_color.a<1:m.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA;m.cull_mode=BaseMaterial3D.CULL_DISABLED
 materials[key]=m;return m
static func mesh(parent,m,p,scale,color):
 var a=MeshInstance3D.new();a.mesh=m;a.position=p;a.scale=scale;a.material_override=mat(color);parent.add_child(a);return a
static func box(n,p,s,c):return mesh(n,BoxMesh.new(),p,s,c)
static func ball(n,p,s,c):
 var m=SphereMesh.new();m.radial_segments=10;m.rings=5;return mesh(n,m,p,s,c)
static func cyl(n,p,r,h,c,top=-1):
 var m=CylinderMesh.new();m.radial_segments=8;m.bottom_radius=r;m.top_radius=r if top<0 else top;m.height=h;return mesh(n,m,p,Vector3.ONE,c)
static func rod(n,a,b,r,c):
 var q=cyl(n,(a+b)/2,r,a.distance_to(b),c);q.quaternion=Quaternion(Vector3.UP,(b-a).normalized());return q
static func ring(n,p,r,c):
 var m=TorusMesh.new();m.inner_radius=r-.035;m.outer_radius=r+.035;m.rings=24;m.ring_segments=4;var a=mesh(n,m,p,Vector3.ONE,c);a.material_override=mat(c,true);return a
static func merge(root):
 var vs=PackedVector3Array();var ns=PackedVector3Array();var cs=PackedColorArray();var ids=PackedInt32Array()
 for child in root.get_children():
  if not child is MeshInstance3D:continue
  var a=child.mesh.surface_get_arrays(0);var start=vs.size();var color=child.material_override.albedo_color.srgb_to_linear()
  for i in a[Mesh.ARRAY_VERTEX].size():vs.append(child.transform*a[Mesh.ARRAY_VERTEX][i]);ns.append((child.basis.inverse().transposed()*a[Mesh.ARRAY_NORMAL][i]).normalized());cs.append(color)
  for i in a[Mesh.ARRAY_INDEX]:ids.append(start+i)
 var arrays=[];arrays.resize(Mesh.ARRAY_MAX);arrays[Mesh.ARRAY_VERTEX]=vs;arrays[Mesh.ARRAY_NORMAL]=ns;arrays[Mesh.ARRAY_COLOR]=cs;arrays[Mesh.ARRAY_INDEX]=ids;var result=ArrayMesh.new();result.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arrays);var material=mat("ffffff").duplicate();material.vertex_color_use_as_albedo=true;var shaded=ShaderMaterial.new();shaded.shader=load("res://Actor.gdshader");result.surface_set_material(0,shaded);root.free();return result
static func actor(kind,frame=0):
 var key=str(kind)+":"+str(frame)
 if frames.has(key):return frames[key]
 var n=Node3D.new();var step=sin(frame*PI/2)*.13
 if kind<3:
  var cloth=["623c4f","40564b","393d69"][kind];var metal="a7a5aa";var gold="bb9561"
  box(n,Vector3(0,.86,.09),Vector3(.52,.63,.25),cloth);box(n,Vector3(0,1.0,-.04),Vector3(.43,.39,.30),metal if kind==0 else cloth);box(n,Vector3(0,.75,-.07),Vector3(.47,.09,.35),gold)
  for side in [-1,1]:
   box(n,Vector3(side*.14,.4,step*side),Vector3(.17,.40,.19),metal if kind==0 else cloth);box(n,Vector3(side*.14,.14,-.08+step*side),Vector3(.20,.20,.34),"38323b");ball(n,Vector3(side*.3,1.08,0),Vector3(.34,.32,.34),metal if kind==0 else cloth);rod(n,Vector3(side*.29,1,0),Vector3(side*.35,.69,-.04),.08,cloth)
  ball(n,Vector3(0,1.40,0),Vector3(.37,.40,.35),metal if kind==0 else "c39677");box(n,Vector3(0,1.38,-.18),Vector3(.31,.08,.03),"23232d")
  if kind==0:
   box(n,Vector3(0,1.0,-.20),Vector3(.05,.29,.025),gold);box(n,Vector3(0,1.01,-.21),Vector3(.26,.05,.02),gold);box(n,Vector3(0,1.39,-.195),Vector3(.025,.22,.025),gold)
   for side in [-1,1]:
    for i in 2:ball(n,Vector3(side*.17,.89+i*.21,-.20),Vector3(.04,.04,.025),gold)
   cyl(n,Vector3(0,1.65,.01),.20,.18,cloth,.08);box(n,Vector3(-.40,.86,-.08),Vector3(.06,.55,.37),gold);box(n,Vector3(-.435,.88,-.08),Vector3(.04,.43,.27),"4b4653");rod(n,Vector3(.36,.76,-.04),Vector3(.36,.96,-.62),.05,gold);box(n,Vector3(.36,.96,-.62),Vector3(.12,.045,.80),metal).rotation.x=-.2
  elif kind==1:
   cyl(n,Vector3(0,1.65,0),.24,.28,cloth,.02);rod(n,Vector3(.4,.7,-.3),Vector3(.4,1.3,-.3),.035,gold);rod(n,Vector3(.4,.7,-.3),Vector3(.4,1,-.55),.035,gold);rod(n,Vector3(.4,1.3,-.3),Vector3(.4,1,-.55),.035,gold)
  else:
   cyl(n,Vector3(0,1.7,0),.27,.45,cloth,0);rod(n,Vector3(.4,.3,-.15),Vector3(.4,1.65,-.15),.035,gold);ball(n,Vector3(.4,1.77,-.15),Vector3(.22,.25,.22),"93d6e0")
 elif kind==3:
  var bone="c0b394"
  for side in [-1,1]:rod(n,Vector3(side*.14,.1,side*step),Vector3(side*.16,.8,0),.055,bone);rod(n,Vector3(side*.24,1.05,0),Vector3(side*.4,.69,-.14),.055,bone);ball(n,Vector3(side*.14,.11,-.06+step*side),Vector3(.17,.12,.26),bone)
  rod(n,Vector3(0,.65,0),Vector3(0,1.15,0),.05,bone)
  for i in 3:box(n,Vector3(0,.83+i*.11,0),Vector3(.39,.04,.22),bone)
  ball(n,Vector3(0,1.34,0),Vector3(.36,.40,.33),bone)
  for side in [-1,1]:box(n,Vector3(side*.09,1.39,-.16),Vector3(.085,.09,.04),"383136")
  box(n,Vector3(0,1.23,-.14),Vector3(.25,.035,.045),"6b5143");rod(n,Vector3(.38,.70,-.1),Vector3(.42,1,-.4),.035,"81888c")
 elif kind==4:
  ball(n,Vector3(0,.35,0),Vector3(.9,.5,.75),"535349");ball(n,Vector3(0,.43,-.32),Vector3(.55,.30,.40),"81725b")
  for side in [-1,1]:
   for i in 3:rod(n,Vector3(side*.30,.30,-.2+i*.22),Vector3(side*.58,.06,-.2+i*.22+step),.035,"aaa28b")
   ball(n,Vector3(side*.12,.5,-.52),Vector3(.10,.07,.04),"d09a66")
 elif kind==5:
  cyl(n,Vector3(0,.75,0),.45,1.25,"46565c",.15);ball(n,Vector3(0,1.43,0),Vector3(.43,.45,.40),"637c7c");box(n,Vector3(0,1.4,-.22),Vector3(.31,.07,.04),"87dad2")
  for side in [-1,1]:rod(n,Vector3(side*.12,1.06,0),Vector3(side*.63,.67,-.12),.06,"5b7273")
 else:
  var c="7b514f" if kind==6 else "646778";ball(n,Vector3(0,1.15,0),Vector3(1.2,1.3,.75),c);box(n,Vector3(0,1.28,-.36),Vector3(.9,.65,.12),"645342");ball(n,Vector3(0,1.97,0),Vector3(.64,.61,.59),"b7aa8d")
  for side in [-1,1]:
   box(n,Vector3(side*.29,.43,step*side),Vector3(.32,.60,.38),c);ball(n,Vector3(side*.72,1.54,0),Vector3(.55,.45,.55),"7a776f");rod(n,Vector3(side*.65,1.42,0),Vector3(side*.75,.68,-.1),.17,c);cyl(n,Vector3(side*.28,2.38,0),.13,.60,"ba995c",0).rotation.z=side*.45;box(n,Vector3(side*.17,2,-.29),Vector3(.12,.08,.05),"e5a959")
  rod(n,Vector3(.77,.68,0),Vector3(.80,.68,-.90),.08,"8e7150");ball(n,Vector3(.8,.7,-.95),Vector3(.60,.6,.65),"6d7682")
  if kind==7:box(n,Vector3(0,2.18,-.31),Vector3(.50,.20,.05),"ac8656")
 var result=merge(n);frames[key]=result;return result
static func entity(parent,kind):
 var n=Node3D.new();parent.add_child(n);var a=MeshInstance3D.new();a.name="Body";a.mesh=actor(kind);n.add_child(a);var shadow=cyl(n,Vector3(0,.025,0),.50,.01,"05090ba0");shadow.material_override=mat("05090ba0",true);return n
static func pillar(parent,p):
 var n=Node3D.new();n.position=p;parent.add_child(n);box(n,Vector3(0,.18,0),Vector3(1.7,.36,1.7),"393940");cyl(n,Vector3(0,1.55,0),.45,2.6,"625b5b");cyl(n,Vector3(0,2.85,0),.70,.28,"847364");box(n,Vector3(0,3.10,0),Vector3(1.2,.26,1.2),"62595c")
 for side in [-1,1]:box(n,Vector3(side*.43,1.5,-.10),Vector3(.14,2.4,.13),"9b8268")
 return n
static func torch(parent,p):
 var n=Node3D.new();n.position=p;parent.add_child(n);cyl(n,Vector3(0,.9,0),.20,1.8,"4a3940");cyl(n,Vector3(0,1.8,0),.48,.25,"9d7651",.25);var a=ball(n,Vector3(0,2.12,0),Vector3(.45,.65,.45),"dd9252");a.material_override=mat("dd9252",true);var b=ball(n,Vector3(0,2.15,0),Vector3(.25,.48,.25),"ffe3a0");b.material_override=mat("ffe3a0",true);return n
static func well(parent,p):
 var n=Node3D.new();n.position=p;parent.add_child(n)
 cyl(n,Vector3(0,.2,0),1.3,.4,"666267");cyl(n,Vector3(0,.43,0),1,.06,"182e33");ring(n,Vector3(0,.47,0),.99,"78ada6")
 for i in 8:var a=i*TAU/8;box(n,Vector3(sin(a)*1.10,.56,cos(a)*1.10),Vector3(.5,.38,.5),"8c8277")
 for side in [-1,1]:box(n,Vector3(side*.95,1.5,0),Vector3(.18,2.6,.2),"69513f")
 box(n,Vector3(0,2.8,0),Vector3(2.4,.2,.22),"997959");rod(n,Vector3(0,2.8,0),Vector3(0,1.4,0),.02,"c1ae87");cyl(n,Vector3(0,1.37,0),.28,.32,"b99865");return n
