extends SceneTree
var w
var failures=[]
var checks=0
var backup=""
func _initialize():call_deferred("run")
func check(ok,label):
 checks+=1
 if not ok:failures.append(label);printerr("FAIL "+label)
func reset():w.new_run();w.profile.muted=true;w.set_process(false);w.set_physics_process(false);w.clear_entities();w.spawn_timer=10000;w.regen_timer=0;w.pos=Vector3.ZERO;w.hurt_cd=0
func run():
 if FileAccess.file_exists("user://ashen_reliquary.json"):backup=FileAccess.get_file_as_string("user://ashen_reliquary.json")
 w=load("res://World.tscn").instantiate();root.add_child(w);await process_frame;w.profile={"gold":0,"power":0,"heart":0,"fortune":0,"relics":[],"best":0,"runs":0,"character":0,"muted":true,"low":false};reset()
 var e=w.spawn_enemy(3,Vector3(0,0,-3));w.hit(e,100);check(e not in w.enemies and w.r.kills==1,"kill removes enemy once and creates loot")
 var kill=w.r.kills;w.hit(e,100);check(w.r.kills==kill,"dead enemy cannot reward twice")
 reset();w.drop(0,Vector3.ZERO,10);w._physics_process(.02);check(w.mode=="choice" and w.choices.size()==3,"souls trigger three upgrade choices")
 var key=w.choices[0];var previous=w.r.skills[key];check(w.upgrade(key) and w.r.level==2 and w.r.skills[key]==previous+1 and w.r.xp==0,"upgrade consumes level threshold and grants trait")
 check(not w.upgrade(key),"upgrade cannot repeat outside choice")
 reset();w.r.hp=20;w.r.xp=10;w.choices=["vitality"];w.mode="choice";w.upgrade("vitality");check(w.max_hp()==70 and w.r.hp==35,"vigor raises maximum and heals")
 reset();check(w.dash(),"dash activates");check(not w.dash() and w.dash_cd>0,"dash cooldown blocks spam")
 var hp=w.r.hp;w.take_damage(100);check(w.r.hp==hp,"dash invulnerability blocks damage")
 reset();e=w.spawn_enemy(3,Vector3(0,0,-2));check(w.pulse() and e not in w.enemies,"burst damages nearby enemies");check(not w.pulse(),"burst cooldown blocks spam")
 reset();hp=w.r.hp;w.take_damage(4);w.take_damage(4);check(w.r.hp==hp-4,"contact immunity prevents multiple simultaneous hits")
 reset();w.r.gold=35;w.r.hp=1;w.take_damage(2);check(w.mode=="defeat" and w.profile.gold==35 and w.profile.runs==1,"death banks collected gold")
 w.bank_run();check(w.profile.gold==35 and w.profile.runs==1,"bank is idempotent")
 w.profile.gold=0;check(not w.buy("power") and w.profile.power==0,"unaffordable blessing blocked")
 w.profile.gold=100;check(w.buy("power") and w.profile.power==1 and w.profile.gold==75,"permanent blessing purchases once at correct price")
 w.profile.power=5;hp=w.profile.gold;check(not w.buy("power") and w.profile.gold==hp,"maximum blessing does not charge")
 reset();w.r.relic=0;w.pos=Vector3.ZERO;check(not w.retrieve(),"relic requires proximity to well")
 w.pos=w.WELL;check(w.retrieve() and 0 in w.profile.relics,"well secures relic permanently")
 check(not w.retrieve() and w.profile.relics.size()==1,"same relic is not retrieved twice")
 w.r.relic=1;w.r.retrieved=false;check(w.retrieve() and w.profile.relics.size()==2,"a second relic can be secured in same run")
 w.profile.relics=[];w.r.active=false;w.character(2);check(w.profile.character==0,"warlock locked until relic recovered")
 w.profile.relics=[0];w.character(2);w.new_run();check(w.profile.character==2 and w.r.skills.nova==1 and w.r.skills.bolt==1,"relic unlocks warlock starting abilities")
 w.profile.character=0;w.profile.power=0;reset();e=w.spawn_enemy(3,Vector3(0,0,-2));w.cooldown.blade=0;w._physics_process(.02);check(e.hp<e.max_hp,"automatic blade attacks without input")
 reset();w.r.skills.blade=0;w.r.skills.bow=1;e=w.spawn_enemy(3,Vector3(0,0,-3));w.cooldown.bow=0
 for i in 35:w._physics_process(.02)
 check(e.hp<e.max_hp,"arrow projectile collides and deals damage")
 reset();w.r.skills.blade=0;w.r.skills.bolt=1;e=w.spawn_enemy(3,Vector3(0,0,-5));w.cooldown.bolt=0;w._physics_process(.02);check(e.hp<e.max_hp,"chain lightning damages targeted foe")
 reset();w.r.skills.blade=0;w.r.skills.orbs=1;e=w.spawn_enemy(3,Vector3(0,0,2.6));w.clock=0;w._physics_process(.02);check(e.hp<e.max_hp,"orbit weapon hits enemies on its path")
 reset();w.r.skills.blade=0;w.r.skills.nova=1;e=w.spawn_enemy(3,Vector3(0,0,-3));w.cooldown.nova=0;w._physics_process(.02);check(e.hp<e.max_hp,"nova attacks nearby foes")
 reset();w.r.time=65;w._physics_process(.02);check(w.r.boss_spawned==1 and w.enemies[0].boss,"first lord appears at configured time")
 reset();w.r.bosses=2;e=w.spawn_enemy(7,Vector3(0,0,-4),true);w.hit(e,10000);check(w.mode=="victory" and w.r.banked and w.r.bosses==3,"third defeated lord completes descent")
 w.hud.act("endless");check(w.mode=="play" and w.r.active and not w.r.banked and w.r.gold==0,"endless continuation resets only unbanked earnings")
 w.clear_entities();w.r.time=306;w.r.boss_spawned=3;w.spawn_timer=1000;w._physics_process(.02);check(w.r.boss_spawned==4 and w.enemies[0].boss,"endless lord continues spawning")
 reset();w.r.skills.blade=0;w.make_hazard(Vector3.ZERO,2,6);w._physics_process(1.2);check(int(w.r.hp)==w.max_hp()-6 and w.hazards.is_empty(),"telegraphed hazard resolves and clears")
 reset();w.r.skills.blade=0;w.r.level=50
 for i in 200:w.spawn_enemy(3,Vector3(i%10,0,-15));w.drop(0,Vector3(10,0,10))
 check(w.enemies.size()<=80 and w.drops.size()<=130,"enemy and loot pools remain bounded")
 reset();w.r.gold=17;w.r.skills.orbs=2;w.pos=Vector3(4,0,-2);w.save_game();w.load_save();check(w.saved_run.r.gold==17 and w.saved_run.r.skills.orbs==2,"save preserves run traits and gold")
 w.restore_run(w.saved_run);check(w.pos==Vector3(4,0,-2),"save restores exact location")
 w.queue_free();await process_frame
 if not backup.is_empty():var file=FileAccess.open("user://ashen_reliquary.json",FileAccess.WRITE);file.store_string(backup);file.close()
 else:DirAccess.remove_absolute("user://ashen_reliquary.json")
 print(JSON.stringify({"checks":checks,"failures":failures}));quit(0 if failures.is_empty() else 1)
