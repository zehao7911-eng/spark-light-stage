extends Node3D
const HUD=preload("res://HUD.gd")
const SAVE="user://ashen_reliquary.json"
const WELL=Vector3(0,0,9)
const SKILLS={"blade":["CLEAVING EDGE","Wider arcs · more damage"],"bow":["HUNTER'S VOLLEY","More arrows · piercing"],"nova":["CINDER NOVA","Fire erupts around you"],"orbs":["ORBITING SCYTHES","Blades circle your hero"],"bolt":["CHAIN LIGHTNING","Leaps between enemies"],"power":["MIGHT","All damage +4"],"haste":["QUICKENING","Attacks recover faster"],"vitality":["VIGOR","Max health +10 · heal"],"magnet":["SOUL MAGNET","Collect from farther away"],"regen":["SECOND WIND","Recover health over time"]}
var profile={"gold":0,"power":0,"heart":0,"fortune":0,"relics":[],"best":0,"runs":0,"character":0,"muted":false,"low":false}
var r={}
var mode="title"
var pos=Vector3.ZERO
var move_vec=Vector2.ZERO
var facing=Vector3.FORWARD
var dash_time=0.0
var dash_cd=0.0
var pulse_cd=0.0
var hurt_cd=0.0
var enemies=[]
var drops=[]
var projectiles=[]
var hazards=[]
var effects=[]
var pillars=[]
var camera:Camera3D
var hero:Node3D
var orbit_nodes=[]
var hud
var map_root:Node3D
var sun:DirectionalLight3D
var env:Environment
var rng=RandomNumberGenerator.new()
var clock=0.0
var spawn_timer=0.0
var regen_timer=0.0
var autosave=0.0
var bridge=0.0
var cooldown={"blade":.4,"bow":.4,"nova":3.0,"bolt":1.0}
var choices=[]
var notice=""
var notice_time=0.0
var shake=0.0
var sounds={}
var audio=[]
var music:AudioStreamPlayer
var saved_run={}
func _ready():
 if has_node("EditorPreview"):get_node("EditorPreview").queue_free()
 Engine.max_fps=30;rng.randomize();load_save()
 var e=WorldEnvironment.new();env=Environment.new();env.background_mode=Environment.BG_COLOR;env.background_color=Color("13171f");env.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;env.ambient_light_color=Color("8395aa");env.ambient_light_energy=.80;e.environment=env;add_child(e)
 sun=DirectionalLight3D.new();sun.rotation_degrees=Vector3(-52,-25,0);sun.light_color=Color("d6b695");sun.light_energy=1.2;sun.shadow_enabled=not profile.low;sun.directional_shadow_max_distance=28;add_child(sun)
 map_root=Node3D.new();map_root.name="TheCrypt";add_child(map_root);make_map()
 hero=ReliquaryArt.entity(self,int(profile.character));hero.scale=Vector3.ONE*1.35;camera=Camera3D.new();camera.projection=Camera3D.PROJECTION_ORTHOGONAL;camera.size=20;camera.rotation_degrees=Vector3(-45,0,0);camera.near=.1;camera.far=100;add_child(camera);camera.current=true
 var light=OmniLight3D.new();light.position=Vector3(0,2,0);light.light_color=Color("e6ad66");light.light_energy=1.0;light.omni_range=7;hero.add_child(light)
 for i in 6:var a=ReliquaryArt.box(self,Vector3.ZERO,Vector3(.06,.10,.9),"b5d5d9");a.material_override=ReliquaryArt.mat("b5d5d9",true);a.visible=false;orbit_nodes.append(a)
 var grade=CanvasLayer.new();grade.layer=-1;add_child(grade);var filter=ColorRect.new();filter.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);filter.mouse_filter=Control.MOUSE_FILTER_IGNORE;var shader=ShaderMaterial.new();shader.shader=load("res://Grade.gdshader");filter.material=shader;grade.add_child(filter)
 hud=HUD.new();hud.world=self;add_child(hud)
 for n in ["shot","move","hit","coin","hurt"]:sounds[n]=load("res://audio/"+n+".wav")
 for i in 8:var a=AudioStreamPlayer.new();a.volume_db=-20;add_child(a);audio.append(a)
 music=AudioStreamPlayer.new();music.stream=load("res://audio/ambient.wav");music.stream.loop_mode=AudioStreamWAV.LOOP_FORWARD;music.stream.loop_end=int(music.stream.get_length()*22050);music.volume_db=-25;add_child(music)
 new_run(false);if not saved_run.is_empty():restore_run(saved_run)
 mode="title";get_viewport().size_changed.connect(resize);resize()
func resize():
 var v=DisplayServer.window_get_size();get_viewport().content_scale_size=Vector2i(480,800) if v.x<v.y else Vector2i(960,540);camera.keep_aspect=Camera3D.KEEP_WIDTH if v.x<v.y else Camera3D.KEEP_HEIGHT;camera.size=16 if v.x<v.y else 18
func make_map():
 var floor_node=ReliquaryArt.box(map_root,Vector3(0,-.20,0),Vector3(66,.4,66),"30333b");var fm=ShaderMaterial.new();fm.shader=load("res://Floor.gdshader");fm.set_shader_parameter("stone_tex",load("res://art/stone.png"));floor_node.material_override=fm
 for i in 12:
  var a=i*TAU/12;var p=Vector3(sin(a)*21,0,cos(a)*21);ReliquaryArt.pillar(map_root,p);pillars.append(p)
 for p in [Vector3(-10,0,-7),Vector3(10,0,-7),Vector3(-10,0,9),Vector3(10,0,9)]:ReliquaryArt.pillar(map_root,p);pillars.append(p)
 for side in [-1,1]:
  for x in [-25,-15,-5,5,15,25]:
   var p=Vector3(x,0,side*31);var n=ReliquaryArt.pillar(map_root,p);n.scale=Vector3(1.2,1.6,1.2)
  ReliquaryArt.box(map_root,Vector3(side*32,1.8,0),Vector3(1,3.6,65),"343640");ReliquaryArt.box(map_root,Vector3(0,1.8,side*32),Vector3(65,3.6,1),"343640")
 for p in [Vector3(-7,0,-6),Vector3(7,0,-6),Vector3(-7,0,7),Vector3(7,0,7)]:ReliquaryArt.torch(map_root,p)
 ReliquaryArt.well(map_root,WELL)
 for i in 38:
  var a=i*2.41;var p=Vector3(sin(a)*(13+fmod(i*3.2,15)),.10,cos(a)*(13+fmod(i*3.2,15)));ReliquaryArt.box(map_root,p,Vector3(.6,.2,.45),"635c56").rotation.y=a
 for p in [Vector3(-13,0,-3),Vector3(13,0,3),Vector3(3,0,-14),Vector3(-3,0,14)]:
  var n=Node3D.new();n.position=p;map_root.add_child(n);ReliquaryArt.box(n,Vector3(0,.3,0),Vector3(1.6,.6,2.2),"565157");ReliquaryArt.box(n,Vector3(0,.67,0),Vector3(1.8,.18,2.4),"8b7869");ReliquaryArt.box(n,Vector3(0,.78,0),Vector3(.08,.05,1.5),"b5a58a")
 for i in 3:var ring=ReliquaryArt.ring(map_root,Vector3(0,.02,0),3.2+i*.30,"67584c");ring.material_override=ReliquaryArt.mat("67584c")
func max_hp():return 60+int(profile.heart)*8+int(r.get("skills",{}).get("vitality",0))*10+(10 if 5 in profile.relics else 0)
func damage():return 11+int(profile.power)*2+int(r.skills.power)*4+(3 if 1 in profile.relics else 0)
func xp_need():return 6+int(r.level)*4
func new_run(start=true):
 clear_entities();pos=Vector3.ZERO;facing=Vector3.FORWARD;r={"active":start,"time":0.0,"level":1,"xp":0,"kills":0,"gold":0,"bosses":0,"boss_spawned":0,"relic":-1,"retrieved":false,"banked":false,"skills":{"blade":1,"bow":0,"nova":0,"orbs":0,"bolt":0,"power":0,"haste":0,"vitality":0,"magnet":0,"regen":0}}
 if profile.character==1:r.skills.blade=0;r.skills.bow=1
 elif profile.character==2:r.skills.blade=0;r.skills.nova=1;r.skills.bolt=1
 r.hp=max_hp();mode="play" if start else "title";cooldown={"blade":.4,"bow":.4,"nova":2.0,"bolt":1.0};spawn_timer=0;dash_time=0;dash_cd=0;pulse_cd=0;hurt_cd=0;choices=[]
 for i in 8:spawn_enemy(3,Vector3(sin(i*TAU/8)*8,0,cos(i*TAU/8)*8))
 if start:save_game()
func clear_entities():
 for a in enemies+drops+projectiles+hazards+effects:if a.has("node") and is_instance_valid(a.node):a.node.queue_free()
 enemies=[];drops=[];projectiles=[];hazards=[];effects=[]
func set_mode(m):mode=m;move_vec=Vector2.ZERO
func start():
 if r.active:set_mode("choice" if not choices.is_empty() else "play")
 else:new_run()
func spawn_enemy(kind,p,boss=false):
 if enemies.size()>=(84 if boss else 80):return null
 var n=ReliquaryArt.entity(self,kind);n.position=p;var factor=1+float(r.time)/300;var hp=(18 if kind==3 else 12 if kind==4 else 26 if kind==5 else 65 if kind==6 else 320)*factor
 n.scale=Vector3.ONE*1.2
 if boss:hp=210+int(r.bosses)*180;n.scale=Vector3.ONE*1.65
 var e={"kind":kind,"p":p,"hp":hp,"max_hp":hp,"node":n,"speed":1.4 if kind==3 else 2.4 if kind==4 else 1.1 if kind==5 else .85,"boss":boss,"hit":0.0,"orb_cd":0.0,"special":2.0+rng.randf()*3,"dir":Vector3.FORWARD,"phase":rng.randf()*TAU};enemies.append(e);return e
func drop(kind,p,value=1):
 if drops.size()>=130:
  if kind==0:r.xp+=value
  elif kind==1:r.gold+=value
  return
 var n=ReliquaryArt.ball(self,p+Vector3.UP*.23,Vector3(.18,.26,.18) if kind==0 else Vector3(.20,.10,.20) if kind==1 else Vector3(.40,.45,.40),"9bc8c0" if kind==0 else "d0a264" if kind==1 else "c26263" if kind==2 else "be99df");n.material_override=ReliquaryArt.mat("9bc8c0" if kind==0 else "d0a264" if kind==1 else "c26263" if kind==2 else "be99df",true);drops.append({"kind":kind,"p":p,"value":value,"node":n})
func nearest(range_limit=99):
 var target=null;var dist=range_limit
 for e in enemies:
  var d=pos.distance_to(e.p)
  if d<dist:target=e;dist=d
 return target
func hit(e,value,knock=1.0,critical=false):
 if e not in enemies:return
 var crit=critical or rng.randf()<.12;var actual=value*(2 if crit else 1);e.hp-=actual;e.hit=.13;e.p+=(e.p-pos).normalized()*knock;shake=maxf(shake,.06);spark(e.p+Vector3.UP*.8,Color("efc083") if crit else Color("c7dbd8"),5);sound("hit");number(e.p,int(actual),"efc083" if crit else "ddd8c8")
 if e.hp<=0:
  r.kills+=1;drop(0,e.p,4 if e.boss else 2 if e.kind==6 else 1);if rng.randf()<.35+int(profile.fortune)*.05:drop(1,e.p+Vector3(.25,0,0),2 if e.kind==6 else 1)
  if rng.randf()<.035:drop(2,e.p)
  if e.boss:
   r.bosses+=1;r.gold+=20;drop(3,e.p,clampi(int(r.bosses)-1,0,5));toast("LORD FALLEN · A RELIC APPEARS");sound("coin");shake=.25
   if r.bosses>=3:set_mode("victory");bank_run()
  e.node.queue_free();enemies.erase(e)
func spark(p,c,n=8):
 for i in n:
  if effects.size()>=100:return
  var q=ReliquaryArt.box(self,p,Vector3(.07,.07,.12),c.to_html());q.material_override=ReliquaryArt.mat(c.to_html(),true);effects.append({"node":q,"p":p,"v":Vector3(rng.randf_range(-3,3),rng.randf_range(1,4),rng.randf_range(-3,3)),"life":.35,"type":0})
func number(p,value,color):
 if effects.size()>=100:return
 var q=Label3D.new();q.text=str(value);q.font_size=32;q.pixel_size=.012;q.billboard=BaseMaterial3D.BILLBOARD_ENABLED;q.modulate=Color(color);q.outline_modulate=Color("17171e");q.outline_size=5;q.position=p+Vector3.UP*1.5;add_child(q);effects.append({"node":q,"p":q.position,"v":Vector3.UP,"life":.65,"type":1})
func arc(p,dir,radius,color,full=false):
 var n=Node3D.new();add_child(n);n.position=p;n.rotation.y=atan2(-dir.x,-dir.z);var mesh=ImmediateMesh.new();mesh.surface_begin(Mesh.PRIMITIVE_TRIANGLES,ReliquaryArt.mat(color,true));var count=28;var angle=TAU if full else PI*.95
 for i in count:
  var a=-angle/2+i*angle/count;var b=-angle/2+(i+1)*angle/count;var v1=Vector3(sin(a),.7,-cos(a));var v2=Vector3(sin(b),.7,-cos(b))
  for v in [v1*(radius-.25),v2*radius,v1*radius,v1*(radius-.25),v2*(radius-.25),v2*radius]:mesh.surface_add_vertex(v)
 mesh.surface_end();var mi=MeshInstance3D.new();mi.mesh=mesh;n.add_child(mi);effects.append({"node":n,"p":p,"v":Vector3.ZERO,"life":.18,"type":2})
func shoot_bolt(dir,damage_value,pierce=0):
 if projectiles.size()>=48:return
 var n=ReliquaryArt.box(self,pos+Vector3.UP*.65,Vector3(.06,.08,.8),"dbc28c");n.material_override=ReliquaryArt.mat("dbc28c",true);n.rotation.y=atan2(dir.x,dir.z);projectiles.append({"node":n,"p":pos,"dir":dir,"life":1.5,"damage":damage_value,"pierce":pierce,"hit":[]})
func upgrade(key):
 if mode!="choice" or key not in choices:return false
 if r.skills[key]>=6:return false
 r.skills[key]+=1
 if key=="vitality":r.hp=minf(max_hp(),r.hp+15)
 r.xp-=xp_need();r.level+=1;choices=[];sound("coin");spark(pos+Vector3.UP,Color("d7b075"),14);set_mode("play");save_game();return true
func offer():
 choices=[];var keys=SKILLS.keys();keys.shuffle()
 for key in keys:
  if r.skills[key]<6:choices.append(key)
  if choices.size()==3:break
 if choices.is_empty():r.xp=0;return
 set_mode("choice");save_game();sound("coin")
func dash():
 if mode!="play" or dash_cd>0:return false
 dash_time=.25;dash_cd=2.4;hurt_cd=maxf(hurt_cd,.30);sound("shot");spark(pos,Color("9bc2ce"),8);return true
func pulse():
 if mode!="play" or pulse_cd>0:return false
 pulse_cd=5 if 4 in profile.relics else 7;arc(pos,facing,6.2,"95cad0",true);shake=.22;sound("shot")
 for e in enemies.duplicate():if e.p.distance_to(pos)<6.2:hit(e,damage()*1.8,2.4)
 return true
func take_damage(amount):
 if hurt_cd>0:return
 r.hp-=amount;hurt_cd=.8;shake=.20;sound("hurt");hud.flash=.28
 if r.hp<=0:r.hp=0;set_mode("defeat");bank_run()
func retrieve():
 if mode!="play" or pos.distance_to(WELL)>3 or int(r.relic)<0 or r.retrieved:return false
 var relic=int(r.relic);if relic not in profile.relics:profile.relics.append(relic)
 r.retrieved=true;toast("RELIC SECURED · SAFE FOR FUTURE RUNS");save_game();sound("coin");return true
func bank_run():
 if r.banked:return
 r.banked=true;r.active=false;profile.gold+=int(r.gold);profile.runs+=1;profile.best=maxf(profile.best,r.time);save_game()
func end_run():
 if mode not in ["play","pause"]:return
 bank_run();set_mode("defeat")
func buy(key):
 if key not in ["power","heart","fortune"]:return false
 var level=int(profile[key]);var cost=(25 if key=="power" else 20 if key=="heart" else 30)*(level+1)
 if level>=5 or profile.gold<cost:return false
 profile.gold-=cost;profile[key]+=1;save_game();sound("coin");return true
func character(id):
 if r.get("active",false):toast("FINISH YOUR DESCENT TO CHANGE HERO");return
 if id==2 and profile.relics.is_empty():toast("RECOVER A RELIC TO UNLOCK");return
 profile.character=id;hero.get_node("Body").mesh=ReliquaryArt.actor(id);save_game()
func _physics_process(dt):
 if mode!="play":return
 r.time+=dt;spawn_timer-=dt;regen_timer+=dt;dash_cd=maxf(0,dash_cd-dt);pulse_cd=maxf(0,pulse_cd-dt);hurt_cd=maxf(0,hurt_cd-dt);dash_time=maxf(0,dash_time-dt)
 var input=move_vec;var keys=Vector2(float(Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT))-float(Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT)),float(Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN))-float(Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP)))
 if keys.length()>.1:input=keys.normalized()
 var dir=Vector3(input.x,0,input.y)
 if dir.length()>.1:facing=dir.normalized()
 pos+=(facing*12 if dash_time>0 else dir*4.5)*dt;pos.x=clampf(pos.x,-29,29);pos.z=clampf(pos.z,-29,29)
 for pillar in pillars:
  var delta=pos-pillar;delta.y=0
  if delta.length()<1.15:pos=pillar+delta.normalized()*1.15
 hero.position=pos;hero.rotation.y=lerp_angle(hero.rotation.y,atan2(-facing.x,-facing.z),minf(1,dt*12));hero.get_node("Body").mesh=ReliquaryArt.actor(int(profile.character),int(clock*8)%4 if input.length()>.1 or dash_time>0 else 0);hero.position.y=absf(sin(clock*10))*.045 if input.length()>.1 else sin(clock*3)*.015
 if spawn_timer<=0:
  spawn_timer=maxf(.45,1.4-r.time*.002)
  for i in 1+mini(3,int(r.time/50)):
   var a=rng.randf()*TAU;var kind=3 if r.time<25 else rng.randi_range(3,5) if r.time<80 else rng.randi_range(3,6);var p=pos+Vector3(sin(a),0,cos(a))*rng.randf_range(11,15);p.x=clampf(p.x,-29,29);p.z=clampf(p.z,-29,29);spawn_enemy(kind,p)
 var threshold=[65,140,225]
 if r.boss_spawned<3 and r.time>=threshold[int(r.boss_spawned)]:
  spawn_enemy(7,pos+Vector3(0,0,-9),true);r.boss_spawned+=1;toast("A LORD APPROACHES");sound("hurt")
 elif r.boss_spawned>=3 and r.time>=225+(int(r.boss_spawned)-2)*80:
  spawn_enemy(7,pos+Vector3(0,0,-10),true);r.boss_spawned+=1
 for e in enemies.duplicate():
  e.hit=maxf(0,e.hit-dt);e.orb_cd=maxf(0,e.orb_cd-dt);e.special-=dt;var delta=pos-e.p;delta.y=0;e.dir=delta.normalized()
  e.p+=e.dir*e.speed*dt
  for pillar in pillars:
   var d=e.p-pillar;d.y=0
   if d.length()<1:e.p=pillar+d.normalized()
  e.node.position=e.p;e.node.rotation.y=atan2(-e.dir.x,-e.dir.z);e.node.get_node("Body").mesh=ReliquaryArt.actor(e.kind,int((clock+e.phase)*6)%4);e.node.get_node("Body").material_override=ReliquaryArt.mat("eadbb7",true) if e.hit>0 else null;e.node.scale=(Vector3.ONE*1.65 if e.boss else Vector3.ONE*1.2)*(1.08 if e.hit>0 else 1);e.node.position.y=sin(clock*3+e.phase)*.08 if e.kind==5 else 0
  if e.p.distance_to(pos)<.9+(1.0 if e.boss else 0):
   take_damage(15 if e.boss else 7 if e.kind==6 else 4)
   if mode!="play":return
  if e.special<=0 and (e.boss or e.kind==5):
   e.special=3.2 if e.boss else 5;make_hazard(pos,2.4 if e.boss else 1.3,14 if e.boss else 6)
  if e.p.distance_to(pos)>37 and not e.boss:e.node.queue_free();enemies.erase(e)
 for h in hazards.duplicate():
  h.time-=dt;h.node.scale=Vector3.ONE*(1+sin(clock*16)*.04)
  if h.time<=0:
   arc(h.p,Vector3.FORWARD,h.radius,"a35755",true)
   if h.p.distance_to(pos)<h.radius:take_damage(h.damage)
   h.node.queue_free();hazards.erase(h)
 for d in drops.duplicate():
  var distance=d.p.distance_to(pos);var reach=1.4+int(r.skills.magnet)*.65+(.8 if 3 in profile.relics else 0)
  if distance<reach and d.kind!=3:d.p=d.p.move_toward(pos,dt*10)
  if distance<.7:
   if d.kind==0:r.xp+=d.value
   elif d.kind==1:r.gold+=d.value
   elif d.kind==2:r.hp=minf(max_hp(),r.hp+15)
   else:r.relic=d.value;r.retrieved=false;toast("RELIC FOUND · TAKE IT TO THE WELL")
   sound("move");d.node.queue_free();drops.erase(d);continue
  d.node.position=d.p+Vector3.UP*(.22+sin(clock*3+d.p.x)*.07);d.node.rotation.y+=dt
 for q in projectiles.duplicate():
  var prev=q.p;q.p+=q.dir*dt*18;q.life-=dt;q.node.position=q.p+Vector3.UP*.65
  for e in enemies.duplicate():
   if e in q.hit:continue
   var u=clampf((e.p-prev).dot(q.p-prev)/maxf((q.p-prev).length_squared(),.01),0,1)
   if e.p.distance_to(prev.lerp(q.p,u))<.65+( .4 if e.boss else 0):q.hit.append(e);hit(e,q.damage,.30);q.pierce-=1;if q.pierce<0:q.life=0;break
  if q.life<=0:q.node.queue_free();projectiles.erase(q)
 for key in cooldown:cooldown[key]-=dt
 var target=nearest(9)
 if target:
  if input.length()<.1:facing=(target.p-pos).normalized()
  var toward=(target.p-pos).normalized()
  if r.skills.blade>0 and cooldown.blade<=0:
   var radius=3.8+int(r.skills.blade)*.25;arc(pos,toward,radius,"ddc7a8");sound("shot");cooldown.blade=maxf(.28,1.10-int(r.skills.haste)*.10)
   for e in enemies.duplicate():
    var delta=e.p-pos
    if delta.length()<radius and toward.dot(delta.normalized())>-.03:hit(e,damage()+int(r.skills.blade)*4,.45)
  if r.skills.bow>0 and cooldown.bow<=0:
   cooldown.bow=maxf(.3,1.25-int(r.skills.haste)*.10)
   for i in 1+int(r.skills.bow/2):shoot_bolt(toward.rotated(Vector3.UP,(i-int(r.skills.bow/2)/2.0)*.12),damage()+int(r.skills.bow)*3,int(r.skills.bow/3)+(1 if 2 in profile.relics else 0))
   sound("shot")
  if r.skills.bolt>0 and cooldown.bolt<=0:
   cooldown.bolt=maxf(.6,3.8-int(r.skills.haste)*.25);var from=pos+Vector3.UP*.8;var targets=enemies.duplicate();targets.sort_custom(func(a,b):return a.p.distance_to(pos)<b.p.distance_to(pos))
   for i in mini(1+int(r.skills.bolt),targets.size()):
    var e=targets[i];if e.p.distance_to(pos)>9:break
    var to=e.p+Vector3.UP*.8;var line=ReliquaryArt.rod(self,from,to,.045,"acd8dc");line.material_override=ReliquaryArt.mat("acd8dc",true);effects.append({"node":line,"p":line.position,"v":Vector3.ZERO,"life":.18,"type":2});hit(e,damage()+int(r.skills.bolt)*6,.20);from=to
 if r.skills.nova>0 and cooldown.nova<=0:
  cooldown.nova=maxf(1.2,6.0-int(r.skills.haste)*.30);var radius=3.5+int(r.skills.nova)*.65;arc(pos,facing,radius,"d79b63",true)
  for e in enemies.duplicate():if e.p.distance_to(pos)<radius:hit(e,damage()+int(r.skills.nova)*8,1)
 for i in orbit_nodes.size():
  var a=orbit_nodes[i];a.visible=i<int(r.skills.orbs)
  if a.visible:
   var angle=clock*2.4+i*TAU/maxi(1,int(r.skills.orbs));a.position=pos+Vector3(sin(angle)*2.6,.85,cos(angle)*2.6);a.rotation.y=angle
   for e in enemies.duplicate():if e.orb_cd<=0 and e.p.distance_to(a.position)<1:e.orb_cd=.35;hit(e,damage()+int(r.skills.orbs)*3,.20)
 if regen_timer>1:regen_timer=0;r.hp=minf(max_hp(),r.hp+int(r.skills.regen)*.45+(1 if 0 in profile.relics else 0)*.2)
 if r.xp>=xp_need() and mode=="play":offer()
func make_hazard(p,radius,damage_value):
 if hazards.size()>=10:return
 var n=ReliquaryArt.ring(self,p+Vector3.UP*.07,radius,"aa6455");hazards.append({"p":p,"radius":radius,"damage":damage_value,"time":1.15,"node":n})
func _process(dt):
 clock+=dt;autosave+=dt;bridge+=dt;notice_time=maxf(0,notice_time-dt);shake=move_toward(shake,0,dt*.8)
 var goal=pos+Vector3(0,17,17);camera.position=camera.position.lerp(goal,minf(1,dt*8));camera.position.x+=rng.randf_range(-shake,shake);camera.position.z+=rng.randf_range(-shake,shake)
 for a in effects.duplicate():
  a.life-=dt;a.p+=a.v*dt;a.node.position=a.p
  if a.type==0:a.v.y-=dt*12;a.node.rotate_y(dt*5)
  if a.life<=0:a.node.queue_free();effects.erase(a)
 if autosave>6:autosave=0;save_game()
 if OS.has_feature("web") and bridge>.25:
  bridge=0;var controls=[];var loot=[];var actors=[]
  for d in drops:loot.append({"kind":d.kind,"p":[d.p.x,d.p.z]})
  for e in enemies:actors.append({"kind":e.kind,"p":[e.p.x,e.p.z],"hp":e.hp,"boss":e.boss})
  for b in hud.buttons:controls.append({"id":b.id,"r":[b.r.position.x,b.r.position.y,b.r.size.x,b.r.size.y]})
  JavaScriptBridge.eval("window.ReliquarySnapshot="+JSON.stringify({"mode":mode,"r":r,"profile":profile,"pos":[pos.x,pos.y,pos.z],"enemies":enemies.size(),"drops":drops.size(),"loot":loot,"actors":actors,"controls":controls,"choices":choices,"dash":dash_cd,"pulse":pulse_cd,"viewport":[get_viewport().get_visible_rect().size.x,get_viewport().get_visible_rect().size.y]}),true)
func sound(n):
 if profile.muted:return
 for a in audio:if not a.playing:a.stream=sounds[n];a.play();return
func toast(t):notice=t;notice_time=3
func save_game():
 if not hero:return
 var data={"profile":profile}
 if r.get("active",false):
  var es=[];var ds=[]
  for e in enemies:es.append({"kind":e.kind,"p":[e.p.x,e.p.z],"hp":e.hp,"boss":e.boss})
  for d in drops:ds.append({"kind":d.kind,"p":[d.p.x,d.p.z],"value":d.value})
  data.run={"r":r,"pos":[pos.x,pos.z],"enemies":es,"drops":ds,"choices":choices,"mode":mode,"cooldown":cooldown}
 var raw=JSON.stringify(data);var file=FileAccess.open(SAVE,FileAccess.WRITE)
 if file:file.store_string(raw);file.close()
 if OS.has_feature("web"):JavaScriptBridge.eval("try{localStorage.setItem('ashen_reliquary_v1',"+JSON.stringify(raw)+")}catch(e){}",true)
func load_save():
 var data=null
 if OS.has_feature("web"):
  var raw=JavaScriptBridge.eval("(()=>{try{return localStorage.getItem('ashen_reliquary_v1')||''}catch(e){return ''}})()",true)
  if raw is String and not raw.is_empty():data=JSON.parse_string(raw)
 if not data is Dictionary and FileAccess.file_exists(SAVE):data=JSON.parse_string(FileAccess.get_file_as_string(SAVE))
 if data is Dictionary:profile.merge(data.get("profile",{}),true);saved_run=data.get("run",{})
func restore_run(data):
 clear_entities();r=data.r;pos=Vector3(data.pos[0],0,data.pos[1]);choices=data.get("choices",[]);cooldown.merge(data.get("cooldown",{}),true)
 for e in data.enemies:
  var a=spawn_enemy(int(e.kind),Vector3(e.p[0],0,e.p[1]),e.boss);if a:a.hp=e.hp
 for d in data.drops:drop(int(d.kind),Vector3(d.p[0],0,d.p[1]),int(d.value))
func _notification(n):
 if n==NOTIFICATION_APPLICATION_FOCUS_OUT and mode=="play":set_mode("pause");save_game()
