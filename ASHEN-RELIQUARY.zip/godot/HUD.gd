extends Control
var world
var font=ThemeDB.fallback_font
var title_font=preload("res://art/Cinzel.ttf")
var icon_frame=preload("res://art/icon_frame.png")
var icon_textures={}
var buttons=[]
var joystick=-1
var stick=Vector2.ZERO
var flash=0.0
var ink=Color("e6d5ac")
var muted=Color("a19788")
func _ready():
 for key in ["blade","power","dash","bow","nova","pulse","bolt","orbs","vitality","heart","regen","magnet","fortune","relic"]:icon_textures[key]=load("res://art/"+key+".png")
 set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);mouse_filter=Control.MOUSE_FILTER_IGNORE
func _process(dt):flash=maxf(0,flash-dt);queue_redraw()
func text(t,p,size=17,c=Color("e6d5ac")):draw_string(font,p,str(t),HORIZONTAL_ALIGNMENT_LEFT,-1,size,c)
func centered(t,x,y,size=20,c=Color("e6d5ac")):
 var f=title_font if size>=22 else font;var width=f.get_string_size(str(t),HORIZONTAL_ALIGNMENT_LEFT,-1,size).x;draw_string(f,Vector2(x-width/2,y),str(t),HORIZONTAL_ALIGNMENT_LEFT,-1,size,c)
func panel(r):
 var b=StyleBoxFlat.new();b.bg_color=Color("181c23f5");b.border_color=Color("887256");b.set_border_width_all(2);b.set_corner_radius_all(3);draw_style_box(b,r);draw_rect(Rect2(r.position+Vector2(5,5),r.size-Vector2(10,10)),Color("433e36"),false,1)
 for x in [r.position.x,r.end.x]:
  for y in [r.position.y,r.end.y]:draw_colored_polygon(PackedVector2Array([Vector2(x-5,y),Vector2(x,y-5),Vector2(x+5,y),Vector2(x,y+5)]),Color("bc9b63"))
func button(id,label,r,active=true,sub=""):
 draw_rect(r,Color("3b3430") if active else Color("25272e"));draw_rect(r,Color("b19460") if active else Color("605747"),false,2);var size=17 if label.length()<23 else 14;centered(label,r.get_center().x,r.get_center().y+5-(8 if not sub.is_empty() else 0),size,ink if active else muted)
 if not sub.is_empty():centered(sub,r.get_center().x,r.end.y-10,12,muted)
 buttons.append({"id":id,"r":r})
func icon(key,p,r=18.0):
 if icon_textures.has(key):
  draw_texture_rect(icon_frame,Rect2(p-Vector2.ONE*(r+3),Vector2.ONE*(r+3)*2),false);draw_texture_rect(icon_textures[key],Rect2(p-Vector2.ONE*r,Vector2.ONE*r*2),false);return
 var c=Color("cab48b")
 if key in ["blade","power","dash"]:
  draw_line(p+Vector2(-r*.6,r*.65),p+Vector2(r*.7,-r*.8),Color("9cadb1"),5);draw_line(p+Vector2(-r*.55,-r*.1),p+Vector2(r*.1,r*.5),c,4);draw_circle(p+Vector2(-r*.6,r*.65),3,c)
 elif key=="bow":draw_arc(p+Vector2(-r*.3,0),r*.8,-1.2,1.2,14,c,3);draw_line(p+Vector2(0,-r*.75),p+Vector2(0,r*.75),c,1);draw_line(p+Vector2(-r*.8,0),p+Vector2(r*.8,0),Color("9cadb1"),2)
 elif key in ["nova","pulse"]:
  draw_colored_polygon(PackedVector2Array([p+Vector2(-r*.7,r*.8),p+Vector2(-r*.65,-r*.2),p+Vector2(-r*.1,-r*.9),p+Vector2(r*.1,-r*.1),p+Vector2(r*.5,-r*.6),p+Vector2(r*.8,r*.8)]),Color("cc8a56"));draw_circle(p+Vector2(0,r*.4),r*.3,Color("e2bd7c"))
 elif key=="bolt":draw_colored_polygon(PackedVector2Array([p+Vector2(r*.3,-r),p+Vector2(-r*.65,r*.1),p+Vector2(0,r*.05),p+Vector2(-r*.3,r),p+Vector2(r*.7,-r*.1),p+Vector2(r*.1,-r*.1)]),Color("a9d6d7"))
 elif key=="orbs":
  draw_arc(p,r*.8,0,TAU,28,Color("9aafbe"),2)
  for i in 3:var a=i*TAU/3;draw_circle(p+Vector2(sin(a),cos(a))*r*.8,4,c)
 elif key in ["vitality","heart","regen"]:
  draw_circle(p+Vector2(-r*.25,-r*.2),r*.45,Color("b56566"));draw_circle(p+Vector2(r*.25,-r*.2),r*.45,Color("b56566"));draw_colored_polygon(PackedVector2Array([p+Vector2(-r*.7,-r*.05),p+Vector2(r*.7,-r*.05),p+Vector2(0,r*.85)]),Color("b56566"))
 else:draw_colored_polygon(PackedVector2Array([p+Vector2(0,-r),p+Vector2(r*.65,0),p+Vector2(0,r),p+Vector2(-r*.65,0)]),Color("b498c7"));draw_line(p+Vector2(0,-r*.7),p+Vector2(r*.4,0),Color("e2cde9"),2)
func joy_center():var v=get_viewport_rect().size;return Vector2(84,v.y-114)
func _draw():
 buttons=[];var v=get_viewport_rect().size;var w=v.x;var h=v.y;var m=world.mode;var r=world.r;var p=world.profile
 if m not in ["title","forge","help"]:
  panel(Rect2(13,12,205,68));draw_rect(Rect2(26,45,176,16),Color("443237"));draw_rect(Rect2(26,45,176*clampf(float(r.hp)/world.max_hp(),0,1),16),Color("a3585a"));text("%d / %d"%[int(r.hp),world.max_hp()],Vector2(28,37),14);text("LV %d"%int(r.level),Vector2(154,37),14);draw_rect(Rect2(26,66,176,4),Color("42474a"));draw_rect(Rect2(26,66,176*minf(1,float(r.xp)/world.xp_need()),4),Color("86b6b6"))
  panel(Rect2(w-177,12,164,68));text("%02d:%02d"%[int(r.time/60),int(r.time)%60],Vector2(w-163,37),22);text("%d KILLS   $%d"%[r.kills,r.gold],Vector2(w-162,64),12)
  var i=0
  for key in ["blade","bow","nova","orbs","bolt"]:
   if r.skills[key]>0:icon(key,Vector2(32+i*43,108),13);text(str(r.skills[key]),Vector2(43+i*43,119),11);i+=1
 if m=="play":
  var joy=joy_center();draw_circle(joy,58,Color("141c2599"));draw_arc(joy,58,0,TAU,40,Color("bba477aa"),2);draw_circle(joy+stick*33,22,Color("aa9362aa"))
  button("dash","DASH",Rect2(w-99,h-112,85,76),world.dash_cd<=0,str(ceil(world.dash_cd))+"s" if world.dash_cd>0 else "Invulnerable")
  button("pulse","BURST",Rect2(w-99,h-201,85,76),world.pulse_cd<=0,str(ceil(world.pulse_cd))+"s" if world.pulse_cd>0 else "Clear space")
  button("pause","II",Rect2(w-78,90,64,64),false)
  if r.relic>=0 and not r.retrieved:
   if world.pos.distance_to(world.WELL)<3:button("retrieve","SECURE RELIC",Rect2(w/2-115,h-100,230,60))
   else:
    var a=world.camera.unproject_position(world.WELL+Vector3.UP*1);var safe=Vector2(clampf(a.x,28,w-28),clampf(a.y,151,h-225));draw_circle(safe,13,Color("141c25cc"));icon("relic",safe,9);text("WELL",safe+Vector2(-18,27),11)
  if r.time<8:centered("Move. Your weapons strike automatically.",w/2,150,14)
  var boss=null
  for e in world.enemies:if e.boss:boss=e;break
  if boss:
   var bw=minf(w*.66,420);var y=143;draw_rect(Rect2(w/2-bw/2,y,bw,9),Color("412f35"));draw_rect(Rect2(w/2-bw/2,y,bw*maxf(0,boss.hp/boss.max_hp),9),Color("b67d57"));centered("THE ASHEN LORD",w/2,y-7,12)
 elif m=="title":
  draw_rect(Rect2(Vector2.ZERO,v),Color("10141a88"));var pr=Rect2(w/2-minf(w*.43,275),h*.19,minf(w*.86,550),minf(h*.76,410));panel(pr);centered("ASHEN",w/2,pr.position.y+64,42);centered("RELIQUARY",w/2,pr.position.y+108,34);centered("Survive · Ascend · Recover",w/2,pr.position.y+147,15,muted)
  var cw=(pr.size.x-40)/3
  for i in 3:button("hero%d"%i,["KNIGHT","RANGER","WARLOCK"][i],Rect2(pr.position.x+16+i*cw,pr.position.y+172,cw-6,62),p.character==i,"LOCKED" if i==2 and p.relics.is_empty() else "")
  button("begin","CONTINUE DESCENT" if r.active else "ENTER THE HALL",Rect2(w/2-145,pr.end.y-148,290,62));button("forge","BLESSINGS · $%d"%p.gold,Rect2(w/2-145,pr.end.y-76,290,62),false)
 elif m=="choice":
  draw_rect(Rect2(Vector2.ZERO,v),Color("11131c99"));centered("CHOOSE YOUR POWER",w/2,h*.20,26);centered("LEVEL %d"%(r.level+1),w/2,h*.20+28,14,muted)
  var portrait=w<h;var cw=minf((w-70)/3,250) if not portrait else minf(w-50,430)
  for i in world.choices.size():
   var key=world.choices[i];var pr=Rect2(w/2-cw/2,h*.20+63+i*112,cw,98) if portrait else Rect2(w/2-cw*1.5-10+i*(cw+10),h*.20+62,cw,225);panel(pr)
   icon(key,pr.position+Vector2(35,pr.size.y/2 if portrait else 47),22)
   if portrait:text(world.SKILLS[key][0],pr.position+Vector2(67,33),17);text(world.SKILLS[key][1],pr.position+Vector2(67,58),12,muted);text("RANK %d > %d"%[r.skills[key],r.skills[key]+1],pr.position+Vector2(67,79),12)
   else:centered(world.SKILLS[key][0],pr.get_center().x,pr.position.y+98,16);centered(world.SKILLS[key][1],pr.get_center().x,pr.position.y+125,12,muted);centered("RANK %d > %d"%[r.skills[key],r.skills[key]+1],pr.get_center().x,pr.position.y+154,13)
   buttons.append({"id":"choose:"+key,"r":pr})
 elif m=="pause":
  var pr=Rect2(w/2-180,h/2-190,360,380);panel(pr);centered("THE HALL CAN WAIT",w/2,pr.position.y+44,24);button("close","RESUME",Rect2(w/2-148,pr.position.y+65,296,62));button("mute","SOUND · OFF" if p.muted else "SOUND · ON",Rect2(w/2-148,pr.position.y+134,144,62),false);button("quality","SHADOWS",Rect2(w/2+5,pr.position.y+134,143,62),not p.low);button("help","HOW TO PLAY",Rect2(w/2-148,pr.position.y+202,296,62),false);button("retire","RETURN · BANK $%d"%r.gold,Rect2(w/2-148,pr.end.y-83,296,61))
 elif m=="forge":
  var pr=Rect2(w/2-minf(w*.44,270),h*.16,minf(w*.88,540),minf(h*.74,400));panel(pr);centered("THE SHRINE",w/2,pr.position.y+43,30);centered("$%d · PERMANENT BLESSINGS"%p.gold,w/2,pr.position.y+76,14,muted)
  for i in 3:
   var key=["power","heart","fortune"][i];var level=int(p[key]);var cost=[25,20,30][i]*(level+1);var rect=Rect2(pr.position.x+16,pr.position.y+94+i*68,pr.size.x-32,59);button("buy:"+key,(key.to_upper()+" · MAX") if level>=5 else "%s %d · $%d"%[key.to_upper(),level+1,cost],rect,p.gold>=cost and level<5,["All attacks hit harder","Start with more health","More gold drops"][i]);icon(key,rect.position+Vector2(28,29),16)
  centered("%d RELICS RECOVERED · %d RUNS"%[p.relics.size(),p.runs],w/2,pr.end.y-94,13,muted);button("title","BACK",Rect2(w/2-100,pr.end.y-75,200,61),false)
 elif m in ["victory","defeat"]:
  draw_rect(Rect2(Vector2.ZERO,v),Color("10141a88"));var pr=Rect2(w/2-185,h/2-182,370,364);panel(pr);centered("LORDS VANQUISHED" if m=="victory" else "THE FLAME ENDURES",w/2,pr.position.y+47,24);centered("%d KILLS · LEVEL %d"%[r.kills,r.level],w/2,pr.position.y+105,17);centered("+$%d BANKED"%r.gold,w/2,pr.position.y+152,26);centered("Recovered relics and blessings carry forward.",w/2,pr.position.y+190,13,muted)
  if m=="victory":button("endless","DESCEND FURTHER",Rect2(w/2-145,pr.end.y-136,290,62))
  button("title","RETURN TO SHRINE",Rect2(w/2-145,pr.end.y-67,290,62),false)
 elif m=="help":
  var pr=Rect2(w/2-minf(w*.45,290),h*.14,minf(w*.9,580),h*.76);panel(pr);centered("A SIMPLE DESCENT",w/2,pr.position.y+42,25)
  var lines=["Move with the stick or WASD. Attacks are automatic.","Collect blue souls. Choose a power when you level up.","DASH avoids hits. BURST pushes enemies away.","Lords appear at 1:05, 2:20 and 3:45.","Take purple relics to the well before you fall.","Gold banks after a run. Buy permanent blessings."]
  for i in lines.size():centered(lines[i],w/2,pr.position.y+83+i*36,14 if w>700 else 12,muted)
  button("close","READY",Rect2(w/2-120,pr.end.y-67,240,62))
 if world.notice_time>0:centered(world.notice,w/2,h-235,13)
 if flash>0:draw_rect(Rect2(Vector2.ZERO,v),Color(.55,.12,.11,flash))
func unlock_audio():
 if world.music and not world.music.playing and not world.profile.muted:world.music.play()
func act(id):
 unlock_audio()
 if id.begins_with("choose:"):world.upgrade(id.substr(7));return
 if id.begins_with("buy:"):world.buy(id.substr(4));return
 if id.begins_with("hero"):world.character(int(id.substr(4)));return
 match id:
  "begin":world.start()
  "close":world.set_mode("play")
  "pause":world.set_mode("pause");world.save_game()
  "dash":world.dash()
  "pulse":world.pulse()
  "retrieve":world.retrieve()
  "forge","help":world.set_mode(id)
  "retire":world.end_run()
  "title":world.set_mode("title")
  "endless":world.r.banked=false;world.r.gold=0;world.r.active=true;world.set_mode("play");world.save_game()
  "mute":world.profile.muted=not world.profile.muted;world.music.stream_paused=world.profile.muted;world.save_game()
  "quality":world.profile.low=not world.profile.low;world.sun.shadow_enabled=not world.profile.low;world.save_game()
func pointer(p,pressed,id):
 if not pressed:
  if id==joystick:joystick=-1;stick=Vector2.ZERO;world.move_vec=Vector2.ZERO
  return
 for b in buttons:
  if b.r.has_point(p):act(b.id);return
 if world.mode=="play" and p.distance_to(joy_center())<80:joystick=id;move_stick(p)
func move_stick(p):stick=((p-joy_center())/40).limit_length(1);world.move_vec=stick
func _input(e):
 if e is InputEventScreenTouch:pointer(e.position,e.pressed,e.index)
 elif e is InputEventScreenDrag and e.index==joystick:move_stick(e.position)
 elif e is InputEventMouseButton and e.button_index==MOUSE_BUTTON_LEFT:pointer(e.position,e.pressed,99)
 elif e is InputEventMouseMotion and joystick==99:move_stick(e.position)
 elif e is InputEventKey and e.pressed and not e.echo:
  if e.keycode==KEY_SPACE:act("dash")
  elif e.keycode==KEY_E:act("pulse")
  elif e.keycode==KEY_R:act("retrieve")
  elif e.keycode==KEY_ENTER:act("begin" if world.mode=="title" else "close" if world.mode in ["pause","help"] else "")
  elif e.keycode==KEY_ESCAPE:act("pause" if world.mode=="play" else "close")
  elif world.mode=="choice" and e.keycode in [KEY_1,KEY_2,KEY_3]:
   var i=e.keycode-KEY_1;if i<world.choices.size():act("choose:"+world.choices[i])
