extends SceneTree
func _initialize():call_deferred("run")
func own(n,r):
 for c in n.get_children():c.owner=r;own(c,r)
func run():
 var w=load("res://World.tscn").instantiate();root.add_child(w);await process_frame
 var scene=Node3D.new();scene.name="AshenReliquary";scene.set_script(load("res://World.gd"));var preview=Node3D.new();preview.name="EditorPreview";scene.add_child(preview);preview.add_child(w.map_root.duplicate());preview.add_child(w.sun.duplicate())
 for c in w.get_children():
  if c is WorldEnvironment:preview.add_child(c.duplicate())
 var camera=w.camera.duplicate();camera.position=Vector3(0,17,17);preview.add_child(camera);preview.add_child(w.hero.duplicate())
 for e in w.enemies:preview.add_child(e.node.duplicate())
 own(scene,scene);var packed=PackedScene.new();packed.pack(scene);ResourceSaver.save(packed,"res://World.tscn");scene.free();w.queue_free();await process_frame;print("Editable 2.5D crypt baked");quit()
