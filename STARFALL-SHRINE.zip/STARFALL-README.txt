STARFALL SHRINE

A mobile-friendly HTML5 arcade game with original art.

HOW TO PLAY
Choose a star cost, then tap a lane on the board or press DROP STAR.
Watch the star bounce through the shrine and land in a visible multiplier chamber.
Tap the left or right side of the board once during a drop to nudge its path.
Every fifth drop is a Fever Drop. Every five drops begins a new night.

CONTROLS
Touch: tap a lane to drop; tap left or right to nudge once.
Keyboard: Left/Right to aim or nudge; Space to drop or nudge.

Stars are fictional in-game tokens. No purchase or real-money payout.
All game files must stay in one folder. Open starfall-shrine.html in a modern browser.
