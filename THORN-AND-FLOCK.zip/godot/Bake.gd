extends SceneTree
func _initialize():call_deferred("bake")
func bake():
 var g=load("res://Main.tscn").instantiate();root.add_child(g);await process_frame
 var r=Node2D.new();r.name="ThornAndFlock";r.set_script(load("res://Game.gd"))
 var p=Node2D.new();p.name="EditorPreview";r.add_child(p);p.owner=r
 var ground=Polygon2D.new();ground.name="GrassClearing";ground.polygon=PackedVector2Array([Vector2(30,70),Vector2(870,70),Vector2(870,550),Vector2(30,550)]);ground.color=Color("6d7562");p.add_child(ground);ground.owner=r
 var floor=Sprite2D.new();floor.name="PaintedGround";floor.texture=g.art["ground-camp"];floor.position=Vector2(450,290);p.add_child(floor);floor.owner=r
 var obj=g.decor.duplicate();obj.append_array(g.props)
 obj.append({"k":"lamb0","p":Vector2(450,375),"size":Vector2(98,98)})
 obj.append({"k":"fox0","p":Vector2(330,340),"size":Vector2(65,65)});obj.append({"k":"rabbit0","p":Vector2(400,315),"size":Vector2(65,65)})
 var n=0
 for o in obj:
  n+=1;var a=Sprite2D.new();a.name=o.k.capitalize()+str(n);a.texture=g.art[o.k];a.position=o.p-Vector2(0,o.size.y*.38);a.scale=o.size/a.texture.get_size();a.z_index=int(o.p.y);p.add_child(a);a.owner=r
 var pack=PackedScene.new();pack.pack(r);ResourceSaver.save(pack,"res://Main.tscn");r.free();g.queue_free();await process_frame;quit()
