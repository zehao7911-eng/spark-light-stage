extends CharacterBody2D
var game
var kind=-1
var hp=6.0
var maxhp=6.0
var cd=0.0
var roll_cd=0.0
var inv=0.0
var rolling=0.0
var roll_dir=Vector2.RIGHT
var face=Vector2.RIGHT
var anim=0.0
var wind=0.0
var aim=Vector2.ZERO
var knock=Vector2.ZERO
var stun=0.0
var swing_time=0.0
var combo=0
var dead=false
var enraged=false
func setup(g,k,p):
 game=g;kind=k;position=p;collision_layer=2 if k<0 else 4;collision_mask=1
 var c=CollisionShape2D.new();var s=CircleShape2D.new();s.radius=13 if k<3 else 25;c.shape=s;add_child(c)
 maxhp=float(game.s.maxhp) if k<0 else (8.0+game.m.stage*2 if k<3 else 65.0+game.m.stage*12)
 hp=float(game.s.hp) if k<0 else maxhp
func _physics_process(dt):
 if game.mode not in ["camp","play"] or dead or game.hitstop>0:return
 inv=maxf(0,inv-dt);cd=maxf(0,cd-dt);roll_cd=maxf(0,roll_cd-dt);stun=maxf(0,stun-dt);swing_time=maxf(0,swing_time-dt)
 knock=knock.move_toward(Vector2.ZERO,dt*500);velocity=Vector2.ZERO
 if kind<0:
  var v=game.move_vec
  var k=Input.get_vector("ui_left","ui_right","ui_up","ui_down")
  k+=Vector2(float(Input.is_physical_key_pressed(KEY_D))-float(Input.is_physical_key_pressed(KEY_A)),float(Input.is_physical_key_pressed(KEY_S))-float(Input.is_physical_key_pressed(KEY_W)))
  if k.length()>.1:v=k.normalized()
  if v.length()>.1:face=v.normalized()
  if rolling>0:rolling-=dt;velocity=roll_dir*650;game.spark(position,Color("e99b91"),1)
  else:velocity=v*(160+float(game.s.speed))
  if game.mode=="play":
   if game.attack_held or Input.is_physical_key_pressed(KEY_SPACE):slash()
   if Input.is_physical_key_pressed(KEY_SHIFT):roll()
 else:ai(dt)
 velocity+=knock;move_and_slide();position=position.clamp(Vector2(65,100),Vector2(835,515));anim+=dt*(10 if velocity.length()>5 else 2)
func slash():
 if cd>0 or game.mode!="play":return
 cd=maxf(.18,.38-float(game.s.haste));combo=combo%3+1;swing_time=.2
 var e=game.nearest(position)
 if e and position.distance_to(e.position)<145:face=(e.position-position).normalized()
 var hits=0
 for enemy in game.enemies.duplicate():
  var d=enemy.position-position
  if d.length()<float(game.s.reach)+(20 if combo==3 else 0) and d.normalized().dot(face)>-.2:
   enemy.hurt(float(game.s.damage)*(1.6 if combo==3 else 1),face*210);hits+=1
 if hits>0:game.hitstop=.04;game.shake=.16;game.sound("hit")
 else:game.sound("move")
 for obj in game.props.duplicate():
  if obj.get("break",false) and position.distance_to(obj.p)<game.s.reach:
   game.props.erase(obj);game.spark(obj.p,Color("bf8f74"),9);game.s.wood+=1
func roll():
 if roll_cd>0:return
 roll_cd=maxf(.45,.85-float(game.s.roll));rolling=.23;inv=.32;roll_dir=face;game.sound("move")
func ai(dt):
 if stun>0:return
 var d=game.hero.position-position;face=d.normalized()
 if wind>0:
  wind-=dt
  if wind<=0:
   if kind==1:game.bolt(position,face*180,true,1)
   elif kind>=3:
    for i in (10 if enraged else 7):game.bolt(position,Vector2.RIGHT.rotated(i*TAU/(10 if enraged else 7)+game.t*.25)*(145+mini(3,int(game.m.stage))*15),true,1)
    if int(game.m.stage)>=2:
     for j in 3:game.bolt(position,face.rotated((j-1)*.2)*230,true,1)
    if int(game.m.stage)>=3:
     game.warning(game.hero.position+Vector2(120,0),90,1.1);game.warning(game.hero.position-Vector2(120,0),90,1.1)
    game.warning(game.hero.position,105,.85)
   elif game.hero.position.distance_to(aim)<65:game.hero.hurt(1)
   cd=1.2 if kind<3 else 1.8
  return
 if kind>=3 and not enraged and hp<maxhp*.5:
  enraged=true;game.spawn_enemy(0,position+Vector2(-90,0));game.spawn_enemy(1,position+Vector2(90,0));game.toast("THE WARDEN AWAKENS")
 if kind==1:
  velocity=face*(65 if d.length()>240 else -55 if d.length()<150 else 0)
  if cd<=0:wind=.7;aim=game.hero.position
 elif kind>=3:
  velocity=face*45 if d.length()>170 else Vector2.ZERO
  if cd<=0:wind=1.0;aim=game.hero.position;game.warning(aim,100,.95)
 else:
  velocity=face*(90 if kind==2 else 65)
  if d.length()<65 and cd<=0:wind=.6;aim=game.hero.position;game.warning(aim,58,.6,false)
func hurt(dmg,push=Vector2.ZERO):
 if dead:return
 if kind<0:
  if inv>0:return
  hp-=dmg;inv=.85;game.s.hp=hp;game.flash=.35;game.shake=.3;game.sound("hurt")
 else:
  hp-=dmg;knock=push;stun=.09 if kind<3 else .025;game.spark(position,Color("f98d79"),5);game.floats.append({"p":position,"t":str(int(ceil(dmg))),"life":.7})
 if hp<=0:
  dead=true
  if kind<0:game.finish(false)
  else:game.enemy_dead(self);queue_free()
