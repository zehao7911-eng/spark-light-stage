extends SceneTree
var g
var original=""
func _initialize():call_deferred("run")
func run():
 var path="user://thorn_flock.json"
 if FileAccess.file_exists(path):original=FileAccess.get_file_as_string(path)
 g=load("res://Main.tscn").instantiate();root.add_child(g);await process_frame
 g.m={"followers":2,"wood":12,"berries":8,"faith":12.0,"coins":0,"tents":1,"level":0,"stage":1,"wins":0,"fed":false,"best":0,"armory":0};g.camp()
 g.interact("tent");assert(g.m.tents==2 and g.m.wood==0)
 g.ready_crop=true;g.interact("farm");assert(g.m.berries>8)
 g.interact("kitchen");assert(g.m.fed)
 g.m.faith=15;g.interact("shrine");assert(g.m.level==1 and g.m.faith==0)
 g.venture();assert(not g.m.fed and g.s.damage>4)
 g.hero.inv=0;g.hero.roll();var hp=g.hero.hp;g.hero.hurt(1);assert(g.hero.hp==hp)
 g.hero.rolling=0;g.hero.inv=0
 Engine.max_fps=0;Engine.time_scale=6
 var steps=0;var completed=0;var kills=0
 for i in 14000:
  await physics_frame;steps+=1
  if g.mode=="lost":break
  if g.mode=="victory":
   completed+=1;kills+=g.s.kills
   print("CRUSADE ",completed," rescued=",g.s.rescued," kills=",g.s.kills," hp=",g.hero.hp)
   if completed>=3:break
   g.camp();g.venture()
  if g.mode=="gift":g.gift(0)
  if g.mode!="play":continue
  var e=g.nearest(g.hero.position);g.attack_held=true
  if e:
   var d=e.position-g.hero.position
   g.move_vec=d.normalized() if d.length()>65 else Vector2.ZERO
   if g.s.mana>=3 and d.length()<260:g.magic()
   for h in g.warnings:
    if h.time<.22 and g.hero.position.distance_to(h.p)<h.r+18 and g.hero.roll_cd<=0:
     var away=(g.hero.position-h.p).normalized()
     if away.length()<.1:away=Vector2.RIGHT
     g.hero.face=away;g.move_vec=away;g.hero.roll()
 print("RESULT ",g.mode," completed=",completed," steps=",steps," kills=",kills)
 assert(completed>=1,"Normal-stat agent did not beat first crusade")
 # Regression fixtures for death banking, checkpoint restart and curse spending.
 g.m.coins=12;g.interact("armory");assert(g.m.armory==1 and g.m.coins==0)
 g.camp();g.venture();g.s.wood=10;g.s.coins=10;g.s.rescued=1;var old=g.m.wood;var friends=g.m.followers
 g.finish(false);assert(g.m.wood==old+5 and g.m.followers==friends+1)
 g.finish(false);assert(g.m.wood==old+5)
 g.camp();g.venture();g.s.mana=4;g.magic();assert(g.s.mana==1)
 g.checkpoint=g.s.duplicate(true);g.save_game();g.load_save();assert(g.checkpoint.room==1)
 print("PASS farm, cook, tent, devotion, roll, banking, checkpoint, curse")
 g.queue_free();await process_frame
 var f=FileAccess.open(path,FileAccess.WRITE);f.store_string(original);f.close();quit()

