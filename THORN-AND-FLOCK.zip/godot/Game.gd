extends Node2D
const Actor=preload("res://Actor.gd")
const SAVE="user://thorn_flock.json"
const GIFTS=[["SHARP THORN","Blade +25%","damage"],["LONG REACH","Larger slash","reach"],["FLEET FLEECE","Faster movement","speed"],["QUICK HAND","Faster combo","haste"],["MOON STEP","Quicker roll","roll"],["RED HEART","Health +1; heal 2","heart"],["SOUL HARVEST","Heal every 5 defeats","vampire"],["GOLDEN TONGUE","Extra coins","gold"],["WILD FIRE","Curse burns harder","magic"]]
var m={"followers":2,"wood":12,"berries":8,"faith":12.0,"coins":0,"tents":1,"level":0,"stage":1,"wins":0,"fed":false,"best":0,"armory":0}
var s:Dictionary={}
var checkpoint:Dictionary={}
var mode="title"
var previous="camp"
var hero
var enemies:Array=[]
var props:Array=[]
var decor:Array=[]
var particles:Array=[]
var bolts:Array=[]
var warnings:Array=[]
var floats:Array=[]
var followers:Array=[]
var art:Dictionary={}
var audio:Array=[]
var sounds:Dictionary={}
var rng=RandomNumberGenerator.new()
var move_vec=Vector2.ZERO
var attack_held=false
var touches:Dictionary={}
var joy_id=-1
var joy_start=Vector2.ZERO
var cam=Vector2(450,310)
var zoom=1.0
var t=0.0
var hitstop=0.0
var shake=0.0
var flash=0.0
var crop=0.0
var ready_crop=false
var ritual=0.0
var notice=""
var notice_time=0.0
var offer:Array=[]
var buttons:Array=[]
var muted=false
var bridge_timer=0.0
var autosave=0.0
var font:Font=ThemeDB.fallback_font
var display_font:Font
var music:AudioStreamPlayer
func _ready():
 if has_node("EditorPreview"):get_node("EditorPreview").queue_free()
 Engine.max_fps=30;rng.randomize()
 display_font=load("res://art/Cinzel.ttf")
 music=AudioStreamPlayer.new();music.stream=load("res://audio/ambient.wav");music.stream.loop_mode=AudioStreamWAV.LOOP_FORWARD;music.stream.loop_end=int(music.stream.get_length()*22050);music.volume_db=-22;add_child(music)
 for k in ["lamb","fox","rabbit","cat","frog","cultist","archer","brute","warden"]:
  for f in 3:art[k+str(f)]=load("res://art/"+k+str(f)+".png")
 for k in ["armory","pine","thorn","shrine","tent","farm","kitchen","gate","rock","cage","stump","ground-camp","ground-forest","glow","fern"]:art[k]=load("res://art/"+k+".png")
 for stage in [2,3]:
  for frame in 3:art["warden"+str(stage)+"_"+str(frame)]=load("res://art/warden"+str(stage)+"_"+str(frame)+".png")
 for n in ["shot","move","hit","coin","hurt"]:sounds[n]=load("res://audio/"+n+".wav")
 for i in 6:
  var a=AudioStreamPlayer.new();a.volume_db=-17;add_child(a);audio.append(a)
 for r in [Rect2(40,50,820,25),Rect2(40,540,820,25),Rect2(30,60,25,490),Rect2(845,60,25,490)]:
  var b=StaticBody2D.new();b.position=r.get_center();var c=CollisionShape2D.new();var q=RectangleShape2D.new();q.size=r.size;c.shape=q;b.add_child(c);add_child(b)
 load_save();default_state();camp();mode="title";get_viewport().size_changed.connect(resize);resize()
func resize():
 var a=DisplayServer.window_get_size();var v=Vector2i(480,800) if a.x<a.y*1.1 else Vector2i(900,500)
 if get_viewport().content_scale_size!=v:get_viewport().content_scale_size=v
 queue_redraw()
func default_state():
 s={"room":1,"hp":6+int(int(m.level)/2),"maxhp":6+int(int(m.level)/2),"damage":3.5+int(m.armory)*.5+int(m.level)*.6+(1 if m.fed else 0),"reach":95.0,"speed":0.0,"haste":0.0,"roll":0.0,"vampire":false,"gold":false,"magic":1.0,"mana":4,"wood":0,"coins":0,"kills":0,"rescued":0,"paid":false}
func clear():
 if is_instance_valid(hero):hero.queue_free()
 for e in enemies:if is_instance_valid(e):e.queue_free()
 enemies=[];bolts=[];warnings=[];particles=[];props=[];floats=[];move_vec=Vector2.ZERO;attack_held=false;touches={};joy_id=-1;hitstop=0
func new_hero(p):
 hero=Actor.new();add_child(hero);hero.setup(self,-1,p)
func scenery():
 decor=[];rng.seed=102+int(m.stage)*117+int(s.room)*89
 for i in 25:
  var p=Vector2(35+i*35,rng.randf_range(24,80));decor.append({"k":"pine","p":p,"size":Vector2(135,173)})
 for side in [0,1]:
  for i in 9:decor.append({"k":"pine","p":Vector2(30+side*840,110+i*53),"size":Vector2(145,186)})
 for i in 18:decor.append({"k":"fern","p":Vector2(65+fmod(i*137,780),485+fmod(i*31,50)),"size":Vector2(82,82)})
 for i in 16:
  var p=Vector2(rng.randf_range(60,840),rng.randf_range(510,570));decor.append({"k":"thorn","p":p,"size":Vector2(72,82)})
func camp():
 clear();default_state();scenery();new_hero(Vector2(450,375));mode="camp";cam=Vector2(450,310)
 props=[{"k":"shrine","p":Vector2(450,235),"size":Vector2(170,194),"id":"shrine","label":"DEVOTION"},{"k":"farm","p":Vector2(220,400),"size":Vector2(170,194),"id":"farm","label":"HARVEST"},{"k":"kitchen","p":Vector2(680,405),"size":Vector2(145,166),"id":"kitchen","label":"COOK"},{"k":"gate","p":Vector2(740,225),"size":Vector2(140,160),"id":"venture","label":"CRUSADE"},{"k":"stump","p":Vector2(145,250),"size":Vector2(105,120),"id":"wood","label":"CHOP"}]
 props.append({"k":"armory","p":Vector2(680,480),"size":Vector2(104,119),"id":"armory","label":"ARMORY"})
 for i in int(m.tents):props.append({"k":"tent","p":Vector2(240+i*110,485),"size":Vector2(105,120),"id":"tent","label":"BUILD"})
 followers=[]
 for i in int(m.followers):followers.append({"k":["fox","rabbit","cat","frog"][i%4],"p":Vector2(310+(i%4)*80,330+int(i/4)*60),"phase":i*1.73})
 save_game()
func venture():
 default_state();m.fed=false;enter_room();toast("FOLLOW THE RED CROWN")
func enter_room():
 clear();scenery();new_hero(Vector2(450,440));mode="play";cam=Vector2(450,310)
 checkpoint=s.duplicate(true);save_game()
 for p in [Vector2(210,230),Vector2(690,245),Vector2(210,430)]:props.append({"k":"stump","p":p,"size":Vector2(70,80),"break":true})
 if int(s.room)==4:
  spawn_enemy(3,Vector2(450,235));props.append({"k":"shrine","p":Vector2(450,145),"size":Vector2(170,194)})
 else:
  props.append({"k":"cage","p":Vector2(450,200),"size":Vector2(110,126)})
  var n=mini(7,2+int(m.stage)+int(s.room))
  for i in n:spawn_enemy(i%3,Vector2(150+i*600.0/maxi(1,n-1),rng.randf_range(240,350)))
func spawn_enemy(k,p):
 var e=Actor.new();add_child(e);e.setup(self,k,p.clamp(Vector2(80,120),Vector2(820,490)));enemies.append(e);return e
func nearest(p):
 var result=null;var dist=1e9
 for e in enemies:
  if not e.dead and e.position.distance_squared_to(p)<dist:result=e;dist=e.position.distance_squared_to(p)
 return result
func enemy_dead(e):
 enemies.erase(e);s.kills+=1;s.coins+=2 if e.kind<3 else 12;s.wood+=1; s.mana=mini(4,int(s.mana)+1)
 if s.gold:s.coins+=1
 if s.vampire and int(s.kills)%5==0:hero.hp=minf(hero.maxhp,hero.hp+1)
 spark(e.position,Color("f0d1a8"),12)
 if enemies.is_empty():
  if int(s.room)==4:finish(true)
  else:
   s.rescued+=1;hero.hp=minf(hero.maxhp,hero.hp+.5);s.hp=hero.hp;mode="gift";reset_input();offer=[]
   while offer.size()<3:
    var n=rng.randi_range(0,GIFTS.size()-1)
    if n not in offer:offer.append(n)
   sound("coin");toast("A NEW FRIEND IS FREE")
func gift(i):
 var key=GIFTS[int(offer[i])][2]
 match key:
  "damage":s.damage*=1.25
  "reach":s.reach=minf(150,s.reach+15)
  "speed":s.speed=minf(70,s.speed+20)
  "haste":s.haste=minf(.16,s.haste+.04)
  "roll":s.roll=minf(.4,s.roll+.1)
  "heart":s.maxhp+=1;s.hp=minf(s.maxhp,hero.hp+2)
  "magic":s.magic*=1.3
  _:s[key]=true
 s.room+=1;enter_room()
func magic():
 if mode!="play" or s.mana<3:return
 s.mana-=3;var e=nearest(hero.position);var dir=hero.face if not e else (e.position-hero.position).normalized()
 for i in 3:bolt(hero.position,dir.rotated((i-1)*.16)*420,false,7*s.magic)
 sound("shot");shake=.16
func bolt(p,v,enemy,damage):
 if bolts.size()<50:bolts.append({"p":p,"v":v,"enemy":enemy,"damage":damage,"life":3.0})
func warning(p,r,delay,hurt=true):warnings.append({"p":p,"r":r,"time":delay,"max":delay,"hurt":hurt})
func spark(p,c,n):
 for i in n:
  if particles.size()>100:break
  particles.append({"p":p,"v":Vector2.RIGHT.rotated(rng.randf()*TAU)*rng.randf_range(20,130),"c":c,"life":rng.randf_range(.25,.7)})
func finish(won):
 if not s.paid:
  m.wood+=int(s.wood) if won else int(s.wood)/2;m.coins+=int(s.coins) if won else int(s.coins)/2;m.followers+=int(s.rescued);s.paid=true
  if won:m.wins+=1;m.stage+=1;m.best=maxi(m.best,m.stage-1)
 mode="victory" if won else "lost";reset_input();checkpoint={};save_game();sound("coin" if won else "hurt")
func interact(id):
 match id:
  "venture":venture()
  "farm":
   if ready_crop:m.berries+=4+int(m.followers)/2;ready_crop=false;crop=0;sound("coin");spark(Vector2(220,390),Color("e9a48d"),15);toast("FRESH BERRIES")
   else:toast("GROWING · "+str(int(20-crop))+"s")
  "kitchen":
   if m.berries>=3:m.berries-=3;m.fed=true;hero.hp=hero.maxhp;ritual=1.5;sound("coin");toast("FED · NEXT CRUSADE +1 DAMAGE")
   else:toast("NEED 3 BERRIES")
  "wood":
   if ritual<=0:m.wood+=2;ritual=1.5;sound("hit");spark(Vector2(145,250),Color("c19c7b"),8);toast("+2 WOOD")
  "tent":
   var cost=8+int(m.tents)*4
   if m.wood>=cost and int(m.tents)<4:m.wood-=cost;m.tents+=1;camp();toast("A NEW HOME")
   else:toast("NEED "+str(cost)+" WOOD" if m.tents<4 else "CAMP COMPLETE")
  "armory":
   var cost=12+int(m.armory)*8
   if m.coins>=cost and m.armory<5:m.coins-=cost;m.armory+=1;sound("coin");toast("BLADE TEMPERED")
   else:toast("NEED "+str(cost)+" COINS" if m.armory<5 else "BLADE COMPLETE")
  "shrine":
   var cost=15+int(m.level)*10
   if m.faith>=cost and m.level<8:m.faith-=cost;m.level+=1;ritual=2;sound("coin");spark(Vector2(450,230),Color("ffa284"),30);toast("CROWN STRENGTHENED")
   else:toast("NEED "+str(cost)+" DEVOTION")
 save_game()
func act_near():
 var best=null;var d=140.0
 for p in props:
  if p.has("id") and hero.position.distance_to(p.p)<d:best=p;d=hero.position.distance_to(p.p)
 if best:interact(best.id)
 else:toast("APPROACH A BUILDING")
func reset_input():move_vec=Vector2.ZERO;attack_held=false;touches={};joy_id=-1
func toast(a):notice=a;notice_time=2.3
func sound(n):
 if muted:return
 for a in audio:
  if not a.playing:a.stream=sounds[n];a.play();return
func save_game():
 var data=JSON.stringify({"m":m,"checkpoint":checkpoint,"muted":muted,"crop":crop,"ready":ready_crop})
 var f=FileAccess.open(SAVE,FileAccess.WRITE)
 if f:f.store_string(data);f.close()
 if OS.has_feature("web"):JavaScriptBridge.eval("try{localStorage.setItem('thorn_flock_v1',"+JSON.stringify(data)+")}catch(e){}",true)
func load_save():
 var d=null
 if OS.has_feature("web"):
  var raw=JavaScriptBridge.eval("(()=>{try{return localStorage.getItem('thorn_flock_v1')||''}catch(e){return ''}})()",true)
  if raw is String and not raw.is_empty():d=JSON.parse_string(raw)
 if not d is Dictionary and FileAccess.file_exists(SAVE):d=JSON.parse_string(FileAccess.get_file_as_string(SAVE))
 if d is Dictionary:m.merge(d.get("m",{}),true);checkpoint=d.get("checkpoint",{});muted=d.get("muted",false);crop=d.get("crop",0);ready_crop=d.get("ready",false)
func _physics_process(dt):
 hitstop=maxf(0,hitstop-dt)
 if mode!="play" or hitstop>0:return
 for b in bolts.duplicate():
  b.p+=b.v*dt;b.life-=dt;var hit=false
  if b.enemy:
   if b.p.distance_to(hero.position)<20:hero.hurt(b.damage);hit=true
  else:
   for e in enemies.duplicate():
    if b.p.distance_to(e.position)<(42 if e.kind>=3 else 22):e.hurt(b.damage,b.v.normalized()*130);hit=true;break
  if hit or b.life<=0 or not Rect2(50,70,800,490).has_point(b.p):bolts.erase(b)
 for h in warnings.duplicate():
  h.time-=dt
  if h.time<=0:
   if h.hurt and hero.position.distance_to(h.p)<h.r:hero.hurt(1)
   spark(h.p,Color("d35865"),8);warnings.erase(h)
func _process(dt):
 t+=dt;bridge_timer+=dt;autosave+=dt;
 if autosave>10:autosave=0;save_game()
 shake=maxf(0,shake-dt);flash=maxf(0,flash-dt);notice_time=maxf(0,notice_time-dt);ritual=maxf(0,ritual-dt)
 if mode=="camp":
  m.faith=minf(999,m.faith+dt*.28*mini(int(m.followers),int(m.tents)*3));crop=minf(20,crop+dt);ready_crop=crop>=20
  for f in followers:f.p+=Vector2(sin(t*.6+f.phase),cos(t*.8+f.phase))*dt*9;f.p=f.p.clamp(Vector2(270,280),Vector2(640,450))
 if mode in ["camp","play"]:
  cam=cam.lerp(hero.position.lerp(Vector2(450,310),.15),minf(1,dt*3))
  for p in particles.duplicate():
   p.life-=dt;p.p+=p.v*dt;p.v*=.96
   if p.life<=0:particles.erase(p)
  for f in floats.duplicate():
   f.life-=dt;f.p.y-=dt*50
   if f.life<=0:floats.erase(f)
 queue_redraw()
 if OS.has_feature("web") and bridge_timer>.3:
  bridge_timer=0;var es=[]
  for e in enemies:es.append({"p":[e.position.x,e.position.y],"hp":e.hp,"k":e.kind,"screen":[screen(e.position).x,screen(e.position).y]})
  JavaScriptBridge.eval("window.FlockSnapshot="+JSON.stringify({"mode":mode,"m":m,"s":s,"offer":offer,"viewport":[get_viewport_rect().size.x,get_viewport_rect().size.y],"hero":[hero.position.x,hero.position.y,hero.hp],"enemies":es,"buildings":props.filter(func(p):return p.has("id")).map(func(p):return {"id":p.id,"screen":[screen(p.p).x,screen(p.p).y]})}),true)
func screen(p):return (p-cam)*zoom+get_viewport_rect().size*Vector2(.5,.47)
func _notification(n):
 if n==NOTIFICATION_APPLICATION_FOCUS_OUT and mode in ["play","camp"]:previous=mode;mode="pause";reset_input();save_game()
func label(a,p,n=18,c=Color("f6e6cb"),centered=false,heading=false):
 var ft=display_font if heading and display_font else font
 var x=p.x-ft.get_string_size(str(a),HORIZONTAL_ALIGNMENT_LEFT,-1,n).x/2 if centered else p.x
 draw_string(ft,Vector2(x,p.y),str(a),HORIZONTAL_ALIGNMENT_LEFT,-1,n,c)
func panel(r,c=Color("342735ee")):
 var b=StyleBoxFlat.new();b.bg_color=c;b.border_color=Color("a78080");b.set_border_width_all(2);b.set_corner_radius_all(14);draw_style_box(b,r)
func button(id,a,r):
 panel(r);label(a,r.get_center()+Vector2(0,6),18,Color("f6e6cb"),true);buttons.append({"id":id,"r":r})
func round_button(id,a,p,r):
 draw_circle(p,r+3,Color("281a29"));draw_circle(p,r,Color("8b4053dd"));draw_arc(p,r-3,0,TAU,40,Color("d9a493"),1.5,true);label(a,p+Vector2(0,6),16,Color("fff1dc"),true);buttons.append({"id":id,"r":Rect2(p-Vector2.ONE*r,Vector2.ONE*r*2)})
func sprite(k,p,z,tint=Color.WHITE):
 if not art.has(k):return
 var points=PackedVector2Array()
 for i in 20:points.append(p+Vector2(cos(i*TAU/20)*z.x*.3,sin(i*TAU/20)*z.x*.09))
 draw_colored_polygon(points,Color("24162566"))
 draw_texture_rect(art[k],Rect2(p-Vector2(z.x*.5,z.y*.88),z),false,tint)
func _draw():
 buttons=[];var v=get_viewport_rect().size;zoom=.93 if v.x>v.y else 1.08
 for i in 30:draw_rect(Rect2(0,i*v.y/30,v.x,v.y/30+1),Color("2f2734").lerp(Color("4c303f"),i/30.0))
 var offset=Vector2(sin(t*73),cos(t*67))*shake*11
 draw_set_transform(screen(Vector2.ZERO)+offset,0,Vector2.ONE*zoom)
 var ground=PackedVector2Array([Vector2(35,91),Vector2(200,69),Vector2(400,88),Vector2(620,58),Vector2(868,102),Vector2(878,500),Vector2(740,555),Vector2(565,535),Vector2(340,562),Vector2(91,547),Vector2(28,456)])
 draw_colored_polygon(ground,Color("6d7562") if mode in ["camp","title"] else [Color("645060"),Color("555767"),Color("6d4854")][mini(2,int(m.stage)-1)])
 draw_texture_rect(art["ground-camp" if mode in ["camp","title"] else "ground-forest"],Rect2(0,0,900,580),false)
 for lp in [Vector2(450,220),Vector2(680,390),Vector2(740,220)]:draw_texture_rect(art["glow"],Rect2(lp-Vector2(90,55),Vector2(180,110)),false)
 for i in 25:
  var p=Vector2(390+sin(i*2.4)*30,240+i*12);draw_circle(p,3,Color("d0a89b22"))
 for h in warnings:
  draw_circle(h.p,h.r,Color(.95,.25,.34,.13));draw_arc(h.p,h.r,0,TAU,48,Color("f98b7a"),2,true);draw_arc(h.p,h.r*(1-h.time/h.max),0,TAU,40,Color("ef5a6b"),2,true)
 var objects=decor.duplicate();objects.append_array(props)
 for f in followers if mode in ["camp","title"] else []:objects.append({"k":f.k+str(int(t*3+f.phase)%3),"p":f.p+Vector2(0,sin(t*6+f.phase)*2),"size":Vector2(65,65)})
 for e in enemies:
  objects.append({"k":["cultist","archer","brute","warden"][mini(3,e.kind)]+str(int(e.anim)%3),"p":e.position+Vector2(0,sin(e.anim)*2),"size":Vector2.ONE*(158 if e.kind>=3 else 88),"e":e})
 if is_instance_valid(hero):objects.append({"k":"lamb"+str(int(hero.anim)%3),"p":hero.position+Vector2(0,sin(hero.anim)*2),"size":Vector2(98,98),"hero":true})
 objects.sort_custom(func(a,b):return a.p.y<b.p.y)
 for obj in objects:
  if obj.has("e") and obj.e.kind>=3 and int(m.stage)>=2:obj.k="warden"+str(mini(3,int(m.stage)))+"_"+str(int(obj.e.anim)%3)
  if obj.has("hero") and hero.inv>0 and int(hero.inv*16)%2==0:continue
  sprite(obj.k,obj.p,obj.size)
  if obj.has("e"):
   var e=obj.e
   if e.kind<3:
    draw_rect(Rect2(obj.p-Vector2(22,88),Vector2(44,4)),Color("38263e"));draw_rect(Rect2(obj.p-Vector2(22,88),Vector2(44*maxf(0,e.hp/e.maxhp),4)),Color("dc7d85"))
   if e.wind>0:draw_circle(obj.p-Vector2(0,70 if e.kind<3 else 130),4,Color("ffc58f"))
 if is_instance_valid(hero) and hero.swing_time>0:
  var angle=hero.face.angle();var r=float(s.reach);var a=PackedVector2Array()
  for i in 14:a.append(hero.position+Vector2.RIGHT.rotated(angle-1.1+i*2.2/13)*r)
  for i in range(13,-1,-1):a.append(hero.position+Vector2.RIGHT.rotated(angle-1.1+i*2.2/13)*(r-18))
  draw_colored_polygon(a,Color("ffe9bd"));draw_arc(hero.position,r-9,angle-1.1,angle+1.1,22,Color("ed766b"),3,true)
 for i in 18:
  var mote=Vector2(90+fmod(i*127+t*7,720),105+fmod(i*53+t*4,390));draw_circle(mote,1.3,Color("f4cda288"))
 for b in bolts:
  draw_circle(b.p,7 if b.enemy else 9,Color("f44f69"));draw_circle(b.p,3,Color("ffd5a7"));draw_line(b.p,b.p-b.v.normalized()*15,Color("ed766b"),3,true)
 for p in particles:draw_circle(p.p,2+p.life*3,Color(p.c,p.life))
 for f in floats:label(f.t,f.p-Vector2(0,45),24,Color("ffdeac"),true)
 if ritual>0 and mode=="camp":
  for i in 12:draw_circle(Vector2(450,230)+Vector2.RIGHT.rotated(i*TAU/12+t)*70,4,Color("ffd6a9"))
 draw_set_transform(Vector2.ZERO)
 if mode in ["camp","play"]:draw_hud(v)
 else:draw_menu(v)
 if notice_time>0 and mode in ["camp","play"]:
  panel(Rect2(v.x*.12,105,v.x*.76,38),Color("281a29dd"));label(notice,Vector2(v.x/2,130),14,Color("ffe8c9"),true)
 if flash>0:draw_rect(Rect2(Vector2.ZERO,v),Color(.9,.1,.2,flash*.4))
func draw_hud(v):
 var w=v.x;var h=v.y;panel(Rect2(14,14,minf(w-78,440),74));button("pause","II",Rect2(w-56,14,42,42))
 for i in int(s.maxhp):
  var x=28+i*20;var c=Color("ee626b") if i<ceil(hero.hp) else Color("68515f")
  draw_polygon(PackedVector2Array([Vector2(x,38),Vector2(x+4,33),Vector2(x+9,37),Vector2(x+14,33),Vector2(x+18,38),Vector2(x+9,49)]),PackedColorArray([c]))
 if mode=="camp":label("WOOD "+str(int(m.wood))+"   BERRIES "+str(int(m.berries))+"   FAITH "+str(int(m.faith))+"   ¤"+str(int(m.coins)),Vector2(28,73),12)
 else:label("CRUSADE "+str(int(m.stage))+" · "+str(int(s.room))+" / 4   +"+str(int(s.coins))+" COINS",Vector2(28,73),14)
 draw_circle(Vector2(78,h-88),51,Color("34273599"));draw_arc(Vector2(78,h-88),48,0,TAU,40,Color("d9a49399"),2,true);draw_circle(Vector2(78,h-88)+move_vec*27,21,Color("d9a493bb"))
 if mode=="camp":
  round_button("act","ACT",Vector2(w-68,h-88),40)
  round_button("venture","GO",Vector2(w-153,h-76),29)
  for p in props:
   if p.has("id"):
    var q=screen(p.p);var rr=Rect2(q-Vector2(55,20),Vector2(110,35))
    if rr.position.x>-80 and rr.end.x<w+80:label(p.label,q+Vector2(0,21),13,Color("ffe3bb"),true);buttons.append({"id":p.id,"r":Rect2(q-Vector2(46,65),Vector2(92,96))})
  label(str(int(m.followers))+" FRIENDS  ·  CROWN "+str(int(m.level)),Vector2(w/2,h-20),13,Color("e9c6b6"),true)
 else:
  round_button("slash","SLASH",Vector2(w-62,h-90),40);round_button("roll","ROLL",Vector2(w-148,h-73),29);round_button("magic","CURSE",Vector2(w-68,h-179),29)
  for i in 4:draw_circle(Vector2(w-89+i*14,h-217),4,Color("ffa397") if i<s.mana else Color("644c5f"))
  for e in enemies:
   if e.kind>=3:
    panel(Rect2(w*.2,100,w*.6,26));draw_rect(Rect2(w*.2+3,103,(w*.6-6)*maxf(0,e.hp/e.maxhp),20),Color("aa465b"));label(["THE ROOT WARDEN","THE VEIL WARDEN","THE ASH WARDEN"][mini(2,int(m.stage)-1)],Vector2(w/2,118),12,Color("f6e6cb"),true)
func draw_menu(v):
 draw_rect(Rect2(Vector2.ZERO,v),Color("211524bc"));var w=v.x;var h=v.y;var bw=minf(340,w-44);var x=(w-bw)/2
 match mode:
  "title":
   label("THORN",Vector2(w/2,h*.25),43,Color("ffe4bd"),true,true);label("& FLOCK",Vector2(w/2,h*.25+48),39,Color("ee8b87"),true,true)
   label("A SMALL CROWN. A GROWING HOME.",Vector2(w/2,h*.25+83),12,Color("bfa4b2"),true)
   button("camp","Enter camp",Rect2(x,h*.25+120,bw,54))
   if not checkpoint.is_empty():button("resume","Resume crusade",Rect2(x,h*.25+186,bw,48))
   label("MOVE · SLASH · ROLL",Vector2(w/2,h*.25+265),16,Color("ecd0bf"),true)
   label("Rescue friends. Build a home. Return stronger.",Vector2(w/2,h*.25+293),13,Color("bfa4b2"),true)
  "pause":
   label("A QUIET BREATH",Vector2(w/2,h*.3),28,Color("ffe4bd"),true,true)
   button("continue","Return",Rect2(x,h*.3+42,bw,50));button("mute","Sound: "+("Off" if muted else "On"),Rect2(x,h*.3+105,bw,48));button("title","Main menu",Rect2(x,h*.3+166,bw,48))
  "gift":
   label("A FRIEND IS FREE",Vector2(w/2,h*.17),27,Color("ffe4bd"),true,true)
   label("Choose a blessing",Vector2(w/2,h*.17+30),15,Color("d2b2bd"),true)
   var friend=["fox","rabbit","cat"][mini(2,int(s.rescued)-1)]+"0"
   draw_texture_rect(art[friend],Rect2(w/2-44,h*.17-105,88,88),false)
   for i in 3:
    var r=Rect2(x,h*.17+52+i*91,bw,80);panel(r);label(GIFTS[int(offer[i])][0],r.position+Vector2(18,30),19);label(GIFTS[int(offer[i])][1],r.position+Vector2(18,57),14,Color("d9a5ac"));buttons.append({"id":"gift"+str(i),"r":r})
  "victory","lost":
   label("HOMEWARD" if mode=="victory" else "THE CROWN ENDURES",Vector2(w/2,h*.3),27,Color("ffe4bd"),true,true)
   label(str(int(s.rescued))+" new friends · "+str(int(s.kills))+" foes defeated",Vector2(w/2,h*.3+40),16,Color("d9b9bf"),true)
   label("Loot banked" if mode=="victory" else "Half loot saved. Friends stay.",Vector2(w/2,h*.3+70),14,Color("d9b9bf"),true)
   button("camp","Return to camp",Rect2(x,h*.3+115,bw,54))
func action(id):
 if not muted and not music.playing:music.play()
 match id:
  "camp":camp()
  "resume":
   s=checkpoint.duplicate(true);enter_room()
  "pause":previous=mode;mode="pause";reset_input();save_game()
  "continue":mode=previous;reset_input()
  "title":mode="title";reset_input();save_game()
  "mute":muted=not muted;music.stream_paused=muted;save_game()
  "slash":attack_held=true
  "roll":hero.roll()
  "magic":magic()
  "act":act_near()
  _:
   if id.begins_with("gift"):gift(int(id.substr(4)))
   elif mode=="camp":interact(id)
func press(p,id):
 for b in buttons:
  if b.r.has_point(p):
   touches[id]=b.id;action(b.id);return
 if mode in ["play","camp"] and p.x<get_viewport_rect().size.x*.46:joy_id=id;joy_start=p;move_vec=Vector2.ZERO
func release(id):
 if id==joy_id:move_vec=Vector2.ZERO;joy_id=-1
 if touches.get(id,"")=="slash":attack_held=false
 touches.erase(id)
func _input(e):
 if e is InputEventScreenTouch:
  if e.pressed:press(e.position,e.index)
  else:release(e.index)
 elif e is InputEventScreenDrag and e.index==joy_id:move_vec=((e.position-joy_start)/45).limit_length(1)
 elif e is InputEventMouseButton and e.button_index==MOUSE_BUTTON_LEFT:
  if e.pressed:press(e.position,100)
  else:release(100)
 elif e is InputEventMouseMotion and joy_id==100:move_vec=((e.position-joy_start)/45).limit_length(1)
 elif e is InputEventKey and e.pressed and not e.echo:
  if e.keycode==KEY_ESCAPE and mode in ["camp","play","pause"]:action("continue" if mode=="pause" else "pause")
  if e.keycode==KEY_E:
   if mode=="play":magic()
   elif mode=="camp":act_near()

