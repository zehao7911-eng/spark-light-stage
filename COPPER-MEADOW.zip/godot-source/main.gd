extends Node2D

const Farm = preload('res://farm.gd')
const ATLAS = preload('res://assets/atlas.png')
const SAVE = 'copper-meadow.v1'
var farm = Farm.new()
var regions = {}
var callback
var t = 0.0
var sync = 0.0
var save_timer = 0.0
var zoom = 2.0
var camera = Vector2(230,150)
var origin = Vector2.ZERO
var tool = 'inspect'
var selected_crop = 0
var selected_plot = -1
var selected_building = -1
var pointer = Vector2(-100,-100)
var pressing = false
var dragging = false
var down = Vector2.ZERO
var previous = Vector2.ZERO
var particles = []
var pulses = []
var ground: ImageTexture
var size_before = Vector2.ZERO
var tab_hidden = false
var offline_message = 0
var user_zoom = false
var away_started = 0.0

func _ready():
	Engine.max_fps=45
	texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	regions=JSON.parse_string(FileAccess.get_file_as_string('res://assets/regions.json'))
	farm.fresh()
	load_game()
	create_ground()
	if OS.has_feature('web'):
		callback=JavaScriptBridge.create_callback(web_action)
		JavaScriptBridge.get_interface('window').farmAction=callback
		JavaScriptBridge.eval('window.farmReady && window.farmReady()')
	if '--qa' in OS.get_cmdline_user_args():
		print('Use qa.gd for deterministic simulation validation.')

func create_ground():
	var img=Image.create(720,384,false,Image.FORMAT_RGBA8)
	var atlas=ATLAS.get_image()
	for y in range(16):
		for x in range(30):
			var r=regions['grass'+str(posmod(x*13+y*7,8))]
			img.blit_rect(atlas,Rect2i(r[0],r[1],24,24),Vector2i(x*24,y*24))
	ground=ImageTexture.create_from_image(img)

func web_action(args):
	if args.size()==0:return
	var data=JSON.parse_string(str(args[0]))
	if typeof(data)!=TYPE_DICTIONARY:return
	var a=str(data.get('a',''))
	var n=int(data.get('n',0))
	if a=='tool':tool=str(data.get('tool','inspect'));selected_crop=n;selected_plot=-1;selected_building=-1
	elif a=='zoom':zoom=clampf(zoom+n*0.5,1,4);user_zoom=true
	elif a=='home':camera=Vector2(230,150)
	elif a=='pan':camera+=Vector2(float(data.get('x',0)),float(data.get('y',0)))
	elif a=='hidden':
		if n==1:away_started=Time.get_unix_time_from_system();tab_hidden=true;save_game()
		else:
			tab_hidden=false
			if away_started>0 and farm.started and not farm.paused:
				var elapsed=clampf(Time.get_unix_time_from_system()-away_started,0,1800)
				if elapsed>3:
					var before=farm.coins
					for i in range(int(elapsed*2)):farm.step(0.5)
					offline_message=maxi(0,int(farm.coins-before));farm.events.clear()
			away_started=0;save_game()
	elif a=='save':save_game()
	else:farm.action(a,n);save_game()
	sync_state()

func load_game():
	var text=''
	if OS.has_feature('web'):text=str(JavaScriptBridge.eval('localStorage.getItem("'+SAVE+'") || ""'))
	elif FileAccess.file_exists('user://farm.json'):text=FileAccess.get_file_as_string('user://farm.json')
	var data=null
	if text!='':data=JSON.parse_string(text)
	if farm.restore(data) and farm.started and not farm.paused:
		var elapsed=clampf(Time.get_unix_time_from_system()-float(data.get('saved',0)),0,1800)
		if elapsed>30:
			var before=farm.coins
			for i in range(int(elapsed*2)):farm.step(0.5)
			offline_message=maxi(0,int(farm.coins-before));farm.events.clear()

func save_game():
	var text=JSON.stringify(farm.snapshot())
	if OS.has_feature('web'):JavaScriptBridge.eval('try{localStorage.setItem("'+SAVE+'",'+JSON.stringify(text)+')}catch(e){window.saveFailed=true}')
	else:
		var f=FileAccess.open('user://farm.json',FileAccess.WRITE)
		if f:f.store_string(text)

func sync_state():
	if not OS.has_feature('web'):return
	var data=farm.snapshot()
	data['weather']=farm.weather;data['tool']=tool;data['crop']=selected_crop;data['zoom']=zoom
	data['selected_plot']=selected_plot;data['selected_building']=selected_building
	data['offline']=offline_message
	data['events']=farm.events.duplicate(true)
	JavaScriptBridge.eval('window.farmState && window.farmState('+JSON.stringify(data)+')')
	offline_message=0

func _process(delta):
	var dt=minf(delta,0.1)
	if not tab_hidden:
		if not farm.paused:t+=dt
		farm.step(dt)
	for ev in farm.events:
		if not ev.get('drawn',false) and ev.kind in ['water','harvest','coin','build','plant','reward','delivery']:
			pulses.append({'x':float(ev.x)*24+12,'y':float(ev.y)*24+12,'life':1.0,'kind':ev.kind,'n':ev.n})
			if not farm.reduced:
				for j in range(5):particles.append({'p':Vector2(ev.x*24+12,ev.y*24+12),'v':Vector2(randf_range(-18,18),randf_range(-28,-9)),'life':randf_range(0.35,0.8),'kind':ev.kind})
	sync+=dt;save_timer+=dt
	if sync>=0.25:sync=0;sync_state();farm.events.clear()
	# Events get particles once, while their DOM notification waits for the next sync.
	else:
		for ev in farm.events:ev['drawn']=true
	for i in range(particles.size()-1,-1,-1):
		var p=particles[i];p.life-=dt;p.p+=p.v*dt;p.v.y+=35*dt
		if p.life<=0:particles.remove_at(i)
	for i in range(pulses.size()-1,-1,-1):
		pulses[i].life-=dt
		if pulses[i].life<=0:pulses.remove_at(i)
	if save_timer>5:save_timer=0;save_game()
	var view=get_viewport_rect().size
	if size_before!=view:
		if not user_zoom:zoom=(2.0 if view.x>=750 else 1.5) if view.y>=450 else 1.0
		size_before=view
	camera.x=clampf(camera.x,100,farm.width()*24-100);camera.y=clampf(camera.y,60,300)
	origin=(view/2-camera*zoom).floor()
	queue_redraw()

func sprite(name,x,y,modulate=Color.WHITE):
	if name not in regions:return
	var r=regions[name]
	draw_texture_rect_region(ATLAS,Rect2(roundf(x),roundf(y),r[2],r[3]),Rect2(r[0],r[1],r[2],r[3]),modulate)
func small_sprite(name,x,y,factor=0.5):
	var r=regions[name]
	draw_texture_rect_region(ATLAS,Rect2(roundf(x),roundf(y),r[2]*factor,r[3]*factor),Rect2(r[0],r[1],r[2],r[3]))
func rect(x,y,w,h,col):draw_rect(Rect2(roundf(x),roundf(y),w,h),Color(col))
func line(a,b,col,width=1):draw_line(a,b,Color(col),width)

func _draw():
	draw_rect(get_viewport_rect(),Color('#304e43'))
	draw_set_transform(origin,0,Vector2(zoom,zoom))
	var w=farm.width()*24
	# Soft terraces and visible locked meadow; playable ground stays distinct.
	rect(-8,3,w+16,318,'#263e36');rect(-4,-2,w+8,312,'#acb675');rect(0,0,w,310,'#628848')
	draw_texture_rect_region(ground,Rect2(0,0,w,306),Rect2(0,0,w,306))
	for x in range(0,int(w),3):rect(x,306,2,6+posmod(x,5),'#6f7950')
	rect(0,313,w,3,'#314e3d')
	for r in farm.roads:sprite('path',posmod(int(r),28)*24,int(float(r)/28)*24)
	for p in farm.plots:
		sprite('soil1' if p.w>0 else 'soil0',p.x*24,p.y*24)
		if p.s>0:
			var stage=4 if p.s==2 else clampi(int(p.g*4)+1,1,3)
			var sway=0 if farm.reduced else (1 if sin(t*0.8+p.x+p.y)>0.93 else 0)
			sprite('crop%d_%d'%[int(p.c),stage],p.x*24+sway,p.y*24)
			if p.s==1 and p.w==0:
				rect(p.x*24+17,p.y*24+2,4,5,'#30464c');rect(p.x*24+18,p.y*24+2,2,3,'#80bdca')
		if selected_plot>=0 and selected_plot<farm.plots.size() and p==farm.plots[selected_plot]:draw_rect(Rect2(p.x*24,p.y*24,24,24),Color('#f4e3b2'),false,1)
	# Background fence, flowers, pebbles and edge trees, all on the same pixel grid.
	for x in range(1,farm.width()-1):
		rect(x*24,13,2,9,'#5d6548');rect(x*24+1,13,1,8,'#d2bb83');rect(x*24+2,16,22,2,'#b6a26f')
	for i in range(120):
		var x=posmod(i*113+13,int(w)-15)+7;var y=posmod(i*71+21,276)+19
		if farm.plot_at(int(x/24),int(y/24))>=0 or farm.building_at(int(x/24),int(y/24))>=0 or farm.key(int(x/24),int(y/24)) in farm.roads:continue
		var col=['#b4c973','#b8c4a0','#deb0ac','#e6d89a'][i%4]
		rect(x,y,2,1,col)
		if i%4==2:rect(x+1,y-1,1,3,col);rect(x+1,y,1,1,'#e8d696')
	var items=[]
	for b in farm.buildings:items.append({'y':b.y*24+68,'type':'building','item':b})
	for bot in farm.bots:items.append({'y':bot.y*24+23,'type':'bot','item':bot})
	for x in [0,farm.width()-2]:
		for y in [1,8,10]:items.append({'y':y*24+40,'type':'tree','x':x*24-8,'yy':y*24-14,'v':posmod(y+x,4)})
	items.sort_custom(func(a,b):return a.y<b.y)
	for it in items:
		if it.type=='tree':sprite('tree'+str(it.v),it.x,it.yy)
		elif it.type=='building':
			var b=it.item;var bx=b.x*24;var by=b.y*24-9
			if b.kind in ['hive','flower']:small_sprite(b.kind,bx,by+3,2.0/3.0)
			else:sprite(b.kind,bx,by)
			if b.kind=='mill':
				var active=not b.batch.is_empty()
				if active:
					for i in range(4):
						var sy=fmod(t*8+i*8,24);rect(bx+36+sin(t*1.1+i)*3,by-3-sy,3+floor(sy/8),3,'#bdc9a0')
					var gear=int(t*5)%4;rect(bx+23+gear*3,by+48,3,2,'#e5d38c')
				rect(bx+17,by+73,32,3,'#354b42');rect(bx+17,by+73,32*b.p,2,'#b7ce83')
			elif b.kind=='well':
				rect(bx+25+int(t*2)%4,by+47,7,1,'#b9e3d7')
			elif b.kind=='depot':
				rect(bx+24,by+43,24,1,'#a9d8b5')
			if selected_building>=0 and selected_building<farm.buildings.size() and b==farm.buildings[selected_building]:draw_rect(Rect2(bx,by+20,72,50),Color('#f4e3b2'),false,1)
		else:
			var b=it.item;var x=b.x*24;var y=b.y*24-8
			var frame=int(t*7)%6 if not b.path.is_empty() else 0
			sprite('bot%d_%d'%[int(b.role),frame],x,y)
			if b.load>0:small_sprite('harvest',x+14,y+9)
			elif b.job=='water':
				small_sprite('water',x+13,y+10)
				if b.path.is_empty():rect(x+25,y+22,2,2,'#b8e1d6');rect(x+28,y+25,1,2,'#81b7bf')
			elif b.job=='seed' and b.path.is_empty():rect(x+22,y+21,2,1,'#e5b965')
	# Pond is outside the walkable southern border, with reeds, lilies and a gentle ripple.
	for j in range(4):
		var y=282+j*5;var xx=w-95-j*4;rect(xx,y,76+j*6,5,'#466e69');rect(xx+3,y,70+j*6,4,'#6a9b93')
	for i in range(8):rect(w-92+i*11,286+posmod(i,3)*4,4+int(t+i)%3,1,'#a6cab1')
	for i in range(4):
		rect(w-98+i*22,285,2,10,'#5d793c');rect(w-98+i*22,283,2,4,'#bba16a')
	# Ambient butterflies / bees have limited, deterministic flight paths.
	if not farm.reduced:
		for i in range(5):
			var x=80+i*76+sin(t*0.3+i)*20;var y=45+posmod(i*53,190)+sin(t*0.7+i)*9
			rect(x,y,1,2,'#3d5140');rect(x-2,y+int(t*5)%2,2,2,'#f0d7a1');rect(x+1,y+int(t*5)%2,2,2,'#e6ad8c')
		if farm.weather=='rain':
			for i in range(60):
				var x=fmod(i*47+t*12,w);var y=fmod(i*31+t*105,300);line(Vector2(x,y),Vector2(x-1,y+4),'#aecbc2')
	for p in particles:
		var color='#a6d2ca' if p.kind=='water' else '#e9c578'
		rect(p.p.x,p.p.y,2,2,color)
	for p in pulses:
		if p.kind=='coin' or p.kind=='reward':sprite('coin',p.x-8,p.y-22-(1-p.life)*18,Color(1,1,1,p.life))
	# Hover blueprint is measured in tiles, shows real placement validity.
	if tool!='inspect' and pointer.x>-20:
		var cell=((pointer-origin)/zoom/24).floor()
		var ss=1
		if tool in Farm.BUILD:ss=2 if tool in ['flower','hive'] else 3
		var good=farm.valid(int(cell.x),int(cell.y),ss) if tool in ['plot','well','mill','depot','greenhouse','hive','flower'] else true
		draw_rect(Rect2(cell*24,Vector2(ss,ss)*24),Color(0.9,0.86,0.6,0.3) if good else Color(0.8,0.35,0.3,0.4))
		draw_rect(Rect2(cell*24,Vector2(ss,ss)*24),Color('#e8d7a1') if good else Color('#d38676'),false,1)
		if tool in Farm.BUILD:sprite(tool,cell.x*24,cell.y*24-9,Color(1,1,1,0.65))
	# Evening tint never changes the palette to saturated neon.
	var night=maxf(0,sin(farm.clock/220))*0.13
	if night>0:draw_rect(Rect2(0,0,w,307),Color(0.15,0.22,0.38,night))
	draw_set_transform(Vector2.ZERO,0,Vector2.ONE)

func _unhandled_input(event):
	if event is InputEventMouseButton:
		pointer=event.position
		if event.button_index==MOUSE_BUTTON_WHEEL_UP and event.pressed:zoom=minf(4,zoom+1)
		elif event.button_index==MOUSE_BUTTON_WHEEL_DOWN and event.pressed:zoom=maxf(1,zoom-1)
		elif event.button_index in [MOUSE_BUTTON_LEFT,MOUSE_BUTTON_RIGHT]:
			if event.pressed:pressing=true;dragging=false;down=event.position;previous=event.position
			else:
				if pressing and not dragging:tap(event.position)
				pressing=false
	elif event is InputEventMouseMotion:
		pointer=event.position
		if pressing:
			if down.distance_to(event.position)>7:dragging=true
			if dragging:camera-=(event.position-previous)/zoom
			previous=event.position

func tap(pos):
	var cell=((pos-origin)/zoom/24).floor();var x=int(cell.x);var y=int(cell.y)
	if tool=='inspect':selected_plot=farm.plot_at(x,y);selected_building=farm.building_at(x,y)
	else:
		var success=farm.use(tool,x,y,selected_crop)
		if not success:farm.event('error',x,y)
		else:save_game()
	sync_state()

