extends RefCounted

const CROPS = ['Wheat','Carrot','Corn','Tomato','Aubergine','Cabbage','Sunflower','Cucumber','Strawberry','Pumpkin','Broccoli','Blueberry']
const UNLOCK = [0,0,0,12,28,50,80,120,180,260,380,550]
const GROW = [14,18,22,25,30,34,38,42,48,54,60,68]
const COST = [1,1,2,2,3,3,4,4,5,6,7,8]
const BUILD = {'well':120,'mill':220,'depot':160,'greenhouse':420,'hive':360,'flower':20}
const UPGRADES = ['speed','capacity','water','mill','yield','auto']
var coins = 180.0
var earned = 0.0
var fuel = 0
var harvested = 0
var delivered = 0
var plots = []
var buildings = []
var roads = []
var bots = []
var stock = []
var counts = []
var upgrades = [0,0,0,0,0,0]
var claims = []
var area = 0
var clock = 0.0
var weather = 'sun'
var events = []
var plan = 0
var paused = false
var focus = false
var started = false
var muting = false
var reduced = false
var offline_gain = 0

func fresh():
	stock.resize(12); stock.fill(0); counts.resize(12); counts.fill(0)
	stock[0]=4;stock[1]=4;stock[2]=4
	buildings=[{'kind':'barn','x':1,'y':1,'p':0.0,'batch':[]},{'kind':'well','x':1,'y':5,'p':0.0,'batch':[]},{'kind':'mill','x':14,'y':2,'p':0.0,'batch':[]}]
	for y in range(2,6):
		for x in range(6,12):
			var c=(x-6)/2
			plots.append({'x':x,'y':y,'c':int(c),'next':int(c),'g':float((y-2)*0.12),'w':1,'s':1,'r':-1})
	for x in range(2,16): roads.append(key(x,7))
	add_bot(0);add_bot(0)

func key(x,y):return int(y)*28+int(x)
func width():return [19,23,27][area]
func unlocked(c):return c>=0 and c<12 and harvested>=UNLOCK[c]
func event(kind,x=0,y=0,n=0):
	if events.size()<60: events.append({'kind':kind,'x':x,'y':y,'n':n})
func plot_at(x,y):
	for i in range(plots.size()):
		if int(plots[i].x)==x and int(plots[i].y)==y:return i
	return -1
func building_at(x,y):
	for i in range(buildings.size()):
		var b=buildings[i];var size=2 if b.kind in ['flower','hive'] else 3
		if x>=int(b.x) and y>=int(b.y) and x<int(b.x)+size and y<int(b.y)+size:return i
	return -1
func valid(x,y,size=1):
	if x<1 or y<1 or x+size>width()-1 or y+size>12:return false
	for yy in range(y,y+size):
		for xx in range(x,x+size):
			if building_at(xx,yy)>=0 or plot_at(xx,yy)>=0:return false
			for b in bots:
				if roundi(b.x)==xx and roundi(b.y)==yy:return false
	return true
func add_bot(role):
	var i=bots.size()
	bots.append({'x':4.0+i*0.3,'y':7.0,'role':role,'job':'idle','target':-1,'path':[],'wait':0.0,'water':4,'load':0,'crop':0})
func bot_cost():return int(85*pow(1.6,bots.size()-2))
func upgrade_cost(i):return int([90,110,80,150,180,240][i]*pow(1.85,upgrades[i]))
func expand_cost():return [380,1250,0][area]
func build_count(kind):
	var n=0
	for b in buildings:
		if b.kind==kind:n+=1
	return n
func use(tool,x,y,c):
	if not started or paused:return false
	if tool=='plot':
		if valid(x,y) and coins>=8:
			coins-=8;plots.append({'x':x,'y':y,'c':c,'next':c,'g':0.0,'w':0,'s':0,'r':-1});event('build',x,y);return true
	elif tool=='seed':
		var i=plot_at(x,y)
		if i>=0 and unlocked(c):
			var p=plots[i]
			# Changing planted crops sets next planting only; nothing is silently destroyed.
			p.next=c
			if p.s==0 and coins>=COST[c]:coins-=COST[c];p.c=c;p.s=1;p.g=0;p.w=0;event('plant',x,y)
			return true
	elif tool=='water':
		var i=plot_at(x,y)
		if i>=0 and plots[i].s==1 and plots[i].w<2:plots[i].w=2;event('water',x,y);return true
	elif tool=='harvest':
		var i=plot_at(x,y)
		if i>=0 and plots[i].s==2 and plots[i].r==-1:
			var p=plots[i];var amount=1+upgrades[4]
			stock[p.c]+=amount;counts[p.c]+=amount;harvested+=amount;delivered+=amount;p.s=0;p.g=0;p.w=0;event('harvest',x,y,amount);return true
	elif tool=='path':
		if x>0 and y>0 and x<width()-1 and y<12 and building_at(x,y)<0 and plot_at(x,y)<0 and key(x,y) not in roads and coins>=2:coins-=2;roads.append(key(x,y));event('build',x,y);return true
	elif tool=='erase':
		var i=plot_at(x,y)
		if i>=0:
			if plots[i].r!=-1:return false
			plots.remove_at(i);coins+=4
			# Reservation indices change after removal: cancel all outbound jobs safely.
			for b in bots:
				if b.job in ['water','harvest','seed']:b.job='idle';b.path=[];b.target=-1
			for p in plots:p.r=-1
			return true
		if key(x,y) in roads:roads.erase(key(x,y));coins+=1;return true
	elif tool in BUILD:
		var size=2 if tool in ['flower','hive'] else 3
		if valid(x,y,size) and coins>=BUILD[tool]:
			coins-=BUILD[tool];buildings.append({'kind':tool,'x':x,'y':y,'p':0.0,'batch':[]})
			# Newly occupied tiles invalidate queued paths. Re-plan from the current position.
			for b in bots:b.job='idle';b.path=[];b.target=-1;b.wait=0.0
			for p in plots:p.r=-1
			event('build',x,y);return true
	return false

func action(a,number=0):
	if a=='start':started=true;return true
	if a=='pause':paused=not paused;return true
	if a=='focus':focus=not focus;return true
	if a=='sound':muting=not muting;return true
	if a=='motion':reduced=not reduced;return true
	if a=='plan':plan=clampi(number,0,2);return true
	if a=='hire':
		var cost=bot_cost()
		if bots.size()<12 and coins>=cost:coins-=cost;add_bot(clampi(number,0,3));event('hire',4,7);return true
	if a=='upgrade':
		var i=clampi(number,0,5);var cost=upgrade_cost(i)
		if upgrades[i]<(1 if i==5 else 5) and coins>=cost:coins-=cost;upgrades[i]+=1;event('upgrade',4,7,i);return true
	if a=='expand' and area<2 and coins>=expand_cost():coins-=expand_cost();area+=1;event('expand',width()-5,5);return true
	if a=='sell':
		var c=clampi(number,0,11)
		if stock[c]>0:
			var n=stock[c];stock[c]=0;var money=n*(2+c);coins+=money;earned+=money;event('coin',2,4,money);return true
	if a=='claim':
		var goals=[12,30,65,120,220,400,650,1000]
		var i=clampi(number,0,7)
		if harvested>=goals[i] and i not in claims:claims.append(i);var money=45+50*i;coins+=money;earned+=money;event('reward',9,5,money);return true
	return false

func blocked(x,y):return x<1 or y<1 or x>=width()-1 or y>=12 or building_at(x,y)>=0
func path_to(sx,sy,tx,ty):
	var start=Vector2i(clampi(int(round(sx)),1,width()-2),clampi(int(round(sy)),1,11));var end=Vector2i(tx,ty)
	if start==end:return []
	var q=[start];var seen={start:Vector2i(-1,-1)};var head=0
	while head<q.size():
		var cell=q[head];head+=1
		for dir in [Vector2i(1,0),Vector2i(-1,0),Vector2i(0,1),Vector2i(0,-1)]:
			var n=cell+dir
			if n in seen or blocked(n.x,n.y):continue
			seen[n]=cell;q.append(n)
			if n==end:
				var result=[];var t=end
				while t!=start:result.push_front([t.x,t.y]);t=seen[t]
				return result
	return []
func nearest(kind,b):
	var dest=Vector2i(4,7);var best=INF
	for item in buildings:
		if item.kind!=kind:continue
		# Walkable front apron, never walk through a building.
		for off in [Vector2i(1,3),Vector2i(3,1),Vector2i(-1,1),Vector2i(1,-1)]:
			var p=Vector2i(item.x,item.y)+off
			if blocked(p.x,p.y):continue
			var distance=Vector2(b.x,b.y).distance_squared_to(Vector2(p))
			if distance<best:best=distance;dest=p
	return dest
func route(b,job,point):
	b.job=job;b.wait=0.0;b.path=path_to(b.x,b.y,int(point.x),int(point.y))
	return b.path.size()>0 or Vector2(b.x,b.y).distance_to(Vector2(point))<0.9
func assign(b,id):
	if b.load>0:
		if b.load<(1+upgrades[1])*(1+upgrades[4]):
			for i in range(plots.size()):
				var p=plots[i]
				if p.s==2 and p.r==-1 and p.c==b.crop and route(b,'harvest',Vector2i(p.x,p.y)):b.target=i;p.r=id;return
		route(b,'deliver',nearest('barn',b));return
	if b.water<=0 and b.role in [0,1]:route(b,'refill',nearest('well',b));return
	var candidates=[]
	for i in range(plots.size()):
		var p=plots[i]
		if p.r!=-1:continue
		var job='';var priority=0
		if p.s==2 and b.role in [0,2]:job='harvest';priority=100
		elif p.s==1 and p.w<2 and b.role in [0,1] and b.water>0:job='water';priority=50
		elif p.s==0 and b.role in [0,3] and coins>=COST[p.get('next',p.c)]:job='seed';priority=20
		if job!='':candidates.append({'i':i,'job':job,'score':priority-Vector2(b.x,b.y).distance_to(Vector2(p.x,p.y))*1.7})
	if candidates.is_empty():
		b.wait=0.5
		return
	candidates.sort_custom(func(a,c):return a.score>c.score)
	for can in candidates:
		var p=plots[can.i]
		if route(b,can.job,Vector2i(p.x,p.y)):b.target=can.i;p.r=id;return
	b.job='idle';b.wait=1.0

func finish(b):
	if b.job=='refill':b.water=4+upgrades[2]*3;event('water',b.x,b.y)
	elif b.job=='deliver':
		stock[b.crop]+=b.load;delivered+=b.load;event('delivery',b.x,b.y,b.load);b.load=0
	elif b.target>=0 and b.target<plots.size():
		var p=plots[b.target]
		if b.job=='water' and p.s==1:p.w=2;b.water-=1;event('water',p.x,p.y)
		elif b.job=='harvest' and p.s==2:
			var amount=1+upgrades[4];b.crop=p.c;b.load+=amount;counts[p.c]+=amount;harvested+=amount;p.s=0;p.g=0;p.w=0;event('harvest',p.x,p.y,amount)
		elif b.job=='seed' and p.s==0:
			var c=int(p.get('next',p.c))
			if coins>=COST[c]:coins-=COST[c];p.c=c;p.s=1;p.g=0;p.w=0;event('plant',p.x,p.y)
		p.r=-1
	b.target=-1;b.job='idle';b.wait=0.0

func step(dt):
	if not started or paused:return
	if focus:dt*=0.35
	clock+=dt
	weather='rain' if int(clock/90)%5==3 else 'sun'
	for p in plots:
		if p.s==1:
			if weather=='rain':p.w=2
			var greenhouse=1.0
			for building in buildings:
				if building.kind=='greenhouse' and Vector2(p.x,p.y).distance_to(Vector2(building.x+1,building.y+1))<6:greenhouse=1.5;break
			if p.w>0:p.g+=dt/GROW[p.c]*greenhouse*(1.0+0.04*build_count('hive'))
			if p.g>=1:p.g=1.0;p.s=2;event('ripe',p.x,p.y)
	for id in range(bots.size()):
		var b=bots[id]
		if not b.path.is_empty():
			var dest=Vector2(b.path[0][0],b.path[0][1]);var pos=Vector2(b.x,b.y)
			var speed=2.2*(1+upgrades[0]*0.22)*(1.4 if key(round(b.x),round(b.y)) in roads else 1.0)
			var next=pos.move_toward(dest,dt*speed);b.x=next.x;b.y=next.y
			if next.distance_to(dest)<0.02:b.path.pop_front()
		elif b.job!='idle':
			b.wait+=dt
			if b.wait>=0.6:finish(b)
		elif b.wait>0:b.wait-=dt
		else:assign(b,id)
	for machine in buildings:
		if machine.kind!='mill':continue
		if machine.batch.is_empty():
			var choices=[]
			for c in range(12):
				if stock[c]>=2:choices.append(c)
			if choices.size()>=3:
				# Recipe policy chooses a different crop combination without consuming all variety.
				if plan==1:choices.reverse()
				elif plan==2:choices.sort_custom(func(a,b):return stock[a]>stock[b])
				machine.batch=choices.slice(0,3)
				for c in machine.batch:stock[c]-=2
				machine.p=0.0
		else:
			machine.p+=dt*(1+upgrades[3]*0.25)/9.0
			if machine.p>=1:
				var quality=0
				for c in machine.batch:quality+=c
				var profit=34+quality*5+build_count('depot')*4
				coins+=profit;earned+=profit;fuel+=1;machine.p=0;machine.batch=[];event('coin',machine.x+1,machine.y+2,profit)
	# A safety shipment keeps an overbuilt farm recoverable without a paid reset.
	if coins<2:
		var empty=0
		for p in plots:
			if p.s==0:empty+=1
		if empty==plots.size() and delivered>0:
			for c in range(12):
				if stock[c]>0:stock[c]-=1;coins+=2+c;earned+=2+c;break
	if upgrades[5]>0:
		for p in plots:
			var c=int(p.get('next',p.c))
			if p.s==0 and p.r==-1 and coins>=COST[c]:coins-=COST[c];p.c=c;p.s=1;event('plant',p.x,p.y)

func snapshot():
	return {'v':1,'coins':coins,'earned':earned,'fuel':fuel,'harvested':harvested,'delivered':delivered,'plots':plots,'buildings':buildings,'roads':roads,'bots':bots,'stock':stock,'counts':counts,'upgrades':upgrades,'claims':claims,'area':area,'clock':clock,'plan':plan,'paused':paused,'focus':focus,'started':started,'muting':muting,'reduced':reduced,'saved':Time.get_unix_time_from_system()}
func restore(d):
	if typeof(d)!=TYPE_DICTIONARY or int(d.get('v',0))!=1:return false
	for k in ['coins','earned','fuel','harvested','delivered','plots','buildings','roads','bots','stock','counts','upgrades','claims','area','clock','plan','paused','focus','started','muting','reduced']:
		if k in d:set(k,d[k])
	# Saves hold in-flight jobs and reservations; JSON numbers convert safely at use sites.
	coins=maxf(0,float(coins));area=clampi(int(area),0,2)
	for field in ['fuel','harvested','delivered','plan']:set(field,int(get(field)))
	for i in range(upgrades.size()):upgrades[i]=int(upgrades[i])
	for i in range(claims.size()):claims[i]=int(claims[i])
	for i in range(roads.size()):roads[i]=int(roads[i])
	for p in plots:
		for k in ['x','y','c','w','s','r']:p[k]=int(p[k])
		p.next=int(p.get('next',p.c))
	for b in bots:
		for k in ['role','target','water','load','crop']:b[k]=int(b[k])
	for b in buildings:
		b.x=int(b.x);b.y=int(b.y)
		for i in range(b.batch.size()):b.batch[i]=int(b.batch[i])
	return true
