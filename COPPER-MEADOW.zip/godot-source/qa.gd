extends SceneTree
const Farm=preload('res://farm.gd')
func _initialize():
	var f=Farm.new();f.fresh();f.started=true
	assert(f.plots.size()==24 and f.bots.size()==2)
	assert(not f.use('mill',2,2,0))
	assert(f.use('plot',12,9,0));assert(f.use('seed',12,9,0))
	for i in range(2400):f.step(0.25);f.events.clear()
	assert(f.harvested>40,'Autonomous farm must harvest repeatedly')
	assert(f.fuel>5,'Three-crop refinery must repeatedly sell biofuel')
	assert(f.coins>180,'Farm must earn more than running costs')
	print('10 minute farm ',JSON.stringify({'coins':f.coins,'harvested':f.harvested,'fuel':f.fuel,'stock':f.stock}))
	var saved=f.snapshot().duplicate(true);var g=Farm.new();g.fresh()
	assert(g.restore(JSON.parse_string(JSON.stringify(saved))))
	for i in range(120):f.step(0.25);g.step(0.25)
	print('Reload comparison ',f.coins,' ',g.coins,' harvest ',f.harvested,' ',g.harvested,' fuel ',f.fuel,' ',g.fuel)
	assert(is_equal_approx(f.coins,g.coins) and f.harvested==g.harvested and f.fuel==g.fuel,'Save must preserve routes, reservations and machine batches')
	var before=f.coins;f.paused=true;f.step(100);assert(f.coins==before);f.paused=false
	# Exercise actual currency checks, costs and expanded collision rules.
	assert(f.action('hire',1));assert(f.bots.size()==3)
	assert(f.action('upgrade',0));assert(f.upgrades[0]==1)
	f.coins=100000
	assert(f.action('expand'));assert(f.area==1)
	assert(f.use('greenhouse',19,3,0));assert(f.use('hive',19,8,0))
	assert(f.action('expand'));assert(f.area==2)
	for c in range(12):
		f.harvested=maxi(f.harvested,Farm.UNLOCK[c]);assert(f.unlocked(c))
	for c in range(12):
		assert(f.use('plot',5+c,10,c));assert(f.use('seed',5+c,10,c))
	for i in range(4800):f.step(0.25);f.events.clear()
	assert(f.counts[11]>0,'Late crops must mature, be harvested and delivered')
	for i in range(8):
		f.harvested=1000;assert(f.action('claim',i));assert(not f.action('claim',i))
	for b in f.bots:
		assert(not f.blocked(roundi(b.x),roundi(b.y)),'Robots must not stand inside buildings')
	assert(f.use('erase',12,9,0))
	for p in f.plots:assert(p.r==-1,'Removing a plot must clear reservation indices')
	print('PASS: income, crops, reservations, save/reload, pause, hire, upgrades, expansion, milestones and late crop loop')
	quit()
