PINGU: NOOT ROUTE
An unofficial fan-made HTML5 game with original procedural models and sounds.

PLAY
Tap the orange ice arrows to change direction. Guide the whole queue to the igloo.
A wrong turn sends a penguin splashing into the sea; a rescue ring brings it back.
There are no lives, countdown or permanent lost penguins.
Tap NOOT! for a short belly-slide boost. It recharges automatically.
Keyboard: 1..6 flip switches, Left/Right select then Enter/Space flip, N boost,
Escape pause. The numbered keys are the simplest desktop option.

REWARDS
Stars: everybody home / collect all three fish / two splashes or fewer.
Only your best stars per floe count. Six unlock pink scarves; twelve a fish hat.
Eight designed ice routes; later floes reuse them with alternating mirrors,
numbered up to999. Not999 independently authored levels.

INSTALL
Open index.html directly, or upload it to any static HTML5 host.
Rendering code and license are bundled; no CDN/network requests are needed.
WebGL is required. Portrait recommended; landscape supported.
Local progress and exact current state save if browser storage is available.
Continuing starts paused. Storage-denied browsers remain playable for the session.
Browser touch simulation and small-screen layouts were tested, not every handset.

CREDITS
Loose crowd-routing inspiration: HUMANITY, Steam app1581480.
This is an original compact route-switching game, not a port of its levels/assets.
Pingu belongs to the respective rights holders; unofficial fan work, no endorsement.
No commercial models, footage, textures, songs or voice samples were extracted.
NOOT effects are synthesized original tones. Three.js r147 MIT: license included.
