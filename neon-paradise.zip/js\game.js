/* ==========================================================================
   NEON PARADISE — a pocket idol stage
   three.js (r147 global build) + GLTFLoader. Loads a neon poolside resort and
   a dancing maid, then lets you tap floating neon notes to keep the rhythm,
   chain combos, and repaint the whole paradise phase by phase.
   ========================================================================== */
(function () {
  'use strict';

  /* ----- Content / tuning ------------------------------------------------- */

  var HITS_PER_PHASE = 10;
  var NOTE_TTL = 7.5;          // seconds a note stays before it evaporates
  var COMBO_WINDOW = 1900;     // ms allowed between taps to keep the chain
  var MAX_NOTES = 5;           // concurrent tappable notes

  var PHASES = [
    { name: 'Aqua',   accent: 0x38e6ff, accent2: 0x7aa7ff, epigraph: 'The pool wakes first.' },
    { name: 'Blush',  accent: 0xff7ac8, accent2: 0xff9e6b, epigraph: 'Warmth creeps in at sunset.' },
    { name: 'Citrus', accent: 0xb6ff5a, accent2: 0x38ffd9, epigraph: 'The drinks come alive.' },
    { name: 'Violet', accent: 0xb47bff, accent2: 0xff6fd8, epigraph: 'The stage remembers you.' },
    { name: 'Amber',  accent: 0xffd447, accent2: 0xff8a3d, epigraph: 'You are the headliner now.' }
  ];

  var RANKS = [
    { at: 5,  name: 'Warm' },
    { at: 10, name: 'In flow' },
    { at: 15, name: 'Resonant' },
    { at: 20, name: 'Radiant' },
    { at: 25, name: 'Incandescent' },
    { at: 30, name: 'Transcendent' }
  ];

  var SCALE = [0, 2, 4, 7, 9]; // minor pentatonic, for note pitches
  var BEST_KEY = 'neon.best';

  var REDUCED = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var SMALL = Math.min(window.innerWidth, window.innerHeight) <= 760;

  var MAX_SPARKS = REDUCED ? 220 : (SMALL ? 480 : 900);
  var MAX_RINGS = REDUCED ? 8 : (SMALL ? 12 : 18);
  var MAX_DUST = REDUCED ? 0 : (SMALL ? 26 : 44);

  /* Character height in world units — everything (camera, notes, particles)
     is scaled against this so it reads correctly regardless of the source
     model's scale. Set during load; harmless fallback of 2 until then. */
  var U = 2;

  /* ----- State ------------------------------------------------------------ */

  var state = {
    score: 0, best: 0, combo: 0, bestCombo: 0, hits: 0,
    phaseHits: 0, phaseIndex: 0, soundOn: true, loaded: false, bestFlagged: false
  };

  function loadBest() { try { state.best = parseInt(localStorage.getItem(BEST_KEY) || '0', 10) || 0; state.bestFlagged = state.best > 0; } catch (e) {} }
  function storeBest() { try { localStorage.setItem(BEST_KEY, String(state.best)); } catch (e) {} }
  loadBest();

  /* ----- DOM -------------------------------------------------------------- */

  function $(id) { return document.getElementById(id); }
  var host = $('stage-host');
  var elScore = $('stat-score'), elBest = $('stat-best'), elPhase = $('stat-phase');
  var elPhaseCount = $('phase-count'), elPhaseFill = $('phase-fill'), elPhaseTicks = $('phase-ticks');
  var elTicker = $('ticker'), elToasts = $('toasts'), elLoader = $('loader');
  var elLoaderFill = $('loader-fill'), elLoaderPct = $('loader-pct');
  var elTitlecard = $('titlecard');
  var elSoundBtn = $('sound-btn'), elSoundState = $('sound-state'), elResetBtn = $('reset-btn');
  var elLede = $('lede');

  /* ----- three.js core ---------------------------------------------------- */

  var renderer, scene, camera, mixer;
  var sceneCenter = new THREE.Vector3();
  var sceneRadius = 5;
  var charAim = new THREE.Vector3();

  function initGL() {
    renderer = new THREE.WebGLRenderer({ antialias: !SMALL, alpha: false, powerPreference: 'high-performance' });
    var dpr = Math.min(SMALL ? 1.3 : 1.5, window.devicePixelRatio || 1);
    renderer.setPixelRatio(dpr);
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x0a0612, 1);
    if ('outputEncoding' in renderer) renderer.outputEncoding = THREE.sRGBEncoding;
    if ('toneMapping' in renderer) { renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 0.85; }
    host.appendChild(renderer.domElement);

    scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x0a0612, 0.0018);

    camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.1, 400);
    camera.position.set(0, 4, 14);

    /* Neon night rig: the resort is pale/white PBR, so instead of a white
       "daylight" sun we paint it with coloured key/fill/rim lights, a soft
       front stage light (keeps the maid readable), and a dim violet ambient.
       ACES tone mapping compresses the highlights so the colour reads rich
       instead of washing out. The accent light is recoloured per phase. */
    scene.add(new THREE.HemisphereLight(0x2a2040, 0x05030f, 0.10));
    var front = new THREE.DirectionalLight(0xfff1e8, 0.52);
    front.position.set(0, 3, 12);
    scene.add(front);
    var cyan = new THREE.DirectionalLight(0x23c8ff, 0.22);
    cyan.position.set(10, 12, 6);
    scene.add(cyan);
    var pink = new THREE.DirectionalLight(0xff3fd0, 0.3);
    pink.position.set(-10, 5, -4);
    scene.add(pink);
    var purple = new THREE.DirectionalLight(0x8a4bff, 0.2);
    purple.position.set(0, 6, -12);
    scene.add(purple);
    accentLight = new THREE.DirectionalLight(0x38e6ff, 0.3);
    accentLight.position.set(0, 8, -6);
    scene.add(accentLight);
  }

  /* ----- Procedural textures --------------------------------------------- */

  var glowTex, ringTex;

  function makeGlowTexture(size) {
    var c = document.createElement('canvas'); c.width = c.height = size;
    var x = c.getContext('2d');
    var g = x.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
    g.addColorStop(0.0, 'rgba(255,255,255,1)');
    g.addColorStop(0.22, 'rgba(255,255,255,0.62)');
    g.addColorStop(0.55, 'rgba(255,255,255,0.14)');
    g.addColorStop(1.0, 'rgba(255,255,255,0)');
    x.fillStyle = g; x.fillRect(0, 0, size, size);
    var t = new THREE.CanvasTexture(c); t.needsUpdate = true; return t;
  }

  function makeRingTexture(size) {
    var c = document.createElement('canvas'); c.width = c.height = size;
    var x = c.getContext('2d');
    x.shadowColor = '#ffffff'; x.shadowBlur = size * 0.14;
    x.strokeStyle = 'rgba(255,255,255,0.95)';
    x.lineWidth = size * 0.055;
    x.beginPath(); x.arc(size / 2, size / 2, size * 0.36, 0, Math.PI * 2); x.stroke();
    var t = new THREE.CanvasTexture(c); t.needsUpdate = true; return t;
  }

  /* ----- Notes, sparks, rings, dust -------------------------------------- */

  var accentColor = new THREE.Color(PHASES[0].accent);
  var accentTarget = new THREE.Color(PHASES[0].accent);
  var accentLight = null;
  var screenMats = []; // emissive "screen" materials that follow the scene mood

  var noteGroup = new THREE.Group();
  var notes = [];
  var noteGeo = new THREE.SphereGeometry(1, 18, 12);

  var sparkPos, sparkMat, sparkGeo, sparkPoints, sparks = [];
  var ringPool = [], dustPool = [];

  function buildParticles() {
    sparkPos = new Float32Array(MAX_SPARKS * 3);
    sparkGeo = new THREE.BufferGeometry();
    sparkGeo.setAttribute('position', new THREE.BufferAttribute(sparkPos, 3).setUsage(THREE.DynamicDrawUsage));
    sparkGeo.setDrawRange(0, 0);
    sparkGeo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1000);
    sparkMat = new THREE.PointsMaterial({
      size: U * 0.035, map: glowTex, color: 0xffffff,
      blending: THREE.AdditiveBlending, depthWrite: false, transparent: true,
      sizeAttenuation: true, opacity: 0.95
    });
    sparkPoints = new THREE.Points(sparkGeo, sparkMat);
    sparkPoints.frustumCulled = false;
    scene.add(sparkPoints);
  }

  function buildRings() {
    for (var i = 0; i < MAX_RINGS; i++) {
      var m = new THREE.SpriteMaterial({
        map: ringTex, color: 0xffffff, blending: THREE.AdditiveBlending,
        depthWrite: false, transparent: true, opacity: 0
      });
      var s = new THREE.Sprite(m);
      s.visible = false; s.userData.life = 0; s.userData.max = 0; s.userData.grow = 1;
      scene.add(s); ringPool.push(s);
    }
  }

  function buildDust() {
    for (var i = 0; i < MAX_DUST; i++) {
      var m = new THREE.SpriteMaterial({
        map: glowTex, color: new THREE.Color().setHSL(Math.random(), 0.8, 0.62),
        blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, opacity: 0
      });
      var s = new THREE.Sprite(m);
      s.position.set((Math.random() - 0.5) * U * 6, Math.random() * U * 3.4, (Math.random() - 0.5) * U * 6);
      s.scale.set(U * 0.05, U * 0.05, U * 0.05);
      s.userData = { phase: Math.random() * Math.PI * 2, speed: 0.08 + Math.random() * 0.16, amp: U * (0.4 + Math.random() * 0.9) };
      scene.add(s); dustPool.push(s);
    }
  }

  /* ----- Notes ------------------------------------------------------------ */

  function makeNoteSprite() {
    var m = new THREE.SpriteMaterial({
      map: glowTex, color: 0xffffff, blending: THREE.AdditiveBlending,
      depthWrite: false, transparent: true, opacity: 0.9
    });
    var s = new THREE.Sprite(m);
    return s;
  }

  function spawnNoteAt(x, y, z) {
    if (liveNoteCount() >= MAX_NOTES) return null;
    var s = makeNoteSprite();
    s.position.set(x, y, z);
    var r = U * 0.42;
    s.scale.set(r, r, r);
    noteGroup.add(s);
    var n = {
      sprite: s,
      x: x, y: y, z: z,
      born: performance.now(),
      ttl: NOTE_TTL,
      bob: Math.random() * Math.PI * 2,
      spin: 0.2 + Math.random() * 0.4,
      ang: Math.random() * Math.PI * 2,
      orbitR: U * (0.12 + Math.random() * 0.3),
      alive: true
    };
    notes.push(n);
    return n;
  }

  function randomNotePos() {
    // Generate candidate positions in a forward arc and keep only those whose
    // projection actually lands inside the (safe) viewport, so notes are always
    // visible and tappable — critical on narrow portrait phones where the
    // horizontal FOV is much tighter than the vertical one.
    var w = window.innerWidth, h = window.innerHeight;
    var vHalf = THREE.MathUtils.degToRad(camera.fov) * 0.5;
    var hHalf = Math.atan(Math.tan(vHalf) * camera.aspect);
    for (var i = 0; i < 48; i++) {
      var front = yaw + Math.PI;
      var ang = front + (Math.random() - 0.5) * hHalf * 1.3;
      var rr = U * (0.5 + Math.random() * 1.1);
      var y = sceneCenter.y + (Math.random() - 0.25) * U;
      var px = sceneCenter.x + Math.cos(ang) * rr;
      var pz = sceneCenter.z + Math.sin(ang) * rr;
      var pr = project3(px, y, pz);
      if (pr.z < 1 && pr.z > -1 &&
          pr.sx > w * 0.14 && pr.sx < w * 0.86 &&
          pr.sy > h * 0.18 && pr.sy < h * 0.8) {
        return { x: px, y: y, z: pz };
      }
    }
    // Fallback: dead ahead, mid-torso, a comfortable distance out.
    var a2 = yaw + Math.PI, r2 = U * 0.8;
    return {
      x: sceneCenter.x + Math.cos(a2) * r2,
      y: sceneCenter.y,
      z: sceneCenter.z + Math.sin(a2) * r2
    };
  }

  function spawnNote() {
    var p = randomNotePos();
    spawnNoteAt(p.x, p.y, p.z);
  }

  function killNote(n) {
    n.alive = false;
    n.sprite.visible = false;
    noteGroup.remove(n.sprite);
  }

  var lastSpawn = 0;

  /* ----- Effects ---------------------------------------------------------- */

  function burstSparks(x, y, z, count, color, power) {
    for (var i = 0; i < count && sparks.length < MAX_SPARKS; i++) {
      var a = Math.random() * Math.PI * 2;
      var b = (Math.random() - 0.5) * Math.PI;
      var sp = (0.4 + Math.random() * 1.4) * (power || 1) * Math.max(0.4, U);
      sparks.push({
        x: x, y: y, z: z,
        vx: Math.cos(a) * Math.cos(b) * sp,
        vy: Math.sin(b) * sp + U * 0.2,
        vz: Math.sin(a) * Math.cos(b) * sp,
        life: 0.5 + Math.random() * 0.6,
        max: 0.7 + Math.random() * 0.4
      });
    }
  }

  function spawnRing(x, y, z, color, grow) {
    for (var i = 0; i < ringPool.length; i++) {
      var r = ringPool[i];
      if (r.userData.life <= 0) {
        r.visible = true;
        r.material.color.copy(color);
        r.position.set(x, y, z);
        r.scale.set(U * 0.02, U * 0.02, U * 0.02);
        r.userData.life = 1; r.userData.max = 1; r.userData.grow = grow || 1;
        return r;
      }
    }
    return null;
  }

  function spawnFloat(x, y, text, kind) {
    if (!floatHost) return;
    var el = document.createElement('span');
    el.className = 'float' + (kind ? ' float--' + kind : '');
    el.textContent = text;
    el.style.left = x + 'px'; el.style.top = y + 'px';
    floatHost.appendChild(el);
    setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 900);
  }

  var floatHost;

  /* ----- Audio ------------------------------------------------------------ */

  var AC = null, master = null;

  function ensureAudio() {
    if (AC) { if (AC.state === 'suspended') AC.resume(); return; }
    var W = window.AudioContext || window.webkitAudioContext;
    if (!W) return;
    AC = new W();
    master = AC.createGain();
    master.gain.value = 0.5;
    master.connect(AC.destination);
  }

  function env(g, t0, a, d, peak) {
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(peak, t0 + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + a + d);
  }

  function freqFor(combo) {
    var oct = Math.floor(combo / SCALE.length);
    var sem = SCALE[combo % SCALE.length];
    return 220 * Math.pow(2, (sem + 12 * oct) / 12);
  }

  function soundNote(combo, perfect) {
    if (!state.soundOn || !AC) return;
    var t = AC.currentTime;
    var f = freqFor(combo);
    var o = AC.createOscillator();
    o.type = perfect ? 'triangle' : 'sine';
    o.frequency.value = f;
    var g = AC.createGain();
    env(g, t, 0.01, perfect ? 0.5 : 0.32, perfect ? 0.5 : 0.34);
    o.connect(g); g.connect(master);
    o.start(t); o.stop(t + 0.6);
    if (perfect) {
      var o2 = AC.createOscillator();
      o2.type = 'sine'; o2.frequency.value = f * 2;
      var g2 = AC.createGain();
      env(g2, t, 0.01, 0.4, 0.14);
      o2.connect(g2); g2.connect(master);
      o2.start(t); o2.stop(t + 0.5);
    }
  }

  function soundThud() {
    if (!state.soundOn || !AC) return;
    var t = AC.currentTime;
    var o = AC.createOscillator();
    o.type = 'sine'; o.frequency.setValueAtTime(150, t);
    o.frequency.exponentialRampToValueAtTime(90, t + 0.18);
    var g = AC.createGain();
    env(g, t, 0.01, 0.22, 0.18);
    o.connect(g); g.connect(master);
    o.start(t); o.stop(t + 0.26);
  }

  function soundMilestone(rank) {
    if (!state.soundOn || !AC) return;
    var t = AC.currentTime;
    var notes = [0, 4, 7, 12];
    for (var i = 0; i < notes.length; i++) {
      (function (i) {
        var o = AC.createOscillator(); o.type = 'triangle';
        o.frequency.value = 261.6 * Math.pow(2, notes[i] / 12);
        var g = AC.createGain();
        var t0 = t + i * 0.07;
        env(g, t0, 0.01, 0.4, 0.22);
        o.connect(g); g.connect(master);
        o.start(t0); o.stop(t0 + 0.5);
      })(i);
    }
  }

  function soundPhase() {
    if (!state.soundOn || !AC) return;
    var t = AC.currentTime;
    var arp = [0, 4, 7, 12, 16, 19, 24];
    for (var i = 0; i < arp.length; i++) {
      (function (i) {
        var o = AC.createOscillator(); o.type = 'sawtooth';
        o.frequency.value = 220 * Math.pow(2, arp[i] / 12);
        var f = AC.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 3200;
        var g = AC.createGain();
        var t0 = t + i * 0.08;
        env(g, t0, 0.01, 0.5, 0.12);
        o.connect(f); f.connect(g); g.connect(master);
        o.start(t0); o.stop(t0 + 0.6);
      })(i);
    }
  }

  /* ----- UI --------------------------------------------------------------- */

  function roman(n) { var S = ['I','II','III','IV','V','VI','VII','VIII','IX','X']; return S[Math.min(n, S.length) - 1] || String(n); }

  function toast(kind, title, sub, ms) {
    var t = document.createElement('div');
    t.className = 'toast' + (kind ? ' toast--' + kind : '');
    var ti = document.createElement('p'); ti.className = 'toast__title'; ti.textContent = title;
    var su = document.createElement('p'); su.className = 'toast__sub'; su.textContent = sub || '';
    t.appendChild(ti); t.appendChild(su);
    elToasts.appendChild(t);
    while (elToasts.children.length > 3) elToasts.removeChild(elToasts.firstChild);
    (function (node) {
      setTimeout(function () {
        node.classList.add('is-leaving');
        setTimeout(function () { if (node.parentNode) node.parentNode.removeChild(node); }, 320);
      }, ms || 2400);
    })(t);
  }

  function rankFor(n) {
    for (var i = 0; i < RANKS.length; i++) if (RANKS[i].at === n) return RANKS[i].name;
    if (n > 30 && n % 10 === 0) return 'Chain ×' + n;
    return null;
  }

  function setCombo(n) {
    var prev = state.combo;
    state.combo = n;
    if (n > 0) lastCombo = performance.now(); // keep the chain alive while tapping
    if (n > state.bestCombo) state.bestCombo = n;
    elBest.textContent = '×' + state.bestCombo;
    var r = rankFor(n);
    if (r && n > prev) { toast('rank', r, 'Chain ×' + n); soundMilestone(n); }
  }

  function addScore(points) {
    state.score += points;
    if (state.score > state.best) {
      state.best = state.score;
      if (!state.bestFlagged) { state.bestFlagged = true; toast('rank', 'New personal best', 'Momentum ' + state.best); }
      storeBest();
    }
    elScore.textContent = state.score;
    elScore.classList.remove('is-bumped'); void elScore.offsetWidth; elScore.classList.add('is-bumped');
  }

  function phaseLabel() {
    var p = PHASES[state.phaseIndex];
    return roman(state.phaseIndex + 1) + ' — ' + p.name;
  }

  function renderHUD() {
    elPhase.textContent = phaseLabel();
    elPhaseCount.textContent = state.phaseHits + ' / ' + HITS_PER_PHASE;
    elPhaseFill.style.width = ((state.phaseHits / HITS_PER_PHASE) * 100).toFixed(1) + '%';
    elTicker.textContent = 'Notes ' + liveNoteCount() + ' · Chain ×' + state.combo + ' · Scene mood ' + roman(state.phaseIndex + 1);
  }

  function liveNoteCount() { var c = 0; for (var i = 0; i < notes.length; i++) if (notes[i].alive) c++; return c; }

  function buildTicks() {
    elPhaseTicks.innerHTML = '';
    for (var i = 0; i < HITS_PER_PHASE; i++) { var li = document.createElement('li'); elPhaseTicks.appendChild(li); }
    syncTicks();
  }

  function syncTicks() {
    var lis = elPhaseTicks.children;
    for (var i = 0; i < lis.length; i++) lis[i].classList.toggle('is-done', i < state.phaseHits);
  }

  function setAccent(phase) {
    var a = '#' + phase.accent.toString(16).padStart(6, '0');
    var a2 = '#' + phase.accent2.toString(16).padStart(6, '0');
    document.documentElement.style.setProperty('--accent', a);
    document.documentElement.style.setProperty('--accent-2', a2);
    accentTarget.set(a);
  }

  function advancePhase() {
    state.phaseIndex = (state.phaseIndex + 1) % PHASES.length;
    state.phaseHits = 0;
    var p = PHASES[state.phaseIndex];
    setAccent(p);
    showTitleCard(p);
    toast('rank', p.name, 'Scene mood ' + roman(state.phaseIndex + 1) + '/V', 3400);
    soundPhase();
  }

  function showTitleCard(p) {
    $('tc-eyebrow').textContent = 'Scene ' + roman(state.phaseIndex + 1) + ' of V';
    $('tc-name').textContent = p.name;
    $('tc-line').textContent = p.epigraph;
    $('tc-rite').textContent = 'Mood ' + roman(state.phaseIndex + 1) + ' · Scene ' + roman(state.phaseIndex + 1) + '/V';
    elTitlecard.className = 'titlecard is-on';
    setTimeout(function () { elTitlecard.className = 'titlecard'; }, 2600);
  }

  function registerHit(opts) {
    opts = opts || {};
    var x = opts.x, y = opts.y, z = opts.z;
    var perfect = !!opts.perfect;
    var points = opts.points != null ? opts.points : (perfect ? 18 : 10);
    var quiet = !!opts.quiet;

    state.hits++;
    state.phaseHits++;
    setCombo(state.combo + 1);
    addScore(points);

    if (!quiet && x != null) {
      var col = new THREE.Color(PHASES[state.phaseIndex].accent);
      burstSparks(x, y, z, perfect ? 90 : 55, col, perfect ? 1.5 : 1);
      spawnRing(x, y, z, col, perfect ? 1.4 : 1);
      soundNote(state.combo, perfect);
    }
    if (perfect && x != null) {
      var v = project3(x, y, z);
      spawnFloat(v.sx, v.sy - 26, 'PERFECT', 'perfect');
    } else if (!quiet && x != null) {
      var v2 = project3(x, y, z);
      spawnFloat(v2.sx, v2.sy - 22, '+' + points, null);
    }

    if (state.phaseHits >= HITS_PER_PHASE) advancePhase();

    renderHUD(); syncTicks();
  }

  /* ----- Camera ----------------------------------------------------------- */

  var yaw = 0.9, pitch = 0.22, radius = 16, radiusTarget = 16;
  var minR = 3, maxR = 60;
  var autoYaw = true;
  var lastInput = 0;

  function updateCamera(dt) {
    var now = performance.now();
    if (autoYaw) yaw += dt * 0.18;
    if (now - lastInput > 4500) autoYaw = true;
    radius += (radiusTarget - radius) * Math.min(1, dt * 4);
    var y0 = sceneCenter.y + charAim.y;
    var cx = sceneCenter.x, cy = y0, cz = sceneCenter.z;
    var s = radius;
    camera.position.set(
      cx + s * Math.cos(pitch) * Math.sin(yaw),
      cy + s * Math.sin(pitch),
      cz + s * Math.cos(pitch) * Math.cos(yaw)
    );
    camera.lookAt(cx, cy, cz);
  }

  /* ----- Input ------------------------------------------------------------ */

  var pointers = {};
  var pinchStartDist = 0, pinchStartRadius = 0;

  function pinchDist() {
    var arr = [];
    for (var k in pointers) arr.push(pointers[k]);
    if (arr.length < 2) return 0;
    return Math.hypot(arr[0].x - arr[1].x, arr[0].y - arr[1].y);
  }

  function onPointerDown(e) {
    ensureAudio();
    lastInput = performance.now(); autoYaw = false; // any touch parks the slow spin
    pointers[e.pointerId] = { x: e.clientX, y: e.clientY, sx: e.clientX, sy: e.clientY, t: performance.now(), moved: false };
    var n = 0; for (var k in pointers) n++;
    if (n === 2) { pinchStartDist = pinchDist(); pinchStartRadius = radius; }
  }

  function onPointerMove(e) {
    if (!pointers[e.pointerId]) return;
    var p = pointers[e.pointerId];
    var dx = e.clientX - p.x, dy = e.clientY - p.y;
    p.x = e.clientX; p.y = e.clientY;

    var n = 0; for (var k in pointers) n++;
    if (n >= 2) {
      var d = pinchDist();
      if (pinchStartDist > 0 && d > 0) radiusTarget = clamp(pinchStartRadius * (pinchStartDist / d), minR, maxR);
      lastInput = performance.now(); autoYaw = false;
    } else if (n === 1) {
      var moved = Math.hypot(e.clientX - p.sx, e.clientY - p.sy);
      if (moved > 8) p.moved = true;
      if (p.moved) {
        yaw -= dx * 0.0052;
        pitch += dy * 0.0042;
        if (pitch > 1.35) pitch = 1.35; if (pitch < -0.15) pitch = -0.15;
        lastInput = performance.now(); autoYaw = false;
      }
    }
  }

  function onPointerUp(e) {
    var p = pointers[e.pointerId];
    delete pointers[e.pointerId];
    if (p && !p.moved && (performance.now() - p.t) < 420) tapAt(e.clientX, e.clientY);
    var n = 0; for (var k in pointers) n++;
    if (n < 2) { pinchStartDist = 0; }
  }

  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }

  /* ----- Tap → note hit test (screen-space) ------------------------------ */

  var vTmp = new THREE.Vector3();

  function project3(x, y, z) {
    vTmp.set(x, y, z).project(camera);
    return { sx: (vTmp.x * 0.5 + 0.5) * window.innerWidth, sy: (-vTmp.y * 0.5 + 0.5) * window.innerHeight, z: vTmp.z };
  }

  function hitRadius() { return clamp(0.085 * Math.min(window.innerWidth, window.innerHeight), 30, 62); }

  function tapAt(mx, my) {
    if (!state.loaded) return;
    var best = null, bestD = Infinity, bestRatio = 0;
    for (var i = 0; i < notes.length; i++) {
      var n = notes[i];
      if (!n.alive) continue;
      var pr = project3(n.x, n.y, n.z);
      if (pr.z >= 1 || pr.z < -1) continue;
      var d = Math.hypot(pr.sx - mx, pr.sy - my);
      if (d < hitRadius() && d < bestD) { bestD = d; best = n; bestRatio = d / hitRadius(); }
    }
    if (best) {
      var perfect = bestRatio < 0.45;
      registerHit({
        points: perfect ? 18 : 10, perfect: perfect,
        x: best.x, y: best.y, z: best.z
      });
      killNote(best);
    } else {
      soundThud();
      // soft ambient pulse so even an empty tap feels alive
      var dv = new THREE.Vector3();
      dv.set(mx, my, 0.5).unproject(camera);
      var dir = dv.sub(camera.position).normalize();
      var p = camera.position.clone().addScaledVector(dir, U * 2.2);
      var col = new THREE.Color(PHASES[state.phaseIndex].accent);
      burstSparks(p.x, p.y, p.z, 8, col, 0.5);
      spawnRing(p.x, p.y, p.z, col, 0.7);
    }
  }

  /* ----- Loading / scene setup ------------------------------------------- */

  var loader = new THREE.GLTFLoader();

  function hideRigidBodies(obj) {
    obj.traverse(function (o) {
      if (!o.isMesh) return;
      var mats = Array.isArray(o.material) ? o.material : [o.material];
      for (var i = 0; i < mats.length; i++) {
        if (mats[i] && mats[i].name && mats[i].name.indexOf('mmd_tools') === 0) { o.visible = false; return; }
      }
    });
  }

  /* Give the pale/white resort a neon-night identity. The model's surfaces are
     plain white PBR with no textures or emissive, so we (1) darken the plain
     architecture/ground into a twilight base, (2) tint foliage and water, and
     (3) make the light fixtures + screens glow in their own neon colour. The
     maid's textured materials are left untouched (they carry a map). */
  var NEONY = [0xff4fd8, 0x2fd4ff, 0xb47bff, 0x7a5cff, 0xff7ac8, 0x2fffd0];

  function neonify(obj) {
    var pick = 0;
    obj.traverse(function (o) {
      if (!o.isMesh) return;
      var mats = Array.isArray(o.material) ? o.material : [o.material];
      for (var i = 0; i < mats.length; i++) {
        var m = mats[i];
        if (!m || !m.isMaterial || !m.emissive) continue; // skip unlit rigidity meshes
        if (m.map) continue;                              // leave the maid untouched
        var name = ((m.name || '') + '|' + (o.name || ''));

        if (/萤幕|幕|text/.test(name)) {
          m.color.set(0x050810);
          m.emissive.set(0x18c0e8); m.emissiveIntensity = 0.85;
          screenMats.push(m);
        } else if (/灯/.test(name)) {
          m.color.set(0x16162a);
          m.emissive.set(NEONY[pick++ % NEONY.length]); m.emissiveIntensity = 2.4;
        } else if (/水|泳|池|玻璃|游泳/.test(name)) {
          m.color.set(0x081820); m.metalness = 0.2; m.roughness = 0.3;
          m.emissive.set(0x18d0ff); m.emissiveIntensity = 0.55;
        } else if (/树|植物|花|叶|草/.test(name)) {
          m.color.setHSL(0.42 + (pick % 4) * 0.06, 0.45, 0.16);
          m.roughness = 0.85;
        } else if (/气球/.test(name)) {
          m.color.set(0x120e28);
          m.emissive.set(0xb47bff); m.emissiveIntensity = 1.2;
        } else {
          // ground, walls, stage, buildings, props -> dark twilight navy
          m.color.setHSL(0.72 + (pick % 3) * 0.05, 0.34, 0.065 + (pick % 3) * 0.02);
          m.metalness = 0.05; m.roughness = 0.75;
        }
      }
    });
  }

  function start() {
    loader.load(
      'assets/scene.glb',
      function (gltf) {
        var obj = gltf.scene;
        hideRigidBodies(obj);
        neonify(obj);
        scene.add(obj);

        // Frame on the maid, not the whole resort, so she is the star and the
        // resort glows away into the fog behind her.
        var charNode = null;
        obj.traverse(function (o) {
          if (!charNode && o.name && (o.name.indexOf('星临者') === 0 || o.name.indexOf('女仆') >= 0)) charNode = o;
        });
        var focus = charNode || obj;
        var box = new THREE.Box3().setFromObject(focus);
        var size = box.getSize(new THREE.Vector3());
        var center = box.getCenter(new THREE.Vector3());

        U = Math.max(0.3, size.y);      // character height drives every effect
        sceneCenter.copy(center);
        // Aim above the torso (the camera tilts down, and the dance raises the hair),
        // and pull back a little so the full figure — ponytail to heels — stays in
        // frame even on tall portrait phones.
        charAim.y = U * 0.28;
        sceneRadius = Math.max(1, size.length() * 0.5);

        var dist = clamp(U * 2.9, 1.2, 70);
        radiusTarget = radius = dist;
        minR = U * 1.3; maxR = Math.min(80, U * 15);
        camera.near = Math.max(0.01, U * 0.02);
        camera.far = Math.max(dist * 4, U * 90);
        camera.updateProjectionMatrix();
        scene.fog.density = 0.005 / (U * U);

        // dance + facial animations
        if (gltf.animations && gltf.animations.length) {
          mixer = new THREE.AnimationMixer(obj);
          var dance = gltf.animations[0];
          if (dance) { var a = mixer.clipAction(dance); a.loop = THREE.LoopRepeat; a.play(); }
          if (gltf.animations[1]) { var f = mixer.clipAction(gltf.animations[1]); f.loop = THREE.LoopRepeat; f.play(); }
        }

        scene.add(noteGroup);

        // Frame the camera now (before seeding notes) so the note spawner's
        // screen-space FOV check sees a valid view matrix.
        updateCamera(0);
        camera.updateMatrixWorld(true);

        state.loaded = true;
        elLoader.classList.add('is-done');

        // seed a couple of notes and start the spawn timer
        spawnNote(); spawnNote(); spawnNote();
        lastSpawn = performance.now();
        renderHUD();
      },
      function (xhr) {
        if (xhr.total) {
          var pct = Math.round((xhr.loaded / xhr.total) * 100);
          elLoaderFill.style.width = pct + '%';
          elLoaderPct.textContent = 'Loading paradise · ' + pct + '%';
        }
      },
      function (err) {
        elLoaderPct.textContent = 'Could not load the stage. Check the console.';
        console.error('GLB load error', err);
      }
    );
  }

  /* ----- Loop ------------------------------------------------------------- */

  var clock = new THREE.Clock();
  var lastCombo = 0;

  function updateNotes(dt) {
    var now = performance.now();
    // spawn cadence
    if (state.loaded && now - lastSpawn > 1500 && liveNoteCount() < MAX_NOTES) {
      spawnNote(); lastSpawn = now;
    }
    for (var i = notes.length - 1; i >= 0; i--) {
      var n = notes[i];
      if (!n.alive) continue;
      var age = (now - n.born) / 1000;
      if (age > n.ttl) { killNote(n); continue; }
      n.ang += dt * n.spin;
      n.bob += dt * 1.4;
      var ox = Math.cos(n.ang) * n.orbitR;
      var oz = Math.sin(n.ang) * n.orbitR;
      var oy = Math.sin(n.bob) * U * 0.06;
      n.x += ox * dt; n.z += oz * dt;
      // soft re-centre so notes don't wander off
      n.x += (sceneCenter.x - n.x) * dt * 0.05;
      n.z += (sceneCenter.z - n.z) * dt * 0.05;
      n.y += oy * dt;
      n.sprite.position.set(n.x, n.y, n.z);
      var r = U * 0.42;
      var pulse = 1 + Math.sin(n.bob * 3) * 0.08;
      n.sprite.scale.set(r * pulse, r * pulse, 1);
      // fade in/out near life edges
      var fade = age < 0.4 ? age / 0.4 : (n.ttl - age < 0.7 ? (n.ttl - age) / 0.7 : 1);
      n.sprite.material.opacity = 0.9 * clamp(fade, 0, 1);
    }
  }

  function updateSparks(dt) {
    var i = 0;
    while (i < sparks.length) {
      var s = sparks[i];
      s.life -= dt;
      if (s.life <= 0) {
        sparks[i] = sparks[sparks.length - 1]; sparks.pop();
        continue;
      }
      s.vy -= dt * U * 0.7; // gentle gravity
      s.vx *= (1 - dt * 1.1); s.vy *= (1 - dt * 1.1); s.vz *= (1 - dt * 1.1);
      s.x += s.vx * dt; s.y += s.vy * dt; s.z += s.vz * dt;
      sparkPos[i * 3] = s.x; sparkPos[i * 3 + 1] = s.y; sparkPos[i * 3 + 2] = s.z;
      i++;
    }
    sparkGeo.attributes.position.needsUpdate = true;
    sparkGeo.setDrawRange(0, sparks.length);
    sparkMat.color.copy(accentColor);
  }

  function updateRings(dt) {
    for (var i = 0; i < ringPool.length; i++) {
      var r = ringPool[i];
      if (r.userData.life <= 0) continue;
      r.userData.life -= dt * 1.6;
      var k = 1 - r.userData.life;
      var sc = U * (0.02 + k * 0.9) * r.userData.grow;
      r.scale.set(sc, sc, 1);
      r.material.opacity = Math.max(0, 0.65 * (1 - k));
      if (r.userData.life <= 0) { r.visible = false; r.material.opacity = 0; }
    }
  }

  function updateDust(t) {
    for (var i = 0; i < dustPool.length; i++) {
      var s = dustPool[i], u = s.userData;
      s.position.y += Math.sin(t * u.speed + u.phase) * 0.0012;
      s.material.opacity = REDUCED ? 0 : 0.16 + 0.1 * Math.sin(t * u.speed + u.phase);
    }
  }

  function tickPalette(dt) {
    accentColor.lerp(accentTarget, Math.min(1, dt * 4));
    // drift the accent light, screens and fog toward the current scene mood
    if (accentLight) accentLight.color.lerp(accentColor, Math.min(1, dt * 3));
    for (var i = 0; i < screenMats.length; i++) screenMats[i].emissive.lerp(accentColor, Math.min(1, dt * 3));
    if (scene.fog) scene.fog.color.lerp(accentColor.clone().lerp(new THREE.Color(0x0a0612), 0.7), 0.04);
  }

  function animate() {
    requestAnimationFrame(animate);
    var dt = Math.min(clock.getDelta(), 0.05);
    var t = performance.now() / 1000;

    if (mixer) mixer.update(dt);

    if (state.loaded) {
      updateNotes(dt);
      updateSparks(dt);
      updateRings(dt);
      updateDust(t);
      tickPalette(dt);
      updateCamera(dt);
    }

    // combo decay
    if (lastCombo > 0 && state.combo > 0 && performance.now() - lastCombo > COMBO_WINDOW) {
      if (state.combo > 0) {
        setCombo(0);
        if (state.hits > 0) toast('break', 'Rhythm faded', 'Chain ×' + state.bestCombo);
      }
      lastCombo = 0;
    }

    if (state.loaded) renderer.render(scene, camera);
  }

  function bumpComboClock() { lastCombo = performance.now(); }

  /* ----- Reset ------------------------------------------------------------ */

  function reset() {
    state.score = 0; state.combo = 0; state.hits = 0;
    state.phaseHits = 0; state.phaseIndex = 0; state.bestFlagged = state.best > 0;
    elToasts.innerHTML = '';
    setAccent(PHASES[0]); accentColor.set(PHASES[0].accent);
    elScore.textContent = '0'; elBest.textContent = '×0';
    for (var i = notes.length - 1; i >= 0; i--) killNote(notes[i]);
    notes.length = 0;
    sparks.length = 0; sparkGeo.setDrawRange(0, 0);
    for (var j = 0; j < ringPool.length; j++) { ringPool[j].visible = false; ringPool[j].userData.life = 0; }
    spawnNote(); spawnNote(); spawnNote();
    lastSpawn = performance.now();
    renderHUD(); syncTicks();
  }

  /* ----- Resize ----------------------------------------------------------- */

  function onResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  }

  /* ----- Wire up ---------------------------------------------------------- */

  function init() {
    initGL();
    glowTex = makeGlowTexture(128);
    ringTex = makeRingTexture(128);

    floatHost = document.createElement('div');
    floatHost.className = 'floats';
    floatHost.id = 'floats';
    document.body.appendChild(floatHost);

    buildParticles();
    buildRings();
    buildDust();
    buildTicks();
    setAccent(PHASES[0]);
    renderHUD();

    host.addEventListener('pointerdown', onPointerDown);
    host.addEventListener('pointermove', onPointerMove);
    host.addEventListener('pointerup', onPointerUp);
    host.addEventListener('pointercancel', onPointerUp);
    window.addEventListener('resize', onResize);

    elSoundBtn.addEventListener('click', function () {
      state.soundOn = !state.soundOn;
      elSoundState.textContent = state.soundOn ? 'on' : 'off';
      elSoundBtn.setAttribute('aria-pressed', String(state.soundOn));
      if (state.soundOn) ensureAudio();
    });
    elResetBtn.addEventListener('click', reset);

    start();
    animate();
  }

  /* ----- Test hooks ------------------------------------------------------- */

  window.NEON = {
    state: function () { return JSON.stringify(state); },
    registerHit: function (o) { bumpComboClock(); registerHit(o || {}); return 'ok'; },
    reset: function () { reset(); return 'ok'; },
    loaded: function () { return state.loaded; },
    project: function (x, y, z) { var p = project3(x, y, z); return JSON.stringify(p); },
    spawnNoteAt: function (x, y, z) { spawnNoteAt(x, y, z); return 'ok'; },
    spawnVisibleNote: function () {
      var w = window.innerWidth, h = window.innerHeight, tries = 80;
      for (var i = 0; i < tries; i++) {
        var p = randomNotePos();
        var pr = project3(p.x, p.y, p.z);
        if (pr.z < 1 && pr.z > -1 && pr.sx > w * 0.12 && pr.sx < w * 0.88 && pr.sy > h * 0.12 && pr.sy < h * 0.88) {
          spawnNoteAt(p.x, p.y, p.z);
          return JSON.stringify({ x: p.x, y: p.y, z: p.z, sx: pr.sx, sy: pr.sy });
        }
      }
      var p2 = randomNotePos(); spawnNoteAt(p2.x, p2.y, p2.z);
      var pr2 = project3(p2.x, p2.y, p2.z);
      return JSON.stringify({ x: p2.x, y: p2.y, z: p2.z, sx: pr2.sx, sy: pr2.sy });
    },
    noteCount: function () { return liveNoteCount(); },
    notesDebug: function () {
      var out = [];
      for (var i = 0; i < notes.length; i++) {
        var n = notes[i];
        if (!n.alive) continue;
        var pr = project3(n.x, n.y, n.z);
        out.push({ x: +n.x.toFixed(2), y: +n.y.toFixed(2), z: +n.z.toFixed(2), sx: Math.round(pr.sx), sy: Math.round(pr.sy), pz: +pr.z.toFixed(2) });
      }
      return JSON.stringify(out);
    },
    tapProbe: function (mx, my) {
      var bestD = 1e9, best = null;
      for (var i = 0; i < notes.length; i++) {
        var n = notes[i];
        if (!n.alive) continue;
        var pr = project3(n.x, n.y, n.z);
        if (pr.z >= 1 || pr.z < -1) continue;
        var d = Math.hypot(pr.sx - mx, pr.sy - my);
        if (d < bestD) { bestD = d; best = { sx: Math.round(pr.sx), sy: Math.round(pr.sy), pz: +pr.z.toFixed(2) }; }
      }
      return JSON.stringify({ bestD: Math.round(bestD), hitRadius: hitRadius(), best: best, alive: liveNoteCount() });
    },
    sceneCenter: function () { return JSON.stringify({ x: sceneCenter.x, y: sceneCenter.y, z: sceneCenter.z }); },
    sceneRadius: function () { return sceneRadius; },
    phaseIndex: function () { return state.phaseIndex; }
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();

})();