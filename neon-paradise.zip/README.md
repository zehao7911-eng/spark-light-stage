# Neon Paradise

A pocket idol stage — a mobile-first HTML5 rhythm game built with **three.js**.
Tap the glowing notes around a dancing maid, keep the rhythm, and repaint an
entire neon poolside resort, one scene mood at a time.

## Run it

The game is a static site. It needs to be served over HTTP (not `file://`)
because the 3D model is fetched via `fetch`.

```bash
# any static server works, e.g.
npx serve .
# or
python -m http.server 8000
```

Then open `http://localhost:8000/` on a phone or desktop browser.

## How to play

- **Tap** a glowing note to score. Dead-centre taps ring louder and score higher.
- **Chain** taps together to climb a five-note scale and unlock scene moods.
- **Drag** to orbit the stage. **Pinch** to zoom.

Every 10 hits advance the scene mood — `Aqua → Blush → Citrus → Violet → Amber` —
recolouring the stage lights, screens and fog to match.

## Tech

- [three.js r147](https://github.com/mrdoob/three.js) (global UMD build) + `GLTFLoader`
- `assets/scene.glb` — the maid character plus the neon resort stage
- WebAudio synthesized chimes (no audio assets)
- Additive sprite particles + `THREE.Points` sparks (no post-processing blur,
  so it stays fast on older phones)

## Files

| Path | What |
|------|------|
| `index.html` | HUD / loading curtain / title card |
| `css/style.css` | neon visual system + mobile-safe layout |
| `js/game.js` | scene loader, gameplay, camera, effects, audio |
| `vendor/` | three.js + GLTFLoader |
| `assets/scene.glb` | the 3D scene + character |

## Credits

Character &amp; stage model provided for this project. All original code is
released here for private use.