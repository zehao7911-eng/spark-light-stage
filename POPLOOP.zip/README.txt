POPLOOP

Tap a bubble to start a chain. Golden bubbles have a larger blast and double points. Three tap charges refill automatically; a ten-bubble chain grants an extra charge. New bubbles refill after the chain ends. The music button enables ascending synthesized notes. Restart clears this round while preserving your best score on this device. The color button cycles three palettes.

All visuals are rendered in p5.js. No images, external CDNs, accounts or paid services are required. Upload the folder contents with index.html at the root to a static HTTPS host, or run node serve.cjs and open http://127.0.0.1:4210/.

Portrait touch layout and chain scoring were checked in a desktop browser viewport. Real iOS/Android hardware and Appai have not been tested. Animation and audio pause in background tabs. p5.js licensing information is retained in p5.min.js (LGPL-2.1).
