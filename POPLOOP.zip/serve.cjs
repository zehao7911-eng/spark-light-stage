const http=require('http'),fs=require('fs'),path=require('path');const root=__dirname;http.createServer((req,res)=>{const p=path.resolve(root,'.'+(req.url.split('?')[0]==='/'?'/index.html':req.url.split('?')[0]));if(!p.startsWith(root+path.sep)){res.writeHead(403);return res.end()}fs.readFile(p,(e,b)=>{if(e){res.writeHead(404);return res.end()}res.setHeader('Content-Type',({'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css'})[path.extname(p)]||'application/octet-stream');res.end(b)})}).listen(4210,'127.0.0.1',()=>console.log('http://127.0.0.1:4210'));


