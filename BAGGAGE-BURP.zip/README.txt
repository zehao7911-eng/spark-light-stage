STITCH: BAGGAGE BURP
Unofficial, non-commercial fan game. Stitch belongs to Disney.
All geometry, game code and synthesized audio in this project are original.

Open index.html directly. No server, account or network is required.
Drag on the floor to move and gulp nearby luggage. Lift to spit it into the closest available cart.
Eight bags make a SUPER BURP that knocks more cones over. Fill three carts to clear a flight.
No countdown, lives or paid items. A new flight starts after each clear.
Stars: complete the flight; launch at least one full load; finish in at most ceil(total/8)+1 burps.
Flights increase from 18 to 30 bags; three terminal background palettes rotate.
Earn 3 stars for a hibiscus, 6 for a pilot cap and 9 for a Hawaiian shirt. Earned outfits appear on the next flight.
Completed flights, collected stars, best load and sound preference are saved locally when permitted.
Cancelling a gesture or pausing keeps swallowed bags and does not launch them.
Touch: hold and drag; lift to fire. The BURP button also launches a held load.
Keyboard: arrows/WASD move and gulp; hold Space to gulp, release Space to launch; Escape pauses.
If WebGL is unavailable or lost, use Retry in a current browser.

Built with bundled Three.js r147, MIT license included in THREE-LICENSE.txt.
Phone-oriented layout, capped pixel ratio 1.5, batched geometry, bounded particles and voices.
No generated imagery, external CDN, commercial model or commercial audio is included.
